// src/ui/approval.ts
var root = document.querySelector("#app");
var id = new URL(location.href).searchParams.get("id") ?? "";
void load();
async function load() {
  try {
    const [response, statusResponse] = await Promise.all([chrome.runtime.sendMessage({ kind: "approval", command: "get", id }), chrome.runtime.sendMessage({ channel: "wallet", command: "status" })]);
    if (response?.error) throw new Error(response.error.message);
    if (statusResponse?.error) throw new Error(statusResponse.error.message);
    const item = response.result;
    if (statusResponse.result?.locked) {
      renderUnlock(item);
      return;
    }
    renderApproval(item);
  } catch (error) {
    renderError(error);
  }
}
function renderUnlock(item) {
  root.innerHTML = `<main><p class="eyebrow">DAPP CONNECTION</p><h1>Unlock Kaspire</h1><section><h2>${esc(item.origin)}</h2><p>This site is waiting to connect. Unlock your wallet before reviewing the request.</p><label>Wallet password<span style="display:flex;gap:8px"><input id="password" type="password" autocomplete="current-password" autofocus><button id="reveal-password" type="button" aria-label="Show password">\u25C9</button></span></label><p id="unlock-error" class="error"></p></section><div class="actions"><button id="cancel" class="ghost">CANCEL</button><button id="unlock">UNLOCK</button></div><p class="note">Unlocking does not connect the site. You will review and approve the connection next.</p></main>`;
  const password = document.querySelector("#password"), button = document.querySelector("#unlock"), error = document.querySelector("#unlock-error");
  const unlock = async () => {
    button.disabled = true;
    error.textContent = "";
    try {
      const response = await chrome.runtime.sendMessage({ channel: "wallet", command: "unlock", password: password.value });
      if (response?.error) throw new Error(response.error.message);
      renderApproval(item);
    } catch (caught) {
      error.textContent = caught.message;
      password.select();
      button.disabled = false;
    }
  };
  document.querySelector("#cancel").onclick = () => resolve(false);
  document.querySelector("#reveal-password").onclick = (event) => {
    const reveal = event.currentTarget, show = password.type === "password";
    password.type = show ? "text" : "password";
    reveal.textContent = show ? "\u25CE" : "\u25C9";
    password.focus();
  };
  button.onclick = unlock;
  password.onkeydown = (event) => {
    if (event.key === "Enter") void unlock();
  };
  password.focus();
}
function renderApproval(item) {
  root.innerHTML = `<main><p class="eyebrow">SECURE APPROVAL</p><h1>${esc(item.title)}</h1><section><h2>${esc(item.origin)}</h2><p>${esc(item.description)}</p>${item.details.map((detail) => `<p>${esc(detail)}</p>`).join("")}${item.rawJson != null ? `<details class="raw-json"><summary>Raw JSON output</summary><pre>${esc(JSON.stringify(item.rawJson, (_key, value) => typeof value === "bigint" ? String(value) : value, 2))}</pre></details>` : ""}</section><div class="actions"><button id="reject" class="ghost">REJECT</button><button id="approve">APPROVE</button></div><p class="note">Verify the site and every detail. Kaspire never signs silently.</p></main>`;
  document.querySelector("#reject").onclick = () => resolve(false);
  document.querySelector("#approve").onclick = () => resolve(true);
}
function renderError(error) {
  root.innerHTML = `<main><h1>Request unavailable</h1><p class="error">${esc(error.message)}</p></main>`;
}
async function resolve(approved) {
  await chrome.runtime.sendMessage({ kind: "approval", command: "resolve", id, approved });
  close();
}
function esc(value) {
  const node = document.createElement("span");
  node.textContent = value;
  return node.innerHTML;
}
//# sourceMappingURL=approval.js.map
