// src/shared/protocol.ts
var PROVIDER_CHANNEL = "kaspire:provider:v1";
var providerMethods = ["requestAccounts", "getAccounts", "getNetwork", "switchNetwork", "getPublicKey", "getBalance", "getUtxoEntries", "disconnect", "signMessage", "sendKaspa", "sendKRC20", "sendKCC20", "signPskt", "pushTx", "signPolicyTransaction", "transferKRC721", "transferKNS"];
function isProviderRequest(value) {
  if (!value || typeof value !== "object") return false;
  const item = value;
  if (item.channel !== PROVIDER_CHANNEL || item.direction !== "request" || typeof item.id !== "string" || item.id.length < 1 || item.id.length > 128 || !providerMethods.includes(item.method)) return false;
  try {
    return JSON.stringify(value).length <= 1048576;
  } catch {
    return false;
  }
}

// src/content/index.ts
var script = document.createElement("script");
script.src = chrome.runtime.getURL("inpage.js");
script.async = false;
(document.head || document.documentElement).appendChild(script);
script.remove();
addEventListener("message", async (event) => {
  if (event.source !== window || event.origin !== location.origin || !isProviderRequest(event.data)) return;
  const request = event.data;
  let response;
  try {
    const result = await chrome.runtime.sendMessage({ kind: "provider", origin: location.origin, request });
    response = { channel: PROVIDER_CHANNEL, direction: "response", id: request.id, ...result };
  } catch {
    response = { channel: PROVIDER_CHANNEL, direction: "response", id: request.id, error: { code: -32603, message: "Kaspire could not process this request." } };
  }
  postMessage(response, location.origin);
});
chrome.runtime.onMessage.addListener((message) => {
  if (message?.kind !== "providerStateChanged") return;
  const previous = message.previous ?? {};
  const current = message.current ?? {};
  const wasConnected = previous.permissions?.[location.origin]?.accounts === true;
  const connected = current.permissions?.[location.origin]?.accounts === true;
  const emit = (event, data) => postMessage({ channel: PROVIDER_CHANNEL, direction: "event", event, data }, location.origin);
  if (wasConnected && !connected) {
    emit("accountsChanged", []);
    emit("disconnect", { code: 4900, message: "Kaspire disconnected this site." });
    return;
  }
  if (!connected) return;
  if (!wasConnected || previous.selectedAddress !== current.selectedAddress) emit("accountsChanged", current.selectedAddress ? [current.selectedAddress] : []);
  if (previous.network !== current.network) emit("networkChanged", current.network);
});
//# sourceMappingURL=content.js.map
