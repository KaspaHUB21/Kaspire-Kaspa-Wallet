// src/ui/popup.ts
var root = document.querySelector("#app");
void (async () => {
  const status = await chrome.runtime.sendMessage({ channel: "wallet", command: "status" });
  const state = status.result;
  const network = state?.network === "testnet-10" ? "TN10" : "MAINNET";
  root.innerHTML = `<header><b>KASPIRE</b><span>\u25CF ${network}</span></header><main><p class="eyebrow">KASPIRE BROWSER WALLET</p><h1>Your Kaspa universe.<br>One secure wallet.</h1><section><h2>${state?.locked ? "Wallet locked" : "Wallet ready"}</h2><p>${state?.selectedAddress ? `${state.addresses.length} addresses \xB7 ${state.selectedAddress.slice(0, 12)}\u2026` : "Create or restore a secure wallet to begin."}</p></section><button id="open">OPEN WALLET</button><p class="note">dApp connections and personal signatures require an explicit Kaspire approval window.</p></main>`;
  document.querySelector("#open")?.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("wallet.html") }));
})();
//# sourceMappingURL=popup.js.map
