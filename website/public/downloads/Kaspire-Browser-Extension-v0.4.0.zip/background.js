var __defProp = Object.defineProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/background/state.ts
var defaults = { version: 2, network: "mainnet", selectedAddress: null, addresses: [], permissions: {}, contacts: [], settings: { autoLockMinutes: 15, hideBalances: false, currency: "USD", uppercase: true, theme: "midnight", showSubwallets: true, recipientAllowlist: false }, locked: true, recoveryVerified: true };
async function loadState() {
  const { walletState } = await chrome.storage.local.get("walletState");
  if (walletState?.version === 2) return { ...defaults, ...walletState, settings: { ...defaults.settings, ...walletState.settings }, locked: true };
  return { ...defaults };
}
async function saveState(state) {
  const { walletState: previous } = await chrome.storage.local.get("walletState");
  const current = { ...state, locked: true };
  await chrome.storage.local.set({ walletState: current });
  void chrome.tabs.query({}).then((tabs) => Promise.all(tabs.flatMap((tab) => tab.id === void 0 ? [] : [chrome.tabs.sendMessage(tab.id, { kind: "providerStateChanged", previous: previous ?? null, current }).catch(() => void 0)])));
}

// generated/wasm/kaspa_secure_core.js
var kaspa_secure_core_exports = {};
__export(kaspa_secure_core_exports, {
  Abortable: () => Abortable,
  Aborted: () => Aborted,
  Address: () => Address,
  AddressVersion: () => AddressVersion,
  Hash: () => Hash,
  Language: () => Language,
  Mnemonic: () => Mnemonic,
  NetworkId: () => NetworkId,
  NetworkType: () => NetworkType,
  ScriptPublicKey: () => ScriptPublicKey,
  SigHashType: () => SigHashType,
  TransactionUtxoEntry: () => TransactionUtxoEntry,
  addressWithPrefix: () => addressWithPrefix,
  default: () => kaspa_secure_core_default,
  defer: () => defer,
  deriveAddressRange: () => deriveAddressRange,
  deriveBackupKey: () => deriveBackupKey,
  deriveEvmAddress: () => deriveEvmAddress,
  exportPrivateKey: () => exportPrivateKey,
  generateWallet: () => generateWallet,
  generateWalletWithWordCount: () => generateWalletWithWordCount,
  importPrivateKey: () => importPrivateKey,
  importWallet: () => importWallet,
  initBrowserPanicHook: () => initBrowserPanicHook,
  initConsolePanicHook: () => initConsolePanicHook,
  initSync: () => initSync,
  initWASM32Bindings: () => initWASM32Bindings,
  mnemonicWordStatus: () => mnemonicWordStatus,
  prepareEvmTransaction: () => prepareEvmTransaction,
  prepareInscription: () => prepareInscription,
  prepareKcc20Transfer: () => prepareKcc20Transfer,
  preparePolicyTransaction: () => preparePolicyTransaction,
  preparePskt: () => preparePskt,
  prepareReveal: () => prepareReveal,
  prepareTransaction: () => prepareTransaction,
  presentPanicHookLogs: () => presentPanicHookLogs,
  publicKey: () => publicKey,
  setLogLevel: () => setLogLevel,
  signEvmTransaction: () => signEvmTransaction,
  signKcc20Transfer: () => signKcc20Transfer,
  signPersonalMessage: () => signPersonalMessage,
  signPolicyTransaction: () => signPolicyTransaction,
  signPskt: () => signPskt,
  signReveal: () => signReveal,
  signTransaction: () => signTransaction
});
var wasm;
function addToExternrefTable0(obj) {
  const idx = wasm.__externref_table_alloc();
  wasm.__wbindgen_export_2.set(idx, obj);
  return idx;
}
function handleError(f, args) {
  try {
    return f.apply(this, args);
  } catch (e) {
    const idx = addToExternrefTable0(e);
    wasm.__wbindgen_exn_store(idx);
  }
}
function isLikeNone(x) {
  return x === void 0 || x === null;
}
var cachedTextDecoder = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { ignoreBOM: true, fatal: true }) : { decode: () => {
  throw Error("TextDecoder not available");
} };
if (typeof TextDecoder !== "undefined") {
  cachedTextDecoder.decode();
}
var cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
  if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
    cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
  }
  return cachedUint8ArrayMemory0;
}
function getStringFromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}
var WASM_VECTOR_LEN = 0;
var cachedTextEncoder = typeof TextEncoder !== "undefined" ? new TextEncoder("utf-8") : { encode: () => {
  throw Error("TextEncoder not available");
} };
var encodeString = typeof cachedTextEncoder.encodeInto === "function" ? function(arg, view) {
  return cachedTextEncoder.encodeInto(arg, view);
} : function(arg, view) {
  const buf = cachedTextEncoder.encode(arg);
  view.set(buf);
  return {
    read: arg.length,
    written: buf.length
  };
};
function passStringToWasm0(arg, malloc, realloc) {
  if (realloc === void 0) {
    const buf = cachedTextEncoder.encode(arg);
    const ptr2 = malloc(buf.length, 1) >>> 0;
    getUint8ArrayMemory0().subarray(ptr2, ptr2 + buf.length).set(buf);
    WASM_VECTOR_LEN = buf.length;
    return ptr2;
  }
  let len = arg.length;
  let ptr = malloc(len, 1) >>> 0;
  const mem = getUint8ArrayMemory0();
  let offset = 0;
  for (; offset < len; offset++) {
    const code = arg.charCodeAt(offset);
    if (code > 127) break;
    mem[ptr + offset] = code;
  }
  if (offset !== len) {
    if (offset !== 0) {
      arg = arg.slice(offset);
    }
    ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
    const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
    const ret = encodeString(arg, view);
    offset += ret.written;
    ptr = realloc(ptr, len, offset, 1) >>> 0;
  }
  WASM_VECTOR_LEN = offset;
  return ptr;
}
var cachedDataViewMemory0 = null;
function getDataViewMemory0() {
  if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || cachedDataViewMemory0.buffer.detached === void 0 && cachedDataViewMemory0.buffer !== wasm.memory.buffer) {
    cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
  }
  return cachedDataViewMemory0;
}
function debugString(val) {
  const type = typeof val;
  if (type == "number" || type == "boolean" || val == null) {
    return `${val}`;
  }
  if (type == "string") {
    return `"${val}"`;
  }
  if (type == "symbol") {
    const description = val.description;
    if (description == null) {
      return "Symbol";
    } else {
      return `Symbol(${description})`;
    }
  }
  if (type == "function") {
    const name = val.name;
    if (typeof name == "string" && name.length > 0) {
      return `Function(${name})`;
    } else {
      return "Function";
    }
  }
  if (Array.isArray(val)) {
    const length = val.length;
    let debug = "[";
    if (length > 0) {
      debug += debugString(val[0]);
    }
    for (let i = 1; i < length; i++) {
      debug += ", " + debugString(val[i]);
    }
    debug += "]";
    return debug;
  }
  const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
  let className;
  if (builtInMatches && builtInMatches.length > 1) {
    className = builtInMatches[1];
  } else {
    return toString.call(val);
  }
  if (className == "Object") {
    try {
      return "Object(" + JSON.stringify(val) + ")";
    } catch (_) {
      return "Object";
    }
  }
  if (val instanceof Error) {
    return `${val.name}: ${val.message}
${val.stack}`;
  }
  return className;
}
function takeFromExternrefTable0(idx) {
  const value = wasm.__wbindgen_export_2.get(idx);
  wasm.__externref_table_dealloc(idx);
  return value;
}
function generateWallet(passphrase) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(passphrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.generateWallet(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function prepareKcc20Transfer(request2) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.prepareKcc20Transfer(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function signKcc20Transfer(secret, request2, review_hash) {
  let deferred5_0;
  let deferred5_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(review_hash, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.signKcc20Transfer(ptr0, len0, ptr1, len1, ptr2, len2);
    var ptr4 = ret[0];
    var len4 = ret[1];
    if (ret[3]) {
      ptr4 = 0;
      len4 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred5_0 = ptr4;
    deferred5_1 = len4;
    return getStringFromWasm0(ptr4, len4);
  } finally {
    wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
  }
}
function preparePolicyTransaction(request2) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.preparePolicyTransaction(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function signPolicyTransaction(secret, request2, review_hash) {
  let deferred5_0;
  let deferred5_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(review_hash, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.signPolicyTransaction(ptr0, len0, ptr1, len1, ptr2, len2);
    var ptr4 = ret[0];
    var len4 = ret[1];
    if (ret[3]) {
      ptr4 = 0;
      len4 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred5_0 = ptr4;
    deferred5_1 = len4;
    return getStringFromWasm0(ptr4, len4);
  } finally {
    wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
  }
}
function generateWalletWithWordCount(passphrase, word_count) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(passphrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.generateWalletWithWordCount(ptr0, len0, word_count);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function importWallet(phrase, passphrase) {
  let deferred4_0;
  let deferred4_1;
  try {
    const ptr0 = passStringToWasm0(phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(passphrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.importWallet(ptr0, len0, ptr1, len1);
    var ptr3 = ret[0];
    var len3 = ret[1];
    if (ret[3]) {
      ptr3 = 0;
      len3 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred4_0 = ptr3;
    deferred4_1 = len3;
    return getStringFromWasm0(ptr3, len3);
  } finally {
    wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
  }
}
function publicKey(secret) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.publicKey(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function prepareTransaction(request2) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.prepareTransaction(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function signTransaction(secret, request2, review_hash) {
  let deferred5_0;
  let deferred5_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(review_hash, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.signTransaction(ptr0, len0, ptr1, len1, ptr2, len2);
    var ptr4 = ret[0];
    var len4 = ret[1];
    if (ret[3]) {
      ptr4 = 0;
      len4 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred5_0 = ptr4;
    deferred5_1 = len4;
    return getStringFromWasm0(ptr4, len4);
  } finally {
    wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
  }
}
function signPersonalMessage(secret, address, message) {
  let deferred5_0;
  let deferred5_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(message, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.signPersonalMessage(ptr0, len0, ptr1, len1, ptr2, len2);
    var ptr4 = ret[0];
    var len4 = ret[1];
    if (ret[3]) {
      ptr4 = 0;
      len4 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred5_0 = ptr4;
    deferred5_1 = len4;
    return getStringFromWasm0(ptr4, len4);
  } finally {
    wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
  }
}
function preparePskt(request2) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.preparePskt(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function signPskt(secret, request2, review_hash) {
  let deferred5_0;
  let deferred5_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(review_hash, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.signPskt(ptr0, len0, ptr1, len1, ptr2, len2);
    var ptr4 = ret[0];
    var len4 = ret[1];
    if (ret[3]) {
      ptr4 = 0;
      len4 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred5_0 = ptr4;
    deferred5_1 = len4;
    return getStringFromWasm0(ptr4, len4);
  } finally {
    wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
  }
}
function prepareInscription(request2) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.prepareInscription(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function prepareReveal(request2) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.prepareReveal(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function signReveal(secret, request2, review_hash) {
  let deferred5_0;
  let deferred5_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(review_hash, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.signReveal(ptr0, len0, ptr1, len1, ptr2, len2);
    var ptr4 = ret[0];
    var len4 = ret[1];
    if (ret[3]) {
      ptr4 = 0;
      len4 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred5_0 = ptr4;
    deferred5_1 = len4;
    return getStringFromWasm0(ptr4, len4);
  } finally {
    wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
  }
}
function mnemonicWordStatus(phrase) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.mnemonicWordStatus(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function importPrivateKey(value) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.importPrivateKey(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function deriveBackupKey(password, salt_hex) {
  let deferred4_0;
  let deferred4_1;
  try {
    const ptr0 = passStringToWasm0(password, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(salt_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.deriveBackupKey(ptr0, len0, ptr1, len1);
    var ptr3 = ret[0];
    var len3 = ret[1];
    if (ret[3]) {
      ptr3 = 0;
      len3 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred4_0 = ptr3;
    deferred4_1 = len3;
    return getStringFromWasm0(ptr3, len3);
  } finally {
    wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
  }
}
function deriveAddressRange(secret, coin_type, account, change, start, count) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.deriveAddressRange(ptr0, len0, coin_type, account, change, start, count);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function addressWithPrefix(address, testnet) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.addressWithPrefix(ptr0, len0, testnet);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function deriveEvmAddress(secret) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.deriveEvmAddress(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function prepareEvmTransaction(request2) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.prepareEvmTransaction(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function signEvmTransaction(secret, request2, review_hash) {
  let deferred5_0;
  let deferred5_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(request2, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(review_hash, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.signEvmTransaction(ptr0, len0, ptr1, len1, ptr2, len2);
    var ptr4 = ret[0];
    var len4 = ret[1];
    if (ret[3]) {
      ptr4 = 0;
      len4 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred5_0 = ptr4;
    deferred5_1 = len4;
    return getStringFromWasm0(ptr4, len4);
  } finally {
    wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
  }
}
function exportPrivateKey(secret) {
  let deferred3_0;
  let deferred3_1;
  try {
    const ptr0 = passStringToWasm0(secret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.exportPrivateKey(ptr0, len0);
    var ptr2 = ret[0];
    var len2 = ret[1];
    if (ret[3]) {
      ptr2 = 0;
      len2 = 0;
      throw takeFromExternrefTable0(ret[2]);
    }
    deferred3_0 = ptr2;
    deferred3_1 = len2;
    return getStringFromWasm0(ptr2, len2);
  } finally {
    wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
  }
}
function _assertClass(instance, klass) {
  if (!(instance instanceof klass)) {
    throw new Error(`expected instance of ${klass.name}`);
  }
}
function defer() {
  const ret = wasm.defer();
  return ret;
}
function initConsolePanicHook() {
  wasm.initConsolePanicHook();
}
function initBrowserPanicHook() {
  wasm.initBrowserPanicHook();
}
function presentPanicHookLogs() {
  wasm.presentPanicHookLogs();
}
function initWASM32Bindings(config) {
  const ret = wasm.initWASM32Bindings(config);
  if (ret[1]) {
    throw takeFromExternrefTable0(ret[0]);
  }
}
function setLogLevel(level) {
  wasm.setLogLevel(level);
}
var AddressVersion = Object.freeze({
  /**
   * PubKey addresses always have the version byte set to 0
   */
  PubKey: 0,
  "0": "PubKey",
  /**
   * PubKey ECDSA addresses always have the version byte set to 1
   */
  PubKeyECDSA: 1,
  "1": "PubKeyECDSA",
  /**
   * ScriptHash addresses always have the version byte set to 8
   */
  ScriptHash: 8,
  "8": "ScriptHash"
});
var Language = Object.freeze({
  /**
   * English is presently the only supported language
   */
  English: 0,
  "0": "English"
});
var NetworkType = Object.freeze({
  Mainnet: 0,
  "0": "Mainnet",
  Testnet: 1,
  "1": "Testnet",
  Devnet: 2,
  "2": "Devnet",
  Simnet: 3,
  "3": "Simnet"
});
var AbortableFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_abortable_free(ptr >>> 0, 1));
var Abortable = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AbortableFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_abortable_free(ptr, 0);
  }
  /**
   * @returns {boolean}
   */
  isAborted() {
    const ret = wasm.abortable_isAborted(this.__wbg_ptr);
    return ret !== 0;
  }
  constructor() {
    const ret = wasm.abortable_new();
    this.__wbg_ptr = ret >>> 0;
    AbortableFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  abort() {
    wasm.abortable_abort(this.__wbg_ptr);
  }
  check() {
    const ret = wasm.abortable_check(this.__wbg_ptr);
    if (ret[1]) {
      throw takeFromExternrefTable0(ret[0]);
    }
  }
  reset() {
    wasm.abortable_reset(this.__wbg_ptr);
  }
};
var AbortedFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_aborted_free(ptr >>> 0, 1));
var Aborted = class _Aborted {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Aborted.prototype);
    obj.__wbg_ptr = ptr;
    AbortedFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AbortedFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_aborted_free(ptr, 0);
  }
};
var AddressFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_address_free(ptr >>> 0, 1));
var Address = class {
  toJSON() {
    return {
      prefix: this.prefix,
      payload: this.payload,
      version: this.version
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AddressFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_address_free(ptr, 0);
  }
  /**
   * @param {string} address
   */
  constructor(address) {
    const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.address_constructor(ptr0, len0);
    this.__wbg_ptr = ret >>> 0;
    AddressFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {string}
   */
  get prefix() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.address_prefix(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Convert an address to a string.
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.address_toString(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get payload() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.address_payload(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get version() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.address_version(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {string} prefix
   */
  set setPrefix(prefix) {
    const ptr0 = passStringToWasm0(prefix, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    wasm.address_set_setPrefix(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @param {string} address
   * @returns {boolean}
   */
  static validate(address) {
    const ptr0 = passStringToWasm0(address, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.address_validate(ptr0, len0);
    return ret !== 0;
  }
};
var HashFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_hash_free(ptr >>> 0, 1));
var Hash = class _Hash {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Hash.prototype);
    obj.__wbg_ptr = ptr;
    HashFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    HashFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_hash_free(ptr, 0);
  }
  /**
   * @param {string} hex_str
   */
  constructor(hex_str) {
    const ptr0 = passStringToWasm0(hex_str, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.hash_constructor(ptr0, len0);
    this.__wbg_ptr = ret >>> 0;
    HashFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.hash_toString(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
};
var MnemonicFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_mnemonic_free(ptr >>> 0, 1));
var Mnemonic = class _Mnemonic {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Mnemonic.prototype);
    obj.__wbg_ptr = ptr;
    MnemonicFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      entropy: this.entropy,
      phrase: this.phrase
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    MnemonicFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_mnemonic_free(ptr, 0);
  }
  /**
   * @param {string} phrase
   */
  set phrase(phrase) {
    const ptr0 = passStringToWasm0(phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    wasm.mnemonic_set_phrase(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @param {string} phrase
   * @param {Language | null} [language]
   */
  constructor(phrase, language) {
    const ptr0 = passStringToWasm0(phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.mnemonic_constructor(ptr0, len0, isLikeNone(language) ? 1 : language);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    this.__wbg_ptr = ret[0] >>> 0;
    MnemonicFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @param {string | null} [password]
   * @returns {string}
   */
  toSeed(password) {
    let deferred2_0;
    let deferred2_1;
    try {
      var ptr0 = isLikeNone(password) ? 0 : passStringToWasm0(password, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len0 = WASM_VECTOR_LEN;
      const ret = wasm.mnemonic_toSeed(this.__wbg_ptr, ptr0, len0);
      deferred2_0 = ret[0];
      deferred2_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get entropy() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.mnemonic_entropy(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {string} entropy
   */
  set entropy(entropy) {
    const ptr0 = passStringToWasm0(entropy, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    wasm.mnemonic_set_entropy(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @returns {string}
   */
  get phrase() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.mnemonic_phrase(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {number | null} [word_count]
   * @returns {Mnemonic}
   */
  static random(word_count) {
    const ret = wasm.mnemonic_random(isLikeNone(word_count) ? 4294967297 : word_count >>> 0);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    return _Mnemonic.__wrap(ret[0]);
  }
  /**
   * Validate mnemonic phrase. Returns `true` if the phrase is valid, `false` otherwise.
   * @param {string} phrase
   * @param {Language | null} [language]
   * @returns {boolean}
   */
  static validate(phrase, language) {
    const ptr0 = passStringToWasm0(phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.mnemonic_validate(ptr0, len0, isLikeNone(language) ? 1 : language);
    return ret !== 0;
  }
};
var NetworkIdFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_networkid_free(ptr >>> 0, 1));
var NetworkId = class {
  toJSON() {
    return {
      type: this.type,
      suffix: this.suffix,
      id: this.id
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    NetworkIdFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_networkid_free(ptr, 0);
  }
  /**
   * @returns {NetworkType}
   */
  get type() {
    const ret = wasm.__wbg_get_networkid_type(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {NetworkType} arg0
   */
  set type(arg0) {
    wasm.__wbg_set_networkid_type(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {number | undefined}
   */
  get suffix() {
    const ret = wasm.__wbg_get_networkid_suffix(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @param {number | null} [arg0]
   */
  set suffix(arg0) {
    wasm.__wbg_set_networkid_suffix(this.__wbg_ptr, isLikeNone(arg0) ? 4294967297 : arg0 >>> 0);
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.networkid_toString(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  addressPrefix() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.networkid_addressPrefix(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {any} value
   */
  constructor(value) {
    const ret = wasm.networkid_ctor(value);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    this.__wbg_ptr = ret[0] >>> 0;
    NetworkIdFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {string}
   */
  get id() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.networkid_id(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
};
var ScriptPublicKeyFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_scriptpublickey_free(ptr >>> 0, 1));
var ScriptPublicKey = class _ScriptPublicKey {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_ScriptPublicKey.prototype);
    obj.__wbg_ptr = ptr;
    ScriptPublicKeyFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      version: this.version,
      script: this.script
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    ScriptPublicKeyFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_scriptpublickey_free(ptr, 0);
  }
  /**
   * @returns {number}
   */
  get version() {
    const ret = wasm.__wbg_get_scriptpublickey_version(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} arg0
   */
  set version(arg0) {
    wasm.__wbg_set_scriptpublickey_version(this.__wbg_ptr, arg0);
  }
  /**
   * @param {number} version
   * @param {any} script
   */
  constructor(version2, script) {
    const ret = wasm.scriptpublickey_constructor(version2, script);
    if (ret[2]) {
      throw takeFromExternrefTable0(ret[1]);
    }
    this.__wbg_ptr = ret[0] >>> 0;
    ScriptPublicKeyFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {string}
   */
  get script() {
    let deferred1_0;
    let deferred1_1;
    try {
      const ret = wasm.scriptpublickey_script_as_hex(this.__wbg_ptr);
      deferred1_0 = ret[0];
      deferred1_1 = ret[1];
      return getStringFromWasm0(ret[0], ret[1]);
    } finally {
      wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
  }
};
var SigHashTypeFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_sighashtype_free(ptr >>> 0, 1));
var SigHashType = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    SigHashTypeFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_sighashtype_free(ptr, 0);
  }
};
var TransactionUtxoEntryFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm.__wbg_transactionutxoentry_free(ptr >>> 0, 1));
var TransactionUtxoEntry = class {
  toJSON() {
    return {
      amount: this.amount,
      scriptPublicKey: this.scriptPublicKey,
      blockDaaScore: this.blockDaaScore,
      isCoinbase: this.isCoinbase,
      covenantId: this.covenantId
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionUtxoEntryFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm.__wbg_transactionutxoentry_free(ptr, 0);
  }
  /**
   * @returns {bigint}
   */
  get amount() {
    const ret = wasm.__wbg_get_transactionutxoentry_amount(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} arg0
   */
  set amount(arg0) {
    wasm.__wbg_set_transactionutxoentry_amount(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {ScriptPublicKey}
   */
  get scriptPublicKey() {
    const ret = wasm.__wbg_get_transactionutxoentry_scriptPublicKey(this.__wbg_ptr);
    return ScriptPublicKey.__wrap(ret);
  }
  /**
   * @param {ScriptPublicKey} arg0
   */
  set scriptPublicKey(arg0) {
    _assertClass(arg0, ScriptPublicKey);
    var ptr0 = arg0.__destroy_into_raw();
    wasm.__wbg_set_transactionutxoentry_scriptPublicKey(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {bigint}
   */
  get blockDaaScore() {
    const ret = wasm.__wbg_get_transactionutxoentry_blockDaaScore(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} arg0
   */
  set blockDaaScore(arg0) {
    wasm.__wbg_set_transactionutxoentry_blockDaaScore(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {boolean}
   */
  get isCoinbase() {
    const ret = wasm.__wbg_get_transactionutxoentry_isCoinbase(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @param {boolean} arg0
   */
  set isCoinbase(arg0) {
    wasm.__wbg_set_transactionutxoentry_isCoinbase(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {Hash | undefined}
   */
  get covenantId() {
    const ret = wasm.__wbg_get_transactionutxoentry_covenantId(this.__wbg_ptr);
    return ret === 0 ? void 0 : Hash.__wrap(ret);
  }
  /**
   * @param {Hash | null} [arg0]
   */
  set covenantId(arg0) {
    let ptr0 = 0;
    if (!isLikeNone(arg0)) {
      _assertClass(arg0, Hash);
      ptr0 = arg0.__destroy_into_raw();
    }
    wasm.__wbg_set_transactionutxoentry_covenantId(this.__wbg_ptr, ptr0);
  }
};
async function __wbg_load(module2, imports) {
  if (typeof Response === "function" && module2 instanceof Response) {
    if (typeof WebAssembly.instantiateStreaming === "function") {
      try {
        return await WebAssembly.instantiateStreaming(module2, imports);
      } catch (e) {
        if (module2.headers.get("Content-Type") != "application/wasm") {
          console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
        } else {
          throw e;
        }
      }
    }
    const bytes2 = await module2.arrayBuffer();
    return await WebAssembly.instantiate(bytes2, imports);
  } else {
    const instance = await WebAssembly.instantiate(module2, imports);
    if (instance instanceof WebAssembly.Instance) {
      return { instance, module: module2 };
    } else {
      return instance;
    }
  }
}
function __wbg_get_imports() {
  const imports = {};
  imports.wbg = {};
  imports.wbg.__wbg_aborted_new = function(arg0) {
    const ret = Aborted.__wrap(arg0);
    return ret;
  };
  imports.wbg.__wbg_appendChild_8204974b7328bf98 = function() {
    return handleError(function(arg0, arg1) {
      const ret = arg0.appendChild(arg1);
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_body_942ea927546a04ba = function(arg0) {
    const ret = arg0.body;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
  };
  imports.wbg.__wbg_buffer_609cc3eee51ed158 = function(arg0) {
    const ret = arg0.buffer;
    return ret;
  };
  imports.wbg.__wbg_call_672a4d21634d4a24 = function() {
    return handleError(function(arg0, arg1) {
      const ret = arg0.call(arg1);
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_call_7cccdd69e0791ae2 = function() {
    return handleError(function(arg0, arg1, arg2) {
      const ret = arg0.call(arg1, arg2);
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_createElement_8c9931a732ee2fea = function() {
    return handleError(function(arg0, arg1, arg2) {
      const ret = arg0.createElement(getStringFromWasm0(arg1, arg2));
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_crypto_86f2631e91b51511 = function(arg0) {
    const ret = arg0.crypto;
    return ret;
  };
  imports.wbg.__wbg_document_d249400bd7bd996d = function(arg0) {
    const ret = arg0.document;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
  };
  imports.wbg.__wbg_error_5edc95999c70d386 = function(arg0, arg1) {
    let deferred0_0;
    let deferred0_1;
    try {
      deferred0_0 = arg0;
      deferred0_1 = arg1;
      console.error(getStringFromWasm0(arg0, arg1));
    } finally {
      wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
    }
  };
  imports.wbg.__wbg_getRandomValues_b3f15fcbfabb0f8b = function() {
    return handleError(function(arg0, arg1) {
      arg0.getRandomValues(arg1);
    }, arguments);
  };
  imports.wbg.__wbg_get_67b2ba62fc30de12 = function() {
    return handleError(function(arg0, arg1) {
      const ret = Reflect.get(arg0, arg1);
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_innerHTML_e1553352fe93921a = function(arg0, arg1) {
    const ret = arg1.innerHTML;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbg_instanceof_Window_def73ea0955fc569 = function(arg0) {
    let result;
    try {
      result = arg0 instanceof Window;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  };
  imports.wbg.__wbg_length_a446193dc22c12f8 = function(arg0) {
    const ret = arg0.length;
    return ret;
  };
  imports.wbg.__wbg_msCrypto_d562bbe83e0d4b91 = function(arg0) {
    const ret = arg0.msCrypto;
    return ret;
  };
  imports.wbg.__wbg_new_a12002a7f91c75be = function(arg0) {
    const ret = new Uint8Array(arg0);
    return ret;
  };
  imports.wbg.__wbg_new_f5f8a7325e1cb479 = function() {
    const ret = new Error();
    return ret;
  };
  imports.wbg.__wbg_newnoargs_105ed471475aaf50 = function(arg0, arg1) {
    const ret = new Function(getStringFromWasm0(arg0, arg1));
    return ret;
  };
  imports.wbg.__wbg_newwithbyteoffsetandlength_d97e637ebe145a9a = function(arg0, arg1, arg2) {
    const ret = new Uint8Array(arg0, arg1 >>> 0, arg2 >>> 0);
    return ret;
  };
  imports.wbg.__wbg_newwithlength_a381634e90c276d4 = function(arg0) {
    const ret = new Uint8Array(arg0 >>> 0);
    return ret;
  };
  imports.wbg.__wbg_node_e1f24f89a7336c2e = function(arg0) {
    const ret = arg0.node;
    return ret;
  };
  imports.wbg.__wbg_process_3975fd6c72f520aa = function(arg0) {
    const ret = arg0.process;
    return ret;
  };
  imports.wbg.__wbg_randomFillSync_f8c153b79f285817 = function() {
    return handleError(function(arg0, arg1) {
      arg0.randomFillSync(arg1);
    }, arguments);
  };
  imports.wbg.__wbg_removeAttribute_e419cd6726b4c62f = function() {
    return handleError(function(arg0, arg1, arg2) {
      arg0.removeAttribute(getStringFromWasm0(arg1, arg2));
    }, arguments);
  };
  imports.wbg.__wbg_require_b74f47fc2d022fd6 = function() {
    return handleError(function() {
      const ret = module.require;
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_setAttribute_2704501201f15687 = function() {
    return handleError(function(arg0, arg1, arg2, arg3, arg4) {
      arg0.setAttribute(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
    }, arguments);
  };
  imports.wbg.__wbg_set_65595bdd868b3009 = function(arg0, arg1, arg2) {
    arg0.set(arg1, arg2 >>> 0);
  };
  imports.wbg.__wbg_setinnerHTML_31bde41f835786f7 = function(arg0, arg1, arg2) {
    arg0.innerHTML = getStringFromWasm0(arg1, arg2);
  };
  imports.wbg.__wbg_stack_c99a96ed42647c4c = function(arg0, arg1) {
    const ret = arg1.stack;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbg_static_accessor_GLOBAL_88a902d13a557d07 = function() {
    const ret = typeof global === "undefined" ? null : global;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
  };
  imports.wbg.__wbg_static_accessor_GLOBAL_THIS_56578be7e9f832b0 = function() {
    const ret = typeof globalThis === "undefined" ? null : globalThis;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
  };
  imports.wbg.__wbg_static_accessor_SELF_37c5d418e4bf5819 = function() {
    const ret = typeof self === "undefined" ? null : self;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
  };
  imports.wbg.__wbg_static_accessor_WINDOW_5de37043a91a9c40 = function() {
    const ret = typeof window === "undefined" ? null : window;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
  };
  imports.wbg.__wbg_subarray_aa9065fa9dc5df96 = function(arg0, arg1, arg2) {
    const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
    return ret;
  };
  imports.wbg.__wbg_versions_4e31226f5e8dc909 = function(arg0) {
    const ret = arg0.versions;
    return ret;
  };
  imports.wbg.__wbindgen_boolean_get = function(arg0) {
    const v = arg0;
    const ret = typeof v === "boolean" ? v ? 1 : 0 : 2;
    return ret;
  };
  imports.wbg.__wbindgen_debug_string = function(arg0, arg1) {
    const ret = debugString(arg1);
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbindgen_error_new = function(arg0, arg1) {
    const ret = new Error(getStringFromWasm0(arg0, arg1));
    return ret;
  };
  imports.wbg.__wbindgen_init_externref_table = function() {
    const table = wasm.__wbindgen_export_2;
    const offset = table.grow(4);
    table.set(0, void 0);
    table.set(offset + 0, void 0);
    table.set(offset + 1, null);
    table.set(offset + 2, true);
    table.set(offset + 3, false);
    ;
  };
  imports.wbg.__wbindgen_is_function = function(arg0) {
    const ret = typeof arg0 === "function";
    return ret;
  };
  imports.wbg.__wbindgen_is_null = function(arg0) {
    const ret = arg0 === null;
    return ret;
  };
  imports.wbg.__wbindgen_is_object = function(arg0) {
    const val = arg0;
    const ret = typeof val === "object" && val !== null;
    return ret;
  };
  imports.wbg.__wbindgen_is_string = function(arg0) {
    const ret = typeof arg0 === "string";
    return ret;
  };
  imports.wbg.__wbindgen_is_undefined = function(arg0) {
    const ret = arg0 === void 0;
    return ret;
  };
  imports.wbg.__wbindgen_memory = function() {
    const ret = wasm.memory;
    return ret;
  };
  imports.wbg.__wbindgen_number_get = function(arg0, arg1) {
    const obj = arg1;
    const ret = typeof obj === "number" ? obj : void 0;
    getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
  };
  imports.wbg.__wbindgen_string_get = function(arg0, arg1) {
    const obj = arg1;
    const ret = typeof obj === "string" ? obj : void 0;
    var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbindgen_string_new = function(arg0, arg1) {
    const ret = getStringFromWasm0(arg0, arg1);
    return ret;
  };
  imports.wbg.__wbindgen_throw = function(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
  };
  return imports;
}
function __wbg_init_memory(imports, memory) {
}
function __wbg_finalize_init(instance, module2) {
  wasm = instance.exports;
  __wbg_init.__wbindgen_wasm_module = module2;
  cachedDataViewMemory0 = null;
  cachedUint8ArrayMemory0 = null;
  wasm.__wbindgen_start();
  return wasm;
}
function initSync(module2) {
  if (wasm !== void 0) return wasm;
  if (typeof module2 !== "undefined") {
    if (Object.getPrototypeOf(module2) === Object.prototype) {
      ({ module: module2 } = module2);
    } else {
      console.warn("using deprecated parameters for `initSync()`; pass a single object instead");
    }
  }
  const imports = __wbg_get_imports();
  __wbg_init_memory(imports);
  if (!(module2 instanceof WebAssembly.Module)) {
    module2 = new WebAssembly.Module(module2);
  }
  const instance = new WebAssembly.Instance(module2, imports);
  return __wbg_finalize_init(instance, module2);
}
async function __wbg_init(module_or_path) {
  if (wasm !== void 0) return wasm;
  if (typeof module_or_path !== "undefined") {
    if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
      ({ module_or_path } = module_or_path);
    } else {
      console.warn("using deprecated parameters for the initialization function; pass a single object instead");
    }
  }
  if (typeof module_or_path === "undefined") {
    module_or_path = new URL("kaspa_secure_core_bg.wasm", import.meta.url);
  }
  const imports = __wbg_get_imports();
  if (typeof module_or_path === "string" || typeof Request === "function" && module_or_path instanceof Request || typeof URL === "function" && module_or_path instanceof URL) {
    module_or_path = fetch(module_or_path);
  }
  __wbg_init_memory(imports);
  const { instance, module: module2 } = await __wbg_load(await module_or_path, imports);
  return __wbg_finalize_init(instance, module2);
}
var kaspa_secure_core_default = __wbg_init;

// src/background/core.ts
var loading = null;
function core() {
  loading ??= (async () => {
    const wasmUrl = chrome.runtime.getURL("wasm/kaspa_secure_core_bg.wasm");
    const module2 = kaspa_secure_core_exports;
    await module2.default(wasmUrl);
    return module2;
  })();
  return loading;
}

// src/background/vault.ts
var encoder = new TextEncoder();
var decoder = new TextDecoder();
function hex(bytes2) {
  return [...bytes2].map((value) => value.toString(16).padStart(2, "0")).join("");
}
function bytes(value) {
  const result = new Uint8Array(value.length / 2);
  for (let i = 0; i < result.length; i++) result[i] = Number.parseInt(value.slice(i * 2, i * 2 + 2), 16);
  return result;
}
function b64(value) {
  let binary = "";
  for (const item of value) binary += String.fromCharCode(item);
  return btoa(binary);
}
function unb64(value) {
  return Uint8Array.from(atob(value), (item) => item.charCodeAt(0));
}
async function key(password, salt) {
  const derived = bytes((await core()).deriveBackupKey(password, hex(salt)));
  try {
    return await crypto.subtle.importKey("raw", derived, "AES-GCM", false, ["encrypt", "decrypt"]);
  } finally {
    derived.fill(0);
  }
}
async function createVault(password, payload) {
  if (password.length < 12) throw new Error("Use at least 12 password characters.");
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: encoder.encode("kaspire-extension-v2") }, await key(password, salt), encoder.encode(JSON.stringify(payload)));
  const vault = { version: 2, salt: b64(salt), iv: b64(iv), ciphertext: b64(new Uint8Array(ciphertext)) };
  await chrome.storage.local.set({ encryptedVault: vault });
}
async function unlockVault(password) {
  const { encryptedVault } = await chrome.storage.local.get("encryptedVault");
  const vault = encryptedVault;
  return decryptVault(vault, password);
}
async function decryptVault(vault, password) {
  if (!vault || vault.version !== 2) throw new Error("No encrypted Kaspire vault exists.");
  if (![vault.salt, vault.iv, vault.ciphertext].every((value) => typeof value === "string" && value.length > 0)) throw new Error("Damaged Kaspire backup.");
  try {
    const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(vault.iv), additionalData: encoder.encode("kaspire-extension-v2") }, await key(password, unb64(vault.salt)), unb64(vault.ciphertext));
    return JSON.parse(decoder.decode(plaintext));
  } catch {
    throw new Error("Incorrect password or damaged vault.");
  }
}
async function createPortableBackup(password, payload) {
  if (password.length < 12) throw new Error("Use at least 12 characters.");
  const salt = crypto.getRandomValues(new Uint8Array(32)), iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await key(password, salt), encoder.encode(JSON.stringify(payload)));
  return { format: "kaspire-backup-v2", kdf: "argon2id-v19", memoryKiB: 32768, iterations: 3, parallelism: 1, salt: b64(salt), iv: b64(iv), ciphertext: b64(new Uint8Array(ciphertext)) };
}
async function decryptPortableBackup(backup, password) {
  if (backup?.format !== "kaspire-backup-v2" || backup?.kdf !== "argon2id-v19" || backup?.memoryKiB !== 32768 || backup?.iterations !== 3 || backup?.parallelism !== 1) throw new Error("Unsupported Argon2id backup parameters.");
  const salt = unb64(backup.salt), iv = unb64(backup.iv), ciphertext = unb64(backup.ciphertext);
  if (salt.length !== 32 || iv.length !== 12 || ciphertext.length < 16) throw new Error("Damaged Kaspire backup.");
  try {
    const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, await key(password, salt), ciphertext);
    return JSON.parse(decoder.decode(plaintext));
  } catch {
    throw new Error("Incorrect password or damaged backup.");
  }
}

// src/background/api.ts
var MAINNET = "https://kaspire.kaslab.space/api";
var TN10 = "https://api-tn10.kaspa.org";
async function request(url, init = {}, timeoutMs = 12e3) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    if (!response.ok) {
      const parsed = new URL(url);
      throw new Error(
        `Network request failed (${response.status}) for ${parsed.hostname}${parsed.pathname}.`
      );
    }
    return await response.json();
  } catch (error) {
    if (error?.name === "AbortError")
      throw new Error("Live data request timed out. Try again.");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
async function get(url) {
  return request(url, { headers: { accept: "application/json" } });
}
async function post(url, body) {
  return request(url, {
    method: "POST",
    headers: { accept: "application/json", "content-type": "application/json" },
    body: JSON.stringify(body)
  });
}
function base(network) {
  return network === "mainnet" ? MAINNET : TN10;
}
async function spendingData(address, network) {
  const endpoint = base(network);
  const [utxos, estimate] = await Promise.all([
    get(`${endpoint}/addresses/${encodeURIComponent(address)}/utxos`),
    get(`${endpoint}/info/fee-estimate`)
  ]);
  if (!Array.isArray(utxos)) throw new Error("Node returned invalid UTXOs.");
  const seen = /* @__PURE__ */ new Set();
  for (const item of utxos) {
    const id = String(item?.outpoint?.transactionId ?? "");
    const index = Number(item?.outpoint?.index);
    const amount = Number(item?.utxoEntry?.amount);
    if (!/^[0-9a-f]{64}$/.test(id) || !Number.isSafeInteger(index) || index < 0 || !Number.isSafeInteger(amount) || amount <= 0 || seen.has(`${id}:${index}`))
      throw new Error("Node returned an invalid or duplicate UTXO.");
    seen.add(`${id}:${index}`);
  }
  const raw = Number(estimate?.priorityBucket?.feerate);
  if (!Number.isFinite(raw) || raw < 0 || raw > 1e8)
    throw new Error("Node returned an invalid fee estimate.");
  return { utxosJson: JSON.stringify(utxos), feeRate: Math.max(100, raw) };
}
async function walletHistory(address, network) {
  const value = await get(
    `${base(network)}/addresses/${encodeURIComponent(address)}/full-transactions?limit=50&offset=0&resolve_previous_outpoints=light`
  );
  const rows = Array.isArray(value) ? value : Array.isArray(value?.transactions) ? value.transactions : [];
  return rows.filter(
    (item) => /^[0-9a-f]{64}$/.test(
      String(item?.transaction_id ?? item?.transactionId ?? item?.id ?? "")
    )
  ).map((item) => {
    const inputs = Array.isArray(item.inputs) ? item.inputs : [], outputs = Array.isArray(item.outputs) ? item.outputs : [];
    const inputTotal = inputs.reduce(
      (sum, row) => sum + Number(row?.previous_outpoint_amount ?? 0),
      0
    ), outputTotal = outputs.reduce(
      (sum, row) => sum + Number(row?.amount ?? 0),
      0
    );
    const walletInput = inputs.filter((row) => row?.previous_outpoint_address === address).reduce(
      (sum, row) => sum + Number(row?.previous_outpoint_amount ?? 0),
      0
    ), walletOutput = outputs.filter((row) => row?.script_public_key_address === address).reduce((sum, row) => sum + Number(row?.amount ?? 0), 0);
    const incoming = walletInput === 0 && walletOutput > 0;
    const feeSompi = Math.max(0, inputTotal - outputTotal);
    const externalOutputs = outputs.filter(
      (row) => row?.script_public_key_address !== address
    );
    const amountSompi = incoming ? walletOutput : externalOutputs.reduce(
      (sum, row) => sum + Number(row?.amount ?? 0),
      0
    );
    return {
      transactionId: String(
        item.transaction_id ?? item.transactionId ?? item.id
      ),
      blockTime: Number(item.block_time ?? item.blockTime ?? 0),
      isAccepted: item.is_accepted !== false,
      incoming,
      assetKind: "KAS",
      assetSymbol: "KAS",
      amountSompi,
      displayAmount: `${amountSompi / 1e8}`,
      counterparty: incoming ? String(
        inputs.find((row) => row?.previous_outpoint_address)?.previous_outpoint_address ?? ""
      ) : String(
        externalOutputs.find((row) => row?.script_public_key_address)?.script_public_key_address ?? ""
      ),
      from: inputs.map((row) => ({
        address: String(row?.previous_outpoint_address ?? ""),
        amountSompi: Number(row?.previous_outpoint_amount ?? 0),
        ownerId: String(row?.covenant_id ?? "")
      })).filter((row) => row.address),
      to: outputs.map((row) => ({
        address: String(row?.script_public_key_address ?? ""),
        amountSompi: Number(row?.amount ?? 0),
        ownerId: String(row?.covenant_id ?? "")
      })).filter((row) => row.address),
      feeSompi,
      totalInputSompi: inputTotal,
      totalOutputSompi: outputTotal,
      inputCount: inputs.length,
      outputCount: outputs.length,
      blockDaaScore: Number(item.accepting_block_blue_score ?? 0),
      isCoinbase: inputs.length === 0,
      inputs,
      outputs,
      mass: Number(item.mass ?? 0),
      payload: String(item.payload ?? "")
    };
  });
}
async function marketPrice(currency) {
  const price = await get(`${MAINNET}/info/price`);
  const kasUsd = Number(price?.price);
  if (!Number.isFinite(kasUsd) || kasUsd < 0)
    throw new Error("Node returned an invalid market price.");
  if (currency === "USD") return { kasUsd, rate: 1, currency };
  const rates = await get("https://open.er-api.com/v6/latest/USD");
  const rate = Number(rates?.rates?.[currency]);
  if (!Number.isFinite(rate) || rate <= 0)
    throw new Error("Selected currency rate is unavailable.");
  return { kasUsd, rate, currency };
}
var marketCache = /* @__PURE__ */ new Map();
async function tokenMarket(tokenId, symbol) {
  if (!/^[a-z0-9_-]{1,128}$/i.test(tokenId) || !/^[a-z0-9_-]{1,32}$/i.test(symbol))
    throw new Error("Invalid token market request.");
  const normalized = tokenId.toLowerCase().startsWith("krc20-") ? tokenId.toLowerCase() : `krc20-${tokenId.toLowerCase()}`;
  const cached = marketCache.get(normalized);
  if (cached && Date.now() - cached.at < 3e5) return cached.value;
  const value = await get(
    `https://kaspatoken.kaslab.space/api/token/${encodeURIComponent(normalized)}`
  );
  const data = value?.data && typeof value.data === "object" ? value.data : {};
  const priceKas = Number(data.price_kas);
  const priceUsd = Number(data.price_usd);
  const result = {
    tokenId: normalized,
    symbol: symbol.toUpperCase(),
    imageUrl: typeof data.image_url === "string" ? new URL(data.image_url, "https://kaspatoken.kaslab.space").href : "",
    priceKas: Number.isFinite(priceKas) && priceKas >= 0 ? priceKas : null,
    priceUsd: Number.isFinite(priceUsd) && priceUsd >= 0 ? priceUsd : null,
    explorerUrl: `https://kaspatoken.kaslab.space/token/${encodeURIComponent(normalized)}`
  };
  marketCache.set(normalized, { at: Date.now(), value: result });
  return result;
}
async function nftCollection(address, ticker, offset = 0) {
  if (!/^(kaspa|kaspatest):[a-z0-9]{61,63}$/.test(address) || !/^[A-Z0-9_-]{1,32}$/.test(ticker) || !Number.isSafeInteger(offset) || offset < 0)
    throw new Error("Invalid NFT collection request.");
  const value = await get(
    `https://kaspatoken.kaslab.space/api/wallet/krc20/${encodeURIComponent(address)}/krc721/${encodeURIComponent(ticker)}?limit=48&offset=${offset}`
  );
  const data = value?.data && typeof value.data === "object" ? value.data : {};
  const rows = Array.isArray(data.nfts) ? data.nfts : [];
  return {
    ticker: String(data.ticker ?? ticker).toUpperCase(),
    total: Number(data.total ?? rows.length),
    nextOffset: Number.isSafeInteger(data.next_offset) ? data.next_offset : null,
    nfts: rows.map((item) => ({
      ticker: String(item?.ticker ?? ticker).toUpperCase(),
      tokenId: String(item?.token_id ?? ""),
      imageUrl: typeof item?.image_url === "string" ? item.image_url : "",
      rarityRank: Number.isSafeInteger(item?.rarity_rank) ? item.rarity_rank : null,
      nexusUrl: typeof item?.nexus_url === "string" ? item.nexus_url : ""
    })).filter((item) => item.tokenId)
  };
}
async function nftRarity(ticker, tokenId) {
  if (!/^[A-Z0-9_-]{1,32}$/.test(ticker) || !tokenId || tokenId.length > 128)
    throw new Error("Invalid NFT metadata request.");
  const value = await post("https://api.kaspa.com/krc721/tokens", {
    ticker,
    limit: 1,
    offset: 0,
    sortField: "tokenId",
    sortDirection: "asc",
    traits: {},
    tokenIds: [tokenId]
  });
  const item = (Array.isArray(value?.items) ? value.items : []).find(
    (row) => String(row?.tokenId ?? "") === tokenId
  );
  const rank = Number(item?.rarityRank);
  return { rarityRank: Number.isSafeInteger(rank) && rank > 0 ? rank : null };
}
async function resolveWalletInput(input, network) {
  const normalized = input.trim().toLowerCase();
  const prefix = network === "mainnet" ? "kaspa" : "kaspatest";
  if (new RegExp(`^${prefix}:[a-z0-9]{61,63}$`).test(normalized))
    return normalized;
  if (network !== "mainnet" || !/^[a-z0-9][a-z0-9.-]*\.kas$/.test(normalized))
    throw new Error(
      network === "mainnet" ? "Enter a Kaspa address or valid name.kas domain." : "Enter a valid TN10 kaspatest: address."
    );
  const value = await loadTokenAssets(normalized);
  const address = String(value?.data?.address ?? "").toLowerCase();
  if (!/^kaspa:[a-z0-9]{61,63}$/.test(address))
    throw new Error("KNS domain not found or it has no Kaspa owner.");
  return address;
}
async function broadcast(submitJson, network) {
  const response = await fetch(`${base(network)}/transactions`, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json" },
    body: submitJson
  });
  if (!response.ok) throw new Error(`Broadcast rejected (${response.status}).`);
  const value = await response.json();
  const id = String(value?.transactionId ?? value?.transaction_id ?? "");
  if (id && !/^[0-9a-f]{64}$/.test(id))
    throw new Error("Node returned an invalid transaction ID.");
  return id;
}
async function waitForUtxo(address, transactionId, network) {
  for (let attempt = 0; attempt < 40; attempt++) {
    try {
      const utxos = await get(
        `${base(network)}/addresses/${encodeURIComponent(address)}/utxos`
      );
      if (Array.isArray(utxos) && utxos.some(
        (item) => item?.outpoint?.transactionId === transactionId
      ))
        return JSON.stringify(utxos);
    } catch {
    }
    await new Promise((resolve) => setTimeout(resolve, 3e3));
  }
  throw new Error("Commit is accepted but not spendable yet.");
}
async function verifyKrc721Ownership(address, ticker, tokenId) {
  let offset = "";
  for (let page = 0; page < 100; page++) {
    const query = new URLSearchParams({
      limit: "500",
      direction: "forward",
      ...offset ? { offset } : {}
    });
    const value = await get(
      `https://krc721-indexer.kaspa.com/api/v1/krc721/mainnet/address/${encodeURIComponent(address)}?${query}`
    );
    const items = Array.isArray(value?.result) ? value.result : [];
    if (items.some(
      (item) => String(item?.tick ?? "").toUpperCase() === ticker && String(item?.tokenId ?? "") === tokenId
    ))
      return true;
    const next = typeof value?.next === "string" ? value.next : "";
    if (!next || !items.length) return false;
    offset = next;
  }
  throw new Error("KRC-721 ownership result exceeded the safe page limit.");
}
var CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
function ownerId(address) {
  const [prefix, encoded, ...rest] = address.toLowerCase().split(":");
  if (rest.length || prefix !== "kaspa" || !encoded) return "";
  const values = [...encoded].map((char) => CHARSET.indexOf(char));
  if (values.some((value) => value < 0)) return "";
  let checksum = 1n;
  for (const value of [
    ...[...prefix].map((char) => char.charCodeAt(0) & 31),
    0,
    ...values
  ]) {
    const high = checksum >> 35n;
    checksum = (checksum & 0x07ffffffffn) << 5n ^ BigInt(value);
    for (const [bit, constant] of [
      [1n, 0x98f2bc8e61n],
      [2n, 0x79b76d99e2n],
      [4n, 0xf33e5fb3c4n],
      [8n, 0xae2eabe2a8n],
      [16n, 0x1e4f43e470n]
    ])
      if (high & bit) checksum ^= constant;
  }
  if ((checksum ^ 1n) !== 0n) return "";
  let buffer = 0, bits = 0;
  const bytes2 = [];
  for (const value of values.slice(0, -8)) {
    buffer = buffer << 5 | value;
    bits += 5;
    while (bits >= 8) {
      bits -= 8;
      bytes2.push(buffer >> bits & 255);
      buffer &= (1 << bits) - 1;
    }
  }
  return bytes2.length === 33 && bytes2[0] === 0 ? bytes2.slice(1).map((value) => value.toString(16).padStart(2, "0")).join("") : "";
}
function verifiedKcc20Standard(token) {
  const standard = String(token?.standard ?? "").toLowerCase(), status = String(token?.validation_status ?? "").toLowerCase();
  if ((standard === "kron-native" || token?.contract_type === "kron-native") && status === "template_verified")
    return "kron-native";
  if ((!standard || standard === "legacy-kcc20") && status === "verified")
    return "legacy-kcc20";
  return "";
}
async function loadKcc20Assets(address) {
  const owner = ownerId(address);
  if (!owner) return [];
  const [status, balances] = await Promise.all([
    get("https://kcc20.info/v1/status"),
    get(`https://kcc20.info/v1/owners/${owner}/balances?limit=1000`)
  ]);
  if (status?.capabilities?.balances !== true || Number(status?.max_daa) <= 0)
    throw new Error("KCC20 indexer is not ready.");
  const rows = (Array.isArray(balances?.balances) ? balances.balances : []).filter(
    (item) => (item?.validation_status === "verified" || item?.validation_status === "template_verified") && Number(item?.unresolved_cells) === 0 && Number(item?.balance) > 0
  ).slice(0, 1e3);
  return (await Promise.all(
    rows.map(async (item) => {
      const id = String(item.token_id ?? "").toLowerCase();
      if (!/^[0-9a-f]{64}$/.test(id))
        throw new Error("Invalid KCC20 covenant ID.");
      const token = await get(`https://kcc20.info/v1/tokens/${id}`);
      const decimals = Number(
        token?.decimals ?? token?.claimed_decimals ?? 8
      ), standard = verifiedKcc20Standard(token);
      if (!Number.isInteger(decimals) || decimals < 0 || decimals > 18 || !standard)
        throw new Error("Invalid KCC20 metadata.");
      const claimedImage = String(token?.image ?? token?.claimed_image ?? ""), imageApi = String(token?.image_api ?? "");
      const image = /^https:\/\//.test(claimedImage) ? claimedImage : imageApi.startsWith("/v1/tokens/") ? `https://kcc20.info${imageApi}` : "";
      return {
        covenantId: id,
        symbol: String(
          token?.ticker ?? token?.claimed_name ?? token?.name ?? token?.fallback_name ?? "KCC20"
        ).toUpperCase(),
        name: String(
          token?.name ?? token?.claimed_name ?? token?.fallback_name ?? "KCC20"
        ),
        rawBalance: String(item.balance),
        decimals,
        image_url: image,
        standard,
        contractType: String(token?.contract_type ?? ""),
        validationStatus: String(token?.validation_status ?? ""),
        directTransfer: standard === "legacy-kcc20",
        explorerUrl: `https://kcc20.info/token/${id}`,
        kronUrl: standard === "kron-native" ? "https://kron.technology/" : ""
      };
    })
  )).filter(Boolean);
}
function mapKcc20Cells(cellsData, covenantId2, owner, rawBalance, templateHash) {
  const rows = (Array.isArray(cellsData?.cells) ? cellsData.cells : []).filter(
    (item) => String(item?.token_id ?? item?.covenant_id).toLowerCase() === covenantId2 && item?.signing_ready !== false
  );
  const cells = rows.flatMap((item) => {
    const state = item?.state && typeof item.state === "object" ? item.state : {};
    const stateFields = Array.isArray(state?.state_fields) ? state.state_fields : Array.isArray(item?.state_fields) ? item.state_fields : [];
    const field = (name) => stateFields.find((entry) => String(entry?.name) === name)?.value;
    const cellOwner = String(
      item?.owner ?? state?.owner ?? field("owner_identifier") ?? ""
    ).toLowerCase();
    if (cellOwner && cellOwner !== owner) return [];
    const tokenAmount = Number(
      item?.token_amount ?? item?.amount ?? state?.amount
    );
    return [
      {
        covenantId: covenantId2,
        transactionId: String(
          item?.outpoint_tx_id ?? item?.transaction_id ?? item?.txid ?? ""
        ).toLowerCase(),
        index: Number(
          item?.outpoint_index ?? item?.index ?? item?.output_index
        ),
        valueSompi: Number(item?.value),
        blockDaaScore: Number(item?.created_daa),
        scriptPublicKey: normalizeKcc20Script(
          item?.script_public_key ?? item?.script_hex
        ),
        tokenAmount,
        isMinter: item?.is_minter === true || state?.is_minter === true
      }
    ];
  });
  const hasUnmapped = (Array.isArray(cellsData?.unmapped) ? cellsData.unmapped : []).some(
    (item) => String(item?.token_id ?? item?.covenant_id).toLowerCase() === covenantId2
  );
  const seen = /* @__PURE__ */ new Set();
  if (hasUnmapped || !/^[0-9a-f]{64}$/.test(templateHash) || !cells.length || cells.some((cell) => {
    const outpoint = `${cell.transactionId}:${cell.index}`;
    const invalid = !/^[0-9a-f]{64}$/.test(cell.transactionId) || !Number.isSafeInteger(cell.index) || cell.index < 0 || !Number.isSafeInteger(cell.valueSompi) || cell.valueSompi <= 0 || !Number.isSafeInteger(cell.tokenAmount) || cell.tokenAmount <= 0 || !/^[0-9a-f]+$/i.test(cell.scriptPublicKey) || seen.has(outpoint);
    seen.add(outpoint);
    return invalid;
  }) || cells.reduce((sum, cell) => sum + cell.tokenAmount, 0) !== rawBalance)
    throw new Error("KCC20 cell discovery is incomplete.");
  return cells;
}
function normalizeKcc20Script(value) {
  const script = String(value ?? "").toLowerCase();
  return /^0000aa20[0-9a-f]{64}87$/.test(script) ? script.slice(4) : script;
}
async function loadKascovKcc20Cells(covenantId2, owner, rawBalance) {
  const [detail, coin] = await Promise.all([
    get(`https://kascov.io/data/mainnet/token/${covenantId2}`),
    get(`https://kascov.io/data/mainnet/c/${covenantId2}.json`)
  ]);
  const balance = (Array.isArray(detail?.balances) ? detail.balances : []).find(
    (item) => String(item?.owner).toLowerCase() === owner
  );
  if (!Number.isSafeInteger(Number(balance?.balance)) || Number(balance.balance) !== rawBalance || coin?.lineage_complete === false)
    throw new Error("KCC20 fallback conflicts with the primary balance.");
  const amounts = /* @__PURE__ */ new Map();
  for (const event of Array.isArray(detail?.events) ? detail.events : []) {
    if (String(event?.owner_to).toLowerCase() !== owner) continue;
    const txid = String(event?.txid ?? "").toLowerCase(), index = Number(event?.delta_idx ?? event?.output_index ?? event?.index), value = Number(event?.balance_to ?? event?.state_amount ?? event?.amount);
    if (/^[0-9a-f]{64}$/.test(txid) && Number.isSafeInteger(index) && index >= 0 && Number.isSafeInteger(value) && value > 0)
      amounts.set(`${txid}:${index}`, value);
  }
  const liveRows = [coin?.live_utxos, coin?.live_outputs, coin?.utxos].find(Array.isArray) ?? [];
  const rows = [];
  for (const item of liveRows) {
    if (!item || item.live === false) continue;
    const outpoint = typeof item.outpoint === "string" ? item.outpoint : "";
    const parts = outpoint.split(":");
    const nested = item.outpoint && typeof item.outpoint === "object" ? item.outpoint : {};
    const txid = String(
      nested.transaction_id ?? nested.transactionId ?? item.transaction_id ?? item.txid ?? parts[0] ?? ""
    ).toLowerCase();
    const index = Number(
      nested.index ?? item.index ?? item.output_index ?? parts[1]
    );
    const tokenAmount = amounts.get(`${txid}:${index}`);
    if (tokenAmount === void 0) continue;
    const script = String(
      item.script_hex ?? item?.script_public_key?.script ?? item?.scriptPublicKey?.scriptPublicKey ?? ""
    ).toLowerCase();
    rows.push({
      covenant_id: covenantId2,
      outpoint_tx_id: txid,
      outpoint_index: index,
      value: Number(item.value ?? item.amount),
      created_daa: Number(item.created_daa ?? item.block_daa_score),
      script_public_key: script,
      state: { owner, amount: tokenAmount, is_minter: item.is_minter === true },
      signing_ready: true
    });
  }
  const templateHash = String(coin?.kcc1_template_hash ?? "").toLowerCase();
  return {
    templateHash,
    cells: mapKcc20Cells(
      { cells: rows, unmapped: [] },
      covenantId2,
      owner,
      rawBalance,
      templateHash
    )
  };
}
async function loadKcc20CellTransaction(transactionId) {
  try {
    return await get(`${MAINNET}/local-node/transactions/${transactionId}`);
  } catch (error) {
    if (!String(error?.message ?? error).includes("(404)"))
      throw error;
    return get(`https://api.kaspa.org/transactions/${transactionId}`);
  }
}
async function kcc20TransferData(address, covenantId2, amount) {
  const owner = ownerId(address);
  if (!owner || !/^[0-9a-f]{64}$/.test(covenantId2) || !Number.isSafeInteger(amount) || amount <= 0)
    throw new Error("Invalid KCC20 request.");
  const [status, balances, cellsData, token] = await Promise.all([
    get("https://kcc20.info/v1/status"),
    get(`https://kcc20.info/v1/owners/${owner}/balances?limit=1000`),
    get(
      `https://kcc20.info/v1/owners/${owner}/cells?signing_ready=true&limit=1000`
    ),
    get(`https://kcc20.info/v1/tokens/${covenantId2}`)
  ]);
  if (status?.capabilities?.balances !== true || status?.capabilities?.signing_data !== true || Number(status?.max_daa) <= 0)
    throw new Error("KCC20 indexer lacks verified signing data.");
  const balance = (Array.isArray(balances?.balances) ? balances.balances : []).find(
    (item) => String(item?.token_id).toLowerCase() === covenantId2 && item?.validation_status === "verified" && Number(item?.unresolved_cells) === 0
  );
  const rawBalance = Number(balance?.balance);
  if (!Number.isSafeInteger(rawBalance) || rawBalance <= 0 || amount > rawBalance)
    throw new Error("Insufficient verified KCC20 balance.");
  if (token?.validation_status !== "verified" || Number(token?.unresolved_cells) > 0)
    throw new Error("KCC20 token is not fully verified.");
  let templateHash = String(
    token?.template_hash ?? token?.kcc1_template_hash ?? ""
  ).toLowerCase();
  let cells;
  try {
    if (!/^[0-9a-f]{64}$/.test(templateHash)) {
      const coin = await get(
        `https://kascov.io/data/mainnet/c/${covenantId2}.json`
      );
      templateHash = String(coin?.kcc1_template_hash ?? "").toLowerCase();
      if (coin?.lineage_complete === false)
        throw new Error("KCC20 fallback lineage is incomplete.");
    }
    cells = mapKcc20Cells(
      cellsData,
      covenantId2,
      owner,
      rawBalance,
      templateHash
    );
  } catch {
    const fallback = await loadKascovKcc20Cells(covenantId2, owner, rawBalance);
    templateHash = fallback.templateHash;
    cells = fallback.cells;
  }
  for (const cell of cells) {
    const tx = await loadKcc20CellTransaction(cell.transactionId);
    const output = (Array.isArray(tx?.outputs) ? tx.outputs : []).find(
      (item) => Number(item?.index) === cell.index
    );
    const script = normalizeKcc20Script(
      output?.script_public_key ?? output?.scriptPublicKey
    );
    const outputAddress = String(
      output?.script_public_key_address ?? output?.address ?? ""
    );
    if (String(tx?.transaction_id ?? "").toLowerCase() !== cell.transactionId || tx?.is_accepted !== true || String(output?.covenant_id ?? "").toLowerCase() !== covenantId2 || Number(output?.amount) !== cell.valueSompi || script !== cell.scriptPublicKey || !/^kaspa:[a-z0-9]{61,63}$/.test(outputAddress))
      throw new Error("KCC20 indexer conflicts with the verified transaction.");
    const live = await get(
      `${MAINNET}/local-node/addresses/${encodeURIComponent(outputAddress)}/utxos`
    );
    const isLive = Array.isArray(live) && live.some((item) => {
      const outpoint = item?.outpoint ?? {}, entry = item?.utxoEntry ?? {}, liveScript = normalizeKcc20Script(
        typeof entry?.scriptPublicKey === "object" ? entry.scriptPublicKey?.scriptPublicKey ?? entry.scriptPublicKey?.script_public_key : entry?.scriptPublicKey
      );
      return String(
        outpoint?.transactionId ?? outpoint?.transaction_id ?? ""
      ).toLowerCase() === cell.transactionId && Number(outpoint?.index) === cell.index && Number(entry?.amount) === cell.valueSompi && liveScript === cell.scriptPublicKey && entry?.isCoinbase !== true;
    });
    if (!isLive)
      throw new Error(
        "The local Kaspa node reports that this KCC20 cell is no longer spendable."
      );
  }
  return {
    ticker: String(
      token?.ticker ?? token?.claimed_name ?? token?.name ?? "KCC20"
    ).toUpperCase(),
    decimals: Number(token?.decimals ?? token?.claimed_decimals ?? 8),
    templateHash,
    cells,
    rawBalance
  };
}
async function kronTransferData(address, covenantId2, amount) {
  const owner = ownerId(address);
  if (!owner || !/^[0-9a-f]{64}$/.test(covenantId2) || !Number.isSafeInteger(amount) || amount <= 0)
    throw new Error("Invalid KRON transfer request.");
  const [balances, cellsData, token] = await Promise.all([
    get(`https://kcc20.info/v1/owners/${owner}/balances?limit=1000`),
    get(
      `https://kcc20.info/v1/owners/${owner}/cells?signing_ready=true&limit=1000`
    ),
    get(`https://kcc20.info/v1/tokens/${covenantId2}`)
  ]);
  if (verifiedKcc20Standard(token) !== "kron-native")
    throw new Error(
      "The selected token is not a template-verified KRON token."
    );
  const balance = (Array.isArray(balances?.balances) ? balances.balances : []).find(
    (item) => String(item?.token_id).toLowerCase() === covenantId2 && item?.validation_status === "template_verified" && Number(item?.unresolved_cells) === 0
  ), rawBalance = Number(balance?.balance);
  if (!Number.isSafeInteger(rawBalance) || rawBalance <= 0 || amount > rawBalance)
    throw new Error("Insufficient verified KRON balance.");
  const rows = (Array.isArray(cellsData?.cells) ? cellsData.cells : []).filter(
    (item) => String(item?.covenant_id ?? item?.token_id).toLowerCase() === covenantId2 && item?.signing_ready !== false && Number(item?.state?.amount) > 0 && item?.state?.is_minter !== true
  );
  const seen = /* @__PURE__ */ new Set(), cells = rows.map((item) => {
    const transactionId = String(item?.outpoint_tx_id ?? "").toLowerCase(), index = Number(item?.outpoint_index), value = Number(item?.value), tokenAmount = Number(item?.state?.amount), redeemScript = String(item?.redeem_script ?? "").toLowerCase(), scriptPublicKey = normalizeKcc20Script(item?.script_public_key);
    const key2 = `${transactionId}:${index}`;
    if (!/^[0-9a-f]{64}$/.test(transactionId) || !Number.isSafeInteger(index) || index < 0 || !Number.isSafeInteger(value) || value <= 0 || !Number.isSafeInteger(tokenAmount) || tokenAmount <= 0 || !/^[0-9a-f]+$/.test(redeemScript) || !/^[0-9a-f]+$/.test(scriptPublicKey) || seen.has(key2))
      throw new Error("Invalid or duplicate KRON signing cell.");
    seen.add(key2);
    return {
      transactionId,
      index,
      value,
      tokenAmount,
      redeemScript,
      scriptPublicKey
    };
  }).sort((a, b) => b.tokenAmount - a.tokenAmount);
  const selected = [];
  let selectedAmount = 0;
  for (const cell of cells) {
    selected.push(cell);
    selectedAmount += cell.tokenAmount;
    if (selectedAmount >= amount) break;
    if (selected.length === 4) break;
  }
  if (selectedAmount < amount)
    throw new Error(
      "KRON balance needs more than four token cells. Consolidate it in KRON first."
    );
  return {
    ticker: String(token?.ticker ?? token?.name ?? "KRON").toUpperCase(),
    decimals: Number(token?.decimals ?? 0),
    rawBalance,
    standard: "kron-native",
    templateHash: String(
      token?.template_hash ?? token?.kcc1_template_hash ?? ""
    ).toLowerCase(),
    cells: selected
  };
}
async function kcc20History(address) {
  const owner = ownerId(address);
  if (!owner) return [];
  const [status, result] = await Promise.all([
    get("https://kcc20.info/v1/status"),
    get(`https://kcc20.info/v1/owners/${owner}/history?limit=250`)
  ]);
  const tipDaa = Number(status?.max_daa ?? 0), tipAt = Number(status?.tip_at_ms ?? status?.updated_at_ms ?? Date.now());
  const rows = Array.isArray(result?.history) ? result.history : [];
  const selected = /* @__PURE__ */ new Map();
  for (const item of rows) {
    const tx = String(item?.tx_id ?? "").toLowerCase(), tokenId = String(item?.token_id ?? item?.covenant_id ?? "").toLowerCase(), delta = String(item?.balance_delta ?? "");
    if (!/^[0-9a-f]{64}$/.test(tx) || !/^[0-9a-f]{64}$/.test(tokenId) || !/^-[0-9]+$|^[0-9]+$/.test(delta) || delta === "0")
      continue;
    const key2 = `${tx}:${tokenId}`, previous = selected.get(key2);
    if (!previous || item?.source === "node" && previous?.source !== "node" || item?.kind === "balance-change" && previous?.kind !== "balance-change")
      selected.set(key2, item);
  }
  const tokenIds = [
    ...new Set(
      [...selected.values()].map(
        (item) => String(item.token_id ?? item.covenant_id).toLowerCase()
      )
    )
  ];
  const metadata = /* @__PURE__ */ new Map();
  await Promise.all(
    tokenIds.map(async (id) => {
      try {
        metadata.set(id, await get(`https://kcc20.info/v1/tokens/${id}`));
      } catch {
        metadata.set(id, {});
      }
    })
  );
  return [...selected.values()].map((item) => {
    const tokenId = String(item.token_id ?? item.covenant_id).toLowerCase(), token = metadata.get(tokenId) ?? {}, decimals = Number(token?.decimals ?? token?.claimed_decimals ?? 8), raw = BigInt(String(item.balance_delta)), incoming = raw > 0n, absolute = (raw < 0n ? -raw : raw).toString().padStart(decimals + 1, "0"), whole = decimals ? absolute.slice(0, -decimals) : absolute, fraction = decimals ? absolute.slice(-decimals).replace(/0+$/g, "") : "", daa = Number(item?.daa ?? item?.accepting_daa ?? 0), blockTime = tipDaa >= daa && tipAt > 0 ? tipAt - (tipDaa - daa) * 100 : 0;
    return {
      transactionId: String(item.tx_id).toLowerCase(),
      blockTime,
      isAccepted: true,
      incoming,
      assetKind: "KCC20",
      assetSymbol: String(
        token?.ticker ?? token?.claimed_name ?? token?.name ?? "KCC20"
      ).toUpperCase(),
      displayAmount: fraction ? `${whole}.${fraction}` : whole,
      tokenId,
      covenantId: tokenId,
      counterparty: "",
      from: incoming ? [] : [{ address, ownerId: owner }],
      to: incoming ? [{ address, ownerId: owner }] : [],
      feeSompi: null,
      totalInputSompi: null,
      totalOutputSompi: null,
      inputCount: null,
      outputCount: null,
      mass: null,
      blockDaaScore: daa,
      type: String(item?.kind ?? "transfer")
    };
  });
}
function parseKcc20BroadcastId(value, expectedId) {
  const id = String(
    value?.txId ?? value?.transactionId ?? value?.transaction_id ?? ""
  ).toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(id))
    throw new Error("KCC20 broadcaster returned no valid transaction ID.");
  if (id !== expectedId.toLowerCase())
    throw new Error("KCC20 broadcaster returned a mismatching transaction ID.");
  return id;
}
async function broadcastKcc20(wrpcJson, expectedId) {
  const response = await fetch(
    "https://gothdag.kaslab.space/api/covenant-broadcast",
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json"
      },
      body: JSON.stringify({ signedTxJson: wrpcJson })
    }
  );
  const value = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new Error(
      `KCC20 broadcast rejected (${response.status}): ${String(value?.error ?? "unknown broadcaster error")}`
    );
  return parseKcc20BroadcastId(value, expectedId);
}
async function loadTokenAssets(address) {
  try {
    return await get(
      `https://kaspatoken.kaslab.space/api/wallet/krc20/${encodeURIComponent(address)}`
    );
  } catch {
    const [tokens, domains, krc721] = await Promise.all([
      loadKasplexTokens(address).catch(() => []),
      loadKnsDomains(address).catch(() => []),
      loadKrc721Collections(address).catch(() => [])
    ]);
    return {
      data: {
        address,
        tokens,
        domains,
        krc721_tokens: krc721,
        transactions: []
      },
      source_mode: "DIRECT_FALLBACK"
    };
  }
}
async function loadKasplexTokens(address) {
  const values = [];
  let next = "";
  for (let page = 0; page < 20; page++) {
    const value = await get(
      `https://api.kasplex.org/v1/krc20/address/${encodeURIComponent(address)}/tokenlist${next ? `?next=${encodeURIComponent(next)}` : ""}`
    );
    const rows = Array.isArray(value?.result) ? value.result : Array.isArray(value?.data) ? value.data : [];
    for (const item of rows) {
      const symbol = String(
        item?.tick ?? item?.ticker ?? item?.symbol ?? ""
      ).toUpperCase();
      const decimals = Number(item?.dec ?? item?.decimals ?? 8);
      const raw = String(item?.balance ?? item?.amount ?? "0");
      if (/^[A-Z0-9_-]{1,32}$/.test(symbol) && Number.isInteger(decimals) && decimals >= 0 && decimals <= 18 && /^\d+$/.test(raw) && BigInt(raw) > 0n)
        values.push({
          token_id: `krc20-${symbol.toLowerCase()}`,
          symbol,
          decimals,
          raw_balance: raw,
          balance: Number(raw) / 10 ** decimals
        });
    }
    next = String(value?.next ?? value?.next_cursor ?? "");
    if (!next || !rows.length) break;
  }
  return values;
}
async function loadKnsDomains(address) {
  const values = [];
  for (let page = 1; page <= 100; page++) {
    const query = new URLSearchParams({
      owner: address,
      page: String(page),
      pageSize: "100",
      type: "domain"
    });
    const value = await get(
      `https://api.knsdomains.org/mainnet/api/v1/assets?${query}`
    );
    const rows = Array.isArray(value?.data?.assets) ? value.data.assets : [];
    for (const item of rows) {
      const name = String(
        item?.asset ?? item?.domain ?? item?.name ?? ""
      ).toLowerCase();
      const assetId = String(
        item?.assetId ?? item?.asset_id ?? ""
      ).toLowerCase();
      if (/^[a-z0-9][a-z0-9.-]*\.kas$/.test(name) && /^[0-9a-f]{64}i0$/.test(assetId))
        values.push({ name, asset_id: assetId, status: item?.status });
    }
    const total = Number(value?.data?.pagination?.totalPages ?? 0);
    if (!rows.length || (total > 0 ? page >= total : rows.length < 100)) break;
  }
  return values;
}
async function loadKrc721Collections(address) {
  const grouped = /* @__PURE__ */ new Map();
  let offset = "";
  for (let page = 0; page < 100; page++) {
    const query = new URLSearchParams({
      limit: "500",
      direction: "forward",
      ...offset ? { offset } : {}
    });
    const value = await get(
      `https://krc721-indexer.kaspa.com/api/v1/krc721/mainnet/address/${encodeURIComponent(address)}?${query}`
    );
    const rows = Array.isArray(value?.result) ? value.result : [];
    for (const item of rows) {
      const symbol = String(item?.tick ?? "").toUpperCase();
      if (/^[A-Z0-9_-]{1,32}$/.test(symbol))
        grouped.set(symbol, (grouped.get(symbol) ?? 0) + 1);
    }
    const next = String(value?.next ?? "");
    if (!next || !rows.length) break;
    offset = next;
  }
  return [...grouped].map(([symbol, balance]) => ({
    token_id: `krc721-${symbol.toLowerCase()}`,
    symbol,
    name: symbol,
    balance
  }));
}
async function walletCoreSnapshot(address, network) {
  const endpoint = network === "mainnet" ? MAINNET : TN10;
  const [balance, utxos] = await Promise.all([
    get(`${endpoint}/addresses/${encodeURIComponent(address)}/balance`),
    get(`${endpoint}/addresses/${encodeURIComponent(address)}/utxos`)
  ]);
  const sompi = Number(balance?.balance ?? 0);
  if (!Number.isSafeInteger(sompi) || sompi < 0)
    throw new Error("Node returned an invalid balance.");
  if (!Array.isArray(utxos)) throw new Error("Node returned invalid UTXOs.");
  return {
    balanceSompi: sompi,
    balanceKas: sompi / 1e8,
    utxoCount: utxos.length,
    utxos
  };
}
async function walletBalance(address, network) {
  const value = await get(
    `${network === "mainnet" ? MAINNET : TN10}/addresses/${encodeURIComponent(address)}/balance`
  );
  const sompi = Number(value?.balance ?? 0);
  if (!Number.isSafeInteger(sompi) || sompi < 0)
    throw new Error("Node returned an invalid balance.");
  return { balanceSompi: sompi, balanceKas: sompi / 1e8 };
}
var assetCache = /* @__PURE__ */ new Map();
var inscriptionCache = /* @__PURE__ */ new Map();
async function inscriptionAssets(address) {
  const cached = inscriptionCache.get(address);
  if (cached) return cached.value;
  const walletCached = assetCache.get(address);
  if (walletCached) {
    const value2 = {
      tokens: walletCached.value.tokens,
      domains: walletCached.value.domains,
      krc721: walletCached.value.krc721,
      transactions: walletCached.value.transactions
    };
    inscriptionCache.set(address, { at: Date.now(), value: value2 });
    return value2;
  }
  const raw = await loadTokenAssets(address);
  const data = raw?.data && typeof raw.data === "object" ? raw.data : {};
  const value = {
    tokens: Array.isArray(data.tokens) ? data.tokens.map((item) => ({
      ...item,
      symbol: String(item?.symbol ?? "").toUpperCase()
    })) : [],
    domains: Array.isArray(data.domains) ? data.domains : [],
    krc721: Array.isArray(data.krc721_tokens) ? data.krc721_tokens.map((item) => ({
      ...item,
      symbol: String(item?.symbol ?? "").toUpperCase()
    })) : [],
    transactions: Array.isArray(data.transactions) ? data.transactions : []
  };
  inscriptionCache.set(address, { at: Date.now(), value });
  return value;
}
async function walletAssets(address, network) {
  if (network !== "mainnet")
    return { tokens: [], domains: [], krc721: [], kcc20: [], transactions: [] };
  const cached = assetCache.get(address);
  if (cached && Date.now() - cached.at < 3e4) return cached.value;
  const [rawAssets, kcc20] = await Promise.all([
    loadTokenAssets(address).catch(() => null),
    loadKcc20Assets(address).catch(() => [])
  ]);
  const data = rawAssets?.data && typeof rawAssets.data === "object" ? rawAssets.data : {};
  const value = {
    tokens: Array.isArray(data.tokens) ? data.tokens.filter(
      (item) => typeof item?.symbol === "string" && typeof item?.raw_balance === "string" && Number.isInteger(item?.decimals) && item.decimals >= 0 && item.decimals <= 18
    ).map((item) => ({
      ...item,
      symbol: String(item.symbol).toUpperCase()
    })) : [],
    domains: Array.isArray(data.domains) ? data.domains.filter(
      (item) => typeof item?.name === "string" && /^[a-z0-9][a-z0-9.-]*\.kas$/.test(item.name)
    ) : [],
    krc721: Array.isArray(data.krc721_tokens) ? data.krc721_tokens.filter((item) => typeof item?.symbol === "string").map((item) => ({
      ...item,
      symbol: String(item.symbol).toUpperCase()
    })) : [],
    kcc20: kcc20.map((item) => ({
      ...item,
      symbol: String(item.symbol).toUpperCase()
    })),
    transactions: Array.isArray(data.transactions) ? data.transactions : []
  };
  assetCache.set(address, { at: Date.now(), value });
  inscriptionCache.set(address, {
    at: Date.now(),
    value: {
      tokens: value.tokens,
      domains: value.domains,
      krc721: value.krc721,
      transactions: value.transactions
    }
  });
  return value;
}
async function walletSnapshot(address, network) {
  const [core2, assets] = await Promise.all([
    walletCoreSnapshot(address, network),
    walletAssets(address, network)
  ]);
  return { ...core2, assets, transactions: assets.transactions };
}
async function networkDiagnostics(address, network) {
  const endpoint = network === "mainnet" ? MAINNET : TN10;
  const checks = [
    {
      name: "Kaspa node",
      url: `${endpoint}/addresses/${encodeURIComponent(address)}/balance`
    },
    ...network === "mainnet" ? [
      {
        name: "KRC-20 / KNS / KRC-721",
        url: `https://kaspatoken.kaslab.space/api/wallet/krc20/${encodeURIComponent(address)}`
      },
      {
        name: "KRC-20 fallback",
        url: `https://api.kasplex.org/v1/krc20/address/${encodeURIComponent(address)}/tokenlist`
      },
      {
        name: "KNS fallback",
        url: `https://api.knsdomains.org/mainnet/api/v1/assets?owner=${encodeURIComponent(address)}&page=1&pageSize=1&type=domain`
      },
      { name: "KCC20 indexer", url: "https://kcc20.info/v1/status" }
    ] : []
  ];
  return Promise.all(
    checks.map(async (check) => {
      const started = performance.now();
      try {
        await get(check.url);
        return {
          ...check,
          ok: true,
          detail: "Online and returned valid JSON",
          elapsedMs: Math.round(performance.now() - started)
        };
      } catch (error) {
        return {
          ...check,
          ok: false,
          detail: error.message,
          elapsedMs: Math.round(performance.now() - started)
        };
      }
    })
  );
}

// src/shared/protocol.ts
var PROVIDER_CHANNEL = "kaspire:provider:v1";
var providerMethods = ["requestAccounts", "getAccounts", "getNetwork", "switchNetwork", "getPublicKey", "getBalance", "getUtxoEntries", "disconnect", "signMessage", "sendKaspa", "sendKRC20", "sendKCC20", "signPskt", "pushTx", "signPolicyTransaction", "transferKRC721", "transferKNS"];
function isProviderRequest(value) {
  if (!value || typeof value !== "object") return false;
  const item = value;
  if (item.channel !== PROVIDER_CHANNEL || item.direction !== "request" || typeof item.id !== "string" || item.id.length < 1 || item.id.length > 128 || !providerMethods.includes(item.method)) return false;
  try {
    return JSON.stringify(value).length <= 1048576;
  } catch {
    return false;
  }
}

// src/shared/tokenAmount.ts
function formatRawTokenAmount(raw, decimals) {
  if (!/^[0-9]+$/.test(raw) || !Number.isInteger(decimals) || decimals < 0 || decimals > 18) {
    throw new Error("Invalid raw token amount.");
  }
  if (decimals === 0) return BigInt(raw).toString();
  const digits = BigInt(raw).toString().padStart(decimals + 1, "0");
  const whole = digits.slice(0, -decimals);
  const fraction = digits.slice(-decimals).replace(/0+$/g, "");
  return fraction ? `${whole}.${fraction}` : whole;
}

// node_modules/@kronsdk/kron-sdk/dist/index.js
var __defProp2 = Object.defineProperty;
var __export2 = (target, all) => {
  for (var name in all)
    __defProp2(target, name, { get: all[name], enumerable: true });
};
var cpCurve_exports = {};
__export2(cpCurve_exports, {
  DEFAULT_SLIPPAGE_BPS: () => DEFAULT_SLIPPAGE_BPS,
  FEE_OUT_MIN: () => FEE_OUT_MIN,
  MAX_KAS: () => MAX_KAS,
  SCALE: () => SCALE,
  cpPrice: () => cpPrice,
  cpProgress: () => cpProgress,
  cpSold: () => cpSold,
  minOutWithSlippage: () => minOutWithSlippage,
  quoteCpBuy: () => quoteCpBuy,
  quoteCpSell: () => quoteCpSell
});
var SCALE = 1000000n;
var FEE_OUT_MIN = 20000000n;
var padFee = (f) => f > FEE_OUT_MIN ? f : FEE_OUT_MIN;
var MAX_KAS = 900000000000000n;
var ceilDiv = (a, b) => (a + b - 1n) / b;
var DEFAULT_SLIPPAGE_BPS = 100;
var minOutWithSlippage = (out, bps) => out - out * BigInt(Math.min(1e4, Math.max(0, Math.round(bps)))) / 10000n;
var devFundFeeOf = (s, base2) => s.devFundBps && s.devFundBps > 0n ? padFee(base2 * s.devFundBps / 10000n) : 0n;
function quoteCpBuy(s, kasInSompi) {
  const ki = kasInSompi / SCALE;
  const kasIn = ki * SCALE;
  if (kasIn <= 0n) return null;
  const newRealKas = s.realKas + kasIn;
  if (newRealKas > MAX_KAS) return null;
  const ru = s.realKas / SCALE;
  const K = (s.vKas + ru) * s.tokenReserve;
  const newToken = ceilDiv(K, s.vKas + ru + ki);
  const tokenOut = s.tokenReserve - newToken;
  if (tokenOut <= 0n) return null;
  const creatorFee = padFee(kasIn * s.creatorFeeBps / 10000n);
  const platformFee = padFee(kasIn * s.platformFeeBps / 10000n);
  const devFundFee = devFundFeeOf(s, kasIn);
  const fee = creatorFee + platformFee + devFundFee;
  return { kasIn, tokenOut, creatorFee, platformFee, devFundFee, fee, total: kasIn + fee, newRealKas, newTokenReserve: newToken };
}
function quoteCpSell(s, tokenIn) {
  if (tokenIn <= 0n) return null;
  const ru = s.realKas / SCALE;
  const K = (s.vKas + ru) * s.tokenReserve;
  const newToken = s.tokenReserve + tokenIn;
  const minKasUnits = ceilDiv(K, newToken) - s.vKas;
  const newKasUnits = minKasUnits < 0n ? 0n : minKasUnits;
  const kasOutUnits = ru - newKasUnits;
  if (kasOutUnits <= 0n) return null;
  const kasOut = kasOutUnits * SCALE;
  const creatorFee = padFee(kasOut * s.creatorFeeBps / 10000n);
  const platformFee = padFee(kasOut * s.platformFeeBps / 10000n);
  const devFundFee = devFundFeeOf(s, kasOut);
  const fee = creatorFee + platformFee + devFundFee;
  if (kasOut - fee <= 0n) return null;
  return { tokenIn, kasOut, creatorFee, platformFee, devFundFee, fee, net: kasOut - fee, newRealKas: s.realKas - kasOut, newTokenReserve: newToken };
}
function cpPrice(s) {
  if (s.tokenReserve <= 0n) return 0;
  const ru = s.realKas / SCALE;
  return Number((s.vKas + ru) * SCALE) / Number(s.tokenReserve);
}
function cpProgress(s) {
  return s.graduationKas > 0n ? Math.min(100, Number(s.realKas) / Number(s.graduationKas) * 100) : 0;
}
var cpSold = (initialInventory, tokenReserve) => initialInventory - tokenReserve;
var sigscript_exports = {};
__export2(sigscript_exports, {
  SigScriptBuilder: () => SigScriptBuilder,
  int8LE: () => int8LE
});
function int8LE(v) {
  const out = new Uint8Array(8);
  let x = BigInt.asUintN(64, v);
  for (let i = 0; i < 8; i++) {
    out[i] = Number(x & 0xffn);
    x >>= 8n;
  }
  return out;
}
var concat = (parts) => {
  const len = parts.reduce((s, p) => s + p.length, 0);
  const out = new Uint8Array(len);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
};
var SigScriptBuilder = class {
  sb;
  constructor(k) {
    this.sb = new k.ScriptBuilder({ flags: { covenantsEnabled: true } });
  }
  /** int scalar (minimal CScriptNum). */
  int(v) {
    this.sb.addI64(v);
    return this;
  }
  /** bool scalar → 1|0 via addI64 (matches push_sigscript_arg Bool). */
  bool(b) {
    this.sb.addI64(b ? 1n : 0n);
    return this;
  }
  /** single byte → addData([b]). */
  byte(b) {
    this.sb.addData(Uint8Array.of(b & 255));
    return this;
  }
  /** raw bytes (byte[N], pubkey, sig, byte[]) → addData. */
  data(bytes2) {
    this.sb.addData(bytes2);
    return this;
  }
  /** a column of N values pushed as one fixed-width-concatenated array item (encode_array_literal). */
  column(items) {
    this.sb.addData(concat(items));
    return this;
  }
  /** the entrypoint selector (branch index). Omit for single-entrypoint contracts. */
  selector(index) {
    this.sb.addI64(BigInt(index));
    return this;
  }
  /** the P2SH redeem script (pushed last; the VM pops it, hash-checks, then runs it on the arg stack). */
  redeem(script) {
    this.sb.addData(script);
    return this;
  }
  /** finalize → signature-script hex. */
  drain() {
    return this.sb.drain();
  }
};
var genesis_exports = {};
__export2(genesis_exports, {
  ZERO_COVID: () => ZERO_COVID,
  bytesToCovid: () => bytesToCovid,
  covidToBytes: () => covidToBytes,
  genesisCovenantId: () => genesisCovenantId
});
var hexToBytes = (h) => Uint8Array.from((h.replace(/^0x/, "").match(/../g) ?? []).map((b) => parseInt(b, 16)));
var bytesToHex = (u8) => Array.from(u8, (b) => b.toString(16).padStart(2, "0")).join("");
function genesisCovenantId(k, genesisOutpoint, authOutputs) {
  const auth = authOutputs.map((o) => ({
    index: o.index,
    // Normalize to a plain { version, script-hex } object — the form the SDK serializes to match consensus.
    // A bare hex string OR a ScriptPublicKey *instance* both yield a (different) wrong id; only this works.
    output: { value: o.value, scriptPublicKey: { version: o.scriptPublicKey.version ?? 0, script: o.scriptPublicKey.script ?? o.scriptPublicKey } }
  }));
  return k.covenantId(genesisOutpoint, auth).toString();
}
var covidToBytes = (covidHex) => hexToBytes(covidHex);
var bytesToCovid = (u8) => bytesToHex(u8);
var ZERO_COVID = "00".repeat(32);
var spend_exports = {};
__export2(spend_exports, {
  COVENANT_COMPUTE: () => COVENANT_COMPUTE,
  COVENANT_DUST: () => COVENANT_DUST,
  FUNDING_COMPUTE: () => FUNDING_COMPUTE,
  MIN_RELAY_FEERATE: () => MIN_RELAY_FEERATE,
  TOKEN_COMPUTE: () => TOKEN_COMPUTE,
  TX_VERSION: () => TX_VERSION,
  assembleNativeTx: () => assembleNativeTx,
  estimateNativeFee: () => estimateNativeFee,
  estimatedSerializedSize: () => estimatedSerializedSize,
  signFundingInputs: () => signFundingInputs,
  signPsktWithKey: () => signPsktWithKey,
  toPsktJson: () => toPsktJson
});
var partnerTag_exports = {};
__export2(partnerTag_exports, {
  REF_RE: () => REF_RE,
  TAG_PREFIX: () => TAG_PREFIX,
  encodePartnerTag: () => encodePartnerTag,
  parsePartnerTag: () => parsePartnerTag
});
var REF_RE = /^[a-z0-9][a-z0-9_-]{1,31}$/;
var TAG_PREFIX = "kron:r:";
var MAX_TAG_BYTES = TAG_PREFIX.length + 32;
var toHex = (s) => Array.from(new TextEncoder().encode(s), (b) => b.toString(16).padStart(2, "0")).join("");
function encodePartnerTag(ref) {
  const r = String(ref ?? "").trim().toLowerCase();
  if (!REF_RE.test(r)) return "";
  return toHex(`${TAG_PREFIX}${r}`);
}
function parsePartnerTag(payloadHex) {
  const h = String(payloadHex ?? "");
  if (!h || h.length % 2 !== 0 || h.length > MAX_TAG_BYTES * 2 || !/^[0-9a-fA-F]*$/.test(h)) return null;
  const bytes2 = new Uint8Array(h.length / 2);
  for (let i = 0; i < bytes2.length; i++) bytes2[i] = parseInt(h.slice(i * 2, i * 2 + 2), 16);
  let s;
  try {
    s = new TextDecoder("utf-8", { fatal: true }).decode(bytes2);
  } catch {
    return null;
  }
  if (!s.startsWith(TAG_PREFIX)) return null;
  const ref = s.slice(TAG_PREFIX.length);
  return REF_RE.test(ref) ? ref : null;
}
var TX_VERSION = 1;
var FUNDING_COMPUTE = 10;
var TOKEN_COMPUTE = 100;
var COVENANT_COMPUTE = 400;
var COVENANT_DUST = 50000000n;
var MIN_RELAY_FEERATE = 100;
var TRANSIENT_BYTE_TO_MASS_FACTOR = 4n;
var COMPUTE_MASS_LIMIT = 500000n;
var TRANSIENT_MASS_LIMIT = 1000000n;
function estimatedSerializedSize(tx) {
  const hexBytes2 = (h) => BigInt(Math.ceil(String(h ?? "").length / 2));
  let size = 2n + 8n + 8n + 8n + 20n + 8n + 32n + 8n;
  size += hexBytes2(tx.payload);
  for (const inp of tx.inputs ?? []) {
    size += 32n + 4n + 8n + 8n;
    size += hexBytes2(inp.signatureScript);
    if (TX_VERSION >= 1) size += 2n;
  }
  for (const out of tx.outputs ?? []) {
    size += 8n + 2n + 8n;
    size += hexBytes2(out.scriptPublicKey?.script ?? out.scriptPublicKey);
    if (out.covenant) size += 2n + 32n;
  }
  return size;
}
var SUBNET_ZERO = "0000000000000000000000000000000000000000";
var budgetForRole = (role) => role === "curve" || role === "pool" ? COVENANT_COMPUTE : TOKEN_COMPUTE;
function assembleNativeTx(k, opts) {
  const { spend, fundingEntries, changeAddress, networkFee, ref } = opts;
  const kk = k;
  const covInputs = spend.inputs.map(
    (ci) => new kk.TransactionInput({
      previousOutpoint: { transactionId: ci.transactionId, index: ci.index },
      signatureScript: ci.signatureScript,
      sequence: 0n,
      sigOpCount: 0,
      computeBudget: ci.computeBudget ?? budgetForRole(ci.role),
      utxo: {
        outpoint: { transactionId: ci.transactionId, index: ci.index },
        amount: ci.value,
        scriptPublicKey: ci.scriptPublicKey,
        blockDaaScore: 0n,
        isCoinbase: false
      }
    })
  );
  const fundingInputs = fundingEntries.map(
    (e) => new kk.TransactionInput({ previousOutpoint: e.outpoint, signatureScript: "", sequence: 0n, sigOpCount: 0, computeBudget: FUNDING_COMPUTE, utxo: e })
  );
  const covInValue = spend.inputs.reduce((s, ci) => s + ci.value, 0n);
  const fundingTotal = fundingEntries.reduce((s, e) => s + BigInt(e.amount), 0n);
  const totalIn = covInValue + fundingTotal;
  const covenantOut = spend.outputs.reduce((s, o) => s + o.value, 0n);
  const change = totalIn - covenantOut - networkFee;
  if (change < 0n) throw new Error(`insufficient funding: need ${covenantOut + networkFee} sompi, have ${totalIn}`);
  const outputs = spend.outputs.map(
    (o) => o.binding ? new kk.TransactionOutput(o.value, o.scriptPublicKey, new kk.CovenantBinding(o.binding.authorizingInput, new kk.Hash(o.binding.covid))) : new kk.TransactionOutput(o.value, o.scriptPublicKey)
  );
  outputs.push(new kk.TransactionOutput(change, kk.payToAddressScript(changeAddress)));
  const transaction = new kk.Transaction({
    version: TX_VERSION,
    inputs: [...covInputs, ...fundingInputs],
    outputs,
    lockTime: 0n,
    gas: 0n,
    // Partner attribution rides HERE, in the transaction itself — so it is captured whether the trade goes to
    // the sequencer or straight to a node. Recording it at relay time (the old design) meant a wallet with no
    // contention to sequence submitted direct and earned nothing. Empty string when untagged.
    payload: encodePartnerTag(ref),
    subnetworkId: SUBNET_ZERO
  });
  return {
    transaction,
    fundingInputIndexes: fundingInputs.map((_, i) => i + covInputs.length),
    totalIn,
    covenantOut,
    change
  };
}
function estimateNativeFee(k, networkId, asm, feeRateSompiPerGram) {
  const kk = k;
  const tx = asm.transaction;
  const ins = tx.inputs;
  const saved = asm.fundingInputIndexes.map((i) => ins[i].signatureScript);
  for (const i of asm.fundingInputIndexes) ins[i].signatureScript = "00".repeat(66);
  tx.inputs = ins;
  let byteMass = 2000n;
  try {
    byteMass = BigInt(kk.calculateTransactionMass(networkId, tx));
  } catch {
  }
  const ins2 = tx.inputs;
  asm.fundingInputIndexes.forEach((i, j) => ins2[i].signatureScript = saved[j]);
  tx.inputs = ins2;
  let computeGrams = 0n;
  for (const inp of tx.inputs) computeGrams += BigInt(inp.computeBudget || 0) * 100n;
  const rawTransient = estimatedSerializedSize(tx) * TRANSIENT_BYTE_TO_MASS_FACTOR;
  const normTransient = (rawTransient * COMPUTE_MASS_LIMIT + TRANSIENT_MASS_LIMIT - 1n) / TRANSIENT_MASS_LIMIT;
  const compute = byteMass + computeGrams;
  const billable = compute > normTransient ? compute : normTransient;
  const rate = BigInt(Math.max(Math.ceil(feeRateSompiPerGram), MIN_RELAY_FEERATE));
  const fee = billable * rate * 6n / 5n;
  return fee > 10000n ? fee : 10000n;
}
function signFundingInputs(k, tx, privKey, fundingInputIndexes) {
  const inputs = tx.inputs;
  for (const idx of fundingInputIndexes) {
    const sig = k.createInputSignature(tx, idx, privKey);
    inputs[idx].signatureScript = new k.ScriptBuilder().addData(sig).drain();
  }
  tx.inputs = inputs;
  return tx;
}
function toPsktJson(asm, sighashType = 1) {
  return {
    txJsonString: asm.transaction.serializeToSafeJSON(),
    signInputs: asm.fundingInputIndexes.map((index) => ({ index, sighashType }))
  };
}
function signPsktWithKey(k, txJsonString, signInputs, privKey) {
  const kk = k;
  const tx = kk.Transaction.deserializeFromSafeJSON(txJsonString);
  const inputs = tx.inputs;
  for (const { index } of signInputs) {
    const sig = kk.createInputSignature(tx, index, privKey);
    inputs[index].signatureScript = new kk.ScriptBuilder().addData(sig).drain();
  }
  tx.inputs = inputs;
  return tx.serializeToSafeJSON();
}
var covenantSelect_exports = {};
__export2(covenantSelect_exports, {
  COVENANT_DUST: () => COVENANT_DUST,
  carrierOf: () => carrierOf,
  carrierShortfall: () => carrierShortfall,
  continuationValue: () => continuationValue,
  normalizedCovenantId: () => normalizedCovenantId,
  selectCovenantOutpoint: () => selectCovenantOutpoint,
  selectCovenantTokenOutpoint: () => selectCovenantTokenOutpoint,
  selectCovenantTokenUtxo: () => selectCovenantTokenUtxo,
  selectCovenantUtxo: () => selectCovenantUtxo
});
var carrierShortfall = (...inputValues) => inputValues.reduce((sum, v) => sum + (v < COVENANT_DUST ? COVENANT_DUST - v : 0n), 0n);
var carrierOf = (u) => u.value ?? COVENANT_DUST;
var continuationValue = (dust, inputValue) => inputValue > dust ? inputValue : dust;
var normalizedCovenantId = (value) => {
  const text = String(value?.toString?.() ?? value ?? "").trim().toLowerCase().replace(/^0x/, "");
  return /^[0-9a-f]{64}$/.test(text) ? text : null;
};
function selectCovenantUtxo(entries, expectedCovid, expectedAmount) {
  const covid = normalizedCovenantId(expectedCovid);
  if (!covid) return null;
  const matches = entries.filter((e) => e.covenantId === covid && (expectedAmount === null || BigInt(e.amount) === expectedAmount));
  return matches.length === 1 ? matches[0] : null;
}
function selectCovenantOutpoint(entries, expectedOutpoint, expectedCovid, expectedAmount) {
  const txid = normalizedCovenantId(expectedOutpoint.transactionId);
  const covid = normalizedCovenantId(expectedCovid);
  if (!txid || !covid || !Number.isSafeInteger(expectedOutpoint.index) || expectedOutpoint.index < 0) return null;
  const matches = entries.filter((e) => normalizedCovenantId(e.outpoint?.transactionId) === txid && Number(e.outpoint?.index) === expectedOutpoint.index && e.covenantId === covid && (expectedAmount === null || BigInt(e.amount) === expectedAmount));
  return matches.length === 1 ? matches[0] : null;
}
function selectCovenantTokenUtxo(entries, expectedCovid) {
  return selectCovenantUtxo(entries, expectedCovid, null);
}
function selectCovenantTokenOutpoint(entries, expectedOutpoint, expectedCovid) {
  return selectCovenantOutpoint(entries, expectedOutpoint, expectedCovid, null);
}
var kcc20Tx_exports = {};
__export2(kcc20Tx_exports, {
  IDENTIFIER: () => IDENTIFIER,
  addressPresenceOwned: () => addressPresenceOwned,
  buildKcc20Send: () => buildKcc20Send,
  covenantIdOwned: () => covenantIdOwned,
  decodeKcc20Redeem: () => decodeKcc20Redeem,
  kcc20Address: () => kcc20Address,
  kcc20Spk: () => kcc20Spk,
  kcc20SpkForState: () => kcc20SpkForState,
  materializeKcc20Script: () => materializeKcc20Script,
  pubkeyOwned: () => pubkeyOwned,
  pushKcc20StateScalar: () => pushKcc20StateScalar,
  pushKcc20States: () => pushKcc20States,
  scriptHashOwned: () => scriptHashOwned,
  transferSigScript: () => transferSigScript
});
var IDENTIFIER = { PUBKEY: 0, SCRIPT_HASH: 1, COVENANT_ID: 2, ADDRESS: 3 };
var STATE_LEN = 46;
function materializeKcc20Script(tpl, state) {
  const s = tpl.stateStart;
  const t = tpl.script;
  if (t[s] !== 32 || t[s + 33] !== 1 || t[s + 35] !== 8 || t[s + 44] !== 1) {
    throw new Error("kcc20 template has an unexpected state layout (expected push32 owner / push1 type / push8 amount / push1 isMinter)");
  }
  if (state.ownerIdentifier.length !== 32) throw new Error("ownerIdentifier must be 32 bytes");
  if (state.amount < 0n) throw new Error("amount must be non-negative");
  const out = t.slice();
  out[s] = 32;
  out.set(state.ownerIdentifier, s + 1);
  out[s + 33] = 1;
  out[s + 34] = state.identifierType;
  out[s + 35] = 8;
  out.set(int8LE(state.amount), s + 36);
  out[s + 44] = 1;
  out[s + 45] = state.isMinter ? 1 : 0;
  return out;
}
function decodeKcc20Redeem(redeem, opts = {}) {
  const hits = [];
  for (let s2 = 0; s2 + STATE_LEN <= redeem.length; s2++) {
    if (redeem[s2] === 32 && redeem[s2 + 33] === 1 && redeem[s2 + 34] <= 3 && redeem[s2 + 35] === 8 && redeem[s2 + 44] === 1 && redeem[s2 + 45] <= 1) hits.push(s2);
  }
  if (hits.length !== 1) throw new Error(`could not locate the kcc20 state region in the redeem script (${hits.length} candidate offsets) \u2014 is this a kcc20 token UTXO?`);
  const s = hits[0];
  let amount = 0n;
  for (let i = 7; i >= 0; i--) amount = amount << 8n | BigInt(redeem[s + 36 + i]);
  return {
    template: { script: redeem.slice(), stateStart: s, maxIns: opts.maxIns ?? 4, maxOuts: opts.maxOuts ?? 4 },
    state: {
      ownerIdentifier: redeem.slice(s + 1, s + 33),
      identifierType: redeem[s + 34],
      amount,
      isMinter: redeem[s + 45] === 1
    }
  };
}
var kcc20Spk = (k, redeem) => k.payToScriptHashScript(redeem);
var kcc20SpkForState = (k, tpl, state) => kcc20Spk(k, materializeKcc20Script(tpl, state));
function kcc20Address(k, tpl, state, network) {
  return k.addressFromScriptPublicKey(kcc20SpkForState(k, tpl, state), network)?.toString() ?? "";
}
var covenantIdOwned = (covid32, amount, isMinter = false) => ({
  ownerIdentifier: covid32,
  identifierType: IDENTIFIER.COVENANT_ID,
  amount,
  isMinter
});
var pubkeyOwned = (pubkey32, amount) => ({
  ownerIdentifier: pubkey32,
  identifierType: IDENTIFIER.PUBKEY,
  amount,
  isMinter: false
});
var scriptHashOwned = (hash32, amount) => ({
  ownerIdentifier: hash32,
  identifierType: IDENTIFIER.SCRIPT_HASH,
  amount,
  isMinter: false
});
var addressPresenceOwned = (pubkey32, amount) => ({
  ownerIdentifier: pubkey32,
  identifierType: IDENTIFIER.ADDRESS,
  amount,
  isMinter: false
});
function pushKcc20StateScalar(b, st) {
  if (st.ownerIdentifier.length !== 32) throw new Error("ownerIdentifier must be 32 bytes");
  b.data(st.ownerIdentifier).byte(st.identifierType).int(st.amount).bool(st.isMinter);
}
function pushKcc20States(b, states) {
  for (const st of states) if (st.ownerIdentifier.length !== 32) throw new Error("ownerIdentifier must be 32 bytes");
  b.column(states.map((s) => s.ownerIdentifier));
  b.column(states.map((s) => Uint8Array.of(s.identifierType)));
  b.column(states.map((s) => int8LE(s.amount)));
  b.column(states.map((s) => Uint8Array.of(s.isMinter ? 1 : 0)));
}
function transferSigScript(k, redeem, newStates, witnesses, sigs = []) {
  if (newStates.length < 1) throw new Error("transfer requires at least one output state");
  const b = new SigScriptBuilder(k);
  pushKcc20States(b, newStates);
  b.column(sigs);
  b.data(Uint8Array.from(witnesses, (w) => w & 255));
  b.redeem(redeem);
  return b.drain();
}
function buildKcc20Send(k, tpl, senderTokens, recipientPubkey32, sendAmount, presenceWitnessIdx, tokenCovid, opts = {}) {
  if (senderTokens.length < 1) throw new Error("send requires at least one token UTXO");
  if (!tokenCovid) throw new Error("send requires the token covenant id (indexer token info `covenantId`) for the output bindings");
  const total = senderTokens.reduce((s, t) => s + t.state.amount, 0n);
  const change = total - sendAmount;
  if (sendAmount < 1n || change < 0n) throw new Error(`send requires 1 <= sendAmount <= ${total} (the selected UTXOs' total)`);
  const dust = opts.tokenDust ?? 50000000n;
  const owner = senderTokens[0].state.ownerIdentifier;
  const recipientOut = addressPresenceOwned(recipientPubkey32, sendAmount);
  const newStates = change >= 1n ? [recipientOut, addressPresenceOwned(owner, change)] : [recipientOut];
  const witnesses = senderTokens.map(() => presenceWitnessIdx);
  const inputs = senderTokens.map((t) => {
    const r = materializeKcc20Script(tpl, t.state);
    return { transactionId: t.transactionId, index: t.index, value: t.value, scriptPublicKey: kcc20Spk(k, r), signatureScript: transferSigScript(k, r, newStates, witnesses), redeem: r, role: "token" };
  });
  const binding = { covid: tokenCovid, authorizingInput: 0 };
  const outputs = newStates.map((st, i) => ({
    value: dust,
    scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tpl, st)),
    role: i === 0 ? "send" : "change",
    binding
  }));
  return { kind: "transfer", inputs, outputs, economics: { sendAmount, change }, covids: { tokenCovid } };
}
var curveCpTx_exports = {};
__export2(curveCpTx_exports, {
  SCALE: () => SCALE2,
  SELECTOR: () => SELECTOR,
  buildConsolidate: () => buildConsolidate,
  buildCpBuy: () => buildCpBuy,
  buildCpGraduate: () => buildCpGraduate,
  buildCpSell: () => buildCpSell,
  buildSplitToken: () => buildSplitToken,
  cpAddress: () => cpAddress,
  cpSpk: () => cpSpk,
  cpSpkForState: () => cpSpkForState,
  materializeCpScript: () => materializeCpScript,
  p2pkSpk: () => p2pkSpk
});
var poolCpTx_exports = {};
__export2(poolCpTx_exports, {
  MAX_SHARES: () => MAX_SHARES,
  POOL_CP_SELECTOR: () => POOL_CP_SELECTOR,
  addMinDKas: () => addMinDKas,
  buildAddLiquidity: () => buildAddLiquidity,
  buildBindLp: () => buildBindLp,
  buildRemoveLiquidity: () => buildRemoveLiquidity,
  materializePoolCpScript: () => materializePoolCpScript,
  poolCpAddress: () => poolCpAddress,
  poolCpSpk: () => poolCpSpk,
  poolCpSpkForState: () => poolCpSpkForState,
  quoteAddLiquidity: () => quoteAddLiquidity,
  quotePoolCpBuy: () => quotePoolCpBuy,
  quotePoolCpSell: () => quotePoolCpSell,
  quoteRemoveLiquidity: () => quoteRemoveLiquidity,
  removeMinDShares: () => removeMinDShares,
  snapAddDKas: () => snapAddDKas,
  snapRemoveDShares: () => snapRemoveDShares
});
var POOL_CP_SELECTOR = { swapKasForToken: 0, swapTokenForKas: 1, addLiquidity: 2, removeLiquidity: 3, bindLp: 4 };
var MAX_SHARES = 10000000n;
var padFee2 = (f) => f > FEE_OUT_MIN ? f : FEE_OUT_MIN;
var ceilDiv2 = (a, b) => (a + b - 1n) / b;
var hexOf = (u8) => Array.from(u8, (b) => b.toString(16).padStart(2, "0")).join("");
function materializePoolCpScript(tpl, state) {
  const s = tpl.stateStart;
  const t = tpl.script;
  if (t[s] !== 8 || t[s + 9] !== 8 || t[s + 18] !== 32 || t[s + 51] !== 8 || t[s + 60] !== 32) {
    throw new Error("pool template has an unexpected state layout (expected kasReserve/tokenReserve/tokenCovid/totalShares/lpCovid)");
  }
  if (state.kasReserve < 0n || state.tokenReserve < 0n || state.totalShares < 0n) throw new Error("reserves/shares must be non-negative");
  if (state.tokenCovid.length !== 32) throw new Error("tokenCovid must be 32 bytes");
  if (state.lpCovid.length !== 32) throw new Error("lpCovid must be 32 bytes");
  const out = t.slice();
  out[s] = 8;
  out.set(int8LE(state.kasReserve), s + 1);
  out[s + 9] = 8;
  out.set(int8LE(state.tokenReserve), s + 10);
  out[s + 18] = 32;
  out.set(state.tokenCovid, s + 19);
  out[s + 51] = 8;
  out.set(int8LE(state.totalShares), s + 52);
  out[s + 60] = 32;
  out.set(state.lpCovid, s + 61);
  return out;
}
var poolCpSpk = (k, redeem) => k.payToScriptHashScript(redeem);
var poolCpSpkForState = (k, tpl, state) => poolCpSpk(k, materializePoolCpScript(tpl, state));
function poolCpAddress(k, tpl, state, network) {
  return k.addressFromScriptPublicKey(poolCpSpkForState(k, tpl, state), network)?.toString() ?? "";
}
function retainKasUnits(kasUnits, state, p) {
  const weight = p.lpFeeBps * (state.totalShares - p.lockedShares);
  if (weight <= 0n) return 0n;
  return ceilDiv2(kasUnits * weight, 10000n * state.totalShares);
}
function quotePoolCpBuy(state, p, kasInSompi) {
  const kasInUnits = kasInSompi / SCALE;
  const kasIn = kasInUnits * SCALE;
  if (kasInUnits <= 0n) return null;
  const newKas = state.kasReserve + kasInUnits;
  const oldK = state.kasReserve * state.tokenReserve;
  const retainKas = retainKasUnits(kasInUnits, state, p);
  const effKas = newKas - retainKas;
  if (effKas <= 0n) return null;
  const newToken = ceilDiv2(oldK, effKas);
  const tokenOut = state.tokenReserve - newToken;
  if (tokenOut <= 0n) return null;
  const creatorFee = kasIn * p.creatorFeeBps / 10000n;
  const platformFee = kasIn * p.platformFeeBps / 10000n;
  const lpFee = kasIn * p.lpFeeBps / 10000n;
  const creatorFloorRent = lpFee * p.lockedShares / state.totalShares;
  const creatorOut = padFee2(creatorFee + creatorFloorRent);
  const platformOut = padFee2(platformFee);
  return { kasInUnits, kasIn, tokenOut, creatorFee, creatorFloorRent, platformFee, lpFee, creatorOut, platformOut, total: kasIn + creatorOut + platformOut, newKas, newToken };
}
function quotePoolCpSell(state, p, tokenIn) {
  if (tokenIn <= 0n) return null;
  const newToken = state.tokenReserve + tokenIn;
  const oldK = state.kasReserve * state.tokenReserve;
  const effMin = ceilDiv2(oldK, newToken);
  const budget = state.kasReserve - effMin;
  if (budget <= 0n) return null;
  const g = (x) => x + retainKasUnits(x, state, p);
  const vol = state.totalShares - p.lockedShares;
  const denom = 10000n * state.totalShares + p.lpFeeBps * vol;
  let kasOutUnits = budget * 10000n * state.totalShares / denom;
  while (kasOutUnits > 0n && g(kasOutUnits) > budget) kasOutUnits -= 1n;
  while (g(kasOutUnits + 1n) <= budget) kasOutUnits += 1n;
  const newKas = state.kasReserve - kasOutUnits;
  if (kasOutUnits <= 0n || newKas < 1n) return null;
  const kasOut = kasOutUnits * SCALE;
  const creatorFee = kasOut * p.creatorFeeBps / 10000n;
  const platformFee = kasOut * p.platformFeeBps / 10000n;
  const lpFee = kasOut * p.lpFeeBps / 10000n;
  const creatorFloorRent = lpFee * p.lockedShares / state.totalShares;
  const creatorOut = padFee2(creatorFee + creatorFloorRent);
  const platformOut = padFee2(platformFee);
  if (kasOut - creatorOut - platformOut <= 0n) return null;
  return { tokenIn, kasOutUnits, kasOut, creatorFee, creatorFloorRent, platformFee, lpFee, creatorOut, platformOut, net: kasOut - creatorOut - platformOut, newKas, newToken };
}
function addMinDKas(state) {
  return (state.kasReserve + state.totalShares - 1n) / state.totalShares;
}
function snapAddDKas(state, desiredDKas) {
  const min = addMinDKas(state);
  if (min <= 0n || desiredDKas < min) return 0n;
  return desiredDKas;
}
function quoteAddLiquidity(state, dKas) {
  if (dKas <= 0n) throw new Error("dKas must be positive");
  const dShares = state.totalShares * dKas / state.kasReserve;
  if (dShares <= 0n) throw new Error("dKas too small to mint an integer LP share (snap with snapAddDKas / addMinDKas first)");
  const dToken = (state.tokenReserve * dShares + state.totalShares - 1n) / state.totalShares;
  return { dKas, dToken, dShares, newKas: state.kasReserve + dKas, newToken: state.tokenReserve + dToken, newShares: state.totalShares + dShares };
}
function removeMinDShares(state) {
  const ceilDiv3 = (a, b) => (a + b - 1n) / b;
  const minKas = ceilDiv3(state.totalShares, state.kasReserve);
  const minTok = ceilDiv3(state.totalShares, state.tokenReserve);
  return minKas < minTok ? minKas : minTok;
}
function snapRemoveDShares(state, desiredDShares) {
  if (desiredDShares <= 0n || desiredDShares < removeMinDShares(state)) return 0n;
  return desiredDShares;
}
function quoteRemoveLiquidity(state, p, dShares) {
  if (dShares <= 0n) throw new Error("dShares must be positive");
  if (state.totalShares - dShares < p.lockedShares) throw new Error("removal would dip below the permanently-locked floor");
  const dKas = state.kasReserve * dShares / state.totalShares;
  const dToken = state.tokenReserve * dShares / state.totalShares;
  if (dKas === 0n && dToken === 0n) throw new Error("withdrawal too small: both payout sides round to zero");
  return { dShares, dKas, dToken, newKas: state.kasReserve - dKas, newToken: state.tokenReserve - dToken, newShares: state.totalShares - dShares };
}
function addLiquiditySig(k, redeem, dKas, dToken, dShares, poolTokenOut, poolLpOut, lpSharesOut) {
  const b = new SigScriptBuilder(k).int(dKas).int(dToken).int(dShares);
  pushKcc20StateScalar(b, poolTokenOut);
  pushKcc20StateScalar(b, poolLpOut);
  pushKcc20StateScalar(b, lpSharesOut);
  return b.selector(POOL_CP_SELECTOR.addLiquidity).redeem(redeem).drain();
}
function removeLiquiditySig(k, redeem, dShares, dKas, dToken, poolTokenOut, lpTokenOut, poolLpOut) {
  const b = new SigScriptBuilder(k).int(dShares).int(dKas).int(dToken);
  pushKcc20StateScalar(b, poolTokenOut);
  pushKcc20StateScalar(b, lpTokenOut);
  pushKcc20StateScalar(b, poolLpOut);
  return b.selector(POOL_CP_SELECTOR.removeLiquidity).redeem(redeem).drain();
}
function buildAddLiquidity(k, tpl, tokenTpl, utxo, lpInventory, poolCovid, lpDepositToken, lpPubkey, q, presenceWitnessIdx, opts = {}) {
  if ("lpBindVerified" in opts && opts.lpBindVerified !== true) {
    throw new Error(`Refusing to build addLiquidity: pool LP-bind integrity is ${opts.lpBindVerified === false ? "FAILED (counterfeit shares could drain your deposit)" : "UNVERIFIED"}. Gate on IndexerClient.assertLpBindSafe(tick) before building.`);
  }
  if (lpDepositToken.state.amount !== q.dToken) throw new Error("LP deposit token UTXO must equal dToken exactly (split first)");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const { kasReserve, tokenReserve, tokenCovid, lpCovid } = utxo.state;
  const poolCovidHex = hexOf(poolCovid);
  const tokenCovidHex = hexOf(tokenCovid);
  const lpCovidHex = hexOf(lpCovid);
  const poolTokenOut = covenantIdOwned(poolCovid, q.newToken, false);
  const poolLpOut = covenantIdOwned(poolCovid, lpInventory.amount - q.dShares, false);
  const lpSharesOut = addressPresenceOwned(lpPubkey, q.dShares);
  const curRedeem = materializePoolCpScript(tpl, utxo.state);
  const newRedeem = materializePoolCpScript(tpl, { kasReserve: q.newKas, tokenReserve: q.newToken, tokenCovid, totalShares: q.newShares, lpCovid });
  const lpDepositRedeem = materializeKcc20Script(tokenTpl, lpDepositToken.state);
  const poolAResRedeem = materializeKcc20Script(tokenTpl, covenantIdOwned(poolCovid, tokenReserve, false));
  const poolLpInvRedeem = materializeKcc20Script(tokenTpl, covenantIdOwned(poolCovid, lpInventory.amount, false));
  const aStates = [poolTokenOut];
  const aWitnesses = [presenceWitnessIdx, 0];
  const lStates = [poolLpOut, lpSharesOut];
  const lWitnesses = [0];
  const inputs = [
    { transactionId: utxo.transactionId, index: utxo.index, value: kasReserve * SCALE, scriptPublicKey: poolCpSpk(k, curRedeem), signatureScript: addLiquiditySig(k, curRedeem, q.dKas, q.dToken, q.dShares, poolTokenOut, poolLpOut, lpSharesOut), redeem: curRedeem, role: "pool" },
    { transactionId: lpDepositToken.transactionId, index: lpDepositToken.index, value: lpDepositToken.value, scriptPublicKey: kcc20Spk(k, lpDepositRedeem), signatureScript: transferSigScript(k, lpDepositRedeem, aStates, aWitnesses), redeem: lpDepositRedeem, role: "lpDeposit" },
    { transactionId: utxo.tokenUtxo.transactionId, index: utxo.tokenUtxo.index, value: utxo.tokenUtxo.value, scriptPublicKey: kcc20Spk(k, poolAResRedeem), signatureScript: transferSigScript(k, poolAResRedeem, aStates, aWitnesses), redeem: poolAResRedeem, role: "poolToken" },
    { transactionId: lpInventory.transactionId, index: lpInventory.index, value: lpInventory.value, scriptPublicKey: kcc20Spk(k, poolLpInvRedeem), signatureScript: transferSigScript(k, poolLpInvRedeem, lStates, lWitnesses), redeem: poolLpInvRedeem, role: "poolLpInventory" }
  ];
  const outputs = [
    { value: q.newKas * SCALE, scriptPublicKey: poolCpSpk(k, newRedeem), role: "pool", binding: { covid: poolCovidHex, authorizingInput: 0 } },
    { value: continuationValue(dust, utxo.tokenUtxo.value), scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, poolTokenOut)), role: "poolToken", binding: { covid: tokenCovidHex, authorizingInput: 2 } },
    { value: continuationValue(dust, lpInventory.value), scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, poolLpOut)), role: "poolLpInventory", binding: { covid: lpCovidHex, authorizingInput: 3 } },
    { value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, lpSharesOut)), role: "lpShares", binding: { covid: lpCovidHex, authorizingInput: 3 } }
  ];
  return { kind: "addLiquidity", inputs, outputs, economics: { dKas: q.dKas, dToken: q.dToken, dShares: q.dShares, newShares: q.newShares }, covids: { poolCovid: poolCovidHex, tokenCovid: tokenCovidHex } };
}
function buildRemoveLiquidity(k, tpl, tokenTpl, utxo, lpShares, poolCovid, lpPubkey, q, presenceWitnessIdx, opts = {}) {
  if (lpShares.state.amount !== q.dShares) throw new Error("LP shares UTXO must equal dShares exactly (split first)");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const { kasReserve, tokenReserve, tokenCovid, lpCovid } = utxo.state;
  const poolCovidHex = hexOf(poolCovid);
  const tokenCovidHex = hexOf(tokenCovid);
  const lpCovidHex = hexOf(lpCovid);
  const canonical = !!tpl.canonicalInventoryRequired;
  const lpInventory = opts.lpInventory;
  if (canonical && (!lpInventory || lpInventory.amount !== MAX_SHARES - utxo.state.totalShares)) {
    throw new Error("removeLiquidity requires the canonical pool LP inventory (pass opts.lpInventory equal to MAX_SHARES - totalShares)");
  }
  const poolTokenOut = covenantIdOwned(poolCovid, q.newToken, false);
  const lpTokenOut = addressPresenceOwned(lpPubkey, q.dToken);
  const poolLpOut = covenantIdOwned(poolCovid, canonical ? MAX_SHARES - q.newShares : q.dShares, false);
  const curRedeem = materializePoolCpScript(tpl, utxo.state);
  const newRedeem = materializePoolCpScript(tpl, { kasReserve: q.newKas, tokenReserve: q.newToken, tokenCovid, totalShares: q.newShares, lpCovid });
  const poolAResRedeem = materializeKcc20Script(tokenTpl, covenantIdOwned(poolCovid, tokenReserve, false));
  const lpSharesRedeem = materializeKcc20Script(tokenTpl, lpShares.state);
  const poolLpInvRedeem = canonical ? materializeKcc20Script(tokenTpl, covenantIdOwned(poolCovid, lpInventory.amount, false)) : null;
  const aStates = q.dToken > 0n ? [poolTokenOut, lpTokenOut] : [poolTokenOut];
  const aWitnesses = [0];
  const lStates = [poolLpOut];
  const lWitnesses = canonical ? [0, presenceWitnessIdx] : [presenceWitnessIdx];
  const inputs = [
    { transactionId: utxo.transactionId, index: utxo.index, value: kasReserve * SCALE, scriptPublicKey: poolCpSpk(k, curRedeem), signatureScript: removeLiquiditySig(k, curRedeem, q.dShares, q.dKas, q.dToken, poolTokenOut, lpTokenOut, poolLpOut), redeem: curRedeem, role: "pool" },
    { transactionId: utxo.tokenUtxo.transactionId, index: utxo.tokenUtxo.index, value: utxo.tokenUtxo.value, scriptPublicKey: kcc20Spk(k, poolAResRedeem), signatureScript: transferSigScript(k, poolAResRedeem, aStates, aWitnesses), redeem: poolAResRedeem, role: "poolToken" },
    ...canonical ? [{ transactionId: lpInventory.transactionId, index: lpInventory.index, value: lpInventory.value, scriptPublicKey: kcc20Spk(k, poolLpInvRedeem), signatureScript: transferSigScript(k, poolLpInvRedeem, lStates, lWitnesses), redeem: poolLpInvRedeem, role: "poolLpInventory" }] : [],
    { transactionId: lpShares.transactionId, index: lpShares.index, value: lpShares.value, scriptPublicKey: kcc20Spk(k, lpSharesRedeem), signatureScript: transferSigScript(k, lpSharesRedeem, lStates, lWitnesses), redeem: lpSharesRedeem, role: "lpShares" }
  ];
  const outputs = [
    { value: q.newKas * SCALE, scriptPublicKey: poolCpSpk(k, newRedeem), role: "pool", binding: { covid: poolCovidHex, authorizingInput: 0 } },
    { value: continuationValue(dust, utxo.tokenUtxo.value), scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, poolTokenOut)), role: "poolToken", binding: { covid: tokenCovidHex, authorizingInput: 1 } },
    ...q.dToken > 0n ? [{ value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, lpTokenOut)), role: "lpToken", binding: { covid: tokenCovidHex, authorizingInput: 1 } }] : [],
    { value: canonical ? continuationValue(dust, lpInventory.value) : dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, poolLpOut)), role: "poolLpInventory", binding: { covid: lpCovidHex, authorizingInput: 2 } }
  ];
  return { kind: "removeLiquidity", inputs, outputs, economics: { dShares: q.dShares, dKas: q.dKas, dToken: q.dToken, newShares: q.newShares }, covids: { poolCovid: poolCovidHex, tokenCovid: tokenCovidHex } };
}
function buildBindLp(k, tpl, tokenTpl, utxo, poolCovid, lockedShares, opts = {}) {
  if (utxo.state.lpCovid.length !== 32 || !utxo.state.lpCovid.every((b2) => b2 === 0)) throw new Error("pool lpCovid is already bound \u2014 bindLp is one-time");
  if (lockedShares < 1n || lockedShares >= MAX_SHARES) throw new Error("lockedShares out of range");
  if (utxo.state.totalShares !== lockedShares) throw new Error("bindLp requires totalShares == lockedShares (graduation state)");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const { kasReserve, tokenReserve, tokenCovid } = utxo.state;
  const inventoryAmount = MAX_SHARES - lockedShares;
  const lpInventory = covenantIdOwned(poolCovid, inventoryAmount, false);
  const invSpk = kcc20Spk(k, materializeKcc20Script(tokenTpl, lpInventory));
  const lpCovidHex = genesisCovenantId(k, { transactionId: utxo.transactionId, index: utxo.index }, [
    { index: 1, value: dust, scriptPublicKey: invSpk }
  ]);
  const boundLp = covidToBytes(lpCovidHex);
  const curRedeem = materializePoolCpScript(tpl, utxo.state);
  const boundRedeem = materializePoolCpScript(tpl, { kasReserve, tokenReserve, tokenCovid, totalShares: lockedShares, lpCovid: boundLp });
  const poolValue = kasReserve * SCALE;
  const b = new SigScriptBuilder(k);
  pushKcc20StateScalar(b, lpInventory);
  const bindSig = b.selector(POOL_CP_SELECTOR.bindLp).redeem(curRedeem).drain();
  const inputs = [
    { transactionId: utxo.transactionId, index: utxo.index, value: poolValue, scriptPublicKey: poolCpSpk(k, curRedeem), signatureScript: bindSig, redeem: curRedeem, role: "pool" }
  ];
  const poolCovidHex = hexOf(poolCovid);
  const outputs = [
    { value: poolValue, scriptPublicKey: poolCpSpk(k, boundRedeem), role: "pool", binding: { covid: poolCovidHex, authorizingInput: 0 } },
    { value: dust, scriptPublicKey: invSpk, role: "lpInventory", binding: { covid: lpCovidHex, authorizingInput: 0 } }
  ];
  return { kind: "bindLp", inputs, outputs, economics: { lockedShares, inventoryAmount }, covids: { poolCovid: poolCovidHex, tokenCovid: hexOf(tokenCovid) }, lpCovidHex, lpInventoryAmount: inventoryAmount };
}
var SCALE2 = 1000000n;
var padFee3 = (f) => f > FEE_OUT_MIN ? f : FEE_OUT_MIN;
var SELECTOR = { init: 0, buy: 1, sell: 2, graduate: 3, initVested: 4 };
var ZERO32 = new Uint8Array(32);
var devFundLeg = (p) => p.devFundOwner && p.devFundBps != null ? { owner: p.devFundOwner, bps: p.devFundBps } : null;
function materializeCpScript(tpl, state) {
  const s = tpl.stateStart;
  const t = tpl.script;
  if (t[s] !== 1 || t[s + 2] !== 32 || t[s + 35] !== 8) {
    throw new Error("curve_cp template has an unexpected state layout (expected push1 graduated / push32 tokenCovid / push8 tokenReserve)");
  }
  if (state.tokenCovid.length !== 32) throw new Error("tokenCovid must be 32 bytes");
  if (state.tokenReserve < 0n) throw new Error("tokenReserve must be non-negative");
  const out = t.slice();
  out[s] = 1;
  out[s + 1] = state.graduated ? 1 : 0;
  out[s + 2] = 32;
  out.set(state.tokenCovid, s + 3);
  out[s + 35] = 8;
  out.set(int8LE(state.tokenReserve), s + 36);
  return out;
}
var cpSpk = (k, redeem) => k.payToScriptHashScript(redeem);
var cpSpkForState = (k, tpl, state) => cpSpk(k, materializeCpScript(tpl, state));
function cpAddress(k, tpl, state, network) {
  return k.addressFromScriptPublicKey(cpSpkForState(k, tpl, state), network)?.toString() ?? "";
}
function p2pkSpk(k, pubkey) {
  const sb = new k.ScriptBuilder();
  sb.addData(pubkey).addOp(172);
  return new k.ScriptPublicKey(0, sb.drain());
}
function buySig(k, redeem, kasIn, tokenOut, inventoryOut, buyerOut) {
  const b = new SigScriptBuilder(k).int(kasIn).int(tokenOut);
  pushKcc20StateScalar(b, inventoryOut);
  pushKcc20StateScalar(b, buyerOut);
  return b.selector(SELECTOR.buy).redeem(redeem).drain();
}
function sellSig(k, redeem, tokenIn, kasOut, inventoryOut, traderChangeOut) {
  const b = new SigScriptBuilder(k).int(tokenIn).int(kasOut);
  pushKcc20StateScalar(b, inventoryOut);
  pushKcc20StateScalar(b, traderChangeOut);
  return b.selector(SELECTOR.sell).redeem(redeem).drain();
}
function graduateSigV2(k, redeem, pool, poolTokens) {
  const b = new SigScriptBuilder(k).int(pool.kasReserve).int(pool.tokenReserve).data(pool.tokenCovid).int(pool.totalShares).data(pool.lpCovid);
  pushKcc20StateScalar(b, poolTokens);
  return b.selector(SELECTOR.graduate).redeem(redeem).drain();
}
function buildCpBuy(k, tpl, tokenTpl, utxo, inventory, curveCovid, buyerPubkey, kasIn, tokenOut, mergeTokens = [], presenceWitnessIdx = 0, opts = {}) {
  if (utxo.state.graduated) throw new Error("curve has graduated \u2014 buys are locked");
  if (kasIn <= 0n || kasIn % SCALE2 !== 0n) throw new Error("kasIn must be a positive multiple of SCALE (0.01 KAS)");
  if (tokenOut <= 0n || tokenOut >= inventory.amount) throw new Error("invalid tokenOut");
  if (inventory.amount !== utxo.state.tokenReserve) throw new Error("inventory.amount must equal the curve's committed tokenReserve");
  if (mergeTokens.length > 0 && presenceWitnessIdx === 0) throw new Error("presenceWitnessIdx must be set to a co-present signed P2PK funding input when mergeTokens is non-empty (input 0 is the curve covenant and carries no signature)");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const curveCovidHex = hexOf2(curveCovid);
  const tokenCovidHex = hexOf2(utxo.state.tokenCovid);
  const newKas = utxo.realKas + kasIn;
  if (newKas > MAX_KAS) throw new Error("buy exceeds the curve max raise (9,000,000 TKAS)");
  const newToken = inventory.amount - tokenOut;
  const creatorFee = kasIn * tpl.params.creatorFeeBps / 10000n;
  const platformFee = kasIn * tpl.params.platformFeeBps / 10000n;
  const devFund = devFundLeg(tpl.params);
  const devFundFee = devFund ? kasIn * devFund.bps / 10000n : 0n;
  const mergeSum = mergeTokens.reduce((s, t) => s + t.state.amount, 0n);
  const inventoryOut = covenantIdOwned(curveCovid, newToken, false);
  const buyerOut = addressPresenceOwned(buyerPubkey, tokenOut + mergeSum);
  const curRedeem = materializeCpScript(tpl, utxo.state);
  const newCurveRedeem = materializeCpScript(tpl, { graduated: false, tokenCovid: utxo.state.tokenCovid, tokenReserve: newToken });
  const invRedeem = materializeKcc20Script(tokenTpl, covenantIdOwned(curveCovid, inventory.amount, false));
  const invOutRedeem = materializeKcc20Script(tokenTpl, inventoryOut);
  const buyerRedeem = materializeKcc20Script(tokenTpl, buyerOut);
  const witnesses = [0, ...mergeTokens.map(() => presenceWitnessIdx)];
  const newStates = [inventoryOut, buyerOut];
  const inputs = [
    { transactionId: utxo.transactionId, index: utxo.index, value: utxo.realKas, scriptPublicKey: cpSpk(k, curRedeem), signatureScript: buySig(k, curRedeem, kasIn, tokenOut, inventoryOut, buyerOut), redeem: curRedeem, role: "curve" },
    // inventory (covid A, C-owned) spent via kcc20 transfer; the C-owned input is authorized by the curve (input 0)
    { transactionId: inventory.transactionId, index: inventory.index, value: inventory.value, scriptPublicKey: kcc20Spk(k, invRedeem), signatureScript: transferSigScript(k, invRedeem, newStates, witnesses), redeem: invRedeem, role: "inventory" },
    ...mergeTokens.map((mt) => {
      const r = materializeKcc20Script(tokenTpl, mt.state);
      return { transactionId: mt.transactionId, index: mt.index, value: mt.value, scriptPublicKey: kcc20Spk(k, r), signatureScript: transferSigScript(k, r, newStates, witnesses), redeem: r, role: "buyerToken" };
    })
  ];
  const outputs = [
    { value: newKas, scriptPublicKey: cpSpk(k, newCurveRedeem), role: "curve", binding: { covid: curveCovidHex, authorizingInput: 0 } },
    { value: continuationValue(dust, inventory.value), scriptPublicKey: kcc20Spk(k, invOutRedeem), role: "inventory", binding: { covid: tokenCovidHex, authorizingInput: 1 } },
    { value: dust, scriptPublicKey: kcc20Spk(k, buyerRedeem), role: "recipient", binding: { covid: tokenCovidHex, authorizingInput: 1 } },
    { value: padFee3(creatorFee), scriptPublicKey: p2pkSpk(k, tpl.params.creatorFeeOwner), role: "creatorFee" },
    { value: padFee3(platformFee), scriptPublicKey: p2pkSpk(k, tpl.params.platformFeeOwner), role: "platformFee" }
  ];
  if (devFund) outputs.push({ value: padFee3(devFundFee), scriptPublicKey: p2pkSpk(k, devFund.owner), role: "devFundFee" });
  return { kind: "buy", inputs, outputs, economics: { kasIn, tokenOut, creatorFee, platformFee, devFundFee, newRealKas: newKas, newTokenReserve: newToken, merged: mergeSum }, covids: { tokenCovid: tokenCovidHex } };
}
function buildCpSell(k, tpl, tokenTpl, utxo, sellerTokens, inventory, curveCovid, traderPubkey, tokenIn, kasOut, presenceWitnessIdx, opts = {}) {
  if (utxo.state.graduated) throw new Error("curve has graduated \u2014 sells are locked");
  if (sellerTokens.length < 1) throw new Error("need at least one seller token");
  if (tokenIn <= 0n) throw new Error("tokenIn must be positive");
  if (kasOut <= 0n || kasOut % SCALE2 !== 0n || kasOut > utxo.realKas) throw new Error("invalid kasOut");
  if (inventory.amount !== utxo.state.tokenReserve) throw new Error("inventory.amount must equal the curve's committed tokenReserve");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const curveCovidHex = hexOf2(curveCovid);
  const tokenCovidHex = hexOf2(utxo.state.tokenCovid);
  const sellerIn = sellerTokens.reduce((s, t) => s + t.state.amount, 0n);
  const change = sellerIn - tokenIn;
  if (change < 0n) throw new Error("seller inputs are less than the sell amount");
  const hasChange = change > 0n;
  const newToken = inventory.amount + tokenIn;
  const creatorFee = kasOut * tpl.params.creatorFeeBps / 10000n;
  const platformFee = kasOut * tpl.params.platformFeeBps / 10000n;
  const devFund = devFundLeg(tpl.params);
  const devFundFee = devFund ? kasOut * devFund.bps / 10000n : 0n;
  const inventoryOut = covenantIdOwned(curveCovid, newToken, false);
  const traderChangeOut = addressPresenceOwned(traderPubkey, hasChange ? change : 1n);
  const curRedeem = materializeCpScript(tpl, utxo.state);
  const newCurveRedeem = materializeCpScript(tpl, { graduated: false, tokenCovid: utxo.state.tokenCovid, tokenReserve: newToken });
  const invRedeem = materializeKcc20Script(tokenTpl, covenantIdOwned(curveCovid, inventory.amount, false));
  const invOutRedeem = materializeKcc20Script(tokenTpl, inventoryOut);
  const witnesses = [0, ...sellerTokens.map(() => presenceWitnessIdx)];
  const newStates = hasChange ? [inventoryOut, traderChangeOut] : [inventoryOut];
  const inputs = [
    { transactionId: utxo.transactionId, index: utxo.index, value: utxo.realKas, scriptPublicKey: cpSpk(k, curRedeem), signatureScript: sellSig(k, curRedeem, tokenIn, kasOut, inventoryOut, traderChangeOut), redeem: curRedeem, role: "curve" },
    { transactionId: inventory.transactionId, index: inventory.index, value: inventory.value, scriptPublicKey: kcc20Spk(k, invRedeem), signatureScript: transferSigScript(k, invRedeem, newStates, witnesses), redeem: invRedeem, role: "inventory" },
    ...sellerTokens.map((st) => {
      const r = materializeKcc20Script(tokenTpl, st.state);
      return { transactionId: st.transactionId, index: st.index, value: st.value, scriptPublicKey: kcc20Spk(k, r), signatureScript: transferSigScript(k, r, newStates, witnesses), redeem: r, role: "sellerToken" };
    })
  ];
  const outputs = [
    { value: utxo.realKas - kasOut, scriptPublicKey: cpSpk(k, newCurveRedeem), role: "curve", binding: { covid: curveCovidHex, authorizingInput: 0 } },
    { value: continuationValue(dust, inventory.value), scriptPublicKey: kcc20Spk(k, invOutRedeem), role: "inventory", binding: { covid: tokenCovidHex, authorizingInput: 1 } },
    { value: padFee3(creatorFee), scriptPublicKey: p2pkSpk(k, tpl.params.creatorFeeOwner), role: "creatorFee" },
    { value: padFee3(platformFee), scriptPublicKey: p2pkSpk(k, tpl.params.platformFeeOwner), role: "platformFee" }
  ];
  if (devFund) outputs.push({ value: padFee3(devFundFee), scriptPublicKey: p2pkSpk(k, devFund.owner), role: "devFundFee" });
  if (hasChange) outputs.push({ value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, traderChangeOut)), role: "seller", binding: { covid: tokenCovidHex, authorizingInput: 1 } });
  return { kind: "sell", inputs, outputs, economics: { tokenIn, kasOut, change, creatorFee, platformFee, devFundFee, newRealKas: utxo.realKas - kasOut, newTokenReserve: newToken }, covids: { tokenCovid: tokenCovidHex } };
}
function buildCpGraduate(k, tpl, tokenTpl, poolTemplate, utxo, inventory, curveCovid, poolLockedShares, opts = {}) {
  if (utxo.state.graduated) throw new Error("already graduated");
  if (utxo.realKas < tpl.params.graduationKas) throw new Error("reserve has not reached the graduation target");
  if (poolLockedShares < 1n) throw new Error("poolLockedShares must be >= 1");
  if (inventory.amount !== utxo.state.tokenReserve) throw new Error("inventory.amount must equal the curve's committed tokenReserve");
  const lockedValue = opts.lockedCurveValue ?? 1000n;
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const targetPoolKas = utxo.realKas * (10000n - tpl.params.graduationFeeBps) / 10000n;
  const poolKasUnits = targetPoolKas / SCALE2;
  const poolKas = poolKasUnits * SCALE2;
  const gradFee = utxo.realKas - poolKas;
  const leftover = inventory.amount;
  const A = utxo.state.tokenCovid;
  const poolState = { kasReserve: poolKasUnits, tokenReserve: leftover, tokenCovid: A, totalShares: poolLockedShares, lpCovid: ZERO32 };
  const poolRedeem = materializePoolCpScript(poolTemplate, poolState);
  const poolSpkV = k.payToScriptHashScript(poolRedeem);
  const poolCovidHex = genesisCovenantId(k, { transactionId: utxo.transactionId, index: utxo.index }, [
    { index: 1, value: poolKas, scriptPublicKey: poolSpkV }
  ]);
  const poolCovid = covidToBytes(poolCovidHex);
  const poolTokens = covenantIdOwned(poolCovid, leftover, false);
  const poolTokenRedeem = materializeKcc20Script(tokenTpl, poolTokens);
  const curRedeem = materializeCpScript(tpl, utxo.state);
  const lockedRedeem = materializeCpScript(tpl, { graduated: true, tokenCovid: A, tokenReserve: inventory.amount });
  const invRedeem = materializeKcc20Script(tokenTpl, covenantIdOwned(curveCovid, inventory.amount, false));
  const inputs = [
    { transactionId: utxo.transactionId, index: utxo.index, value: utxo.realKas, scriptPublicKey: cpSpk(k, curRedeem), signatureScript: graduateSigV2(k, curRedeem, poolState, poolTokens), redeem: curRedeem, role: "curve" },
    { transactionId: inventory.transactionId, index: inventory.index, value: inventory.value, scriptPublicKey: kcc20Spk(k, invRedeem), signatureScript: transferSigScript(k, invRedeem, [poolTokens], [0]), redeem: invRedeem, role: "inventory" }
  ];
  const curveCovidHex = hexOf2(curveCovid);
  const tokenCovidHex = hexOf2(A);
  const outputs = [
    { value: lockedValue, scriptPublicKey: cpSpk(k, lockedRedeem), role: "curve", binding: { covid: curveCovidHex, authorizingInput: 0 } },
    { value: poolKas, scriptPublicKey: poolSpkV, role: "pool", binding: { covid: poolCovidHex, authorizingInput: 0 } },
    { value: continuationValue(dust, inventory.value), scriptPublicKey: kcc20Spk(k, poolTokenRedeem), role: "poolToken", binding: { covid: tokenCovidHex, authorizingInput: 1 } },
    { value: padFee3(gradFee), scriptPublicKey: p2pkSpk(k, tpl.params.platformFeeOwner), role: "gradFee" }
  ];
  return { kind: "graduate", inputs, outputs, economics: { poolKas, gradFee, leftover, poolLockedShares }, covids: { tokenCovid: hexOf2(A), poolCovid: poolCovidHex } };
}
function buildSplitToken(k, tokenTpl, sellerToken, sellAmount, presenceWitnessIdx, opts = {}) {
  if (!opts.tokenCovid) throw new Error("opts.tokenCovid is required (the token covenant id, hex) \u2014 both outputs need the KIP-20 covenant binding or the assembled tx fails on-chain");
  const change = sellerToken.state.amount - sellAmount;
  if (sellAmount <= 0n || change <= 0n) throw new Error("split requires 0 < sellAmount < the UTXO amount");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const owner = sellerToken.state.ownerIdentifier;
  const out1 = addressPresenceOwned(owner, sellAmount);
  const out2 = addressPresenceOwned(owner, change);
  const redeem = materializeKcc20Script(tokenTpl, sellerToken.state);
  const binding = opts.tokenCovid ? { covid: opts.tokenCovid, authorizingInput: 0 } : void 0;
  const inputs = [
    { transactionId: sellerToken.transactionId, index: sellerToken.index, value: sellerToken.value, scriptPublicKey: kcc20Spk(k, redeem), signatureScript: transferSigScript(k, redeem, [out1, out2], [presenceWitnessIdx]), redeem, role: "sellerToken" }
  ];
  const outputs = [
    { value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, out1)), role: "split", binding },
    { value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, out2)), role: "change", binding }
  ];
  return { kind: "sell", inputs, outputs, economics: { sellAmount, change }, covids: opts.tokenCovid ? { tokenCovid: opts.tokenCovid } : {} };
}
function buildConsolidate(k, tokenTpl, tokens, presenceWitnessIdx, opts = {}) {
  if (!opts.tokenCovid) throw new Error("opts.tokenCovid is required (the token covenant id, hex) \u2014 the merged output needs the KIP-20 covenant binding or the assembled tx fails on-chain");
  if (tokens.length < 2) throw new Error("consolidate needs at least 2 UTXOs");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const owner = tokens[0].state.ownerIdentifier;
  const total = tokens.reduce((s, t) => s + t.state.amount, 0n);
  const merged = addressPresenceOwned(owner, total);
  const newStates = [merged];
  const witnesses = tokens.map(() => presenceWitnessIdx);
  const inputs = tokens.map((t) => {
    const r = materializeKcc20Script(tokenTpl, t.state);
    return { transactionId: t.transactionId, index: t.index, value: t.value, scriptPublicKey: kcc20Spk(k, r), signatureScript: transferSigScript(k, r, newStates, witnesses), redeem: r, role: "token" };
  });
  const binding = opts.tokenCovid ? { covid: opts.tokenCovid, authorizingInput: 0 } : void 0;
  const outputs = [
    { value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, merged)), role: "merged", binding }
  ];
  return { kind: "sell", inputs, outputs, economics: { total }, covids: opts.tokenCovid ? { tokenCovid: opts.tokenCovid } : {} };
}
var hexOf2 = (u8) => Array.from(u8, (b) => b.toString(16).padStart(2, "0")).join("");
var poolCpV3Tx_exports = {};
__export2(poolCpV3Tx_exports, {
  POOL_V3_SELECTOR: () => POOL_V3_SELECTOR,
  buildPoolV3SwapKasForToken: () => buildPoolV3SwapKasForToken,
  buildPoolV3SwapTokenForKas: () => buildPoolV3SwapTokenForKas,
  materializePoolCpV3Script: () => materializePoolCpV3Script,
  poolCpV3Address: () => poolCpV3Address,
  poolCpV3Spk: () => poolCpV3Spk,
  poolCpV3SpkForState: () => poolCpV3SpkForState,
  quotePoolV3Buy: () => quotePoolV3Buy,
  quotePoolV3Sell: () => quotePoolV3Sell
});
var materializePoolCpV3Script = materializePoolCpScript;
var poolCpV3Spk = poolCpSpk;
var poolCpV3SpkForState = poolCpSpkForState;
var poolCpV3Address = poolCpAddress;
var quotePoolV3Buy = quotePoolCpBuy;
var quotePoolV3Sell = quotePoolCpSell;
var POOL_V3_SELECTOR = { swapKasForToken: 0, swapTokenForKas: 1, addLiquidity: 2, removeLiquidity: 3, bindLp: 4 };
var hexOf3 = (u8) => Array.from(u8, (b) => b.toString(16).padStart(2, "0")).join("");
var p2pkSpk2 = (k, pubkey) => {
  const sb = new k.ScriptBuilder();
  sb.addData(pubkey).addOp(172);
  return new k.ScriptPublicKey(0, sb.drain());
};
function v3SwapBuySig(k, redeem, kasInUnits, tokenOut, poolTokenOut, traderTokenOut) {
  const b = new SigScriptBuilder(k).int(kasInUnits).int(tokenOut);
  pushKcc20StateScalar(b, poolTokenOut);
  pushKcc20StateScalar(b, traderTokenOut);
  return b.selector(POOL_V3_SELECTOR.swapKasForToken).redeem(redeem).drain();
}
function v3SwapSellSig(k, redeem, kasOutUnits, poolTokenOut, traderChangeOut) {
  const b = new SigScriptBuilder(k).int(kasOutUnits);
  pushKcc20StateScalar(b, poolTokenOut);
  pushKcc20StateScalar(b, traderChangeOut);
  return b.selector(POOL_V3_SELECTOR.swapTokenForKas).redeem(redeem).drain();
}
function buildPoolV3SwapKasForToken(k, tpl, tokenTpl, params, utxo, poolCovid, traderPubkey, q, mergeTokens = [], presenceWitnessIdx = 0, opts = {}) {
  if (mergeTokens.length > 0 && presenceWitnessIdx === 0) throw new Error("presenceWitnessIdx must be set to a co-present signed P2PK funding input when mergeTokens is non-empty (input 0 is the pool covenant and carries no signature)");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const { kasReserve, tokenReserve, tokenCovid, totalShares, lpCovid } = utxo.state;
  const poolCovidHex = hexOf3(poolCovid);
  const tokenCovidHex = hexOf3(tokenCovid);
  const mergeSum = mergeTokens.reduce((s, t) => s + t.state.amount, 0n);
  const poolTokenOut = covenantIdOwned(poolCovid, q.newToken, false);
  const traderTokenOut = addressPresenceOwned(traderPubkey, q.tokenOut + mergeSum);
  const curRedeem = materializePoolCpV3Script(tpl, utxo.state);
  const newRedeem = materializePoolCpV3Script(tpl, { kasReserve: q.newKas, tokenReserve: q.newToken, tokenCovid, totalShares, lpCovid });
  const poolTokInRedeem = materializeKcc20Script(tokenTpl, covenantIdOwned(poolCovid, tokenReserve, false));
  const witnesses = [0, ...mergeTokens.map(() => presenceWitnessIdx)];
  const newStates = [poolTokenOut, traderTokenOut];
  const inputs = [
    { transactionId: utxo.transactionId, index: utxo.index, value: kasReserve * SCALE, scriptPublicKey: poolCpV3Spk(k, curRedeem), signatureScript: v3SwapBuySig(k, curRedeem, q.kasInUnits, q.tokenOut, poolTokenOut, traderTokenOut), redeem: curRedeem, role: "pool" },
    { transactionId: utxo.tokenUtxo.transactionId, index: utxo.tokenUtxo.index, value: utxo.tokenUtxo.value, scriptPublicKey: kcc20Spk(k, poolTokInRedeem), signatureScript: transferSigScript(k, poolTokInRedeem, newStates, witnesses), redeem: poolTokInRedeem, role: "poolToken" },
    ...mergeTokens.map((tt) => {
      const r = materializeKcc20Script(tokenTpl, tt.state);
      return { transactionId: tt.transactionId, index: tt.index, value: tt.value, scriptPublicKey: kcc20Spk(k, r), signatureScript: transferSigScript(k, r, newStates, witnesses), redeem: r, role: "traderToken" };
    })
  ];
  const outputs = [
    { value: q.newKas * SCALE, scriptPublicKey: poolCpV3Spk(k, newRedeem), role: "pool", binding: { covid: poolCovidHex, authorizingInput: 0 } },
    { value: continuationValue(dust, utxo.tokenUtxo.value), scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, poolTokenOut)), role: "poolToken", binding: { covid: tokenCovidHex, authorizingInput: 1 } },
    { value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, traderTokenOut)), role: "trader", binding: { covid: tokenCovidHex, authorizingInput: 1 } },
    { value: q.creatorOut, scriptPublicKey: p2pkSpk2(k, params.creatorFeeOwner), role: "creatorFee" },
    { value: q.platformOut, scriptPublicKey: p2pkSpk2(k, params.platformFeeOwner), role: "platformFee" }
  ];
  return { kind: "swapKasForToken", inputs, outputs, economics: { kasIn: q.kasIn, tokenOut: q.tokenOut }, covids: { poolCovid: poolCovidHex, tokenCovid: tokenCovidHex } };
}
function buildPoolV3SwapTokenForKas(k, tpl, tokenTpl, params, utxo, poolCovid, traderPubkey, traderTokens, q, presenceWitnessIdx, opts = {}) {
  if (traderTokens.length < 1) throw new Error("need at least one trader token");
  const dust = opts.tokenDust ?? COVENANT_DUST;
  const { kasReserve, tokenReserve, tokenCovid, totalShares, lpCovid } = utxo.state;
  const poolCovidHex = hexOf3(poolCovid);
  const tokenCovidHex = hexOf3(tokenCovid);
  const traderIn = traderTokens.reduce((s, t) => s + t.state.amount, 0n);
  const change = traderIn - q.tokenIn;
  if (change < 0n) throw new Error("trader inputs are less than the sell amount");
  const hasChange = change > 0n;
  const poolTokenOut = covenantIdOwned(poolCovid, q.newToken, false);
  const traderChangeOut = addressPresenceOwned(traderPubkey, hasChange ? change : 1n);
  const curRedeem = materializePoolCpV3Script(tpl, utxo.state);
  const newRedeem = materializePoolCpV3Script(tpl, { kasReserve: q.newKas, tokenReserve: q.newToken, tokenCovid, totalShares, lpCovid });
  const poolTokInRedeem = materializeKcc20Script(tokenTpl, covenantIdOwned(poolCovid, tokenReserve, false));
  const witnesses = [0, ...traderTokens.map(() => presenceWitnessIdx)];
  const newStates = hasChange ? [poolTokenOut, traderChangeOut] : [poolTokenOut];
  const inputs = [
    { transactionId: utxo.transactionId, index: utxo.index, value: kasReserve * SCALE, scriptPublicKey: poolCpV3Spk(k, curRedeem), signatureScript: v3SwapSellSig(k, curRedeem, q.kasOutUnits, poolTokenOut, traderChangeOut), redeem: curRedeem, role: "pool" },
    { transactionId: utxo.tokenUtxo.transactionId, index: utxo.tokenUtxo.index, value: utxo.tokenUtxo.value, scriptPublicKey: kcc20Spk(k, poolTokInRedeem), signatureScript: transferSigScript(k, poolTokInRedeem, newStates, witnesses), redeem: poolTokInRedeem, role: "poolToken" },
    ...traderTokens.map((tt) => {
      const r = materializeKcc20Script(tokenTpl, tt.state);
      return { transactionId: tt.transactionId, index: tt.index, value: tt.value, scriptPublicKey: kcc20Spk(k, r), signatureScript: transferSigScript(k, r, newStates, witnesses), redeem: r, role: "traderToken" };
    })
  ];
  const outputs = [
    { value: q.newKas * SCALE, scriptPublicKey: poolCpV3Spk(k, newRedeem), role: "pool", binding: { covid: poolCovidHex, authorizingInput: 0 } },
    { value: continuationValue(dust, utxo.tokenUtxo.value), scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, poolTokenOut)), role: "poolToken", binding: { covid: tokenCovidHex, authorizingInput: 1 } },
    { value: q.creatorOut, scriptPublicKey: p2pkSpk2(k, params.creatorFeeOwner), role: "creatorFee" },
    { value: q.platformOut, scriptPublicKey: p2pkSpk2(k, params.platformFeeOwner), role: "platformFee" }
  ];
  if (hasChange) outputs.push({ value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, traderChangeOut)), role: "trader", binding: { covid: tokenCovidHex, authorizingInput: 1 } });
  return { kind: "swapTokenForKas", inputs, outputs, economics: { kasOut: q.kasOut, tokenIn: q.tokenIn }, covids: { poolCovid: poolCovidHex, tokenCovid: tokenCovidHex } };
}
var vestingTx_exports = {};
__export2(vestingTx_exports, {
  VEST_SELECTOR: () => VEST_SELECTOR,
  buildVestingClaim: () => buildVestingClaim,
  buildVestingClaimFinal: () => buildVestingClaimFinal,
  materializeVestingScript: () => materializeVestingScript,
  vestedAmount: () => vestedAmount,
  vestingSpk: () => vestingSpk,
  vestingSpkForState: () => vestingSpkForState
});
var VEST_SELECTOR = { claim: 0, claimFinal: 1 };
var hexOf4 = (u8) => Array.from(u8, (b) => b.toString(16).padStart(2, "0")).join("");
function vestedAmount(total, startScore, durationScore, daaScore) {
  if (daaScore <= startScore) return 0n;
  const elapsed = BigInt(daaScore - startScore);
  const dur = BigInt(durationScore);
  if (elapsed >= dur) return total;
  return total * elapsed / dur;
}
function materializeVestingScript(tpl, claimed) {
  const s = tpl.stateStart;
  const t = tpl.script;
  if (t[s] !== 8) throw new Error("vesting template has an unexpected state layout (expected push8 claimed)");
  if (claimed < 0n) throw new Error("claimed must be non-negative");
  const out = t.slice();
  out[s] = 8;
  out.set(int8LE(claimed), s + 1);
  return out;
}
var vestingSpk = (k, redeem) => k.payToScriptHashScript(redeem);
var vestingSpkForState = (k, tpl, claimed) => vestingSpk(k, materializeVestingScript(tpl, claimed));
function buildVestingClaim(k, vestTpl, tokenTpl, vestingUtxo, lockedToken, vestingCovid, creatorPubkey, claimed, release, opts = {}) {
  if (!opts.tokenCovid) throw new Error("opts.tokenCovid is required (the vested token covenant id, hex) \u2014 the relock + recipient outputs need the KIP-20 covenant binding or the tx fails on-chain");
  const total = BigInt(vestTpl.params.total);
  if (claimed < 0n || claimed >= total) throw new Error("nothing left to claim");
  const remaining = total - claimed;
  if (release <= 0n || release >= remaining) throw new Error("partial claim must be > 0 and < remaining (use claimFinal to drain)");
  const dust = opts.tokenDust ?? 1000n;
  const vestingCovidHex = hexOf4(vestingCovid);
  const tokenBinding = opts.tokenCovid ? { covid: opts.tokenCovid, authorizingInput: 1 } : void 0;
  const newClaimed = claimed + release, newRemaining = remaining - release;
  const curRedeem = materializeVestingScript(vestTpl, claimed);
  const newRedeem = materializeVestingScript(vestTpl, newClaimed);
  const lockedState = covenantIdOwned(vestingCovid, remaining, false);
  const relockState = covenantIdOwned(vestingCovid, newRemaining, false);
  const recipientState = addressPresenceOwned(creatorPubkey, release);
  const lockedRedeem = materializeKcc20Script(tokenTpl, lockedState);
  const b = new SigScriptBuilder(k).int(release);
  pushKcc20StateScalar(b, relockState);
  pushKcc20StateScalar(b, recipientState);
  const claimSig = b.selector(VEST_SELECTOR.claim).redeem(curRedeem).drain();
  const inputs = [
    { transactionId: vestingUtxo.transactionId, index: vestingUtxo.index, value: vestingUtxo.value, scriptPublicKey: vestingSpk(k, curRedeem), signatureScript: claimSig, redeem: curRedeem, role: "vesting" },
    { transactionId: lockedToken.transactionId, index: lockedToken.index, value: lockedToken.value, scriptPublicKey: kcc20Spk(k, lockedRedeem), signatureScript: transferSigScript(k, lockedRedeem, [relockState, recipientState], [0]), redeem: lockedRedeem, role: "lockedToken" }
  ];
  const outputs = [
    { value: vestingUtxo.value, scriptPublicKey: vestingSpk(k, newRedeem), role: "vesting", binding: { covid: vestingCovidHex, authorizingInput: 0 } },
    // V continuation (claimed bumped)
    { value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, relockState)), role: "relock", binding: tokenBinding },
    // re-locked (A, V-owned)
    { value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, recipientState)), role: "recipient", binding: tokenBinding }
    // to creator (A, presence)
  ];
  return { kind: "claim", inputs, outputs, economics: { release, newClaimed }, covids: opts.tokenCovid ? { tokenCovid: opts.tokenCovid } : {} };
}
function buildVestingClaimFinal(k, vestTpl, tokenTpl, vestingUtxo, lockedToken, vestingCovid, creatorPubkey, claimed, opts = {}) {
  if (!opts.tokenCovid) throw new Error("opts.tokenCovid is required (the vested token covenant id, hex) \u2014 the recipient output needs the KIP-20 covenant binding or the tx fails on-chain");
  const total = BigInt(vestTpl.params.total);
  if (claimed < 0n || claimed >= total) throw new Error("nothing left to claim");
  const remaining = total - claimed;
  const dust = opts.tokenDust ?? 1000n;
  const vestingCovidHex = hexOf4(vestingCovid);
  const tokenBinding = opts.tokenCovid ? { covid: opts.tokenCovid, authorizingInput: 1 } : void 0;
  const curRedeem = materializeVestingScript(vestTpl, claimed);
  const newRedeem = materializeVestingScript(vestTpl, total);
  const lockedState = covenantIdOwned(vestingCovid, remaining, false);
  const recipientState = addressPresenceOwned(creatorPubkey, remaining);
  const lockedRedeem = materializeKcc20Script(tokenTpl, lockedState);
  const b = new SigScriptBuilder(k);
  pushKcc20StateScalar(b, recipientState);
  const claimSig = b.selector(VEST_SELECTOR.claimFinal).redeem(curRedeem).drain();
  const inputs = [
    { transactionId: vestingUtxo.transactionId, index: vestingUtxo.index, value: vestingUtxo.value, scriptPublicKey: vestingSpk(k, curRedeem), signatureScript: claimSig, redeem: curRedeem, role: "vesting" },
    { transactionId: lockedToken.transactionId, index: lockedToken.index, value: lockedToken.value, scriptPublicKey: kcc20Spk(k, lockedRedeem), signatureScript: transferSigScript(k, lockedRedeem, [recipientState], [0]), redeem: lockedRedeem, role: "lockedToken" }
  ];
  const outputs = [
    { value: vestingUtxo.value, scriptPublicKey: vestingSpk(k, newRedeem), role: "vesting", binding: { covid: vestingCovidHex, authorizingInput: 0 } },
    { value: dust, scriptPublicKey: kcc20Spk(k, materializeKcc20Script(tokenTpl, recipientState)), role: "recipient", binding: tokenBinding }
  ];
  return { kind: "claimFinal", inputs, outputs, economics: { release: remaining }, covids: opts.tokenCovid ? { tokenCovid: opts.tokenCovid } : {} };
}
var wallet_exports = {};
__export2(wallet_exports, {
  ExampleWalletAdapter: () => ExampleWalletAdapter,
  KASPA_ANNOUNCE_PROVIDER_EVENT: () => KASPA_ANNOUNCE_PROVIDER_EVENT,
  KASPA_NETWORKS: () => KASPA_NETWORKS,
  KASPA_REQUEST_PROVIDER_EVENT: () => KASPA_REQUEST_PROVIDER_EVENT,
  WalletCapabilityError: () => WalletCapabilityError,
  announceKaspaWallet: () => announceKaspaWallet,
  normalizeKaspaNetworkId: () => normalizeKaspaNetworkId,
  requestKaspaWallets: () => requestKaspaWallets
});
var WalletCapabilityError = class extends Error {
  constructor(provider2, method, hint) {
    super(`${provider2} does not implement ${method}()${hint ? ` \u2014 ${hint}` : ""}`);
    this.provider = provider2;
    this.method = method;
    this.name = "WalletCapabilityError";
  }
  provider;
  method;
};
var KASPA_NETWORKS = {
  MAINNET: "mainnet",
  TESTNET_10: "testnet-10",
  TESTNET_11: "testnet-11",
  DEVNET: "devnet"
};
var normalizeKaspaNetworkId = (id) => id.startsWith("kaspa_") ? id.slice("kaspa_".length).replace(/_/g, "-") : id;
var KASPA_REQUEST_PROVIDER_EVENT = "kaspa:requestProvider";
var KASPA_ANNOUNCE_PROVIDER_EVENT = "kaspa:provider";
function announceKaspaWallet(info, provider2) {
  if (typeof window === "undefined") return () => {
  };
  const detail = Object.freeze({ info: Object.freeze({ ...info }), provider: provider2 });
  const announce = () => window.dispatchEvent(new CustomEvent(KASPA_ANNOUNCE_PROVIDER_EVENT, { detail }));
  window.addEventListener(KASPA_REQUEST_PROVIDER_EVENT, announce);
  announce();
  return () => window.removeEventListener(KASPA_REQUEST_PROVIDER_EVENT, announce);
}
var isSafeIcon = (icon) => typeof icon === "string" && /^data:/i.test(icon.trim());
function requestKaspaWallets(onAnnounce) {
  if (typeof window === "undefined") return () => {
  };
  const listener = (e) => {
    const detail = e.detail;
    if (!detail?.info?.uuid || !detail?.info?.name) return;
    if (typeof detail.provider?.requestAccounts !== "function") return;
    if (detail.info.icon != null && !isSafeIcon(detail.info.icon)) {
      onAnnounce({ info: { ...detail.info, icon: "" }, provider: detail.provider });
      return;
    }
    onAnnounce(detail);
  };
  window.addEventListener(KASPA_ANNOUNCE_PROVIDER_EVENT, listener);
  window.dispatchEvent(new Event(KASPA_REQUEST_PROVIDER_EVENT));
  return () => window.removeEventListener(KASPA_ANNOUNCE_PROVIDER_EVENT, listener);
}
var GLOBAL_NAME = "exampleWallet";
var provider = () => {
  const p = globalThis[GLOBAL_NAME];
  if (!p) throw new Error(`${GLOBAL_NAME} not installed`);
  return p;
};
var ExampleWalletAdapter = class {
  provider = GLOBAL_NAME;
  label = "Example Wallet (template)";
  address = null;
  isAvailable() {
    return typeof globalThis[GLOBAL_NAME] !== "undefined";
  }
  capabilities() {
    return { signPskt: true, getXOnlyPublicKey: true, signMessage: true, reconnect: true };
  }
  async connect() {
    const p = provider();
    const accounts = await p.requestAccounts();
    this.address = accounts?.[0] ?? null;
    if (!this.address) throw new Error("No account authorized");
    return this.address;
  }
  async reconnect() {
    const p = globalThis[GLOBAL_NAME];
    if (!p) return null;
    try {
      const accounts = await p.getAccounts?.() ?? [];
      if (!accounts.length) return null;
      this.address = accounts[0];
      return this.address;
    } catch {
      return null;
    }
  }
  getAddress() {
    return this.address;
  }
  async signPskt(txJsonString, signInputs) {
    const p = provider();
    const options = { signInputs: signInputs.map((s) => ({ index: s.index, sighashType: s.sighashType ?? 1 })) };
    const res = await p.signPskt({ txJsonString, options });
    return typeof res === "string" ? res : res?.txJsonString ?? res?.signedTx ?? res?.tx ?? JSON.stringify(res);
  }
  async getXOnlyPublicKey() {
    const p = provider();
    const pub = await p.getPublicKey?.();
    if (!pub) return null;
    const hex2 = pub.replace(/^0x/, "").toLowerCase();
    if (hex2.length === 64) return hex2;
    if (hex2.length === 66 && /^0[23]/.test(hex2)) return hex2.slice(2);
    if (hex2.length === 130 && hex2.startsWith("04")) return hex2.slice(2, 66);
    return null;
  }
  async signMessage(message) {
    const p = provider();
    const publicKey2 = await this.getXOnlyPublicKey();
    if (!publicKey2) return null;
    const signature = await p.signMessage(message);
    return { signature, publicKey: publicKey2 };
  }
  disconnect() {
    this.address = null;
  }
};
var client_exports = {};
__export2(client_exports, {
  IndexerClient: () => IndexerClient,
  RegistryClient: () => RegistryClient,
  SequencerClient: () => SequencerClient
});
async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} -> HTTP ${res.status}`);
  const body = await res.json();
  return body.result;
}
var qs = (params) => {
  const parts = Object.entries(params).filter(([, v]) => v !== void 0).map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`);
  return parts.length ? `?${parts.join("&")}` : "";
};
var IndexerClient = class {
  /** @param baseUrl e.g. 'https://idx.kron.technology/v1/kcc20' (TN10) — no default baked in; pass the
   *  network-appropriate URL explicitly (mainnet endpoints publish separately at launch). */
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
  }
  baseUrl;
  info() {
    return fetchJson(`${this.baseUrl}/info`);
  }
  markets(opts = {}) {
    return fetchJson(`${this.baseUrl}/markets${qs(opts)}`);
  }
  topTraders() {
    return fetchJson(`${this.baseUrl}/top-traders`);
  }
  token(tick) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}`);
  }
  balance(tick, address) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/address/${encodeURIComponent(address)}`);
  }
  tokenlist(address) {
    return fetchJson(`${this.baseUrl}/address/${encodeURIComponent(address)}/tokenlist`);
  }
  tokenUtxos(tick, address) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/address/${encodeURIComponent(address)}/utxos`);
  }
  holders(tick) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/holders`);
  }
  trades(tick, opts = {}) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/trades${qs(opts)}`);
  }
  ohlc(tick, opts) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/ohlc${qs(opts)}`);
  }
  addressTrades(address, opts = {}) {
    return fetchJson(`${this.baseUrl}/address/${encodeURIComponent(address)}/trades${qs(opts)}`);
  }
  /** One address's trade history on ONE token (a wallet's per-token history view). */
  tokenAddressTrades(tick, address, opts = {}) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/address/${encodeURIComponent(address)}/trades${qs(opts)}`);
  }
  poolhead(tick) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/poolhead`);
  }
  /** LP-bind integrity for `tick`'s pool: `true` safe, `false` counterfeit, `null` not-yet-verifiable. See
   *  `CpState.lpBindVerified`. Returns `null` (fail-safe) when the field is absent (indexer predates it). */
  async lpBindVerified(tick) {
    const info = await this.token(tick);
    const row = Array.isArray(info) ? info[0] : info;
    const v = row?.cpState?.lpBindVerified;
    return v === true ? true : v === false ? false : null;
  }
  /** MANDATORY gate before `poolCp.buildAddLiquidity`: throws unless the pool's LP shares are provably honest.
   *  A pre-`e5469a7ad482` pool can be counterfeit-bound so that added liquidity is drained by counterfeit shares;
   *  only an exact L-supply match clears it. Fail-safe: an unverifiable (`null`) pool also throws. Removing
   *  liquidity does not need this. */
  async assertLpBindSafe(tick) {
    const v = await this.lpBindVerified(tick);
    if (v !== true) {
      throw new Error(v === false ? `Refusing to add liquidity to ${tick}: the pool's LP shares failed an on-chain integrity check (its bindLp was not a genuine genesis \u2014 counterfeit shares could drain your deposit).` : `Refusing to add liquidity to ${tick}: the pool's LP-share integrity is not confirmed yet (retry shortly).`);
    }
  }
  lpUtxos(tick, address) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/lp/${encodeURIComponent(address)}/utxos`);
  }
  lpEarnings(tick, address) {
    return fetchJson(`${this.baseUrl}/token/${encodeURIComponent(tick)}/lp/${encodeURIComponent(address)}/earnings`);
  }
  /**
   * Subscribe to the SSE update stream (all tokens, or one if `tick` is given). Returns an unsubscribe
   * function. Browser: uses the native EventSource. Node: pass an EventSource-compatible constructor (e.g.
   * the `eventsource` npm package) via `EventSourceImpl` — Node has no built-in EventSource on most
   * supported versions.
   */
  stream(onUpdate, opts = {}) {
    const ES = opts.EventSourceImpl ?? globalThis.EventSource;
    if (!ES) throw new Error('No EventSource available \u2014 in Node, pass EventSourceImpl (e.g. from the "eventsource" package)');
    const es = new ES(`${this.baseUrl}/stream${qs({ tick: opts.tick })}`);
    es.addEventListener("update", (ev) => {
      try {
        onUpdate(JSON.parse(ev.data));
      } catch {
      }
    });
    return () => es.close();
  }
};
var RegistryClient = class {
  /** @param baseUrl e.g. 'https://api.kron.technology' (TN10) */
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
  }
  baseUrl;
  async tokens() {
    const res = await fetch(`${this.baseUrl}/api/registry/tokens`);
    if (!res.ok) throw new Error(`registry tokens -> HTTP ${res.status}`);
    const body = await res.json();
    return body.tokens;
  }
  /** Fetch the public token list — a tokenlists.org-shaped index of KRON tokens for wallets/explorers/
   *  aggregators. Default = chain-verified tokens only (anti-phishing); `{ all: true }` adds unverified ones
   *  (each tagged `extensions.chainVerified:false`). Verify any entry against the chain with
   *  verify.verifyTokenListEntry before trusting it. */
  async tokenlist(opts) {
    const q = opts?.all ? "?all=1" : "";
    const res = await fetch(`${this.baseUrl}/api/registry/tokenlist${q}`);
    if (!res.ok) throw new Error(`registry tokenlist -> HTTP ${res.status}`);
    return await res.json();
  }
};
var SequencerClient = class {
  /** @param baseUrl e.g. 'https://seq.kron.technology' (TN10) */
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
  }
  baseUrl;
  async health() {
    const res = await fetch(`${this.baseUrl}/health`);
    return res.json();
  }
  /** The in-flight head + queue depth for a pool — use this instead of the indexer's confirmed `poolhead`
   *  when the pool is busy, so you build on the latest unconfirmed state. */
  async head(poolP2sh) {
    const res = await fetch(`${this.baseUrl}/head?pool=${encodeURIComponent(poolP2sh)}`);
    if (!res.ok) throw new Error(`sequencer head -> HTTP ${res.status}`);
    return res.json();
  }
  /** Enqueue a signed swap tx built against a `head()` snapshot. A 409-shaped `{ok:false, retry:true}`
   *  means `prevHead` is stale — re-fetch `head()` and rebuild.
   *
   *  `ref` (optional) — your wallet-integrator partner tag (kron.technology/wallets): 2–32 chars of
   *  `a-z 0-9 - _`, case-insensitive. Tagged trades are recorded server-side per-trade and count toward
   *  your revenue share; a malformed tag is rejected with 400 so a misconfigured integration fails on the
   *  first submit rather than silently at settlement. Only sequencer-routed trades carry attribution. */
  async submit(body) {
    const res = await fetch(`${this.baseUrl}/submit`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body)
    });
    return res.json();
  }
  /** The in-flight curve head + queue depth for a pre-graduation token, keyed by its curve covenant id
   *  (hex). `head: null` with `ok: true` means no chain is in flight — build against the confirmed state
   *  from the node/indexer instead. A `{ok:false}` gate (unknown/full/unreachable) → submit direct. */
  async curveHead(curveCovid) {
    const res = await fetch(`${this.baseUrl}/curve/head?covid=${encodeURIComponent(curveCovid)}`);
    if (!res.ok && res.status !== 409) throw new Error(`sequencer curve head -> HTTP ${res.status}`);
    return res.json();
  }
  /** Enqueue a signed pre-graduation buy/sell built against a `curveHead()` snapshot. A 409-shaped
   *  `{ok:false, retry:true}` means `prevHead` is stale — re-fetch `curveHead()` and rebuild.
   *  `ref` — optional partner tag, same contract as `submit()`. */
  async curveSubmit(body) {
    const res = await fetch(`${this.baseUrl}/curve/submit`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body)
    });
    return res.json();
  }
  /** SSE: head changes for a pool. Same Node-EventSource caveat as IndexerClient.stream. */
  events(poolP2sh, onEvent, EventSourceImpl) {
    const ES = EventSourceImpl ?? globalThis.EventSource;
    if (!ES) throw new Error('No EventSource available \u2014 in Node, pass EventSourceImpl (e.g. from the "eventsource" package)');
    const es = new ES(`${this.baseUrl}/events?pool=${encodeURIComponent(poolP2sh)}`);
    es.onmessage = (ev) => {
      try {
        onEvent(JSON.parse(ev.data));
      } catch {
      }
    };
    return () => es.close();
  }
};
var verify_exports = {};
__export2(verify_exports, {
  canonicalTokenListMsg: () => canonicalTokenListMsg,
  kaspaRestFetchTx: () => kaspaRestFetchTx,
  verifyTokenListEntry: () => verifyTokenListEntry,
  verifyTokenListSignature: () => verifyTokenListSignature
});
var lc = (s) => String(s ?? "").toLowerCase();
async function verifyTokenListEntry(entry, fetchTx) {
  const covid = lc(entry?.covenantId);
  const txid = entry?.extensions?.genesisTxid ?? null;
  if (!covid) return { ok: false, covenantIdPresent: false, reason: "entry has no covenantId" };
  if (!txid) return { ok: false, covenantIdPresent: false, reason: "entry has no genesisTxid to verify against" };
  let tx;
  try {
    tx = await fetchTx(txid);
  } catch (e) {
    return { ok: false, covenantIdPresent: false, reason: `fetchTx failed for ${txid}: ${e?.message ?? e}` };
  }
  const outs = Array.isArray(tx?.outputs) ? tx.outputs : [];
  const present = outs.some((o) => lc(o?.covenant_id ?? o?.covenantId) === covid);
  return present ? { ok: true, covenantIdPresent: true } : { ok: false, covenantIdPresent: false, reason: `covenantId ${entry.covenantId} not found on any output of genesis tx ${txid}` };
}
function kaspaRestFetchTx(baseUrl) {
  const base2 = baseUrl.replace(/\/+$/, "");
  return async (txid) => {
    const res = await fetch(`${base2}/transactions/${encodeURIComponent(txid)}?outputs=true`);
    if (!res.ok) throw new Error(`kaspa REST tx ${txid} -> HTTP ${res.status}`);
    return await res.json();
  };
}
var canonicalTokenListMsg = (doc) => JSON.stringify({
  v: "KRON-TOKENLIST-1",
  network: lc(doc.network),
  variant: { all: !!doc.variant?.all, tier: doc.variant?.tier ?? null },
  version: { major: Number(doc.version?.major ?? 0), minor: Number(doc.version?.minor ?? 0), patch: Number(doc.version?.patch ?? 0) },
  tokens: doc.tokens ?? []
});
var xOnly = (key2) => {
  let h = lc(key2).replace(/^0x/, "");
  if (h.length === 66 && (h.startsWith("02") || h.startsWith("03"))) h = h.slice(2);
  else if (h.length === 130 && h.startsWith("04")) h = h.slice(2, 66);
  return h;
};
function verifyTokenListSignature(kaspa, list, opts = {}) {
  if (!list?.signature) return { ok: false, signed: false, reason: "list is unsigned (older backend or signing key not configured)" };
  const pinned = xOnly(opts.pinnedPublicKey);
  const fromResponse = xOnly(list.publicKey);
  let keySource;
  let publicKey2;
  if (pinned) {
    if (fromResponse && fromResponse !== pinned) {
      return { ok: false, signed: true, keySource: "pinned", reason: `signer mismatch: response publicKey ${fromResponse} != pinned ${pinned}` };
    }
    keySource = "pinned";
    publicKey2 = pinned;
  } else if (fromResponse) {
    keySource = "response";
    publicKey2 = fromResponse;
  } else {
    return { ok: false, signed: true, reason: "signed list carries no publicKey and no pinnedPublicKey was provided" };
  }
  if (!list.variant) return { ok: false, signed: true, keySource, reason: "signed list has no variant field (cannot rule out cross-variant replay)" };
  const expected = { all: false, tier: null, ...opts.expectedVariant };
  const got = { all: !!list.variant.all, tier: list.variant.tier ?? null };
  if (got.all !== expected.all || got.tier !== expected.tier) {
    return { ok: false, signed: true, keySource, reason: `variant mismatch: document is signed for ${JSON.stringify(got)} but ${JSON.stringify(expected)} was expected (possible replay)` };
  }
  let valid = false;
  try {
    valid = kaspa.verifyMessage({ message: canonicalTokenListMsg(list), signature: String(list.signature), publicKey: publicKey2 }) === true;
  } catch (e) {
    return { ok: false, signed: true, keySource, reason: `verifyMessage failed: ${e?.message ?? e}` };
  }
  return valid ? { ok: true, signed: true, keySource } : { ok: false, signed: true, keySource, reason: "signature verification failed (document was modified, or signed by a different key)" };
}

// node_modules/@kronsdk/kron-sdk/vendor/kaspa/kaspa.js
var kaspa_exports = {};
__export(kaspa_exports, {
  Abortable: () => Abortable2,
  Aborted: () => Aborted2,
  AccountKind: () => AccountKind,
  AccountsDiscoveryKind: () => AccountsDiscoveryKind,
  Address: () => Address2,
  AddressVersion: () => AddressVersion2,
  AgentConstructorOptions: () => AgentConstructorOptions,
  AppendFileOptions: () => AppendFileOptions,
  AssertionErrorOptions: () => AssertionErrorOptions,
  Balance: () => Balance,
  BalanceStrings: () => BalanceStrings,
  CommitRevealAddressKind: () => CommitRevealAddressKind,
  CompressedParents: () => CompressedParents,
  ConnectStrategy: () => ConnectStrategy,
  ConsoleConstructorOptions: () => ConsoleConstructorOptions,
  CovenantBinding: () => CovenantBinding,
  CreateHookCallbacks: () => CreateHookCallbacks,
  CreateReadStreamOptions: () => CreateReadStreamOptions,
  CreateWriteStreamOptions: () => CreateWriteStreamOptions,
  CryptoBox: () => CryptoBox,
  CryptoBoxPrivateKey: () => CryptoBoxPrivateKey,
  CryptoBoxPublicKey: () => CryptoBoxPublicKey,
  DerivationPath: () => DerivationPath,
  Encoding: () => Encoding,
  FeeSource: () => FeeSource,
  FormatInputPathObject: () => FormatInputPathObject,
  Generator: () => Generator,
  GeneratorSummary: () => GeneratorSummary,
  GenesisCovenantGroup: () => GenesisCovenantGroup,
  GetNameOptions: () => GetNameOptions,
  Hash: () => Hash2,
  Header: () => Header,
  Keypair: () => Keypair,
  Language: () => Language2,
  MkdtempSyncOptions: () => MkdtempSyncOptions,
  Mnemonic: () => Mnemonic2,
  NetServerOptions: () => NetServerOptions,
  NetworkId: () => NetworkId2,
  NetworkType: () => NetworkType2,
  NewAddressKind: () => NewAddressKind,
  NodeDescriptor: () => NodeDescriptor,
  Opcodes: () => Opcodes,
  OptionalHeader: () => OptionalHeader,
  PSKB: () => PSKB,
  PSKT: () => PSKT,
  PaymentOutput: () => PaymentOutput,
  PaymentOutputs: () => PaymentOutputs,
  PendingTransaction: () => PendingTransaction,
  PipeOptions: () => PipeOptions,
  PoW: () => PoW,
  PrivateKey: () => PrivateKey,
  PrivateKeyGenerator: () => PrivateKeyGenerator,
  ProcessSendOptions: () => ProcessSendOptions,
  PrvKeyDataInfo: () => PrvKeyDataInfo,
  PublicKey: () => PublicKey,
  PublicKeyGenerator: () => PublicKeyGenerator,
  ReadStream: () => ReadStream,
  Resolver: () => Resolver,
  RpcClient: () => RpcClient,
  ScriptBuilder: () => ScriptBuilder,
  ScriptPublicKey: () => ScriptPublicKey2,
  SetAadOptions: () => SetAadOptions,
  SigHashType: () => SigHashType2,
  SighashType: () => SighashType,
  Storage: () => Storage,
  StreamTransformOptions: () => StreamTransformOptions,
  Transaction: () => Transaction,
  TransactionInput: () => TransactionInput,
  TransactionOutpoint: () => TransactionOutpoint,
  TransactionOutput: () => TransactionOutput,
  TransactionRecord: () => TransactionRecord,
  TransactionRecordNotification: () => TransactionRecordNotification,
  TransactionSigningHash: () => TransactionSigningHash,
  TransactionSigningHashECDSA: () => TransactionSigningHashECDSA,
  TransactionUtxoEntry: () => TransactionUtxoEntry2,
  UserInfoOptions: () => UserInfoOptions,
  UtxoContext: () => UtxoContext,
  UtxoEntries: () => UtxoEntries,
  UtxoEntry: () => UtxoEntry,
  UtxoEntryReference: () => UtxoEntryReference,
  UtxoProcessor: () => UtxoProcessor,
  Wallet: () => Wallet,
  WalletDescriptor: () => WalletDescriptor,
  WasiOptions: () => WasiOptions,
  WriteFileSyncOptions: () => WriteFileSyncOptions,
  WriteStream: () => WriteStream,
  XOnlyPublicKey: () => XOnlyPublicKey,
  XPrv: () => XPrv,
  XPub: () => XPub,
  addressFromScriptPublicKey: () => addressFromScriptPublicKey,
  argon2sha256ivFromBinary: () => argon2sha256ivFromBinary,
  argon2sha256ivFromText: () => argon2sha256ivFromText,
  calculateStorageMass: () => calculateStorageMass,
  calculateTarget: () => calculateTarget,
  calculateTransactionFee: () => calculateTransactionFee,
  calculateTransactionMass: () => calculateTransactionMass,
  covenantId: () => covenantId,
  createAddress: () => createAddress,
  createInputSignature: () => createInputSignature,
  createMultisigAddress: () => createMultisigAddress,
  createTransaction: () => createTransaction,
  createTransactions: () => createTransactions,
  decryptXChaCha20Poly1305: () => decryptXChaCha20Poly1305,
  default: () => kaspa_default,
  defer: () => defer2,
  encryptXChaCha20Poly1305: () => encryptXChaCha20Poly1305,
  estimateTransactions: () => estimateTransactions,
  getNetworkParams: () => getNetworkParams,
  getTransactionMaturityProgress: () => getTransactionMaturityProgress,
  initBrowserPanicHook: () => initBrowserPanicHook2,
  initConsolePanicHook: () => initConsolePanicHook2,
  initSync: () => initSync2,
  initWASM32Bindings: () => initWASM32Bindings2,
  isScriptPayToPubkey: () => isScriptPayToPubkey,
  isScriptPayToPubkeyECDSA: () => isScriptPayToPubkeyECDSA,
  isScriptPayToScriptHash: () => isScriptPayToScriptHash,
  kaspaToSompi: () => kaspaToSompi,
  maximumStandardTransactionMass: () => maximumStandardTransactionMass,
  payToAddressScript: () => payToAddressScript,
  payToScriptHashScript: () => payToScriptHashScript,
  payToScriptHashSignatureScript: () => payToScriptHashSignatureScript,
  presentPanicHookLogs: () => presentPanicHookLogs2,
  setDefaultStorageFolder: () => setDefaultStorageFolder,
  setDefaultWalletFile: () => setDefaultWalletFile,
  setLogLevel: () => setLogLevel2,
  sha256FromBinary: () => sha256FromBinary,
  sha256FromText: () => sha256FromText,
  sha256dFromBinary: () => sha256dFromBinary,
  sha256dFromText: () => sha256dFromText,
  signMessage: () => signMessage,
  signScriptHash: () => signScriptHash,
  signTransaction: () => signTransaction2,
  sompiToKaspaString: () => sompiToKaspaString,
  sompiToKaspaStringWithSuffix: () => sompiToKaspaStringWithSuffix,
  updateTransactionMass: () => updateTransactionMass,
  verifyMessage: () => verifyMessage,
  version: () => version
});
var wasm2;
var heap = new Array(128).fill(void 0);
heap.push(void 0, null, true, false);
function getObject(idx) {
  return heap[idx];
}
var heap_next = heap.length;
function addHeapObject(obj) {
  if (heap_next === heap.length) heap.push(heap.length + 1);
  const idx = heap_next;
  heap_next = heap[idx];
  heap[idx] = obj;
  return idx;
}
function handleError2(f, args) {
  try {
    return f.apply(this, args);
  } catch (e) {
    wasm2.__wbindgen_export_0(addHeapObject(e));
  }
}
var WASM_VECTOR_LEN2 = 0;
var cachedUint8ArrayMemory02 = null;
function getUint8ArrayMemory02() {
  if (cachedUint8ArrayMemory02 === null || cachedUint8ArrayMemory02.byteLength === 0) {
    cachedUint8ArrayMemory02 = new Uint8Array(wasm2.memory.buffer);
  }
  return cachedUint8ArrayMemory02;
}
var cachedTextEncoder2 = typeof TextEncoder !== "undefined" ? new TextEncoder("utf-8") : { encode: () => {
  throw Error("TextEncoder not available");
} };
var encodeString2 = typeof cachedTextEncoder2.encodeInto === "function" ? function(arg, view) {
  return cachedTextEncoder2.encodeInto(arg, view);
} : function(arg, view) {
  const buf = cachedTextEncoder2.encode(arg);
  view.set(buf);
  return {
    read: arg.length,
    written: buf.length
  };
};
function passStringToWasm02(arg, malloc, realloc) {
  if (realloc === void 0) {
    const buf = cachedTextEncoder2.encode(arg);
    const ptr2 = malloc(buf.length, 1) >>> 0;
    getUint8ArrayMemory02().subarray(ptr2, ptr2 + buf.length).set(buf);
    WASM_VECTOR_LEN2 = buf.length;
    return ptr2;
  }
  let len = arg.length;
  let ptr = malloc(len, 1) >>> 0;
  const mem = getUint8ArrayMemory02();
  let offset = 0;
  for (; offset < len; offset++) {
    const code = arg.charCodeAt(offset);
    if (code > 127) break;
    mem[ptr + offset] = code;
  }
  if (offset !== len) {
    if (offset !== 0) {
      arg = arg.slice(offset);
    }
    ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
    const view = getUint8ArrayMemory02().subarray(ptr + offset, ptr + len);
    const ret = encodeString2(arg, view);
    offset += ret.written;
    ptr = realloc(ptr, len, offset, 1) >>> 0;
  }
  WASM_VECTOR_LEN2 = offset;
  return ptr;
}
var cachedDataViewMemory02 = null;
function getDataViewMemory02() {
  if (cachedDataViewMemory02 === null || cachedDataViewMemory02.buffer.detached === true || cachedDataViewMemory02.buffer.detached === void 0 && cachedDataViewMemory02.buffer !== wasm2.memory.buffer) {
    cachedDataViewMemory02 = new DataView(wasm2.memory.buffer);
  }
  return cachedDataViewMemory02;
}
var cachedTextDecoder2 = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { ignoreBOM: true, fatal: true }) : { decode: () => {
  throw Error("TextDecoder not available");
} };
if (typeof TextDecoder !== "undefined") {
  cachedTextDecoder2.decode();
}
function getStringFromWasm02(ptr, len) {
  ptr = ptr >>> 0;
  return cachedTextDecoder2.decode(getUint8ArrayMemory02().subarray(ptr, ptr + len));
}
function isLikeNone2(x) {
  return x === void 0 || x === null;
}
function dropObject(idx) {
  if (idx < 132) return;
  heap[idx] = heap_next;
  heap_next = idx;
}
function takeObject(idx) {
  const ret = getObject(idx);
  dropObject(idx);
  return ret;
}
function getArrayU8FromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  return getUint8ArrayMemory02().subarray(ptr / 1, ptr / 1 + len);
}
var CLOSURE_DTORS = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((state) => {
  wasm2.__wbindgen_export_4.get(state.dtor)(state.a, state.b);
});
function makeClosure(arg0, arg1, dtor, f) {
  const state = { a: arg0, b: arg1, cnt: 1, dtor };
  const real = (...args) => {
    state.cnt++;
    try {
      return f(state.a, state.b, ...args);
    } finally {
      if (--state.cnt === 0) {
        wasm2.__wbindgen_export_4.get(state.dtor)(state.a, state.b);
        state.a = 0;
        CLOSURE_DTORS.unregister(state);
      }
    }
  };
  real.original = state;
  CLOSURE_DTORS.register(real, state, state);
  return real;
}
function makeMutClosure(arg0, arg1, dtor, f) {
  const state = { a: arg0, b: arg1, cnt: 1, dtor };
  const real = (...args) => {
    state.cnt++;
    const a = state.a;
    state.a = 0;
    try {
      return f(a, state.b, ...args);
    } finally {
      if (--state.cnt === 0) {
        wasm2.__wbindgen_export_4.get(state.dtor)(a, state.b);
        CLOSURE_DTORS.unregister(state);
      } else {
        state.a = a;
      }
    }
  };
  real.original = state;
  CLOSURE_DTORS.register(real, state, state);
  return real;
}
function debugString2(val) {
  const type = typeof val;
  if (type == "number" || type == "boolean" || val == null) {
    return `${val}`;
  }
  if (type == "string") {
    return `"${val}"`;
  }
  if (type == "symbol") {
    const description = val.description;
    if (description == null) {
      return "Symbol";
    } else {
      return `Symbol(${description})`;
    }
  }
  if (type == "function") {
    const name = val.name;
    if (typeof name == "string" && name.length > 0) {
      return `Function(${name})`;
    } else {
      return "Function";
    }
  }
  if (Array.isArray(val)) {
    const length = val.length;
    let debug = "[";
    if (length > 0) {
      debug += debugString2(val[0]);
    }
    for (let i = 1; i < length; i++) {
      debug += ", " + debugString2(val[i]);
    }
    debug += "]";
    return debug;
  }
  const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
  let className;
  if (builtInMatches && builtInMatches.length > 1) {
    className = builtInMatches[1];
  } else {
    return toString.call(val);
  }
  if (className == "Object") {
    try {
      return "Object(" + JSON.stringify(val) + ")";
    } catch (_) {
      return "Object";
    }
  }
  if (val instanceof Error) {
    return `${val.name}: ${val.message}
${val.stack}`;
  }
  return className;
}
var stack_pointer = 128;
function addBorrowedObject(obj) {
  if (stack_pointer == 1) throw new Error("out of js stack");
  heap[--stack_pointer] = obj;
  return stack_pointer;
}
function _assertClass2(instance, klass) {
  if (!(instance instanceof klass)) {
    throw new Error(`expected instance of ${klass.name}`);
  }
}
function isScriptPayToPubkeyECDSA(script) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.isScriptPayToPubkeyECDSA(retptr, addHeapObject(script));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return r0 !== 0;
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function payToAddressScript(address) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.payToAddressScript(retptr, addBorrowedObject(address));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return ScriptPublicKey2.__wrap(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    heap[stack_pointer++] = void 0;
  }
}
function isScriptPayToPubkey(script) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.isScriptPayToPubkey(retptr, addHeapObject(script));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return r0 !== 0;
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function payToScriptHashScript(redeem_script) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.payToScriptHashScript(retptr, addHeapObject(redeem_script));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return ScriptPublicKey2.__wrap(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function isScriptPayToScriptHash(script) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.isScriptPayToScriptHash(retptr, addHeapObject(script));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return r0 !== 0;
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function addressFromScriptPublicKey(script_public_key, network) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.addressFromScriptPublicKey(retptr, addBorrowedObject(script_public_key), addBorrowedObject(network));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    heap[stack_pointer++] = void 0;
    heap[stack_pointer++] = void 0;
  }
}
function payToScriptHashSignatureScript(redeem_script, signature) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.payToScriptHashSignatureScript(retptr, addHeapObject(redeem_script), addHeapObject(signature));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function covenantId(genesis_outpoint, auth_outputs) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.covenantId(retptr, addBorrowedObject(genesis_outpoint), addBorrowedObject(auth_outputs));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return Hash2.__wrap(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    heap[stack_pointer++] = void 0;
    heap[stack_pointer++] = void 0;
  }
}
function calculateTarget(difficulty) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.calculateTarget(retptr, difficulty);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function signMessage(value) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.signMessage(retptr, addHeapObject(value));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function verifyMessage(value) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.verifyMessage(retptr, addHeapObject(value));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return r0 !== 0;
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function setDefaultStorageFolder(folder) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    const ptr0 = passStringToWasm02(folder, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.setDefaultStorageFolder(retptr, ptr0, len0);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    if (r1) {
      throw takeObject(r0);
    }
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function setDefaultWalletFile(folder) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    const ptr0 = passStringToWasm02(folder, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.setDefaultWalletFile(retptr, ptr0, len0);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    if (r1) {
      throw takeObject(r0);
    }
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function encryptXChaCha20Poly1305(plainText, password) {
  let deferred4_0;
  let deferred4_1;
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    const ptr0 = passStringToWasm02(plainText, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    const ptr1 = passStringToWasm02(password, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len1 = WASM_VECTOR_LEN2;
    wasm2.encryptXChaCha20Poly1305(retptr, ptr0, len0, ptr1, len1);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
    var ptr3 = r0;
    var len3 = r1;
    if (r3) {
      ptr3 = 0;
      len3 = 0;
      throw takeObject(r2);
    }
    deferred4_0 = ptr3;
    deferred4_1 = len3;
    return getStringFromWasm02(ptr3, len3);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    wasm2.__wbindgen_export_3(deferred4_0, deferred4_1, 1);
  }
}
function sha256dFromBinary(data) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.sha256dFromBinary(retptr, addHeapObject(data));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function decryptXChaCha20Poly1305(base64string, password) {
  let deferred4_0;
  let deferred4_1;
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    const ptr0 = passStringToWasm02(base64string, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    const ptr1 = passStringToWasm02(password, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len1 = WASM_VECTOR_LEN2;
    wasm2.decryptXChaCha20Poly1305(retptr, ptr0, len0, ptr1, len1);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
    var ptr3 = r0;
    var len3 = r1;
    if (r3) {
      ptr3 = 0;
      len3 = 0;
      throw takeObject(r2);
    }
    deferred4_0 = ptr3;
    deferred4_1 = len3;
    return getStringFromWasm02(ptr3, len3);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    wasm2.__wbindgen_export_3(deferred4_0, deferred4_1, 1);
  }
}
function sha256dFromText(text) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    const ptr0 = passStringToWasm02(text, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.sha256dFromText(retptr, ptr0, len0);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function sha256FromBinary(data) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.sha256FromBinary(retptr, addHeapObject(data));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function argon2sha256ivFromBinary(data, hashLength) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.argon2sha256ivFromBinary(retptr, addHeapObject(data), hashLength);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function argon2sha256ivFromText(text, byteLength) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    const ptr0 = passStringToWasm02(text, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.argon2sha256ivFromText(retptr, ptr0, len0, byteLength);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function sha256FromText(text) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    const ptr0 = passStringToWasm02(text, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.sha256FromText(retptr, ptr0, len0);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function estimateTransactions(settings) {
  const ret = wasm2.estimateTransactions(addHeapObject(settings));
  return takeObject(ret);
}
function createTransactions(settings) {
  const ret = wasm2.createTransactions(addHeapObject(settings));
  return takeObject(ret);
}
function createTransaction(utxo_entry_source, outputs, priority_fee, payload, sig_op_count) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.createTransaction(retptr, addHeapObject(utxo_entry_source), addHeapObject(outputs), addHeapObject(priority_fee), isLikeNone2(payload) ? 0 : addHeapObject(payload), isLikeNone2(sig_op_count) ? 16777215 : sig_op_count);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return Transaction.__wrap(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function updateTransactionMass(network_id, tx, minimum_signatures) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    _assertClass2(tx, Transaction);
    wasm2.updateTransactionMass(retptr, addHeapObject(network_id), tx.__wbg_ptr, isLikeNone2(minimum_signatures) ? 16777215 : minimum_signatures);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return r0 !== 0;
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function calculateTransactionFee(network_id, tx, minimum_signatures) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-32);
    wasm2.calculateTransactionFee(retptr, addHeapObject(network_id), addBorrowedObject(tx), isLikeNone2(minimum_signatures) ? 16777215 : minimum_signatures);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r2 = getDataViewMemory02().getBigInt64(retptr + 8 * 1, true);
    var r4 = getDataViewMemory02().getInt32(retptr + 4 * 4, true);
    var r5 = getDataViewMemory02().getInt32(retptr + 4 * 5, true);
    if (r5) {
      throw takeObject(r4);
    }
    return r0 === 0 ? void 0 : BigInt.asUintN(64, r2);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(32);
    heap[stack_pointer++] = void 0;
  }
}
function calculateTransactionMass(network_id, tx, minimum_signatures) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.calculateTransactionMass(retptr, addHeapObject(network_id), addBorrowedObject(tx), isLikeNone2(minimum_signatures) ? 16777215 : minimum_signatures);
    var r0 = getDataViewMemory02().getBigInt64(retptr + 8 * 0, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
    if (r3) {
      throw takeObject(r2);
    }
    return BigInt.asUintN(64, r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    heap[stack_pointer++] = void 0;
  }
}
function calculateStorageMass(network_id, input_values, output_values) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-32);
    wasm2.calculateStorageMass(retptr, addHeapObject(network_id), addBorrowedObject(input_values), addBorrowedObject(output_values));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r2 = getDataViewMemory02().getBigInt64(retptr + 8 * 1, true);
    var r4 = getDataViewMemory02().getInt32(retptr + 4 * 4, true);
    var r5 = getDataViewMemory02().getInt32(retptr + 4 * 5, true);
    if (r5) {
      throw takeObject(r4);
    }
    return r0 === 0 ? void 0 : BigInt.asUintN(64, r2);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(32);
    heap[stack_pointer++] = void 0;
    heap[stack_pointer++] = void 0;
  }
}
function maximumStandardTransactionMass() {
  const ret = wasm2.maximumStandardTransactionMass();
  return BigInt.asUintN(64, ret);
}
function createAddress(key2, network, ecdsa, account_kind) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    let ptr0 = 0;
    if (!isLikeNone2(account_kind)) {
      _assertClass2(account_kind, AccountKind);
      ptr0 = account_kind.__destroy_into_raw();
    }
    wasm2.createAddress(retptr, addBorrowedObject(key2), addBorrowedObject(network), isLikeNone2(ecdsa) ? 16777215 : ecdsa ? 1 : 0, ptr0);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return Address2.__wrap(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    heap[stack_pointer++] = void 0;
    heap[stack_pointer++] = void 0;
  }
}
function createMultisigAddress(minimum_signatures, keys, network_type, ecdsa, account_kind) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    let ptr0 = 0;
    if (!isLikeNone2(account_kind)) {
      _assertClass2(account_kind, AccountKind);
      ptr0 = account_kind.__destroy_into_raw();
    }
    wasm2.createMultisigAddress(retptr, minimum_signatures, addBorrowedObject(keys), network_type, isLikeNone2(ecdsa) ? 16777215 : ecdsa ? 1 : 0, ptr0);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return Address2.__wrap(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    heap[stack_pointer++] = void 0;
  }
}
function sompiToKaspaStringWithSuffix(sompi, network) {
  let deferred2_0;
  let deferred2_1;
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.sompiToKaspaStringWithSuffix(retptr, addHeapObject(sompi), addBorrowedObject(network));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
    var ptr1 = r0;
    var len1 = r1;
    if (r3) {
      ptr1 = 0;
      len1 = 0;
      throw takeObject(r2);
    }
    deferred2_0 = ptr1;
    deferred2_1 = len1;
    return getStringFromWasm02(ptr1, len1);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    heap[stack_pointer++] = void 0;
    wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
  }
}
function kaspaToSompi(kaspa) {
  const ptr0 = passStringToWasm02(kaspa, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
  const len0 = WASM_VECTOR_LEN2;
  const ret = wasm2.kaspaToSompi(ptr0, len0);
  return takeObject(ret);
}
function getNetworkParams(networkId) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.getNetworkParams(retptr, addHeapObject(networkId));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function sompiToKaspaString(sompi) {
  let deferred2_0;
  let deferred2_1;
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.sompiToKaspaString(retptr, addHeapObject(sompi));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
    var ptr1 = r0;
    var len1 = r1;
    if (r3) {
      ptr1 = 0;
      len1 = 0;
      throw takeObject(r2);
    }
    deferred2_0 = ptr1;
    deferred2_1 = len1;
    return getStringFromWasm02(ptr1, len1);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
  }
}
function getTransactionMaturityProgress(blockDaaScore, currentDaaScore, networkId, isCoinbase) {
  let deferred2_0;
  let deferred2_1;
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.getTransactionMaturityProgress(retptr, addHeapObject(blockDaaScore), addHeapObject(currentDaaScore), addHeapObject(networkId), isCoinbase);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
    var ptr1 = r0;
    var len1 = r1;
    if (r3) {
      ptr1 = 0;
      len1 = 0;
      throw takeObject(r2);
    }
    deferred2_0 = ptr1;
    deferred2_1 = len1;
    return getStringFromWasm02(ptr1, len1);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
  }
}
function createInputSignature(tx, input_index, private_key, sighash_type) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    _assertClass2(tx, Transaction);
    _assertClass2(private_key, PrivateKey);
    wasm2.createInputSignature(retptr, tx.__wbg_ptr, input_index, private_key.__wbg_ptr, isLikeNone2(sighash_type) ? 6 : sighash_type);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return takeObject(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function signTransaction2(tx, signer, verify_sig) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    _assertClass2(tx, Transaction);
    wasm2.signTransaction(retptr, tx.__wbg_ptr, addBorrowedObject(signer), verify_sig);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    if (r2) {
      throw takeObject(r1);
    }
    return Transaction.__wrap(r0);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    heap[stack_pointer++] = void 0;
  }
}
function signScriptHash(script_hash, privkey) {
  let deferred2_0;
  let deferred2_1;
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    _assertClass2(privkey, PrivateKey);
    wasm2.signScriptHash(retptr, addHeapObject(script_hash), privkey.__wbg_ptr);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
    var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
    var ptr1 = r0;
    var len1 = r1;
    if (r3) {
      ptr1 = 0;
      len1 = 0;
      throw takeObject(r2);
    }
    deferred2_0 = ptr1;
    deferred2_1 = len1;
    return getStringFromWasm02(ptr1, len1);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
  }
}
function version() {
  let deferred1_0;
  let deferred1_1;
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.version(retptr);
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    deferred1_0 = r0;
    deferred1_1 = r1;
    return getStringFromWasm02(r0, r1);
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
    wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
  }
}
function passArrayJsValueToWasm0(array, malloc) {
  const ptr = malloc(array.length * 4, 4) >>> 0;
  const mem = getDataViewMemory02();
  for (let i = 0; i < array.length; i++) {
    mem.setUint32(ptr + 4 * i, addHeapObject(array[i]), true);
  }
  WASM_VECTOR_LEN2 = array.length;
  return ptr;
}
function getArrayJsValueFromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  const mem = getDataViewMemory02();
  const result = [];
  for (let i = ptr; i < ptr + 4 * len; i += 4) {
    result.push(takeObject(mem.getUint32(i, true)));
  }
  return result;
}
function setLogLevel2(level) {
  wasm2.setLogLevel(addHeapObject(level));
}
function initWASM32Bindings2(config) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.initWASM32Bindings(retptr, addHeapObject(config));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    if (r1) {
      throw takeObject(r0);
    }
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function initBrowserPanicHook2() {
  wasm2.initBrowserPanicHook();
}
function initConsolePanicHook2() {
  wasm2.initConsolePanicHook();
}
function presentPanicHookLogs2() {
  wasm2.presentPanicHookLogs();
}
function defer2() {
  const ret = wasm2.defer();
  return takeObject(ret);
}
function __wbg_adapter_66(arg0, arg1) {
  wasm2.__wbindgen_export_5(arg0, arg1);
}
function __wbg_adapter_69(arg0, arg1, arg2) {
  wasm2.__wbindgen_export_6(arg0, arg1, addHeapObject(arg2));
}
function __wbg_adapter_72(arg0, arg1) {
  wasm2.__wbindgen_export_7(arg0, arg1);
}
function __wbg_adapter_75(arg0, arg1, arg2) {
  try {
    const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
    wasm2.__wbindgen_export_8(retptr, arg0, arg1, addHeapObject(arg2));
    var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
    var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
    if (r1) {
      throw takeObject(r0);
    }
  } finally {
    wasm2.__wbindgen_add_to_stack_pointer(16);
  }
}
function __wbg_adapter_78(arg0, arg1, arg2) {
  wasm2.__wbindgen_export_9(arg0, arg1, addHeapObject(arg2));
}
function __wbg_adapter_81(arg0, arg1, arg2) {
  wasm2.__wbindgen_export_10(arg0, arg1, addHeapObject(arg2));
}
function __wbg_adapter_84(arg0, arg1, arg2, arg3) {
  const ret = wasm2.__wbindgen_export_11(arg0, arg1, addHeapObject(arg2), arg3);
  return takeObject(ret);
}
function __wbg_adapter_87(arg0, arg1, arg2) {
  wasm2.__wbindgen_export_10(arg0, arg1, arg2);
}
function __wbg_adapter_90(arg0, arg1, arg2) {
  wasm2.__wbindgen_export_12(arg0, arg1, addHeapObject(arg2));
}
function __wbg_adapter_161(arg0, arg1, arg2, arg3) {
  wasm2.__wbindgen_export_13(arg0, arg1, addHeapObject(arg2), addHeapObject(arg3));
}
var AccountsDiscoveryKind = Object.freeze({
  Bip44: 0,
  "0": "Bip44"
});
var AddressVersion2 = Object.freeze({
  /**
   * PubKey addresses always have the version byte set to 0
   */
  PubKey: 0,
  "0": "PubKey",
  /**
   * PubKey ECDSA addresses always have the version byte set to 1
   */
  PubKeyECDSA: 1,
  "1": "PubKeyECDSA",
  /**
   * ScriptHash addresses always have the version byte set to 8
   */
  ScriptHash: 8,
  "8": "ScriptHash"
});
var CommitRevealAddressKind = Object.freeze({
  Receive: 0,
  "0": "Receive",
  Change: 1,
  "1": "Change"
});
var ConnectStrategy = Object.freeze({
  /**
   * Continuously attempt to connect to the server. This behavior will
   * block `connect()` function until the connection is established.
   */
  Retry: 0,
  "0": "Retry",
  /**
   * Causes `connect()` to return immediately if the first-time connection
   * has failed.
   */
  Fallback: 1,
  "1": "Fallback"
});
var Encoding = Object.freeze({
  Borsh: 0,
  "0": "Borsh",
  SerdeJson: 1,
  "1": "SerdeJson"
});
var FeeSource = Object.freeze({
  SenderPays: 0,
  "0": "SenderPays",
  ReceiverPays: 1,
  "1": "ReceiverPays"
});
var Language2 = Object.freeze({
  /**
   * English is presently the only supported language
   */
  English: 0,
  "0": "English"
});
var NetworkType2 = Object.freeze({
  Mainnet: 0,
  "0": "Mainnet",
  Testnet: 1,
  "1": "Testnet",
  Devnet: 2,
  "2": "Devnet",
  Simnet: 3,
  "3": "Simnet"
});
var NewAddressKind = Object.freeze({
  Receive: 0,
  "0": "Receive",
  Change: 1,
  "1": "Change"
});
var Opcodes = Object.freeze({
  OpFalse: 0,
  "0": "OpFalse",
  OpData1: 1,
  "1": "OpData1",
  OpData2: 2,
  "2": "OpData2",
  OpData3: 3,
  "3": "OpData3",
  OpData4: 4,
  "4": "OpData4",
  OpData5: 5,
  "5": "OpData5",
  OpData6: 6,
  "6": "OpData6",
  OpData7: 7,
  "7": "OpData7",
  OpData8: 8,
  "8": "OpData8",
  OpData9: 9,
  "9": "OpData9",
  OpData10: 10,
  "10": "OpData10",
  OpData11: 11,
  "11": "OpData11",
  OpData12: 12,
  "12": "OpData12",
  OpData13: 13,
  "13": "OpData13",
  OpData14: 14,
  "14": "OpData14",
  OpData15: 15,
  "15": "OpData15",
  OpData16: 16,
  "16": "OpData16",
  OpData17: 17,
  "17": "OpData17",
  OpData18: 18,
  "18": "OpData18",
  OpData19: 19,
  "19": "OpData19",
  OpData20: 20,
  "20": "OpData20",
  OpData21: 21,
  "21": "OpData21",
  OpData22: 22,
  "22": "OpData22",
  OpData23: 23,
  "23": "OpData23",
  OpData24: 24,
  "24": "OpData24",
  OpData25: 25,
  "25": "OpData25",
  OpData26: 26,
  "26": "OpData26",
  OpData27: 27,
  "27": "OpData27",
  OpData28: 28,
  "28": "OpData28",
  OpData29: 29,
  "29": "OpData29",
  OpData30: 30,
  "30": "OpData30",
  OpData31: 31,
  "31": "OpData31",
  OpData32: 32,
  "32": "OpData32",
  OpData33: 33,
  "33": "OpData33",
  OpData34: 34,
  "34": "OpData34",
  OpData35: 35,
  "35": "OpData35",
  OpData36: 36,
  "36": "OpData36",
  OpData37: 37,
  "37": "OpData37",
  OpData38: 38,
  "38": "OpData38",
  OpData39: 39,
  "39": "OpData39",
  OpData40: 40,
  "40": "OpData40",
  OpData41: 41,
  "41": "OpData41",
  OpData42: 42,
  "42": "OpData42",
  OpData43: 43,
  "43": "OpData43",
  OpData44: 44,
  "44": "OpData44",
  OpData45: 45,
  "45": "OpData45",
  OpData46: 46,
  "46": "OpData46",
  OpData47: 47,
  "47": "OpData47",
  OpData48: 48,
  "48": "OpData48",
  OpData49: 49,
  "49": "OpData49",
  OpData50: 50,
  "50": "OpData50",
  OpData51: 51,
  "51": "OpData51",
  OpData52: 52,
  "52": "OpData52",
  OpData53: 53,
  "53": "OpData53",
  OpData54: 54,
  "54": "OpData54",
  OpData55: 55,
  "55": "OpData55",
  OpData56: 56,
  "56": "OpData56",
  OpData57: 57,
  "57": "OpData57",
  OpData58: 58,
  "58": "OpData58",
  OpData59: 59,
  "59": "OpData59",
  OpData60: 60,
  "60": "OpData60",
  OpData61: 61,
  "61": "OpData61",
  OpData62: 62,
  "62": "OpData62",
  OpData63: 63,
  "63": "OpData63",
  OpData64: 64,
  "64": "OpData64",
  OpData65: 65,
  "65": "OpData65",
  OpData66: 66,
  "66": "OpData66",
  OpData67: 67,
  "67": "OpData67",
  OpData68: 68,
  "68": "OpData68",
  OpData69: 69,
  "69": "OpData69",
  OpData70: 70,
  "70": "OpData70",
  OpData71: 71,
  "71": "OpData71",
  OpData72: 72,
  "72": "OpData72",
  OpData73: 73,
  "73": "OpData73",
  OpData74: 74,
  "74": "OpData74",
  OpData75: 75,
  "75": "OpData75",
  OpPushData1: 76,
  "76": "OpPushData1",
  OpPushData2: 77,
  "77": "OpPushData2",
  OpPushData4: 78,
  "78": "OpPushData4",
  Op1Negate: 79,
  "79": "Op1Negate",
  OpReserved: 80,
  "80": "OpReserved",
  OpTrue: 81,
  "81": "OpTrue",
  Op2: 82,
  "82": "Op2",
  Op3: 83,
  "83": "Op3",
  Op4: 84,
  "84": "Op4",
  Op5: 85,
  "85": "Op5",
  Op6: 86,
  "86": "Op6",
  Op7: 87,
  "87": "Op7",
  Op8: 88,
  "88": "Op8",
  Op9: 89,
  "89": "Op9",
  Op10: 90,
  "90": "Op10",
  Op11: 91,
  "91": "Op11",
  Op12: 92,
  "92": "Op12",
  Op13: 93,
  "93": "Op13",
  Op14: 94,
  "94": "Op14",
  Op15: 95,
  "95": "Op15",
  Op16: 96,
  "96": "Op16",
  OpNop: 97,
  "97": "OpNop",
  OpVer: 98,
  "98": "OpVer",
  OpIf: 99,
  "99": "OpIf",
  OpNotIf: 100,
  "100": "OpNotIf",
  OpVerIf: 101,
  "101": "OpVerIf",
  OpVerNotIf: 102,
  "102": "OpVerNotIf",
  OpElse: 103,
  "103": "OpElse",
  OpEndIf: 104,
  "104": "OpEndIf",
  OpVerify: 105,
  "105": "OpVerify",
  OpReturn: 106,
  "106": "OpReturn",
  OpToAltStack: 107,
  "107": "OpToAltStack",
  OpFromAltStack: 108,
  "108": "OpFromAltStack",
  Op2Drop: 109,
  "109": "Op2Drop",
  Op2Dup: 110,
  "110": "Op2Dup",
  Op3Dup: 111,
  "111": "Op3Dup",
  Op2Over: 112,
  "112": "Op2Over",
  Op2Rot: 113,
  "113": "Op2Rot",
  Op2Swap: 114,
  "114": "Op2Swap",
  OpIfDup: 115,
  "115": "OpIfDup",
  OpDepth: 116,
  "116": "OpDepth",
  OpDrop: 117,
  "117": "OpDrop",
  OpDup: 118,
  "118": "OpDup",
  OpNip: 119,
  "119": "OpNip",
  OpOver: 120,
  "120": "OpOver",
  OpPick: 121,
  "121": "OpPick",
  OpRoll: 122,
  "122": "OpRoll",
  OpRot: 123,
  "123": "OpRot",
  OpSwap: 124,
  "124": "OpSwap",
  OpTuck: 125,
  "125": "OpTuck",
  /**
   * Splice opcodes.
   */
  OpCat: 126,
  "126": "OpCat",
  OpSubstr: 127,
  "127": "OpSubstr",
  OpLeft: 128,
  "128": "OpLeft",
  OpRight: 129,
  "129": "OpRight",
  OpSize: 130,
  "130": "OpSize",
  /**
   * Bitwise logic opcodes.
   */
  OpInvert: 131,
  "131": "OpInvert",
  OpAnd: 132,
  "132": "OpAnd",
  OpOr: 133,
  "133": "OpOr",
  OpXor: 134,
  "134": "OpXor",
  OpEqual: 135,
  "135": "OpEqual",
  OpEqualVerify: 136,
  "136": "OpEqualVerify",
  OpReserved1: 137,
  "137": "OpReserved1",
  OpReserved2: 138,
  "138": "OpReserved2",
  /**
   * Numeric related opcodes.
   */
  Op1Add: 139,
  "139": "Op1Add",
  Op1Sub: 140,
  "140": "Op1Sub",
  Op2Mul: 141,
  "141": "Op2Mul",
  Op2Div: 142,
  "142": "Op2Div",
  OpNegate: 143,
  "143": "OpNegate",
  OpAbs: 144,
  "144": "OpAbs",
  OpNot: 145,
  "145": "OpNot",
  Op0NotEqual: 146,
  "146": "Op0NotEqual",
  OpAdd: 147,
  "147": "OpAdd",
  OpSub: 148,
  "148": "OpSub",
  OpMul: 149,
  "149": "OpMul",
  OpDiv: 150,
  "150": "OpDiv",
  OpMod: 151,
  "151": "OpMod",
  OpLShift: 152,
  "152": "OpLShift",
  OpRShift: 153,
  "153": "OpRShift",
  OpBoolAnd: 154,
  "154": "OpBoolAnd",
  OpBoolOr: 155,
  "155": "OpBoolOr",
  OpNumEqual: 156,
  "156": "OpNumEqual",
  OpNumEqualVerify: 157,
  "157": "OpNumEqualVerify",
  OpNumNotEqual: 158,
  "158": "OpNumNotEqual",
  OpLessThan: 159,
  "159": "OpLessThan",
  OpGreaterThan: 160,
  "160": "OpGreaterThan",
  OpLessThanOrEqual: 161,
  "161": "OpLessThanOrEqual",
  OpGreaterThanOrEqual: 162,
  "162": "OpGreaterThanOrEqual",
  OpMin: 163,
  "163": "OpMin",
  OpMax: 164,
  "164": "OpMax",
  OpWithin: 165,
  "165": "OpWithin",
  /**
   * Undefined opcodes.
   */
  OpZkPrecompile: 166,
  "166": "OpZkPrecompile",
  OpBlake2bWithKey: 167,
  "167": "OpBlake2bWithKey",
  /**
   * Crypto opcodes.
   */
  OpSHA256: 168,
  "168": "OpSHA256",
  OpCheckMultiSigECDSA: 169,
  "169": "OpCheckMultiSigECDSA",
  OpBlake2b: 170,
  "170": "OpBlake2b",
  OpCheckSigECDSA: 171,
  "171": "OpCheckSigECDSA",
  OpCheckSig: 172,
  "172": "OpCheckSig",
  OpCheckSigVerify: 173,
  "173": "OpCheckSigVerify",
  OpCheckMultiSig: 174,
  "174": "OpCheckMultiSig",
  OpCheckMultiSigVerify: 175,
  "175": "OpCheckMultiSigVerify",
  OpCheckLockTimeVerify: 176,
  "176": "OpCheckLockTimeVerify",
  OpCheckSequenceVerify: 177,
  "177": "OpCheckSequenceVerify",
  /**
   * Transaction introspection opcodes.
   */
  OpTxVersion: 178,
  "178": "OpTxVersion",
  OpTxInputCount: 179,
  "179": "OpTxInputCount",
  OpTxOutputCount: 180,
  "180": "OpTxOutputCount",
  OpTxLockTime: 181,
  "181": "OpTxLockTime",
  OpTxSubnetId: 182,
  "182": "OpTxSubnetId",
  OpTxGas: 183,
  "183": "OpTxGas",
  OpTxPayloadSubstr: 184,
  "184": "OpTxPayloadSubstr",
  OpTxInputIndex: 185,
  "185": "OpTxInputIndex",
  OpOutpointTxId: 186,
  "186": "OpOutpointTxId",
  OpOutpointIndex: 187,
  "187": "OpOutpointIndex",
  OpTxInputScriptSigSubstr: 188,
  "188": "OpTxInputScriptSigSubstr",
  OpTxInputSeq: 189,
  "189": "OpTxInputSeq",
  OpTxInputAmount: 190,
  "190": "OpTxInputAmount",
  OpTxInputSpk: 191,
  "191": "OpTxInputSpk",
  OpTxInputDaaScore: 192,
  "192": "OpTxInputDaaScore",
  OpTxInputIsCoinbase: 193,
  "193": "OpTxInputIsCoinbase",
  OpTxOutputAmount: 194,
  "194": "OpTxOutputAmount",
  OpTxOutputSpk: 195,
  "195": "OpTxOutputSpk",
  OpTxPayloadLen: 196,
  "196": "OpTxPayloadLen",
  OpTxInputSpkLen: 197,
  "197": "OpTxInputSpkLen",
  OpTxInputSpkSubstr: 198,
  "198": "OpTxInputSpkSubstr",
  OpTxOutputSpkLen: 199,
  "199": "OpTxOutputSpkLen",
  OpTxOutputSpkSubstr: 200,
  "200": "OpTxOutputSpkSubstr",
  OpTxInputScriptSigLen: 201,
  "201": "OpTxInputScriptSigLen",
  OpUnknown202: 202,
  "202": "OpUnknown202",
  OpAuthOutputCount: 203,
  "203": "OpAuthOutputCount",
  OpAuthOutputIdx: 204,
  "204": "OpAuthOutputIdx",
  OpNum2Bin: 205,
  "205": "OpNum2Bin",
  OpBin2Num: 206,
  "206": "OpBin2Num",
  OpInputCovenantId: 207,
  "207": "OpInputCovenantId",
  OpCovInputCount: 208,
  "208": "OpCovInputCount",
  OpCovInputIdx: 209,
  "209": "OpCovInputIdx",
  OpCovOutputCount: 210,
  "210": "OpCovOutputCount",
  OpCovOutputIdx: 211,
  "211": "OpCovOutputIdx",
  OpChainblockSeqCommit: 212,
  "212": "OpChainblockSeqCommit",
  OpOutputCovenantId: 213,
  "213": "OpOutputCovenantId",
  OpUnknown214: 214,
  "214": "OpUnknown214",
  OpCheckSigFromStack: 215,
  "215": "OpCheckSigFromStack",
  OpCheckSigFromStackECDSA: 216,
  "216": "OpCheckSigFromStackECDSA",
  OpBlake3: 217,
  "217": "OpBlake3",
  OpBlake3WithKey: 218,
  "218": "OpBlake3WithKey",
  OpUnknown219: 219,
  "219": "OpUnknown219",
  OpUnknown220: 220,
  "220": "OpUnknown220",
  OpUnknown221: 221,
  "221": "OpUnknown221",
  OpUnknown222: 222,
  "222": "OpUnknown222",
  OpUnknown223: 223,
  "223": "OpUnknown223",
  OpUnknown224: 224,
  "224": "OpUnknown224",
  OpUnknown225: 225,
  "225": "OpUnknown225",
  OpUnknown226: 226,
  "226": "OpUnknown226",
  OpUnknown227: 227,
  "227": "OpUnknown227",
  OpUnknown228: 228,
  "228": "OpUnknown228",
  OpUnknown229: 229,
  "229": "OpUnknown229",
  OpUnknown230: 230,
  "230": "OpUnknown230",
  OpUnknown231: 231,
  "231": "OpUnknown231",
  OpUnknown232: 232,
  "232": "OpUnknown232",
  OpUnknown233: 233,
  "233": "OpUnknown233",
  OpUnknown234: 234,
  "234": "OpUnknown234",
  OpUnknown235: 235,
  "235": "OpUnknown235",
  OpUnknown236: 236,
  "236": "OpUnknown236",
  OpUnknown237: 237,
  "237": "OpUnknown237",
  OpUnknown238: 238,
  "238": "OpUnknown238",
  OpUnknown239: 239,
  "239": "OpUnknown239",
  OpUnknown240: 240,
  "240": "OpUnknown240",
  OpUnknown241: 241,
  "241": "OpUnknown241",
  OpUnknown242: 242,
  "242": "OpUnknown242",
  OpUnknown243: 243,
  "243": "OpUnknown243",
  OpUnknown244: 244,
  "244": "OpUnknown244",
  OpUnknown245: 245,
  "245": "OpUnknown245",
  OpUnknown246: 246,
  "246": "OpUnknown246",
  OpUnknown247: 247,
  "247": "OpUnknown247",
  OpUnknown248: 248,
  "248": "OpUnknown248",
  OpUnknown249: 249,
  "249": "OpUnknown249",
  OpSmallInteger: 250,
  "250": "OpSmallInteger",
  OpPubKeys: 251,
  "251": "OpPubKeys",
  OpUnknown252: 252,
  "252": "OpUnknown252",
  OpPubKeyHash: 253,
  "253": "OpPubKeyHash",
  OpPubKey: 254,
  "254": "OpPubKey",
  OpInvalidOpCode: 255,
  "255": "OpInvalidOpCode"
});
var SighashType = Object.freeze({
  All: 0,
  "0": "All",
  None: 1,
  "1": "None",
  Single: 2,
  "2": "Single",
  AllAnyOneCanPay: 3,
  "3": "AllAnyOneCanPay",
  NoneAnyOneCanPay: 4,
  "4": "NoneAnyOneCanPay",
  SingleAnyOneCanPay: 5,
  "5": "SingleAnyOneCanPay"
});
var __wbindgen_enum_BinaryType = ["blob", "arraybuffer"];
var __wbindgen_enum_IdbCursorDirection = ["next", "nextunique", "prev", "prevunique"];
var __wbindgen_enum_IdbRequestReadyState = ["pending", "done"];
var __wbindgen_enum_IdbTransactionMode = ["readonly", "readwrite", "versionchange", "readwriteflush", "cleanup"];
var __wbindgen_enum_RequestCredentials = ["omit", "same-origin", "include"];
var __wbindgen_enum_RequestMode = ["same-origin", "no-cors", "cors", "navigate"];
var AbortableFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_abortable_free(ptr >>> 0, 1));
var Abortable2 = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AbortableFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_abortable_free(ptr, 0);
  }
  /**
   * @returns {boolean}
   */
  isAborted() {
    const ret = wasm2.abortable_isAborted(this.__wbg_ptr);
    return ret !== 0;
  }
  constructor() {
    const ret = wasm2.abortable_new();
    this.__wbg_ptr = ret >>> 0;
    AbortableFinalization2.register(this, this.__wbg_ptr, this);
    return this;
  }
  abort() {
    wasm2.abortable_abort(this.__wbg_ptr);
  }
  check() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.abortable_check(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  reset() {
    wasm2.abortable_reset(this.__wbg_ptr);
  }
};
var AbortedFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_aborted_free(ptr >>> 0, 1));
var Aborted2 = class _Aborted {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Aborted.prototype);
    obj.__wbg_ptr = ptr;
    AbortedFinalization2.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AbortedFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_aborted_free(ptr, 0);
  }
};
var AccountKindFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_accountkind_free(ptr >>> 0, 1));
var AccountKind = class _AccountKind {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_AccountKind.prototype);
    obj.__wbg_ptr = ptr;
    AccountKindFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AccountKindFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_accountkind_free(ptr, 0);
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.accountkind_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {string} kind
   */
  constructor(kind) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(kind, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.accountkind_ctor(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      AccountKindFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var AddressFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_address_free(ptr >>> 0, 1));
var Address2 = class _Address {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Address.prototype);
    obj.__wbg_ptr = ptr;
    AddressFinalization2.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      prefix: this.prefix,
      payload: this.payload,
      version: this.version
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AddressFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_address_free(ptr, 0);
  }
  /**
   * @param {string} address
   */
  constructor(address) {
    const ptr0 = passStringToWasm02(address, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    const ret = wasm2.address_constructor(ptr0, len0);
    this.__wbg_ptr = ret >>> 0;
    AddressFinalization2.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {string}
   */
  get prefix() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.address_prefix(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Convert an address to a string.
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.address_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get payload() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.address_payload(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get version() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.address_version(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {string} prefix
   */
  set setPrefix(prefix) {
    const ptr0 = passStringToWasm02(prefix, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.address_set_setPrefix(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @param {string} address
   * @returns {boolean}
   */
  static validate(address) {
    const ptr0 = passStringToWasm02(address, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    const ret = wasm2.address_validate(ptr0, len0);
    return ret !== 0;
  }
};
var AgentConstructorOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_agentconstructoroptions_free(ptr >>> 0, 1));
var AgentConstructorOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AgentConstructorOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_agentconstructoroptions_free(ptr, 0);
  }
  /**
   * @returns {boolean}
   */
  get keep_alive() {
    const ret = wasm2.agentconstructoroptions_keep_alive(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @returns {number}
   */
  get max_sockets() {
    const ret = wasm2.agentconstructoroptions_max_sockets(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} value
   */
  set timeout(value) {
    wasm2.agentconstructoroptions_set_timeout(this.__wbg_ptr, value);
  }
  /**
   * @param {boolean} value
   */
  set keep_alive(value) {
    wasm2.agentconstructoroptions_set_keep_alive(this.__wbg_ptr, value);
  }
  /**
   * @param {number} value
   */
  set max_sockets(value) {
    wasm2.agentconstructoroptions_set_max_sockets(this.__wbg_ptr, value);
  }
  /**
   * @returns {number}
   */
  get keep_alive_msecs() {
    const ret = wasm2.agentconstructoroptions_keep_alive_msecs(this.__wbg_ptr);
    return ret;
  }
  /**
   * @returns {number}
   */
  get max_free_sockets() {
    const ret = wasm2.agentconstructoroptions_max_free_sockets(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} value
   */
  set keep_alive_msecs(value) {
    wasm2.agentconstructoroptions_set_keep_alive_msecs(this.__wbg_ptr, value);
  }
  /**
   * @param {number} value
   */
  set max_free_sockets(value) {
    wasm2.agentconstructoroptions_set_max_free_sockets(this.__wbg_ptr, value);
  }
  /**
   * @returns {number}
   */
  get timeout() {
    const ret = wasm2.agentconstructoroptions_timeout(this.__wbg_ptr);
    return ret;
  }
};
var AppendFileOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_appendfileoptions_free(ptr >>> 0, 1));
var AppendFileOptions = class _AppendFileOptions {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_AppendFileOptions.prototype);
    obj.__wbg_ptr = ptr;
    AppendFileOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AppendFileOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_appendfileoptions_free(ptr, 0);
  }
  /**
   * @param {string | null} [value]
   */
  set encoding(value) {
    wasm2.appendfileoptions_set_encoding(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {string | null} [encoding]
   * @param {number | null} [mode]
   * @param {string | null} [flag]
   */
  constructor(encoding, mode, flag) {
    const ret = wasm2.appendfileoptions_new_with_values(isLikeNone2(encoding) ? 0 : addHeapObject(encoding), isLikeNone2(mode) ? 4294967297 : mode >>> 0, isLikeNone2(flag) ? 0 : addHeapObject(flag));
    this.__wbg_ptr = ret >>> 0;
    AppendFileOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {AppendFileOptions}
   */
  static new() {
    const ret = wasm2.appendfileoptions_new();
    return _AppendFileOptions.__wrap(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get flag() {
    const ret = wasm2.appendfileoptions_flag(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {number | undefined}
   */
  get mode() {
    const ret = wasm2.appendfileoptions_mode(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @returns {string | undefined}
   */
  get encoding() {
    const ret = wasm2.appendfileoptions_encoding(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {string | null} [value]
   */
  set flag(value) {
    wasm2.appendfileoptions_set_flag(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {number | null} [value]
   */
  set mode(value) {
    wasm2.appendfileoptions_set_mode(this.__wbg_ptr, isLikeNone2(value) ? 4294967297 : value >>> 0);
  }
};
var AssertionErrorOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_assertionerroroptions_free(ptr >>> 0, 1));
var AssertionErrorOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    AssertionErrorOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_assertionerroroptions_free(ptr, 0);
  }
  /**
   * @param {any} value
   */
  set actual(value) {
    wasm2.assertionerroroptions_set_actual(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {string | null} [value]
   */
  set message(value) {
    wasm2.assertionerroroptions_set_message(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {any} value
   */
  set expected(value) {
    wasm2.assertionerroroptions_set_expected(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {string} value
   */
  set operator(value) {
    wasm2.assertionerroroptions_set_operator(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {string | null | undefined} message
   * @param {any} actual
   * @param {any} expected
   * @param {string} operator
   */
  constructor(message, actual, expected, operator) {
    const ret = wasm2.assertionerroroptions_new(isLikeNone2(message) ? 0 : addHeapObject(message), addHeapObject(actual), addHeapObject(expected), addHeapObject(operator));
    this.__wbg_ptr = ret >>> 0;
    AssertionErrorOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * The actual property on the error instance.
   * @returns {any}
   */
  get actual() {
    const ret = wasm2.assertionerroroptions_actual(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * If provided, the error message is set to this value.
   * @returns {string | undefined}
   */
  get message() {
    const ret = wasm2.assertionerroroptions_message(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * The expected property on the error instance.
   * @returns {any}
   */
  get expected() {
    const ret = wasm2.assertionerroroptions_expected(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * The operator property on the error instance.
   * @returns {string}
   */
  get operator() {
    const ret = wasm2.assertionerroroptions_operator(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var BalanceFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_balance_free(ptr >>> 0, 1));
var Balance = class _Balance {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Balance.prototype);
    obj.__wbg_ptr = ptr;
    BalanceFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    BalanceFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_balance_free(ptr, 0);
  }
  /**
   * @param {NetworkType | NetworkId | string} network_type
   * @returns {BalanceStrings}
   */
  toBalanceStrings(network_type) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.balance_toBalanceStrings(retptr, this.__wbg_ptr, addBorrowedObject(network_type));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return BalanceStrings.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Confirmed amount of funds available for spending.
   * @returns {bigint}
   */
  get mature() {
    const ret = wasm2.balance_mature(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Amount of funds that are being received and are not yet confirmed.
   * @returns {bigint}
   */
  get pending() {
    const ret = wasm2.balance_pending(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Amount of funds that are being send and are not yet accepted by the network.
   * @returns {bigint}
   */
  get outgoing() {
    const ret = wasm2.balance_outgoing(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var BalanceStringsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_balancestrings_free(ptr >>> 0, 1));
var BalanceStrings = class _BalanceStrings {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_BalanceStrings.prototype);
    obj.__wbg_ptr = ptr;
    BalanceStringsFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    BalanceStringsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_balancestrings_free(ptr, 0);
  }
  /**
   * @returns {string}
   */
  get mature() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.balancestrings_mature(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string | undefined}
   */
  get pending() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.balancestrings_pending(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var CompressedParentsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_compressedparents_free(ptr >>> 0, 1));
var CompressedParents = class _CompressedParents {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_CompressedParents.prototype);
    obj.__wbg_ptr = ptr;
    CompressedParentsFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {};
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    CompressedParentsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_compressedparents_free(ptr, 0);
  }
  /**
   * Converts the compressed parents to an expanded `JsValue` of `Array<Array<HexString>>`.
   * @returns {any}
   */
  toExpanded() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.compressedparents_toExpanded(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * The number of levels in the expanded representation.
   * @returns {number}
   */
  expandedLen() {
    const ret = wasm2.compressedparents_expandedLen(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * Get the parent hashes at a specific level.
   * Returns an array of `HexString`s.
   * @param {number} index
   * @returns {any}
   */
  get(index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.compressedparents_get(retptr, this.__wbg_ptr, index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {any} js_value
   */
  constructor(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.compressedparents_new(retptr, addHeapObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      CompressedParentsFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var ConsoleConstructorOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_consoleconstructoroptions_free(ptr >>> 0, 1));
var ConsoleConstructorOptions = class _ConsoleConstructorOptions {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_ConsoleConstructorOptions.prototype);
    obj.__wbg_ptr = ptr;
    ConsoleConstructorOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    ConsoleConstructorOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_consoleconstructoroptions_free(ptr, 0);
  }
  /**
   * @param {any} value
   */
  set stderr(value) {
    wasm2.consoleconstructoroptions_set_stderr(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {any} value
   */
  set stdout(value) {
    wasm2.consoleconstructoroptions_set_stdout(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @returns {boolean | undefined}
   */
  get ignore_errors() {
    const ret = wasm2.consoleconstructoroptions_ignore_errors(this.__wbg_ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @param {any} value
   */
  set color_mod(value) {
    wasm2.consoleconstructoroptions_set_color_mod(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @returns {object | undefined}
   */
  get inspect_options() {
    const ret = wasm2.consoleconstructoroptions_inspect_options(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {any} stdout
   * @param {any} stderr
   * @param {boolean | null | undefined} ignore_errors
   * @param {any} color_mod
   * @param {object | null} [inspect_options]
   */
  constructor(stdout, stderr, ignore_errors, color_mod, inspect_options) {
    const ret = wasm2.consoleconstructoroptions_new_with_values(addHeapObject(stdout), addHeapObject(stderr), isLikeNone2(ignore_errors) ? 16777215 : ignore_errors ? 1 : 0, addHeapObject(color_mod), isLikeNone2(inspect_options) ? 0 : addHeapObject(inspect_options));
    this.__wbg_ptr = ret >>> 0;
    ConsoleConstructorOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @param {boolean | null} [value]
   */
  set ignore_errors(value) {
    wasm2.consoleconstructoroptions_set_ignore_errors(this.__wbg_ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
  /**
   * @param {object | null} [value]
   */
  set inspect_options(value) {
    wasm2.consoleconstructoroptions_set_inspect_options(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {any} stdout
   * @param {any} stderr
   * @returns {ConsoleConstructorOptions}
   */
  static new(stdout, stderr) {
    const ret = wasm2.consoleconstructoroptions_new(addHeapObject(stdout), addHeapObject(stderr));
    return _ConsoleConstructorOptions.__wrap(ret);
  }
  /**
   * @returns {any}
   */
  get stderr() {
    const ret = wasm2.consoleconstructoroptions_stderr(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {any}
   */
  get stdout() {
    const ret = wasm2.consoleconstructoroptions_stdout(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {any}
   */
  get color_mod() {
    const ret = wasm2.consoleconstructoroptions_color_mod(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var CovenantBindingFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_covenantbinding_free(ptr >>> 0, 1));
var CovenantBinding = class _CovenantBinding {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_CovenantBinding.prototype);
    obj.__wbg_ptr = ptr;
    CovenantBindingFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      covenantId: this.covenantId,
      authorizingInput: this.authorizingInput
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    CovenantBindingFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_covenantbinding_free(ptr, 0);
  }
  /**
   * @returns {object}
   */
  toJSON() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.covenantbinding_toJSON(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {Hash}
   */
  get covenantId() {
    const ret = wasm2.covenantbinding_covenantId(this.__wbg_ptr);
    return Hash2.__wrap(ret);
  }
  /**
   * @param {Hash} v
   */
  set covenantId(v) {
    _assertClass2(v, Hash2);
    var ptr0 = v.__destroy_into_raw();
    wasm2.covenantbinding_set_covenantId(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {number}
   */
  get authorizingInput() {
    const ret = wasm2.covenantbinding_authorizingInput(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} v
   */
  set authorizingInput(v) {
    wasm2.covenantbinding_set_authorizingInput(this.__wbg_ptr, v);
  }
  /**
   * @param {number} authorizing_input
   * @param {Hash} covenant_id
   */
  constructor(authorizing_input, covenant_id) {
    _assertClass2(covenant_id, Hash2);
    var ptr0 = covenant_id.__destroy_into_raw();
    const ret = wasm2.covenantbinding_new(authorizing_input, ptr0);
    this.__wbg_ptr = ret >>> 0;
    CovenantBindingFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
};
var CreateHookCallbacksFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_createhookcallbacks_free(ptr >>> 0, 1));
var CreateHookCallbacks = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    CreateHookCallbacksFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_createhookcallbacks_free(ptr, 0);
  }
  /**
   * @param {Function} value
   */
  set before(value) {
    wasm2.createhookcallbacks_set_before(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {Function} value
   */
  set destroy(value) {
    wasm2.createhookcallbacks_set_destroy(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @returns {Function}
   */
  get promise_resolve() {
    const ret = wasm2.createhookcallbacks_promise_resolve(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {Function} value
   */
  set promise_resolve(value) {
    wasm2.createhookcallbacks_set_promise_resolve(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {Function} init
   * @param {Function} before
   * @param {Function} after
   * @param {Function} destroy
   * @param {Function} promise_resolve
   */
  constructor(init, before, after, destroy, promise_resolve) {
    try {
      const ret = wasm2.createhookcallbacks_new(addBorrowedObject(init), addBorrowedObject(before), addBorrowedObject(after), addBorrowedObject(destroy), addBorrowedObject(promise_resolve));
      this.__wbg_ptr = ret >>> 0;
      CreateHookCallbacksFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      heap[stack_pointer++] = void 0;
      heap[stack_pointer++] = void 0;
      heap[stack_pointer++] = void 0;
      heap[stack_pointer++] = void 0;
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {Function}
   */
  get init() {
    const ret = wasm2.createhookcallbacks_init(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {Function}
   */
  get after() {
    const ret = wasm2.createhookcallbacks_after(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {Function}
   */
  get before() {
    const ret = wasm2.createhookcallbacks_before(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {Function}
   */
  get destroy() {
    const ret = wasm2.createhookcallbacks_destroy(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {Function} value
   */
  set init(value) {
    wasm2.createhookcallbacks_set_init(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {Function} value
   */
  set after(value) {
    wasm2.createhookcallbacks_set_after(this.__wbg_ptr, addHeapObject(value));
  }
};
var CreateReadStreamOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_createreadstreamoptions_free(ptr >>> 0, 1));
var CreateReadStreamOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    CreateReadStreamOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_createreadstreamoptions_free(ptr, 0);
  }
  /**
   * @returns {boolean | undefined}
   */
  get auto_close() {
    const ret = wasm2.createreadstreamoptions_auto_close(this.__wbg_ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @returns {boolean | undefined}
   */
  get emit_close() {
    const ret = wasm2.createreadstreamoptions_emit_close(this.__wbg_ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @param {string | null} [value]
   */
  set encoding(value) {
    wasm2.createreadstreamoptions_set_encoding(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {boolean | null} [value]
   */
  set auto_close(value) {
    wasm2.createreadstreamoptions_set_auto_close(this.__wbg_ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
  /**
   * @param {boolean | null} [value]
   */
  set emit_close(value) {
    wasm2.createreadstreamoptions_set_emit_close(this.__wbg_ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
  /**
   * @returns {number | undefined}
   */
  get high_water_mark() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.createreadstreamoptions_high_water_mark(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getFloat64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : r2;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {boolean | null} [auto_close]
   * @param {boolean | null} [emit_close]
   * @param {string | null} [encoding]
   * @param {number | null} [end]
   * @param {number | null} [fd]
   * @param {string | null} [flags]
   * @param {number | null} [high_water_mark]
   * @param {number | null} [mode]
   * @param {number | null} [start]
   */
  constructor(auto_close, emit_close, encoding, end, fd, flags, high_water_mark, mode, start) {
    const ret = wasm2.createreadstreamoptions_new_with_values(isLikeNone2(auto_close) ? 16777215 : auto_close ? 1 : 0, isLikeNone2(emit_close) ? 16777215 : emit_close ? 1 : 0, isLikeNone2(encoding) ? 0 : addHeapObject(encoding), !isLikeNone2(end), isLikeNone2(end) ? 0 : end, isLikeNone2(fd) ? 4294967297 : fd >>> 0, isLikeNone2(flags) ? 0 : addHeapObject(flags), !isLikeNone2(high_water_mark), isLikeNone2(high_water_mark) ? 0 : high_water_mark, isLikeNone2(mode) ? 4294967297 : mode >>> 0, !isLikeNone2(start), isLikeNone2(start) ? 0 : start);
    this.__wbg_ptr = ret >>> 0;
    CreateReadStreamOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @param {number | null} [value]
   */
  set high_water_mark(value) {
    wasm2.createreadstreamoptions_set_high_water_mark(this.__wbg_ptr, !isLikeNone2(value), isLikeNone2(value) ? 0 : value);
  }
  /**
   * @returns {number | undefined}
   */
  get fd() {
    const ret = wasm2.createreadstreamoptions_fd(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @returns {number | undefined}
   */
  get end() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.createreadstreamoptions_end(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getFloat64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : r2;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {number | undefined}
   */
  get mode() {
    const ret = wasm2.createreadstreamoptions_mode(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @returns {string | undefined}
   */
  get flags() {
    const ret = wasm2.createreadstreamoptions_flags(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {number | undefined}
   */
  get start() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.createreadstreamoptions_start(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getFloat64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : r2;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {number | null} [value]
   */
  set fd(value) {
    wasm2.createreadstreamoptions_set_fd(this.__wbg_ptr, isLikeNone2(value) ? 4294967297 : value >>> 0);
  }
  /**
   * @param {number | null} [value]
   */
  set end(value) {
    wasm2.createreadstreamoptions_set_end(this.__wbg_ptr, !isLikeNone2(value), isLikeNone2(value) ? 0 : value);
  }
  /**
   * @returns {string | undefined}
   */
  get encoding() {
    const ret = wasm2.createreadstreamoptions_encoding(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {number | null} [value]
   */
  set mode(value) {
    wasm2.createreadstreamoptions_set_mode(this.__wbg_ptr, isLikeNone2(value) ? 4294967297 : value >>> 0);
  }
  /**
   * @param {string | null} [value]
   */
  set flags(value) {
    wasm2.createreadstreamoptions_set_flags(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {number | null} [value]
   */
  set start(value) {
    wasm2.createreadstreamoptions_set_start(this.__wbg_ptr, !isLikeNone2(value), isLikeNone2(value) ? 0 : value);
  }
};
var CreateWriteStreamOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_createwritestreamoptions_free(ptr >>> 0, 1));
var CreateWriteStreamOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    CreateWriteStreamOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_createwritestreamoptions_free(ptr, 0);
  }
  /**
   * @returns {boolean | undefined}
   */
  get auto_close() {
    const ret = wasm2.createwritestreamoptions_auto_close(this.__wbg_ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @returns {boolean | undefined}
   */
  get emit_close() {
    const ret = wasm2.createwritestreamoptions_emit_close(this.__wbg_ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @param {string | null} [value]
   */
  set encoding(value) {
    wasm2.createwritestreamoptions_set_encoding(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {boolean | null} [value]
   */
  set auto_close(value) {
    wasm2.createwritestreamoptions_set_auto_close(this.__wbg_ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
  /**
   * @param {boolean | null} [value]
   */
  set emit_close(value) {
    wasm2.createwritestreamoptions_set_emit_close(this.__wbg_ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
  /**
   * @param {boolean | null} [auto_close]
   * @param {boolean | null} [emit_close]
   * @param {string | null} [encoding]
   * @param {number | null} [fd]
   * @param {string | null} [flags]
   * @param {number | null} [mode]
   * @param {number | null} [start]
   */
  constructor(auto_close, emit_close, encoding, fd, flags, mode, start) {
    const ret = wasm2.createwritestreamoptions_new_with_values(isLikeNone2(auto_close) ? 16777215 : auto_close ? 1 : 0, isLikeNone2(emit_close) ? 16777215 : emit_close ? 1 : 0, isLikeNone2(encoding) ? 0 : addHeapObject(encoding), isLikeNone2(fd) ? 4294967297 : fd >>> 0, isLikeNone2(flags) ? 0 : addHeapObject(flags), isLikeNone2(mode) ? 4294967297 : mode >>> 0, !isLikeNone2(start), isLikeNone2(start) ? 0 : start);
    this.__wbg_ptr = ret >>> 0;
    CreateWriteStreamOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {number | undefined}
   */
  get fd() {
    const ret = wasm2.createwritestreamoptions_fd(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @returns {number | undefined}
   */
  get mode() {
    const ret = wasm2.createwritestreamoptions_mode(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @returns {string | undefined}
   */
  get flags() {
    const ret = wasm2.createwritestreamoptions_flags(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {number | undefined}
   */
  get start() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.createwritestreamoptions_start(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getFloat64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : r2;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {number | null} [value]
   */
  set fd(value) {
    wasm2.createwritestreamoptions_set_fd(this.__wbg_ptr, isLikeNone2(value) ? 4294967297 : value >>> 0);
  }
  /**
   * @returns {string | undefined}
   */
  get encoding() {
    const ret = wasm2.createwritestreamoptions_encoding(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {number | null} [value]
   */
  set mode(value) {
    wasm2.createwritestreamoptions_set_mode(this.__wbg_ptr, isLikeNone2(value) ? 4294967297 : value >>> 0);
  }
  /**
   * @param {string | null} [value]
   */
  set flags(value) {
    wasm2.createwritestreamoptions_set_flags(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {number | null} [value]
   */
  set start(value) {
    wasm2.createwritestreamoptions_set_start(this.__wbg_ptr, !isLikeNone2(value), isLikeNone2(value) ? 0 : value);
  }
};
var CryptoBoxFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_cryptobox_free(ptr >>> 0, 1));
var CryptoBox = class {
  toJSON() {
    return {
      publicKey: this.publicKey
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    CryptoBoxFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_cryptobox_free(ptr, 0);
  }
  /**
   * @returns {string}
   */
  get publicKey() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.cryptobox_publicKey(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {CryptoBoxPrivateKey | HexString | Uint8Array} secretKey
   * @param {CryptoBoxPublicKey | HexString | Uint8Array} peerPublicKey
   */
  constructor(secretKey, peerPublicKey) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.cryptobox_ctor(retptr, addBorrowedObject(secretKey), addBorrowedObject(peerPublicKey));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      CryptoBoxFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {string} base64string
   * @returns {string}
   */
  decrypt(base64string) {
    let deferred3_0;
    let deferred3_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(base64string, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.cryptobox_decrypt(retptr, this.__wbg_ptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr2 = r0;
      var len2 = r1;
      if (r3) {
        ptr2 = 0;
        len2 = 0;
        throw takeObject(r2);
      }
      deferred3_0 = ptr2;
      deferred3_1 = len2;
      return getStringFromWasm02(ptr2, len2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred3_0, deferred3_1, 1);
    }
  }
  /**
   * @param {string} plaintext
   * @returns {string}
   */
  encrypt(plaintext) {
    let deferred3_0;
    let deferred3_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(plaintext, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.cryptobox_encrypt(retptr, this.__wbg_ptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr2 = r0;
      var len2 = r1;
      if (r3) {
        ptr2 = 0;
        len2 = 0;
        throw takeObject(r2);
      }
      deferred3_0 = ptr2;
      deferred3_1 = len2;
      return getStringFromWasm02(ptr2, len2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred3_0, deferred3_1, 1);
    }
  }
};
var CryptoBoxPrivateKeyFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_cryptoboxprivatekey_free(ptr >>> 0, 1));
var CryptoBoxPrivateKey = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    CryptoBoxPrivateKeyFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_cryptoboxprivatekey_free(ptr, 0);
  }
  /**
   * @returns {CryptoBoxPublicKey}
   */
  to_public_key() {
    const ret = wasm2.cryptoboxprivatekey_to_public_key(this.__wbg_ptr);
    return CryptoBoxPublicKey.__wrap(ret);
  }
  /**
   * @param {HexString | Uint8Array} secretKey
   */
  constructor(secretKey) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.cryptoboxprivatekey_ctor(retptr, addHeapObject(secretKey));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      CryptoBoxPrivateKeyFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var CryptoBoxPublicKeyFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_cryptoboxpublickey_free(ptr >>> 0, 1));
var CryptoBoxPublicKey = class _CryptoBoxPublicKey {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_CryptoBoxPublicKey.prototype);
    obj.__wbg_ptr = ptr;
    CryptoBoxPublicKeyFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    CryptoBoxPublicKeyFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_cryptoboxpublickey_free(ptr, 0);
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.cryptoboxpublickey_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {HexString | Uint8Array} publicKey
   */
  constructor(publicKey2) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.cryptoboxpublickey_ctor(retptr, addHeapObject(publicKey2));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      CryptoBoxPublicKeyFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var DerivationPathFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_derivationpath_free(ptr >>> 0, 1));
var DerivationPath = class _DerivationPath {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_DerivationPath.prototype);
    obj.__wbg_ptr = ptr;
    DerivationPathFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    DerivationPathFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_derivationpath_free(ptr, 0);
  }
  /**
   * Get the count of [`ChildNumber`] values in this derivation path.
   * @returns {number}
   */
  length() {
    const ret = wasm2.derivationpath_length(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * @param {string} path
   */
  constructor(path) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(path, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.derivationpath_new(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      DerivationPathFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Push a [`ChildNumber`] onto an existing derivation path.
   * @param {number} child_number
   * @param {boolean | null} [hardened]
   */
  push(child_number, hardened) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.derivationpath_push(retptr, this.__wbg_ptr, child_number, isLikeNone2(hardened) ? 16777215 : hardened ? 1 : 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Get the parent [`DerivationPath`] for the current one.
   *
   * Returns `Undefined` if this is already the root path.
   * @returns {DerivationPath | undefined}
   */
  parent() {
    const ret = wasm2.derivationpath_parent(this.__wbg_ptr);
    return ret === 0 ? void 0 : _DerivationPath.__wrap(ret);
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.derivationpath_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Is this derivation path empty? (i.e. the root)
   * @returns {boolean}
   */
  isEmpty() {
    const ret = wasm2.derivationpath_isEmpty(this.__wbg_ptr);
    return ret !== 0;
  }
};
var FormatInputPathObjectFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_formatinputpathobject_free(ptr >>> 0, 1));
var FormatInputPathObject = class _FormatInputPathObject {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_FormatInputPathObject.prototype);
    obj.__wbg_ptr = ptr;
    FormatInputPathObjectFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    FormatInputPathObjectFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_formatinputpathobject_free(ptr, 0);
  }
  /**
   * @param {string | null} [base]
   * @param {string | null} [dir]
   * @param {string | null} [ext]
   * @param {string | null} [name]
   * @param {string | null} [root]
   */
  constructor(base2, dir, ext, name, root) {
    const ret = wasm2.formatinputpathobject_new_with_values(isLikeNone2(base2) ? 0 : addHeapObject(base2), isLikeNone2(dir) ? 0 : addHeapObject(dir), isLikeNone2(ext) ? 0 : addHeapObject(ext), isLikeNone2(name) ? 0 : addHeapObject(name), isLikeNone2(root) ? 0 : addHeapObject(root));
    this.__wbg_ptr = ret >>> 0;
    FormatInputPathObjectFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {string | undefined}
   */
  get dir() {
    const ret = wasm2.formatinputpathobject_dir(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get ext() {
    const ret = wasm2.formatinputpathobject_ext(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {FormatInputPathObject}
   */
  static new() {
    const ret = wasm2.formatinputpathobject_new();
    return _FormatInputPathObject.__wrap(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get base() {
    const ret = wasm2.formatinputpathobject_base(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get name() {
    const ret = wasm2.formatinputpathobject_name(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get root() {
    const ret = wasm2.formatinputpathobject_root(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {string | null} [value]
   */
  set dir(value) {
    wasm2.formatinputpathobject_set_dir(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {string | null} [value]
   */
  set ext(value) {
    wasm2.formatinputpathobject_set_ext(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {string | null} [value]
   */
  set base(value) {
    wasm2.formatinputpathobject_set_base(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {string | null} [value]
   */
  set name(value) {
    wasm2.formatinputpathobject_set_name(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {string | null} [value]
   */
  set root(value) {
    wasm2.formatinputpathobject_set_root(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
};
var GeneratorFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_generator_free(ptr >>> 0, 1));
var Generator = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    GeneratorFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_generator_free(ptr, 0);
  }
  /**
   * @param {IGeneratorSettingsObject} args
   */
  constructor(args) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.generator_ctor(retptr, addHeapObject(args));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      GeneratorFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Generate next transaction
   * @returns {Promise<any>}
   */
  next() {
    const ret = wasm2.generator_next(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {GeneratorSummary}
   */
  summary() {
    const ret = wasm2.generator_summary(this.__wbg_ptr);
    return GeneratorSummary.__wrap(ret);
  }
  /**
   * @returns {Promise<GeneratorSummary>}
   */
  estimate() {
    const ret = wasm2.generator_estimate(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var GeneratorSummaryFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_generatorsummary_free(ptr >>> 0, 1));
var GeneratorSummary = class _GeneratorSummary {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_GeneratorSummary.prototype);
    obj.__wbg_ptr = ptr;
    GeneratorSummaryFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      networkType: this.networkType,
      fees: this.fees,
      mass: this.mass,
      utxos: this.utxos,
      finalTransactionId: this.finalTransactionId,
      finalAmount: this.finalAmount,
      transactions: this.transactions
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    GeneratorSummaryFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_generatorsummary_free(ptr, 0);
  }
  /**
   * @returns {NetworkType}
   */
  get networkType() {
    const ret = wasm2.generatorsummary_networkType(this.__wbg_ptr);
    return ret;
  }
  /**
   * @returns {bigint}
   */
  get fees() {
    const ret = wasm2.generatorsummary_fees(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {bigint}
   */
  get mass() {
    const ret = wasm2.generatorsummary_mass(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {number}
   */
  get utxos() {
    const ret = wasm2.generatorsummary_utxos(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * @returns {string | undefined}
   */
  get finalTransactionId() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.generatorsummary_finalTransactionId(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {bigint | undefined}
   */
  get finalAmount() {
    const ret = wasm2.generatorsummary_finalAmount(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {number}
   */
  get transactions() {
    const ret = wasm2.generatorsummary_transactions(this.__wbg_ptr);
    return ret >>> 0;
  }
};
var GenesisCovenantGroupFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_genesiscovenantgroup_free(ptr >>> 0, 1));
var GenesisCovenantGroup = class {
  toJSON() {
    return {
      outputs: this.outputs,
      authorizingInput: this.authorizingInput
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    GenesisCovenantGroupFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_genesiscovenantgroup_free(ptr, 0);
  }
  /**
   * @returns {string}
   */
  toString() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.genesiscovenantgroup_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {object}
   */
  toJSON() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.genesiscovenantgroup_toJSON(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {Array<number>}
   */
  get outputs() {
    const ret = wasm2.genesiscovenantgroup_outputs(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {Array<number>} outputs
   */
  set outputs(outputs) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.genesiscovenantgroup_set_outputs(retptr, this.__wbg_ptr, addHeapObject(outputs));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {number}
   */
  get authorizingInput() {
    const ret = wasm2.genesiscovenantgroup_authorizingInput(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} value
   */
  set authorizingInput(value) {
    wasm2.genesiscovenantgroup_set_authorizingInput(this.__wbg_ptr, value);
  }
  /**
   * @param {number} authorizing_input
   * @param {Array<number>} outputs
   */
  constructor(authorizing_input, outputs) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.genesiscovenantgroup_ctor(retptr, authorizing_input, addHeapObject(outputs));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      GenesisCovenantGroupFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var GetNameOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_getnameoptions_free(ptr >>> 0, 1));
var GetNameOptions = class _GetNameOptions {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_GetNameOptions.prototype);
    obj.__wbg_ptr = ptr;
    GetNameOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    GetNameOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_getnameoptions_free(ptr, 0);
  }
  /**
   * @param {number | null} [value]
   */
  set family(value) {
    wasm2.getnameoptions_set_family(this.__wbg_ptr, isLikeNone2(value) ? 16777215 : value);
  }
  /**
   * @returns {string}
   */
  get local_address() {
    const ret = wasm2.getnameoptions_local_address(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {string} value
   */
  set local_address(value) {
    wasm2.getnameoptions_set_local_address(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {number | null | undefined} family
   * @param {string} host
   * @param {string} local_address
   * @param {number} port
   * @returns {GetNameOptions}
   */
  static new(family, host, local_address, port) {
    const ret = wasm2.getnameoptions_new(isLikeNone2(family) ? 16777215 : family, addHeapObject(host), addHeapObject(local_address), port);
    return _GetNameOptions.__wrap(ret);
  }
  /**
   * @returns {string}
   */
  get host() {
    const ret = wasm2.getnameoptions_host(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {number}
   */
  get port() {
    const ret = wasm2.getnameoptions_port(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * @returns {number | undefined}
   */
  get family() {
    const ret = wasm2.getnameoptions_family(this.__wbg_ptr);
    return ret === 16777215 ? void 0 : ret;
  }
  /**
   * @param {string} value
   */
  set host(value) {
    wasm2.getnameoptions_set_host(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {number} value
   */
  set port(value) {
    wasm2.getnameoptions_set_port(this.__wbg_ptr, value);
  }
};
var HashFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_hash_free(ptr >>> 0, 1));
var Hash2 = class _Hash {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Hash.prototype);
    obj.__wbg_ptr = ptr;
    HashFinalization2.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    HashFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_hash_free(ptr, 0);
  }
  /**
   * @param {string} hex_str
   */
  constructor(hex_str) {
    const ptr0 = passStringToWasm02(hex_str, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    const ret = wasm2.hash_constructor(ptr0, len0);
    this.__wbg_ptr = ret >>> 0;
    HashFinalization2.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.hash_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
};
var HeaderFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_header_free(ptr >>> 0, 1));
var Header = class {
  toJSON() {
    return {
      blueScore: this.blueScore,
      version: this.version,
      timestamp: this.timestamp,
      hash: this.hash,
      pruningPoint: this.pruningPoint,
      utxoCommitment: this.utxoCommitment,
      hashMerkleRoot: this.hashMerkleRoot,
      parentsByLevel: this.parentsByLevel,
      acceptedIdMerkleRoot: this.acceptedIdMerkleRoot,
      bits: this.bits,
      nonce: this.nonce,
      blueWork: this.blueWork,
      daaScore: this.daaScore
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    HeaderFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_header_free(ptr, 0);
  }
  /**
   * @returns {bigint}
   */
  get blueScore() {
    const ret = wasm2.header_blue_score(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {Header | IHeader | IRawHeader} js_value
   */
  constructor(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_constructor(retptr, addHeapObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      HeaderFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Finalizes the header and recomputes (updates) the header hash
   * @return { String } header hash
   * @returns {string}
   */
  finalize() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_finalize(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {number}
   */
  get version() {
    const ret = wasm2.header_get_version(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} version
   */
  set version(version2) {
    wasm2.header_set_version(this.__wbg_ptr, version2);
  }
  /**
   * @returns {bigint}
   */
  get timestamp() {
    const ret = wasm2.header_get_timestamp(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} daa_score
   */
  set daaScore(daa_score) {
    wasm2.header_set_daa_score(this.__wbg_ptr, daa_score);
  }
  /**
   * @param {bigint} timestamp
   */
  set timestamp(timestamp) {
    wasm2.header_set_timestamp(this.__wbg_ptr, timestamp);
  }
  /**
   * @param {bigint} blue_score
   */
  set blueScore(blue_score) {
    wasm2.header_set_blue_score(this.__wbg_ptr, blue_score);
  }
  /**
   * @returns {string}
   */
  get hash() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_get_hash_as_hex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  getBlueWorkAsHex() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_getBlueWorkAsHex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get pruningPoint() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_get_pruning_point_as_hex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get utxoCommitment() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_get_utxo_commitment_as_hex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get hashMerkleRoot() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_get_hash_merkle_root_as_hex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {any} js_value
   */
  set blueWork(js_value) {
    wasm2.header_set_blue_work_from_js_value(this.__wbg_ptr, addHeapObject(js_value));
  }
  /**
   * @param {any} js_value
   */
  set pruningPoint(js_value) {
    wasm2.header_set_pruning_point_from_js_value(this.__wbg_ptr, addHeapObject(js_value));
  }
  /**
   * @returns {any}
   */
  get parentsByLevel() {
    const ret = wasm2.header_get_parents_by_level_as_js_value(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {any} js_value
   */
  set utxoCommitment(js_value) {
    wasm2.header_set_utxo_commitment_from_js_value(this.__wbg_ptr, addHeapObject(js_value));
  }
  /**
   * @returns {string}
   */
  get acceptedIdMerkleRoot() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_get_accepted_id_merkle_root_as_hex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {any} js_value
   */
  set hashMerkleRoot(js_value) {
    wasm2.header_set_hash_merkle_root_from_js_value(this.__wbg_ptr, addHeapObject(js_value));
  }
  /**
   * @param {any} js_value
   */
  set parentsByLevel(js_value) {
    wasm2.header_set_parents_by_level_from_js_value(this.__wbg_ptr, addHeapObject(js_value));
  }
  /**
   * @param {any} js_value
   */
  set acceptedIdMerkleRoot(js_value) {
    wasm2.header_set_accepted_id_merkle_root_from_js_value(this.__wbg_ptr, addHeapObject(js_value));
  }
  /**
   * @returns {number}
   */
  get bits() {
    const ret = wasm2.header_bits(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * @returns {bigint}
   */
  get nonce() {
    const ret = wasm2.header_nonce(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * Obtain `JSON` representation of the header. JSON representation
   * should be obtained using WASM, to ensure proper serialization of
   * big integers.
   * @returns {string}
   */
  asJSON() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.header_asJSON(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {number} bits
   */
  set bits(bits) {
    wasm2.header_set_bits(this.__wbg_ptr, bits);
  }
  /**
   * @returns {bigint}
   */
  get blueWork() {
    const ret = wasm2.header_blue_work(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {bigint}
   */
  get daaScore() {
    const ret = wasm2.header_daa_score(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} nonce
   */
  set nonce(nonce) {
    wasm2.header_set_nonce(this.__wbg_ptr, nonce);
  }
};
var KeypairFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_keypair_free(ptr >>> 0, 1));
var Keypair = class _Keypair {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Keypair.prototype);
    obj.__wbg_ptr = ptr;
    KeypairFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      publicKey: this.publicKey,
      privateKey: this.privateKey,
      xOnlyPublicKey: this.xOnlyPublicKey
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    KeypairFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_keypair_free(ptr, 0);
  }
  /**
   * Get the [`Address`] of this Keypair's [`PublicKey`].
   * Receives a [`NetworkType`](kaspa_consensus_core::network::NetworkType)
   * to determine the prefix of the address.
   * JavaScript: `let address = keypair.toAddress(NetworkType.MAINNET);`.
   * @param {NetworkType | NetworkId | string} network
   * @returns {Address}
   */
  toAddress(network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.keypair_toAddress(retptr, this.__wbg_ptr, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Get the [`PublicKey`] of this [`Keypair`].
   * @returns {string}
   */
  get publicKey() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.keypair_get_public_key(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Get the [`PrivateKey`] of this [`Keypair`].
   * @returns {string}
   */
  get privateKey() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.keypair_get_private_key(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Create a new [`Keypair`] from a [`PrivateKey`].
   * JavaScript: `let privkey = new PrivateKey(hexString); let keypair = privkey.toKeypair();`.
   * @param {PrivateKey} secret_key
   * @returns {Keypair}
   */
  static fromPrivateKey(secret_key) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      _assertClass2(secret_key, PrivateKey);
      wasm2.keypair_fromPrivateKey(retptr, secret_key.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _Keypair.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Get `ECDSA` [`Address`] of this Keypair's [`PublicKey`].
   * Receives a [`NetworkType`](kaspa_consensus_core::network::NetworkType)
   * to determine the prefix of the address.
   * JavaScript: `let address = keypair.toAddress(NetworkType.MAINNET);`.
   * @param {NetworkType | NetworkId | string} network
   * @returns {Address}
   */
  toAddressECDSA(network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.keypair_toAddressECDSA(retptr, this.__wbg_ptr, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Get the `XOnlyPublicKey` of this [`Keypair`].
   * @returns {any}
   */
  get xOnlyPublicKey() {
    const ret = wasm2.keypair_get_xonly_public_key(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Create a new random [`Keypair`].
   * JavaScript: `let keypair = Keypair::random();`.
   * @returns {Keypair}
   */
  static random() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.keypair_random(retptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _Keypair.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var MkdtempSyncOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_mkdtempsyncoptions_free(ptr >>> 0, 1));
var MkdtempSyncOptions = class _MkdtempSyncOptions {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_MkdtempSyncOptions.prototype);
    obj.__wbg_ptr = ptr;
    MkdtempSyncOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    MkdtempSyncOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_mkdtempsyncoptions_free(ptr, 0);
  }
  /**
   * @param {string | null} [value]
   */
  set encoding(value) {
    wasm2.mkdtempsyncoptions_set_encoding(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {string | null} [encoding]
   */
  constructor(encoding) {
    const ret = wasm2.mkdtempsyncoptions_new_with_values(isLikeNone2(encoding) ? 0 : addHeapObject(encoding));
    this.__wbg_ptr = ret >>> 0;
    MkdtempSyncOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {MkdtempSyncOptions}
   */
  static new() {
    const ret = wasm2.mkdtempsyncoptions_new();
    return _MkdtempSyncOptions.__wrap(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get encoding() {
    const ret = wasm2.mkdtempsyncoptions_encoding(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var MnemonicFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_mnemonic_free(ptr >>> 0, 1));
var Mnemonic2 = class _Mnemonic {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Mnemonic.prototype);
    obj.__wbg_ptr = ptr;
    MnemonicFinalization2.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      entropy: this.entropy,
      phrase: this.phrase
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    MnemonicFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_mnemonic_free(ptr, 0);
  }
  /**
   * @param {string} phrase
   */
  set phrase(phrase) {
    const ptr0 = passStringToWasm02(phrase, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.mnemonic_set_phrase(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @param {string} phrase
   * @param {Language | null} [language]
   */
  constructor(phrase, language) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(phrase, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.mnemonic_constructor(retptr, ptr0, len0, isLikeNone2(language) ? 1 : language);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      MnemonicFinalization2.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {string | null} [password]
   * @returns {string}
   */
  toSeed(password) {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      var ptr0 = isLikeNone2(password) ? 0 : passStringToWasm02(password, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      var len0 = WASM_VECTOR_LEN2;
      wasm2.mnemonic_toSeed(retptr, this.__wbg_ptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred2_0 = r0;
      deferred2_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get entropy() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.mnemonic_entropy(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {string} entropy
   */
  set entropy(entropy) {
    const ptr0 = passStringToWasm02(entropy, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.mnemonic_set_entropy(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @returns {string}
   */
  get phrase() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.mnemonic_phrase(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {number | null} [word_count]
   * @returns {Mnemonic}
   */
  static random(word_count) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.mnemonic_random(retptr, isLikeNone2(word_count) ? 4294967297 : word_count >>> 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _Mnemonic.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Validate mnemonic phrase. Returns `true` if the phrase is valid, `false` otherwise.
   * @param {string} phrase
   * @param {Language | null} [language]
   * @returns {boolean}
   */
  static validate(phrase, language) {
    const ptr0 = passStringToWasm02(phrase, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    const ret = wasm2.mnemonic_validate(ptr0, len0, isLikeNone2(language) ? 1 : language);
    return ret !== 0;
  }
};
var NetServerOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_netserveroptions_free(ptr >>> 0, 1));
var NetServerOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    NetServerOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_netserveroptions_free(ptr, 0);
  }
  /**
   * @returns {boolean | undefined}
   */
  get allow_half_open() {
    const ptr = this.__destroy_into_raw();
    const ret = wasm2.netserveroptions_allow_half_open(ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @returns {boolean | undefined}
   */
  get pause_on_connect() {
    const ptr = this.__destroy_into_raw();
    const ret = wasm2.netserveroptions_pause_on_connect(ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @param {boolean | null} [value]
   */
  set allow_half_open(value) {
    const ptr = this.__destroy_into_raw();
    wasm2.netserveroptions_set_allow_half_open(ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
  /**
   * @param {boolean | null} [value]
   */
  set pause_on_connect(value) {
    const ptr = this.__destroy_into_raw();
    wasm2.netserveroptions_set_allow_half_open(ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
};
var NetworkIdFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_networkid_free(ptr >>> 0, 1));
var NetworkId2 = class _NetworkId {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_NetworkId.prototype);
    obj.__wbg_ptr = ptr;
    NetworkIdFinalization2.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      type: this.type,
      suffix: this.suffix,
      id: this.id
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    NetworkIdFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_networkid_free(ptr, 0);
  }
  /**
   * @returns {NetworkType}
   */
  get type() {
    const ret = wasm2.__wbg_get_networkid_type(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {NetworkType} arg0
   */
  set type(arg0) {
    wasm2.__wbg_set_networkid_type(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {number | undefined}
   */
  get suffix() {
    const ret = wasm2.__wbg_get_networkid_suffix(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @param {number | null} [arg0]
   */
  set suffix(arg0) {
    wasm2.__wbg_set_networkid_suffix(this.__wbg_ptr, isLikeNone2(arg0) ? 4294967297 : arg0 >>> 0);
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.networkid_id(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  addressPrefix() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.networkid_addressPrefix(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {any} value
   */
  constructor(value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.networkid_ctor(retptr, addBorrowedObject(value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      NetworkIdFinalization2.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {string}
   */
  get id() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.networkid_id(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
};
var NodeDescriptorFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_nodedescriptor_free(ptr >>> 0, 1));
var NodeDescriptor = class _NodeDescriptor {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_NodeDescriptor.prototype);
    obj.__wbg_ptr = ptr;
    NodeDescriptorFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      uid: this.uid,
      url: this.url
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    NodeDescriptorFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_nodedescriptor_free(ptr, 0);
  }
  /**
   * The unique identifier of the node.
   * @returns {string}
   */
  get uid() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.__wbg_get_nodedescriptor_uid(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * The unique identifier of the node.
   * @param {string} arg0
   */
  set uid(arg0) {
    const ptr0 = passStringToWasm02(arg0, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.__wbg_set_nodedescriptor_uid(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * The URL of the node WebSocket (wRPC URL).
   * @returns {string}
   */
  get url() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.__wbg_get_nodedescriptor_url(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * The URL of the node WebSocket (wRPC URL).
   * @param {string} arg0
   */
  set url(arg0) {
    const ptr0 = passStringToWasm02(arg0, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.__wbg_set_nodedescriptor_url(this.__wbg_ptr, ptr0, len0);
  }
};
var OptionalHeaderFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_optionalheader_free(ptr >>> 0, 1));
var OptionalHeader = class _OptionalHeader {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_OptionalHeader.prototype);
    obj.__wbg_ptr = ptr;
    OptionalHeaderFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      blueScore: this.blueScore,
      blueWork: this.blueWork,
      pruningPoint: this.pruningPoint,
      utxoCommitment: this.utxoCommitment,
      hashMerkleRoot: this.hashMerkleRoot,
      parentsByLevel: this.parentsByLevel,
      acceptedIdMerkleRoot: this.acceptedIdMerkleRoot,
      bits: this.bits,
      hash: this.hash,
      nonce: this.nonce,
      version: this.version,
      daaScore: this.daaScore,
      timestamp: this.timestamp
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    OptionalHeaderFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_optionalheader_free(ptr, 0);
  }
  /**
   * @returns {bigint | undefined}
   */
  get blueScore() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_blueScore(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getBigInt64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : BigInt.asUintN(64, r2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {any}
   */
  get blueWork() {
    const ret = wasm2.optionalheader_blueWork(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get pruningPoint() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_pruningPoint(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string | undefined}
   */
  get utxoCommitment() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_utxoCommitment(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string | undefined}
   */
  get hashMerkleRoot() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_hashMerkleRoot(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {CompressedParents | undefined}
   */
  get parentsByLevel() {
    const ret = wasm2.optionalheader_parentsByLevel(this.__wbg_ptr);
    return ret === 0 ? void 0 : CompressedParents.__wrap(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get acceptedIdMerkleRoot() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_acceptedIdMerkleRoot(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {OptionalHeader | IOptionalHeader} js_value
   */
  constructor(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_new(retptr, addHeapObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      OptionalHeaderFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {number | undefined}
   */
  get bits() {
    const ret = wasm2.optionalheader_bits(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @returns {string | undefined}
   */
  get hash() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_hash(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {bigint | undefined}
   */
  get nonce() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_nonce(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getBigInt64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : BigInt.asUintN(64, r2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {number | undefined}
   */
  get version() {
    const ret = wasm2.optionalheader_version(this.__wbg_ptr);
    return ret === 16777215 ? void 0 : ret;
  }
  /**
   * @returns {bigint | undefined}
   */
  get daaScore() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_daaScore(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getBigInt64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : BigInt.asUintN(64, r2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {bigint | undefined}
   */
  get timestamp() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.optionalheader_timestamp(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getBigInt64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : BigInt.asUintN(64, r2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var PSKBFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_pskb_free(ptr >>> 0, 1));
var PSKB = class _PSKB {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_PSKB.prototype);
    obj.__wbg_ptr = ptr;
    PSKBFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PSKBFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_pskb_free(ptr, 0);
  }
  /**
   * @param {string} hex_data
   * @returns {PSKB}
   */
  static deserialize(hex_data) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(hex_data, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.pskb_deserialize(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKB.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {NetworkId | string} network_id
   * @returns {string}
   */
  displayFormat(network_id) {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskb_displayFormat(retptr, this.__wbg_ptr, addBorrowedObject(network_id));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * @param {PSKT} pskt
   */
  add(pskt) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      _assertClass2(pskt, PSKT);
      wasm2.pskb_add(retptr, this.__wbg_ptr, pskt.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  constructor() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskb_new(retptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      PSKBFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {PSKB} other
   */
  merge(other) {
    _assertClass2(other, _PSKB);
    wasm2.pskb_merge(this.__wbg_ptr, other.__wbg_ptr);
  }
  /**
   * @returns {number}
   */
  get length() {
    const ret = wasm2.pskb_length(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * @returns {string}
   */
  serialize() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskb_serialize(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
};
var PSKTFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_pskt_free(ptr >>> 0, 1));
var PSKT = class _PSKT {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_PSKT.prototype);
    obj.__wbg_ptr = ptr;
    PSKTFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      role: this.role,
      payload: this.payload
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PSKTFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_pskt_free(ptr, 0);
  }
  /**
   * Change role to `CONSTRUCTOR`
   * @returns {PSKT}
   */
  toConstructor() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_toConstructor(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  get role() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_role(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {Hash}
   */
  calculateId() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_calculateId(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Hash2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {bigint} n
   * @param {number} input_index
   * @returns {PSKT}
   */
  setSequence(n, input_index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_setSequence(retptr, this.__wbg_ptr, n, input_index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {any} data
   * @returns {bigint}
   */
  calculateMass(data) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_calculateMass(retptr, this.__wbg_ptr, addBorrowedObject(data));
      var r0 = getDataViewMemory02().getBigInt64(retptr + 8 * 0, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      if (r3) {
        throw takeObject(r2);
      }
      return BigInt.asUintN(64, r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {PSKT}
   */
  noMoreInputs() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_noMoreInputs(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {any}
   */
  get payload() {
    const ret = wasm2.pskt_payload(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {PSKT}
   */
  noMoreOutputs() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_noMoreOutputs(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {ITransactionInput | TransactionInput} input
   * @param {any} data
   * @returns {PSKT}
   */
  inputAndRedeemScript(input, data) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_inputAndRedeemScript(retptr, this.__wbg_ptr, addBorrowedObject(input), addBorrowedObject(data));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {PSKT}
   */
  inputsModifiable() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_inputsModifiable(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {bigint} lock_time
   * @returns {PSKT}
   */
  fallbackLockTime(lock_time) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_fallbackLockTime(retptr, this.__wbg_ptr, lock_time);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {PSKT}
   */
  outputsModifiable() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_outputsModifiable(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {PSKT | Transaction | string | undefined} payload
   */
  constructor(payload) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_new(retptr, addHeapObject(payload));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      PSKTFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {ITransactionInput | TransactionInput} input
   * @returns {PSKT}
   */
  input(input) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_input(retptr, this.__wbg_ptr, addBorrowedObject(input));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {ITransactionOutput | TransactionOutput} output
   * @returns {PSKT}
   */
  output(output) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_output(retptr, this.__wbg_ptr, addBorrowedObject(output));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Change role to `SIGNER`
   * @returns {PSKT}
   */
  toSigner() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_toSigner(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Change role to `CREATOR`
   * #[wasm_bindgen(js_name = toCreator)]
   * @returns {PSKT}
   */
  creator() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_creator(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Change role to `UPDATER`
   * @returns {PSKT}
   */
  toUpdater() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_toUpdater(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Change role to `COMBINER`
   * @returns {PSKT}
   */
  toCombiner() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_toCombiner(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Change role to `EXTRACTOR`
   * @returns {PSKT}
   */
  toExtractor() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_toExtractor(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Change role to `FINALIZER`
   * @returns {PSKT}
   */
  toFinalizer() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_toFinalizer(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PSKT.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  serialize() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pskt_serialize(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
};
var PaymentOutputFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_paymentoutput_free(ptr >>> 0, 1));
var PaymentOutput = class _PaymentOutput {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_PaymentOutput.prototype);
    obj.__wbg_ptr = ptr;
    PaymentOutputFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      address: this.address,
      amount: this.amount,
      covenant: this.covenant
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PaymentOutputFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_paymentoutput_free(ptr, 0);
  }
  /**
   * Factory method for covenant variant
   * @param {Address} address
   * @param {bigint} amount
   * @param {CovenantBinding} covenant
   * @returns {PaymentOutput}
   */
  static withCovenant(address, amount, covenant) {
    _assertClass2(address, Address2);
    var ptr0 = address.__destroy_into_raw();
    _assertClass2(covenant, CovenantBinding);
    var ptr1 = covenant.__destroy_into_raw();
    const ret = wasm2.paymentoutput_withCovenant(ptr0, amount, ptr1);
    return _PaymentOutput.__wrap(ret);
  }
  /**
   * Main constructor (no covenant)
   * @param {Address} address
   * @param {bigint} amount
   */
  constructor(address, amount) {
    _assertClass2(address, Address2);
    var ptr0 = address.__destroy_into_raw();
    const ret = wasm2.paymentoutput_new(ptr0, amount);
    this.__wbg_ptr = ret >>> 0;
    PaymentOutputFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {Address}
   */
  get address() {
    const ret = wasm2.__wbg_get_paymentoutput_address(this.__wbg_ptr);
    return Address2.__wrap(ret);
  }
  /**
   * @param {Address} arg0
   */
  set address(arg0) {
    _assertClass2(arg0, Address2);
    var ptr0 = arg0.__destroy_into_raw();
    wasm2.__wbg_set_paymentoutput_address(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {bigint}
   */
  get amount() {
    const ret = wasm2.__wbg_get_paymentoutput_amount(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} arg0
   */
  set amount(arg0) {
    wasm2.__wbg_set_paymentoutput_amount(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {CovenantBinding | undefined}
   */
  get covenant() {
    const ret = wasm2.__wbg_get_paymentoutput_covenant(this.__wbg_ptr);
    return ret === 0 ? void 0 : CovenantBinding.__wrap(ret);
  }
  /**
   * @param {CovenantBinding | null} [arg0]
   */
  set covenant(arg0) {
    let ptr0 = 0;
    if (!isLikeNone2(arg0)) {
      _assertClass2(arg0, CovenantBinding);
      ptr0 = arg0.__destroy_into_raw();
    }
    wasm2.__wbg_set_paymentoutput_covenant(this.__wbg_ptr, ptr0);
  }
};
var PaymentOutputsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_paymentoutputs_free(ptr >>> 0, 1));
var PaymentOutputs = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PaymentOutputsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_paymentoutputs_free(ptr, 0);
  }
  /**
   * @param {IPaymentOutput[]} output_array
   */
  constructor(output_array) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.paymentoutputs_constructor(retptr, addHeapObject(output_array));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      PaymentOutputsFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var PendingTransactionFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_pendingtransaction_free(ptr >>> 0, 1));
var PendingTransaction = class _PendingTransaction {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_PendingTransaction.prototype);
    obj.__wbg_ptr = ptr;
    PendingTransactionFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      transaction: this.transaction,
      changeAmount: this.changeAmount,
      paymentAmount: this.paymentAmount,
      minimumSignatures: this.minimumSignatures,
      aggregateInputAmount: this.aggregateInputAmount,
      aggregateOutputAmount: this.aggregateOutputAmount,
      id: this.id,
      feeAmount: this.feeAmount,
      type: this.type,
      mass: this.mass
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PendingTransactionFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_pendingtransaction_free(ptr, 0);
  }
  /**
   * Sets a signature to the input at the specified index.
   * @param {number} input_index
   * @param {HexString | Uint8Array} signature_script
   */
  fillInput(input_index, signature_script) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pendingtransaction_fillInput(retptr, this.__wbg_ptr, input_index, addHeapObject(signature_script));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Signs the input at the specified index with the supplied private key
   * and an optional SighashType.
   * @param {number} input_index
   * @param {PrivateKey} private_key
   * @param {SighashType | null} [sighash_type]
   */
  signInput(input_index, private_key, sighash_type) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      _assertClass2(private_key, PrivateKey);
      wasm2.pendingtransaction_signInput(retptr, this.__wbg_ptr, input_index, private_key.__wbg_ptr, isLikeNone2(sighash_type) ? 6 : sighash_type);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Returns encapsulated network [`Transaction`]
   * @returns {Transaction}
   */
  get transaction() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pendingtransaction_transaction(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Transaction.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Change amount (if any).
   * @returns {bigint}
   */
  get changeAmount() {
    const ret = wasm2.pendingtransaction_changeAmount(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Total amount transferred to the destination (aggregate output - change).
   * @returns {any}
   */
  get paymentAmount() {
    const ret = wasm2.pendingtransaction_paymentAmount(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Provides a list of UTXO entries used by the transaction.
   * @returns {Array<any>}
   */
  getUtxoEntries() {
    const ret = wasm2.pendingtransaction_getUtxoEntries(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Serializes the transaction to a JSON string.
   * The schema of the JSON is defined by {@link ISerializableTransaction}.
   * Once serialized, the transaction can be deserialized using {@link Transaction.deserializeFromJSON}.
   * @see {@link Transaction}, {@link ISerializableTransaction}
   * @returns {string}
   */
  serializeToJSON() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pendingtransaction_serializeToJSON(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * Minimum number of signatures required by the transaction.
   * (as specified during the transaction creation).
   * @returns {number}
   */
  get minimumSignatures() {
    const ret = wasm2.pendingtransaction_minimumSignatures(this.__wbg_ptr);
    return ret;
  }
  /**
   * Serializes the transaction to a pure JavaScript Object.
   * The schema of the JavaScript object is defined by {@link ISerializableTransaction}.
   * @see {@link ISerializableTransaction}
   * @see {@link Transaction}, {@link ISerializableTransaction}
   * @returns {ITransaction | Transaction}
   */
  serializeToObject() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pendingtransaction_serializeToObject(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Total aggregate input amount.
   * @returns {bigint}
   */
  get aggregateInputAmount() {
    const ret = wasm2.pendingtransaction_aggregateInputAmount(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Total aggregate output amount.
   * @returns {bigint}
   */
  get aggregateOutputAmount() {
    const ret = wasm2.pendingtransaction_aggregateOutputAmount(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Creates and returns a signature for the input at the specified index.
   * @param {number} input_index
   * @param {PrivateKey} private_key
   * @param {SighashType | null} [sighash_type]
   * @returns {HexString}
   */
  createInputSignature(input_index, private_key, sighash_type) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      _assertClass2(private_key, PrivateKey);
      wasm2.pendingtransaction_createInputSignature(retptr, this.__wbg_ptr, input_index, private_key.__wbg_ptr, isLikeNone2(sighash_type) ? 6 : sighash_type);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Serializes the transaction to a "Safe" JSON schema where it converts all `bigint` values to `string` to avoid potential client-side precision loss.
   * Once serialized, the transaction can be deserialized using {@link Transaction.deserializeFromSafeJSON}.
   * @see {@link Transaction}, {@link ISerializableTransaction}
   * @returns {string}
   */
  serializeToSafeJSON() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pendingtransaction_serializeToSafeJSON(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * Transaction Id
   * @returns {string}
   */
  get id() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pendingtransaction_id(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Total transaction fees (network fees + priority fees).
   * @returns {bigint}
   */
  get feeAmount() {
    const ret = wasm2.pendingtransaction_feeAmount(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Transaction type ("batch" or "final").
   * @returns {string}
   */
  get type() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pendingtransaction_type(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Calculated transaction mass.
   * @returns {bigint}
   */
  get mass() {
    const ret = wasm2.pendingtransaction_mass(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Signs transaction with supplied [`Array`] or [`PrivateKey`] or an array of
   * raw private key bytes (encoded as `Uint8Array` or as hex strings)
   * @param {(PrivateKey | HexString | Uint8Array)[]} js_value
   * @param {boolean | null} [check_fully_signed]
   */
  sign(js_value, check_fully_signed) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pendingtransaction_sign(retptr, this.__wbg_ptr, addHeapObject(js_value), isLikeNone2(check_fully_signed) ? 16777215 : check_fully_signed ? 1 : 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Submit transaction to the supplied [`RpcClient`]
   * **IMPORTANT:** This method will remove UTXOs from the associated
   * {@link UtxoContext} if one was used to create the transaction
   * and will return UTXOs back to {@link UtxoContext} in case of
   * a failed submission.
   *
   * # Important
   *
   * Make sure to consume the returned `txid` value. Always invoke this method
   * as follows `let txid = await pendingTransaction.submit(rpc);`. If you do not
   * consume the returned value and the rpc object is temporary, the GC will
   * collect the `rpc` object passed to submit() potentially causing a panic.
   *
   * @see {@link RpcClient.submitTransaction}
   * @param {RpcClient} wasm_rpc_client
   * @returns {Promise<string>}
   */
  submit(wasm_rpc_client) {
    _assertClass2(wasm_rpc_client, RpcClient);
    const ret = wasm2.pendingtransaction_submit(this.__wbg_ptr, wasm_rpc_client.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * List of unique addresses used by transaction inputs.
   * This method can be used to determine addresses used by transaction inputs
   * in order to select private keys needed for transaction signing.
   * @returns {Array<any>}
   */
  addresses() {
    const ret = wasm2.pendingtransaction_addresses(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var PipeOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_pipeoptions_free(ptr >>> 0, 1));
var PipeOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PipeOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_pipeoptions_free(ptr, 0);
  }
  /**
   * @returns {boolean | undefined}
   */
  get end() {
    const ptr = this.__destroy_into_raw();
    const ret = wasm2.pipeoptions_end(ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @param {boolean | null} [end]
   */
  constructor(end) {
    const ret = wasm2.pipeoptions_new(isLikeNone2(end) ? 16777215 : end ? 1 : 0);
    this.__wbg_ptr = ret >>> 0;
    PipeOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @param {boolean | null} [value]
   */
  set end(value) {
    const ptr = this.__destroy_into_raw();
    wasm2.pipeoptions_set_end(ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
};
var PoWFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_pow_free(ptr >>> 0, 1));
var PoW = class _PoW {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_PoW.prototype);
    obj.__wbg_ptr = ptr;
    PoWFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      prePoWHash: this.prePoWHash,
      target: this.target
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PoWFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_pow_free(ptr, 0);
  }
  /**
   * Checks if the computed target meets or exceeds the difficulty specified in the template.
   * @returns A boolean indicating if it reached the target and a bigint representing the reached target.
   * @param {bigint} nonce
   * @returns {[boolean, bigint]}
   */
  checkWork(nonce) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pow_checkWork(retptr, this.__wbg_ptr, nonce);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Hash of the header without timestamp and nonce.
   * @returns {string}
   */
  get prePoWHash() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pow_get_pre_pow_hash(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {Header | IHeader | IRawHeader} header
   * @param {bigint | null} [timestamp]
   */
  constructor(header, timestamp) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pow_new(retptr, addBorrowedObject(header), !isLikeNone2(timestamp), isLikeNone2(timestamp) ? BigInt(0) : timestamp);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      PoWFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * The target based on the provided bits.
   * @returns {bigint}
   */
  get target() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.pow_target(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Can be used for parsing Stratum templates.
   * @param {string} pre_pow_hash
   * @param {bigint} timestamp
   * @param {number | null} [target_bits]
   * @returns {PoW}
   */
  static fromRaw(pre_pow_hash, timestamp, target_bits) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(pre_pow_hash, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.pow_fromRaw(retptr, ptr0, len0, timestamp, isLikeNone2(target_bits) ? 4294967297 : target_bits >>> 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PoW.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var PrivateKeyFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_privatekey_free(ptr >>> 0, 1));
var PrivateKey = class _PrivateKey {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_PrivateKey.prototype);
    obj.__wbg_ptr = ptr;
    PrivateKeyFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PrivateKeyFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_privatekey_free(ptr, 0);
  }
  /**
   * Get the [`Address`] of the PublicKey generated from this PrivateKey.
   * Receives a [`NetworkType`](kaspa_consensus_core::network::NetworkType)
   * to determine the prefix of the address.
   * JavaScript: `let address = privateKey.toAddress(NetworkType.MAINNET);`.
   * @param {NetworkType | NetworkId | string} network
   * @returns {Address}
   */
  toAddress(network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.privatekey_toAddress(retptr, this.__wbg_ptr, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Generate a [`Keypair`] from this [`PrivateKey`].
   * @returns {Keypair}
   */
  toKeypair() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.privatekey_toKeypair(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Keypair.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {PublicKey}
   */
  toPublicKey() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.privatekey_toPublicKey(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return PublicKey.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Get `ECDSA` [`Address`] of the PublicKey generated from this PrivateKey.
   * Receives a [`NetworkType`](kaspa_consensus_core::network::NetworkType)
   * to determine the prefix of the address.
   * JavaScript: `let address = privateKey.toAddress(NetworkType.MAINNET);`.
   * @param {NetworkType | NetworkId | string} network
   * @returns {Address}
   */
  toAddressECDSA(network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.privatekey_toAddressECDSA(retptr, this.__wbg_ptr, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Returns the [`PrivateKey`] key encoded as a hex string.
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.privatekey_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Create a new [`PrivateKey`] from a hex-encoded string.
   * @param {string} key
   */
  constructor(key2) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(key2, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.privatekey_try_new(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      PrivateKeyFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var PrivateKeyGeneratorFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_privatekeygenerator_free(ptr >>> 0, 1));
var PrivateKeyGenerator = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PrivateKeyGeneratorFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_privatekeygenerator_free(ptr, 0);
  }
  /**
   * @param {number} index
   * @returns {PrivateKey}
   */
  changeKey(index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.privatekeygenerator_changeKey(retptr, this.__wbg_ptr, index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return PrivateKey.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {number} index
   * @returns {PrivateKey}
   */
  receiveKey(index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.privatekeygenerator_receiveKey(retptr, this.__wbg_ptr, index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return PrivateKey.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {XPrv | string} xprv
   * @param {boolean} is_multisig
   * @param {bigint} account_index
   * @param {number | null} [cosigner_index]
   */
  constructor(xprv, is_multisig, account_index, cosigner_index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.privatekeygenerator_new(retptr, addBorrowedObject(xprv), is_multisig, account_index, isLikeNone2(cosigner_index) ? 4294967297 : cosigner_index >>> 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      PrivateKeyGeneratorFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
};
var ProcessSendOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_processsendoptions_free(ptr >>> 0, 1));
var ProcessSendOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    ProcessSendOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_processsendoptions_free(ptr, 0);
  }
  /**
   * @returns {boolean | undefined}
   */
  get swallow_errors() {
    const ret = wasm2.processsendoptions_swallow_errors(this.__wbg_ptr);
    return ret === 16777215 ? void 0 : ret !== 0;
  }
  /**
   * @param {boolean | null} [value]
   */
  set swallow_errors(value) {
    wasm2.processsendoptions_set_swallow_errors(this.__wbg_ptr, isLikeNone2(value) ? 16777215 : value ? 1 : 0);
  }
  /**
   * @param {boolean | null} [swallow_errors]
   */
  constructor(swallow_errors) {
    const ret = wasm2.processsendoptions_new(isLikeNone2(swallow_errors) ? 16777215 : swallow_errors ? 1 : 0);
    this.__wbg_ptr = ret >>> 0;
    ProcessSendOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
};
var PrvKeyDataInfoFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_prvkeydatainfo_free(ptr >>> 0, 1));
var PrvKeyDataInfo = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PrvKeyDataInfoFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_prvkeydatainfo_free(ptr, 0);
  }
  /**
   * @returns {any}
   */
  get isEncrypted() {
    const ret = wasm2.prvkeydatainfo_isEncrypted(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {string}
   */
  get id() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.prvkeydatainfo_id(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {any}
   */
  get name() {
    const ret = wasm2.prvkeydatainfo_name(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {string} _name
   */
  setName(_name) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(_name, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.prvkeydatainfo_setName(retptr, this.__wbg_ptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var PublicKeyFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_publickey_free(ptr >>> 0, 1));
var PublicKey = class _PublicKey {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_PublicKey.prototype);
    obj.__wbg_ptr = ptr;
    PublicKeyFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PublicKeyFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_publickey_free(ptr, 0);
  }
  /**
   * Compute a 4-byte key fingerprint for this public key as a hex string.
   * Default implementation uses `RIPEMD160(SHA256(public_key))`.
   * @returns {HexString | undefined}
   */
  fingerprint() {
    const ret = wasm2.publickey_fingerprint(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Get the [`Address`] of this PublicKey.
   * Receives a [`NetworkType`] to determine the prefix of the address.
   * JavaScript: `let address = publicKey.toAddress(NetworkType.MAINNET);`.
   * @param {NetworkType | NetworkId | string} network
   * @returns {Address}
   */
  toAddress(network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickey_toAddress(retptr, this.__wbg_ptr, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickey_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Get `ECDSA` [`Address`] of this PublicKey.
   * Receives a [`NetworkType`] to determine the prefix of the address.
   * JavaScript: `let address = publicKey.toAddress(NetworkType.MAINNET);`.
   * @param {NetworkType | NetworkId | string} network
   * @returns {Address}
   */
  toAddressECDSA(network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickey_toAddressECDSA(retptr, this.__wbg_ptr, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {XOnlyPublicKey}
   */
  toXOnlyPublicKey() {
    const ret = wasm2.publickey_toXOnlyPublicKey(this.__wbg_ptr);
    return XOnlyPublicKey.__wrap(ret);
  }
  /**
   * Create a new [`PublicKey`] from a hex-encoded string.
   * @param {string} key
   */
  constructor(key2) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(key2, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.publickey_try_new(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      PublicKeyFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var PublicKeyGeneratorFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_publickeygenerator_free(ptr >>> 0, 1));
var PublicKeyGenerator = class _PublicKeyGenerator {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_PublicKeyGenerator.prototype);
    obj.__wbg_ptr = ptr;
    PublicKeyGeneratorFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    PublicKeyGeneratorFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_publickeygenerator_free(ptr, 0);
  }
  /**
   * Generate a single Change Public Key derivation at a given index.
   * @param {number} index
   * @returns {PublicKey}
   */
  changePubkey(index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_changePubkey(retptr, this.__wbg_ptr, index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return PublicKey.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Generate a single Change Address derivation at a given index.
   * @param {NetworkType | NetworkId | string} networkType
   * @param {number} index
   * @returns {Address}
   */
  changeAddress(networkType, index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_changeAddress(retptr, this.__wbg_ptr, addBorrowedObject(networkType), index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Generate Change Public Key derivations for a given range.
   * @param {number} start
   * @param {number} end
   * @returns {(PublicKey | string)[]}
   */
  changePubkeys(start, end) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_changePubkeys(retptr, this.__wbg_ptr, start, end);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Generate a single Receive Public Key derivation at a given index.
   * @param {number} index
   * @returns {PublicKey}
   */
  receivePubkey(index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_receivePubkey(retptr, this.__wbg_ptr, index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return PublicKey.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Generate a single Receive Address derivation at a given index.
   * @param {NetworkType | NetworkId | string} networkType
   * @param {number} index
   * @returns {Address}
   */
  receiveAddress(networkType, index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_receiveAddress(retptr, this.__wbg_ptr, addBorrowedObject(networkType), index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Generate Receive Public Key derivations for a given range.
   * @param {number} start
   * @param {number} end
   * @returns {(PublicKey | string)[]}
   */
  receivePubkeys(start, end) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_receivePubkeys(retptr, this.__wbg_ptr, start, end);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Generate Change Address derivations for a given range.
   * @param {NetworkType | NetworkId | string} networkType
   * @param {number} start
   * @param {number} end
   * @returns {Address[]}
   */
  changeAddresses(networkType, start, end) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_changeAddresses(retptr, this.__wbg_ptr, addBorrowedObject(networkType), start, end);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {XPrv | string} xprv
   * @param {boolean} is_multisig
   * @param {bigint} account_index
   * @param {number | null} [cosigner_index]
   * @returns {PublicKeyGenerator}
   */
  static fromMasterXPrv(xprv, is_multisig, account_index, cosigner_index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_fromMasterXPrv(retptr, addBorrowedObject(xprv), is_multisig, account_index, isLikeNone2(cosigner_index) ? 4294967297 : cosigner_index >>> 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PublicKeyGenerator.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Generate Receive Address derivations for a given range.
   * @param {NetworkType | NetworkId | string} networkType
   * @param {number} start
   * @param {number} end
   * @returns {Address[]}
   */
  receiveAddresses(networkType, start, end) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_receiveAddresses(retptr, this.__wbg_ptr, addBorrowedObject(networkType), start, end);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Generate a single Change Public Key derivation at a given index and return it as a string.
   * @param {number} index
   * @returns {string}
   */
  changePubkeyAsString(index) {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_changePubkeyAsString(retptr, this.__wbg_ptr, index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * Generate a single Change Address derivation at a given index and return it as a string.
   * @param {NetworkType | NetworkId | string} networkType
   * @param {number} index
   * @returns {string}
   */
  changeAddressAsString(networkType, index) {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_changeAddressAsString(retptr, this.__wbg_ptr, addBorrowedObject(networkType), index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * Generate a single Receive Public Key derivation at a given index and return it as a string.
   * @param {number} index
   * @returns {string}
   */
  receivePubkeyAsString(index) {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_receivePubkeyAsString(retptr, this.__wbg_ptr, index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * Generate a range of Change Public Key derivations and return them as strings.
   * @param {number} start
   * @param {number} end
   * @returns {Array<string>}
   */
  changePubkeysAsStrings(start, end) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_changePubkeysAsStrings(retptr, this.__wbg_ptr, start, end);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Generate a single Receive Address derivation at a given index and return it as a string.
   * @param {NetworkType | NetworkId | string} networkType
   * @param {number} index
   * @returns {string}
   */
  receiveAddressAsString(networkType, index) {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_receiveAddressAsString(retptr, this.__wbg_ptr, addBorrowedObject(networkType), index);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * Generate a range of Receive Public Key derivations and return them as strings.
   * @param {number} start
   * @param {number} end
   * @returns {Array<string>}
   */
  receivePubkeysAsStrings(start, end) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_receivePubkeysAsStrings(retptr, this.__wbg_ptr, start, end);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Generate a range of Change Address derivations and return them as strings.
   * @param {NetworkType | NetworkId | string} networkType
   * @param {number} start
   * @param {number} end
   * @returns {Array<string>}
   */
  changeAddressAsStrings(networkType, start, end) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_changeAddressAsStrings(retptr, this.__wbg_ptr, addBorrowedObject(networkType), start, end);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Generate a range of Receive Address derivations and return them as strings.
   * @param {NetworkType | NetworkId | string} networkType
   * @param {number} start
   * @param {number} end
   * @returns {Array<string>}
   */
  receiveAddressAsStrings(networkType, start, end) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_receiveAddressAsStrings(retptr, this.__wbg_ptr, addBorrowedObject(networkType), start, end);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {XPub | string} kpub
   * @param {number | null} [cosigner_index]
   * @returns {PublicKeyGenerator}
   */
  static fromXPub(kpub, cosigner_index) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_fromXPub(retptr, addBorrowedObject(kpub), isLikeNone2(cosigner_index) ? 4294967297 : cosigner_index >>> 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _PublicKeyGenerator.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.publickeygenerator_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
};
var ReadStreamFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_readstream_free(ptr >>> 0, 1));
var ReadStream = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    ReadStreamFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_readstream_free(ptr, 0);
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  on_with_open(listener) {
    try {
      const ret = wasm2.readstream_on_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  on_with_close(listener) {
    try {
      const ret = wasm2.readstream_on_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  once_with_open(listener) {
    try {
      const ret = wasm2.readstream_once_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  once_with_close(listener) {
    try {
      const ret = wasm2.readstream_once_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  add_listener_with_open(listener) {
    try {
      const ret = wasm2.readstream_add_listener_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  add_listener_with_close(listener) {
    try {
      const ret = wasm2.readstream_add_listener_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  prepend_listener_with_open(listener) {
    try {
      const ret = wasm2.readstream_prepend_listener_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  prepend_listener_with_close(listener) {
    try {
      const ret = wasm2.readstream_prepend_listener_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  prepend_once_listener_with_open(listener) {
    try {
      const ret = wasm2.readstream_prepend_once_listener_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  prepend_once_listener_with_close(listener) {
    try {
      const ret = wasm2.readstream_prepend_once_listener_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
};
var ResolverFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_resolver_free(ptr >>> 0, 1));
var Resolver = class _Resolver {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Resolver.prototype);
    obj.__wbg_ptr = ptr;
    ResolverFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      urls: this.urls
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    ResolverFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_resolver_free(ptr, 0);
  }
  /**
   * Creates a new Resolver client with the given
   * configuration supplied as {@link IResolverConfig}
   * interface. If not supplied, the default configuration
   * containing a list of community-operated resolvers
   * will be used.
   * @param {IResolverConfig | string[] | null} [args]
   */
  constructor(args) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.resolver_ctor(retptr, isLikeNone2(args) ? 0 : addHeapObject(args));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      ResolverFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * List of public Kaspa Resolver URLs.
   * @returns {string[] | undefined}
   */
  get urls() {
    const ret = wasm2.resolver_urls(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Connect to a public Kaspa wRPC endpoint for the given encoding and network identifier
   * supplied via {@link IResolverConnect} interface.
   * @see {@link IResolverConnect}, {@link RpcClient}
   * @param {IResolverConnect | NetworkId | string} options
   * @returns {Promise<RpcClient>}
   */
  connect(options) {
    const ret = wasm2.resolver_connect(this.__wbg_ptr, addHeapObject(options));
    return takeObject(ret);
  }
  /**
   * Fetches a public Kaspa wRPC endpoint URL for the given encoding and network identifier.
   * @see {@link Encoding}, {@link NetworkId}
   * @param {Encoding} encoding
   * @param {NetworkId | string} network_id
   * @returns {Promise<string>}
   */
  getUrl(encoding, network_id) {
    const ret = wasm2.resolver_getUrl(this.__wbg_ptr, encoding, addHeapObject(network_id));
    return takeObject(ret);
  }
  /**
   * Fetches a public Kaspa wRPC endpoint for the given encoding and network identifier.
   * @see {@link Encoding}, {@link NetworkId}, {@link Node}
   * @param {Encoding} encoding
   * @param {NetworkId | string} network_id
   * @returns {Promise<NodeDescriptor>}
   */
  getNode(encoding, network_id) {
    const ret = wasm2.resolver_getNode(this.__wbg_ptr, encoding, addHeapObject(network_id));
    return takeObject(ret);
  }
};
var RpcClientFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_rpcclient_free(ptr >>> 0, 1));
var RpcClient = class _RpcClient {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_RpcClient.prototype);
    obj.__wbg_ptr = ptr;
    RpcClientFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      networkId: this.networkId,
      isConnected: this.isConnected,
      nodeId: this.nodeId,
      url: this.url,
      encoding: this.encoding,
      resolver: this.resolver
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    RpcClientFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_rpcclient_free(ptr, 0);
  }
  /**
   * Disconnect from the Kaspa RPC server.
   * @returns {Promise<void>}
   */
  disconnect() {
    const ret = wasm2.rpcclient_disconnect(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Retrieves multiple blocks from the Kaspa BlockDAG.
   * Returned information: List of block information.
   * @see {@link IGetBlocksRequest}, {@link IGetBlocksResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetBlocksRequest} request
   * @returns {Promise<IGetBlocksResponse>}
   */
  getBlocks(request2) {
    const ret = wasm2.rpcclient_getBlocks(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Current nerwork id
   * @returns {NetworkId | undefined}
   */
  get networkId() {
    const ret = wasm2.rpcclient_networkId(this.__wbg_ptr);
    return ret === 0 ? void 0 : NetworkId2.__wrap(ret);
  }
  /**
   * Retrieves block headers from the Kaspa BlockDAG.
   * Returned information: List of block headers.
   * @see {@link IGetHeadersRequest}, {@link IGetHeadersResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetHeadersRequest} request
   * @returns {Promise<IGetHeadersResponse>}
   */
  getHeaders(request2) {
    const ret = wasm2.rpcclient_getHeaders(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves various metrics and statistics related to the
   * performance and status of the Kaspa node.
   * Returned information: Memory usage, CPU usage, network activity.
   * @see {@link IGetMetricsRequest}, {@link IGetMetricsResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetMetricsRequest | null} [request]
   * @returns {Promise<IGetMetricsResponse>}
   */
  getMetrics(request2) {
    const ret = wasm2.rpcclient_getMetrics(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @param {Encoding} encoding
   * @param {NetworkType | NetworkId | string} network
   * @returns {number}
   */
  static defaultPort(encoding, network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_defaultPort(retptr, encoding, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return r0;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * The current connection status of the RPC client.
   * @returns {boolean}
   */
  get isConnected() {
    const ret = wasm2.rpcclient_isConnected(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * Set the resolver for the RPC client.
   * This setting will take effect on the next connection.
   * @param {Resolver} resolver
   */
  setResolver(resolver) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      _assertClass2(resolver, Resolver);
      var ptr0 = resolver.__destroy_into_raw();
      wasm2.rpcclient_setResolver(retptr, this.__wbg_ptr, ptr0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Submits a block to the Kaspa network.
   * Returned information: None.
   * @see {@link ISubmitBlockRequest}, {@link ISubmitBlockResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {ISubmitBlockRequest} request
   * @returns {Promise<ISubmitBlockResponse>}
   */
  submitBlock(request2) {
    const ret = wasm2.rpcclient_submitBlock(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Triggers a disconnection on the underlying WebSocket
   * if the WebSocket is in connected state.
   * This is intended for debug purposes only.
   * Can be used to test application reconnection logic.
   */
  triggerAbort() {
    wasm2.rpcclient_triggerAbort(this.__wbg_ptr);
  }
  /**
   * Retrieves information about a subnetwork in the Kaspa BlockDAG.
   * Returned information: Subnetwork information.
   * @see {@link IGetSubnetworkRequest}, {@link IGetSubnetworkResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetSubnetworkRequest} request
   * @returns {Promise<IGetSubnetworkResponse>}
   */
  getSubnetwork(request2) {
    const ret = wasm2.rpcclient_getSubnetwork(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Set the network id for the RPC client.
   * This setting will take effect on the next connection.
   * @param {NetworkId | string} network_id
   */
  setNetworkId(network_id) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_setNetworkId(retptr, this.__wbg_ptr, addBorrowedObject(network_id));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Retrieves the current number of blocks in the Kaspa BlockDAG.
   * This is not a block count, not a "block height" and can not be
   * used for transaction validation.
   * Returned information: Current block count.
   * @see {@link IGetBlockCountRequest}, {@link IGetBlockCountResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetBlockCountRequest | null} [request]
   * @returns {Promise<IGetBlockCountResponse>}
   */
  getBlockCount(request2) {
    const ret = wasm2.rpcclient_getBlockCount(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Returns the total current coin supply of Kaspa network.
   * Returned information: Total coin supply.
   * @see {@link IGetCoinSupplyRequest}, {@link IGetCoinSupplyResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetCoinSupplyRequest | null} [request]
   * @returns {Promise<IGetCoinSupplyResponse>}
   */
  getCoinSupply(request2) {
    const ret = wasm2.rpcclient_getCoinSupply(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves current number of network connections
   * @see {@link IGetConnectionsRequest}, {@link IGetConnectionsResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetConnectionsRequest | null} [request]
   * @returns {Promise<IGetConnectionsResponse>}
   */
  getConnections(request2) {
    const ret = wasm2.rpcclient_getConnections(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves information about the Kaspa server.
   * Returned information: Version of the Kaspa server, protocol
   * version, network identifier.
   * @see {@link IGetServerInfoRequest}, {@link IGetServerInfoResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetServerInfoRequest | null} [request]
   * @returns {Promise<IGetServerInfoResponse>}
   */
  getServerInfo(request2) {
    const ret = wasm2.rpcclient_getServerInfo(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Obtains basic information about the synchronization status of the Kaspa node.
   * Returned information: Syncing status.
   * @see {@link IGetSyncStatusRequest}, {@link IGetSyncStatusResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetSyncStatusRequest | null} [request]
   * @returns {Promise<IGetSyncStatusResponse>}
   */
  getSyncStatus(request2) {
    const ret = wasm2.rpcclient_getSyncStatus(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Feerate estimates
   * @see {@link IGetFeeEstimateRequest}, {@link IGetFeeEstimateResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetFeeEstimateRequest | null} [request]
   * @returns {Promise<IGetFeeEstimateResponse>}
   */
  getFeeEstimate(request2) {
    const ret = wasm2.rpcclient_getFeeEstimate(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Optional: Resolver node id.
   * @returns {string | undefined}
   */
  get nodeId() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_nodeId(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Retrieves a specific mempool entry by transaction ID.
   * Returned information: Mempool entry information.
   * @see {@link IGetMempoolEntryRequest}, {@link IGetMempoolEntryResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetMempoolEntryRequest} request
   * @returns {Promise<IGetMempoolEntryResponse>}
   */
  getMempoolEntry(request2) {
    const ret = wasm2.rpcclient_getMempoolEntry(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   *
   * Register an event listener callback.
   *
   * Registers a callback function to be executed when a specific event occurs.
   * The callback function will receive an {@link RpcEvent} object with the event `type` and `data`.
   *
   * **RPC Subscriptions vs Event Listeners**
   *
   * Subscriptions are used to receive notifications from the RPC client.
   * Event listeners are client-side application registrations that are
   * triggered when notifications are received.
   *
   * If node is disconnected, upon reconnection you do not need to re-register event listeners,
   * however, you have to re-subscribe for Kaspa node notifications. As such, it is recommended
   * to register event listeners when the RPC `open` event is received.
   *
   * ```javascript
   * rpc.addEventListener("connect", async (event) => {
   *     console.log("Connected to", rpc.url);
   *     await rpc.subscribeDaaScore();
   *     // ... perform wallet address subscriptions
   * });
   * ```
   *
   * **Multiple events and listeners**
   *
   * `addEventListener` can be used to register multiple event listeners for the same event
   * as well as the same event listener for multiple events.
   *
   * ```javascript
   * // Registering a single event listener for multiple events:
   * rpc.addEventListener(["connect", "disconnect"], (event) => {
   *     console.log(event);
   * });
   *
   * // Registering event listener for all events:
   * // (by omitting the event type)
   * rpc.addEventListener((event) => {
   *     console.log(event);
   * });
   *
   * // Registering multiple event listeners for the same event:
   * rpc.addEventListener("connect", (event) => { // first listener
   *     console.log(event);
   * });
   * rpc.addEventListener("connect", (event) => { // second listener
   *     console.log(event);
   * });
   * ```
   *
   * **Use of context objects**
   *
   * You can also register an event with a `context` object. When the event is triggered,
   * the `handleEvent` method of the `context` object will be called while `this` value
   * will be set to the `context` object.
   * ```javascript
   * // Registering events with a context object:
   *
   * const context = {
   *     someProperty: "someValue",
   *     handleEvent: (event) => {
   *         // the following will log "someValue"
   *         console.log(this.someProperty);
   *         console.log(event);
   *     }
   * };
   * rpc.addEventListener(["connect","disconnect"], context);
   *
   * ```
   *
   * **General use examples**
   *
   * In TypeScript you can use {@link RpcEventType} enum (such as `RpcEventType.Connect`)
   * or `string` (such as "connect") to register event listeners.
   * In JavaScript you can only use `string`.
   *
   * ```typescript
   * // Example usage (TypeScript):
   *
   * rpc.addEventListener(RpcEventType.Connect, (event) => {
   *     console.log("Connected to", rpc.url);
   * });
   *
   * rpc.addEventListener(RpcEventType.VirtualDaaScoreChanged, (event) => {
   *     console.log(event.type,event.data);
   * });
   * await rpc.subscribeDaaScore();
   *
   * rpc.addEventListener(RpcEventType.BlockAdded, (event) => {
   *     console.log(event.type,event.data);
   * });
   * await rpc.subscribeBlockAdded();
   *
   * // Example usage (JavaScript):
   *
   * rpc.addEventListener("virtual-daa-score-changed", (event) => {
   *     console.log(event.type,event.data);
   * });
   *
   * await rpc.subscribeDaaScore();
   * rpc.addEventListener("block-added", (event) => {
   *     console.log(event.type,event.data);
   * });
   * await rpc.subscribeBlockAdded();
   * ```
   *
   * @see {@link RpcEventType} for a list of supported events.
   * @see {@link RpcEventData} for the event data interface specification.
   * @see {@link RpcClient.removeEventListener}, {@link RpcClient.removeAllEventListeners}
   * @param {RpcEventType | string | RpcEventCallback} event
   * @param {RpcEventCallback | null} [callback]
   */
  addEventListener(event, callback) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_addEventListener(retptr, this.__wbg_ptr, addHeapObject(event), isLikeNone2(callback) ? 0 : addHeapObject(callback));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Provides information about the Directed Acyclic Graph (DAG)
   * structure of the Kaspa BlockDAG.
   * Returned information: Number of blocks in the DAG,
   * number of tips in the DAG, hash of the selected parent block,
   * difficulty of the selected parent block, selected parent block
   * blue score, selected parent block time.
   * @see {@link IGetBlockDagInfoRequest}, {@link IGetBlockDagInfoResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetBlockDagInfoRequest | null} [request]
   * @returns {Promise<IGetBlockDagInfoResponse>}
   */
  getBlockDagInfo(request2) {
    const ret = wasm2.rpcclient_getBlockDagInfo(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Generates a new block template for mining.
   * Returned information: Block template information.
   * @see {@link IGetBlockTemplateRequest}, {@link IGetBlockTemplateResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetBlockTemplateRequest} request
   * @returns {Promise<IGetBlockTemplateResponse>}
   */
  getBlockTemplate(request2) {
    const ret = wasm2.rpcclient_getBlockTemplate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Provides a list of addresses of known peers in the Kaspa
   * network that the node can potentially connect to.
   * Returned information: List of peer addresses.
   * @see {@link IGetPeerAddressesRequest}, {@link IGetPeerAddressesResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetPeerAddressesRequest | null} [request]
   * @returns {Promise<IGetPeerAddressesResponse>}
   */
  getPeerAddresses(request2) {
    const ret = wasm2.rpcclient_getPeerAddresses(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Submits a transaction to the Kaspa network.
   * Returned information: Submitted Transaction Id.
   * @see {@link ISubmitTransactionRequest}, {@link ISubmitTransactionResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {ISubmitTransactionRequest} request
   * @returns {Promise<ISubmitTransactionResponse>}
   */
  submitTransaction(request2) {
    const ret = wasm2.rpcclient_submitTransaction(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves the current network configuration.
   * Returned information: Current network configuration.
   * @see {@link IGetCurrentNetworkRequest}, {@link IGetCurrentNetworkResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetCurrentNetworkRequest | null} [request]
   * @returns {Promise<IGetCurrentNetworkResponse>}
   */
  getCurrentNetwork(request2) {
    const ret = wasm2.rpcclient_getCurrentNetwork(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves mempool entries from the Kaspa node's mempool.
   * Returned information: List of mempool entries.
   * @see {@link IGetMempoolEntriesRequest}, {@link IGetMempoolEntriesResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetMempoolEntriesRequest} request
   * @returns {Promise<IGetMempoolEntriesResponse>}
   */
  getMempoolEntries(request2) {
    const ret = wasm2.rpcclient_getMempoolEntries(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Returns the blue score of the current sink block, indicating
   * the total amount of work that has been done on the main chain
   * leading up to that block.
   * Returned information: Blue score of the sink block.
   * @see {@link IGetSinkBlueScoreRequest}, {@link IGetSinkBlueScoreResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetSinkBlueScoreRequest | null} [request]
   * @returns {Promise<IGetSinkBlueScoreResponse>}
   */
  getSinkBlueScore(request2) {
    const ret = wasm2.rpcclient_getSinkBlueScore(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Manage subscription for a virtual DAA score changed notification event.
   * Virtual DAA score changed notification event is produced when the virtual
   * Difficulty Adjustment Algorithm (DAA) score changes in the Kaspa BlockDAG.
   * @returns {Promise<void>}
   */
  subscribeVirtualDaaScoreChanged() {
    const ret = wasm2.rpcclient_subscribeVirtualDaaScoreChanged(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   *
   * Unregister a single event listener callback from all events.
   *
   *
   * @param {RpcEventCallback} callback
   */
  clearEventListener(callback) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_clearEventListener(retptr, this.__wbg_ptr, addHeapObject(callback));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Retrieves reward information for a block.
   * Returned information: block color, confirmation count, reward, merging chain block, and header.
   * @see {@link IGetBlockRewardInfoRequest}, {@link IGetBlockRewardInfoResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetBlockRewardInfoRequest} request
   * @returns {Promise<IGetBlockRewardInfoResponse>}
   */
  getBlockRewardInfo(request2) {
    const ret = wasm2.rpcclient_getBlockRewardInfo(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   *
   * Unregister an event listener.
   * This function will remove the callback for the specified event.
   * If the `callback` is not supplied, all callbacks will be
   * removed for the specified event.
   *
   * @see {@link RpcClient.addEventListener}
   * @param {RpcEventType | string} event
   * @param {RpcEventCallback | null} [callback]
   */
  removeEventListener(event, callback) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_removeEventListener(retptr, this.__wbg_ptr, addHeapObject(event), isLikeNone2(callback) ? 0 : addHeapObject(callback));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Manage subscription for a block added notification event.
   * Block added notification event is produced when a new
   * block is added to the Kaspa BlockDAG.
   * @returns {Promise<void>}
   */
  subscribeBlockAdded() {
    const ret = wasm2.rpcclient_subscribeBlockAdded(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Manage subscription for a virtual DAA score changed notification event.
   * Virtual DAA score changed notification event is produced when the virtual
   * Difficulty Adjustment Algorithm (DAA) score changes in the Kaspa BlockDAG.
   * @returns {Promise<void>}
   */
  unsubscribeVirtualDaaScoreChanged() {
    const ret = wasm2.rpcclient_unsubscribeVirtualDaaScoreChanged(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Retrieves the balance of a specific address in the Kaspa BlockDAG.
   * Returned information: Balance of the address.
   * @see {@link IGetBalanceByAddressRequest}, {@link IGetBalanceByAddressResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetBalanceByAddressRequest} request
   * @returns {Promise<IGetBalanceByAddressResponse>}
   */
  getBalanceByAddress(request2) {
    const ret = wasm2.rpcclient_getBalanceByAddress(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves unspent transaction outputs (UTXOs) associated with
   * specific addresses.
   * Returned information: List of UTXOs.
   * @see {@link IGetUtxosByAddressesRequest}, {@link IGetUtxosByAddressesResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetUtxosByAddressesRequest | Address[] | string[]} request
   * @returns {Promise<IGetUtxosByAddressesResponse>}
   */
  getUtxosByAddresses(request2) {
    const ret = wasm2.rpcclient_getUtxosByAddresses(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves information about the peers connected to the Kaspa node.
   * Returned information: Peer ID, IP address and port, connection
   * status, protocol version.
   * @see {@link IGetConnectedPeerInfoRequest}, {@link IGetConnectedPeerInfoResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetConnectedPeerInfoRequest | null} [request]
   * @returns {Promise<IGetConnectedPeerInfoResponse>}
   */
  getConnectedPeerInfo(request2) {
    const ret = wasm2.rpcclient_getConnectedPeerInfo(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Checks if block is blue or not.
   * Returned information: Block blueness.
   * @see {@link IGetCurrentBlockColorRequest}, {@link IGetCurrentBlockColorResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetCurrentBlockColorRequest} request
   * @returns {Promise<IGetCurrentBlockColorResponse>}
   */
  getCurrentBlockColor(request2) {
    const ret = wasm2.rpcclient_getCurrentBlockColor(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Get UTXO Return Addresses.
   * @see {@link IGetUtxoReturnAddressRequest}, {@link IGetUtxoReturnAddressResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetUtxoReturnAddressRequest} request
   * @returns {Promise<IGetUtxoReturnAddressResponse>}
   */
  getUtxoReturnAddress(request2) {
    const ret = wasm2.rpcclient_getUtxoReturnAddress(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Subscribe for a UTXOs changed notification event.
   * UTXOs changed notification event is produced when the set
   * of unspent transaction outputs (UTXOs) changes in the
   * Kaspa BlockDAG. The event notification will be scoped to the
   * provided list of addresses.
   * @param {(Address | string)[]} addresses
   * @returns {Promise<void>}
   */
  subscribeUtxosChanged(addresses) {
    const ret = wasm2.rpcclient_subscribeUtxosChanged(this.__wbg_ptr, addHeapObject(addresses));
    return takeObject(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  unsubscribeBlockAdded() {
    const ret = wasm2.rpcclient_unsubscribeBlockAdded(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Retrieves balances for multiple addresses in the Kaspa BlockDAG.
   * Returned information: Balances of the addresses.
   * @see {@link IGetBalancesByAddressesRequest}, {@link IGetBalancesByAddressesResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetBalancesByAddressesRequest | Address[] | string[]} request
   * @returns {Promise<IGetBalancesByAddressesResponse>}
   */
  getBalancesByAddresses(request2) {
    const ret = wasm2.rpcclient_getBalancesByAddresses(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Resolves a finality conflict in the Kaspa BlockDAG.
   * Returned information: None.
   * @see {@link IResolveFinalityConflictRequest}, {@link IResolveFinalityConflictResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IResolveFinalityConflictRequest} request
   * @returns {Promise<IResolveFinalityConflictResponse>}
   */
  resolveFinalityConflict(request2) {
    const ret = wasm2.rpcclient_resolveFinalityConflict(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Unsubscribe from UTXOs changed notification event
   * for a specific set of addresses.
   * @param {(Address | string)[]} addresses
   * @returns {Promise<void>}
   */
  unsubscribeUtxosChanged(addresses) {
    const ret = wasm2.rpcclient_unsubscribeUtxosChanged(this.__wbg_ptr, addHeapObject(addresses));
    return takeObject(ret);
  }
  /**
   *
   * Unregister all notification callbacks for all events.
   */
  removeAllEventListeners() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_removeAllEventListeners(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Manage subscription for a finality conflict notification event.
   * Finality conflict notification event is produced when a finality
   * conflict occurs in the Kaspa BlockDAG.
   * @returns {Promise<void>}
   */
  subscribeFinalityConflict() {
    const ret = wasm2.rpcclient_subscribeFinalityConflict(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Retrieves the virtual chain corresponding to a specified block hash.
   * Returned information: Virtual chain information.
   * @see {@link IGetVirtualChainFromBlockRequest}, {@link IGetVirtualChainFromBlockResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetVirtualChainFromBlockRequest} request
   * @returns {Promise<IGetVirtualChainFromBlockResponse>}
   */
  getVirtualChainFromBlock(request2) {
    const ret = wasm2.rpcclient_getVirtualChainFromBlock(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Manage subscription for a new block template notification event.
   * New block template notification event is produced when a new block
   * template is generated for mining in the Kaspa BlockDAG.
   * @returns {Promise<void>}
   */
  subscribeNewBlockTemplate() {
    const ret = wasm2.rpcclient_subscribeNewBlockTemplate(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Feerate estimates (experimental)
   * @see {@link IGetFeeEstimateExperimentalRequest}, {@link IGetFeeEstimateExperimentalResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetFeeEstimateExperimentalRequest} request
   * @returns {Promise<IGetFeeEstimateExperimentalResponse>}
   */
  getFeeEstimateExperimental(request2) {
    const ret = wasm2.rpcclient_getFeeEstimateExperimental(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  unsubscribeFinalityConflict() {
    const ret = wasm2.rpcclient_unsubscribeFinalityConflict(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Submits an RBF transaction to the Kaspa network.
   * Returned information: Submitted Transaction Id, Transaction that was replaced.
   * @see {@link ISubmitTransactionReplacementRequest}, {@link ISubmitTransactionReplacementResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {ISubmitTransactionReplacementRequest} request
   * @returns {Promise<ISubmitTransactionReplacementResponse>}
   */
  submitTransactionReplacement(request2) {
    const ret = wasm2.rpcclient_submitTransactionReplacement(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  unsubscribeNewBlockTemplate() {
    const ret = wasm2.rpcclient_unsubscribeNewBlockTemplate(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Retrieves the virtual chain corresponding to a specified block hash.
   * Returned information: Virtual chain information. (Version 2)
   * May be used to get fully populated transactions
   * @see {@link IGetVirtualChainFromBlockV2Request}, {@link IGetVirtualChainFromBlockV2Response}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetVirtualChainFromBlockV2Request} request
   * @returns {Promise<IGetVirtualChainFromBlockV2Response>}
   */
  getVirtualChainFromBlockV2(request2) {
    const ret = wasm2.rpcclient_getVirtualChainFromBlockV2(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Manage subscription for a virtual chain changed notification event.
   * Virtual chain changed notification event is produced when the virtual
   * chain changes in the Kaspa BlockDAG.
   * @param {boolean} include_accepted_transaction_ids
   * @returns {Promise<void>}
   */
  subscribeVirtualChainChanged(include_accepted_transaction_ids) {
    const ret = wasm2.rpcclient_subscribeVirtualChainChanged(this.__wbg_ptr, include_accepted_transaction_ids);
    return takeObject(ret);
  }
  /**
   * Retrieves the estimated DAA (Difficulty Adjustment Algorithm)
   * score timestamp estimate.
   * Returned information: DAA score timestamp estimate.
   * @see {@link IGetDaaScoreTimestampEstimateRequest}, {@link IGetDaaScoreTimestampEstimateResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetDaaScoreTimestampEstimateRequest} request
   * @returns {Promise<IGetDaaScoreTimestampEstimateResponse>}
   */
  getDaaScoreTimestampEstimate(request2) {
    const ret = wasm2.rpcclient_getDaaScoreTimestampEstimate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves mempool entries associated with specific addresses.
   * Returned information: List of mempool entries.
   * @see {@link IGetMempoolEntriesByAddressesRequest}, {@link IGetMempoolEntriesByAddressesResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetMempoolEntriesByAddressesRequest} request
   * @returns {Promise<IGetMempoolEntriesByAddressesResponse>}
   */
  getMempoolEntriesByAddresses(request2) {
    const ret = wasm2.rpcclient_getMempoolEntriesByAddresses(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Manage subscription for a sink blue score changed notification event.
   * Sink blue score changed notification event is produced when the blue
   * score of the sink block changes in the Kaspa BlockDAG.
   * @returns {Promise<void>}
   */
  subscribeSinkBlueScoreChanged() {
    const ret = wasm2.rpcclient_subscribeSinkBlueScoreChanged(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Manage subscription for a virtual chain changed notification event.
   * Virtual chain changed notification event is produced when the virtual
   * chain changes in the Kaspa BlockDAG.
   * @param {boolean} include_accepted_transaction_ids
   * @returns {Promise<void>}
   */
  unsubscribeVirtualChainChanged(include_accepted_transaction_ids) {
    const ret = wasm2.rpcclient_unsubscribeVirtualChainChanged(this.__wbg_ptr, include_accepted_transaction_ids);
    return takeObject(ret);
  }
  /**
   * Estimates the network's current hash rate in hashes per second.
   * Returned information: Estimated network hashes per second.
   * @see {@link IEstimateNetworkHashesPerSecondRequest}, {@link IEstimateNetworkHashesPerSecondResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IEstimateNetworkHashesPerSecondRequest} request
   * @returns {Promise<IEstimateNetworkHashesPerSecondResponse>}
   */
  estimateNetworkHashesPerSecond(request2) {
    const ret = wasm2.rpcclient_estimateNetworkHashesPerSecond(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  unsubscribeSinkBlueScoreChanged() {
    const ret = wasm2.rpcclient_unsubscribeSinkBlueScoreChanged(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Manage subscription for a finality conflict resolved notification event.
   * Finality conflict resolved notification event is produced when a finality
   * conflict in the Kaspa BlockDAG is resolved.
   * @returns {Promise<void>}
   */
  subscribeFinalityConflictResolved() {
    const ret = wasm2.rpcclient_subscribeFinalityConflictResolved(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  unsubscribeFinalityConflictResolved() {
    const ret = wasm2.rpcclient_unsubscribeFinalityConflictResolved(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Bans a peer from connecting to the Kaspa node for a specified duration.
   * Returned information: None.
   * @see {@link IBanRequest}, {@link IBanResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IBanRequest} request
   * @returns {Promise<IBanResponse>}
   */
  ban(request2) {
    const ret = wasm2.rpcclient_ban(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * The current URL of the RPC client.
   * @returns {string | undefined}
   */
  get url() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_url(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Manage subscription for a pruning point UTXO set override notification event.
   * Pruning point UTXO set override notification event is produced when the
   * UTXO set override for the pruning point changes in the Kaspa BlockDAG.
   * @returns {Promise<void>}
   */
  subscribePruningPointUtxoSetOverride() {
    const ret = wasm2.rpcclient_subscribePruningPointUtxoSetOverride(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  unsubscribePruningPointUtxoSetOverride() {
    const ret = wasm2.rpcclient_unsubscribePruningPointUtxoSetOverride(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   *
   * Create a new RPC client with optional {@link Encoding} and a `url`.
   *
   * @see {@link IRpcConfig} interface for more details.
   * @param {IRpcConfig | null} [config]
   */
  constructor(config) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_ctor(retptr, isLikeNone2(config) ? 0 : addHeapObject(config));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      RpcClientFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Tests the connection and responsiveness of a Kaspa node.
   * Returned information: None.
   * @see {@link IPingRequest}, {@link IPingResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IPingRequest | null} [request]
   * @returns {Promise<IPingResponse>}
   */
  ping(request2) {
    const ret = wasm2.rpcclient_ping(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Stop background RPC services (automatically stopped when invoking {@link RpcClient.disconnect}).
   * @returns {Promise<void>}
   */
  stop() {
    const ret = wasm2.rpcclient_stop(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Start background RPC services (automatically started when invoking {@link RpcClient.connect}).
   * @returns {Promise<void>}
   */
  start() {
    const ret = wasm2.rpcclient_start(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Unbans a previously banned peer, allowing it to connect
   * to the Kaspa node again.
   * Returned information: None.
   * @see {@link IUnbanRequest}, {@link IUnbanResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IUnbanRequest} request
   * @returns {Promise<IUnbanResponse>}
   */
  unban(request2) {
    const ret = wasm2.rpcclient_unban(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Connect to the Kaspa RPC server. This function starts a background
   * task that connects and reconnects to the server if the connection
   * is terminated.  Use [`disconnect()`](Self::disconnect()) to
   * terminate the connection.
   * @see {@link IConnectOptions} interface for more details.
   * @param {IConnectOptions | undefined | null} [args]
   * @returns {Promise<void>}
   */
  connect(args) {
    const ret = wasm2.rpcclient_connect(this.__wbg_ptr, isLikeNone2(args) ? 0 : addHeapObject(args));
    return takeObject(ret);
  }
  /**
   * Adds a peer to the Kaspa node's list of known peers.
   * Returned information: None.
   * @see {@link IAddPeerRequest}, {@link IAddPeerResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IAddPeerRequest} request
   * @returns {Promise<IAddPeerResponse>}
   */
  addPeer(request2) {
    const ret = wasm2.rpcclient_addPeer(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * The current protocol encoding.
   * @returns {string}
   */
  get encoding() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.rpcclient_encoding(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Retrieves general information about the Kaspa node.
   * Returned information: Version of the Kaspa node, protocol
   * version, network identifier.
   * This call is primarily used by gRPC clients.
   * For wRPC clients, use {@link RpcClient.getServerInfo}.
   * @see {@link IGetInfoRequest}, {@link IGetInfoResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetInfoRequest | null} [request]
   * @returns {Promise<IGetInfoResponse>}
   */
  getInfo(request2) {
    const ret = wasm2.rpcclient_getInfo(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves the current sink block, which is the block with
   * the highest cumulative difficulty in the Kaspa BlockDAG.
   * Returned information: Sink block hash, sink block height.
   * @see {@link IGetSinkRequest}, {@link IGetSinkResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IGetSinkRequest | null} [request]
   * @returns {Promise<IGetSinkResponse>}
   */
  getSink(request2) {
    const ret = wasm2.rpcclient_getSink(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Current rpc resolver
   * @returns {Resolver | undefined}
   */
  get resolver() {
    const ret = wasm2.rpcclient_resolver(this.__wbg_ptr);
    return ret === 0 ? void 0 : Resolver.__wrap(ret);
  }
  /**
   * Gracefully shuts down the Kaspa node.
   * Returned information: None.
   * @see {@link IShutdownRequest}, {@link IShutdownResponse}
   * @throws `string` on an RPC error or a server-side error.
   * @param {IShutdownRequest | null} [request]
   * @returns {Promise<IShutdownResponse>}
   */
  shutdown(request2) {
    const ret = wasm2.rpcclient_shutdown(this.__wbg_ptr, isLikeNone2(request2) ? 0 : addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Retrieves a specific block from the Kaspa BlockDAG.
   * Returned information: Block information.
   * @see {@link IGetBlockRequest}, {@link IGetBlockResponse}
   * @throws `string` on an RPC error, a server-side error or when supplying incorrect arguments.
   * @param {IGetBlockRequest} request
   * @returns {Promise<IGetBlockResponse>}
   */
  getBlock(request2) {
    const ret = wasm2.rpcclient_getBlock(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Constructs an WebSocket RPC URL given the partial URL or an IP, RPC encoding
   * and a network type.
   *
   * # Arguments
   *
   * * `url` - Partial URL or an IP address
   * * `encoding` - RPC encoding
   * * `network_type` - Network type
   * @param {string} url
   * @param {Encoding} encoding
   * @param {NetworkId} network
   * @returns {string}
   */
  static parseUrl(url, encoding, network) {
    let deferred4_0;
    let deferred4_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(url, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      _assertClass2(network, NetworkId2);
      var ptr1 = network.__destroy_into_raw();
      wasm2.rpcclient_parseUrl(retptr, ptr0, len0, encoding, ptr1);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr3 = r0;
      var len3 = r1;
      if (r3) {
        ptr3 = 0;
        len3 = 0;
        throw takeObject(r2);
      }
      deferred4_0 = ptr3;
      deferred4_1 = len3;
      return getStringFromWasm02(ptr3, len3);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred4_0, deferred4_1, 1);
    }
  }
};
var ScriptBuilderFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_scriptbuilder_free(ptr >>> 0, 1));
var ScriptBuilder = class _ScriptBuilder {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_ScriptBuilder.prototype);
    obj.__wbg_ptr = ptr;
    ScriptBuilderFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {};
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    ScriptBuilderFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_scriptbuilder_free(ptr, 0);
  }
  /**
   * Creates a new ScriptBuilder over an existing script.
   * Supplied script can be represented as an `Uint8Array` or a `HexString`.
   * @param {HexString | Uint8Array} script
   * @param {ScriptBuilderOptions | null} [options]
   * @returns {ScriptBuilder}
   */
  static fromScript(script, options) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_fromScript(retptr, addHeapObject(script), isLikeNone2(options) ? 0 : addHeapObject(options));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _ScriptBuilder.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {bigint} sequence
   * @returns {ScriptBuilder}
   */
  addSequence(sequence) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_addLockTime(retptr, this.__wbg_ptr, sequence);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _ScriptBuilder.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Get script bytes represented by a hex string.
   * @returns {HexString}
   */
  toString() {
    const ret = wasm2.scriptbuilder_toString(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {bigint} lock_time
   * @returns {ScriptBuilder}
   */
  addLockTime(lock_time) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_addLockTime(retptr, this.__wbg_ptr, lock_time);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _ScriptBuilder.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {HexString | Uint8Array} data
   * @returns {number}
   */
  static canonicalDataSize(data) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_canonicalDataSize(retptr, addHeapObject(data));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return r0 >>> 0;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Creates an equivalent pay-to-script-hash script.
   * Can be used to create an P2SH address.
   * @see {@link addressFromScriptPublicKey}
   * @returns {ScriptPublicKey}
   */
  createPayToScriptHashScript() {
    const ret = wasm2.scriptbuilder_createPayToScriptHashScript(this.__wbg_ptr);
    return ScriptPublicKey2.__wrap(ret);
  }
  /**
   * Generates a signature script that fits a pay-to-script-hash script.
   * @param {HexString | Uint8Array} signature
   * @returns {HexString}
   */
  encodePayToScriptHashSignatureScript(signature) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_encodePayToScriptHashSignatureScript(retptr, this.__wbg_ptr, addHeapObject(signature));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {ScriptBuilderOptions | null} [options]
   */
  constructor(options) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_new(retptr, isLikeNone2(options) ? 0 : addHeapObject(options));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      ScriptBuilderFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Drains (empties) the script builder, returning the
   * script bytes represented by a hex string.
   * @returns {HexString}
   */
  drain() {
    const ret = wasm2.scriptbuilder_drain(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Pushes the passed opcode to the end of the script. The script will not
   * be modified if pushing the opcode would cause the script to exceed the
   * maximum allowed script engine size.
   * @param {number} op
   * @returns {ScriptBuilder}
   */
  addOp(op) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_addOp(retptr, this.__wbg_ptr, op);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _ScriptBuilder.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {bigint} value
   * @returns {ScriptBuilder}
   */
  addI64(value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_addI64(retptr, this.__wbg_ptr, value);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _ScriptBuilder.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Adds the passed opcodes to the end of the script.
   * Supplied opcodes can be represented as an `Uint8Array` or a `HexString`.
   * @param {HexString | Uint8Array} opcodes
   * @returns {ScriptBuilder}
   */
  addOps(opcodes) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_addOps(retptr, this.__wbg_ptr, addHeapObject(opcodes));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _ScriptBuilder.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * AddData pushes the passed data to the end of the script. It automatically
   * chooses canonical opcodes depending on the length of the data.
   *
   * A zero length buffer will lead to a push of empty data onto the stack (Op0 = OpFalse)
   * and any push of data greater than the maximum script element size will not modify
   * the script since that is not allowed by the script engine.
   *
   * Also, the script will not be modified if pushing the data would cause the script to
   * exceed the maximum allowed script engine size.
   * @param {HexString | Uint8Array} data
   * @returns {ScriptBuilder}
   */
  addData(data) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_addData(retptr, this.__wbg_ptr, addHeapObject(data));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _ScriptBuilder.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {IHexViewConfig | null} [args]
   * @returns {string}
   */
  hexView(args) {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptbuilder_hexView(retptr, this.__wbg_ptr, isLikeNone2(args) ? 0 : addHeapObject(args));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
};
var ScriptPublicKeyFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_scriptpublickey_free(ptr >>> 0, 1));
var ScriptPublicKey2 = class _ScriptPublicKey {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_ScriptPublicKey.prototype);
    obj.__wbg_ptr = ptr;
    ScriptPublicKeyFinalization2.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      script: this.script,
      version: this.version
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    ScriptPublicKeyFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_scriptpublickey_free(ptr, 0);
  }
  /**
   * @param {number} version
   * @param {any} script
   */
  constructor(version2, script) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptpublickey_constructor(retptr, version2, addHeapObject(script));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      ScriptPublicKeyFinalization2.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  get script() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.scriptpublickey_script_as_hex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {number}
   */
  get version() {
    const ret = wasm2.__wbg_get_scriptpublickey_version(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} arg0
   */
  set version(arg0) {
    wasm2.__wbg_set_scriptpublickey_version(this.__wbg_ptr, arg0);
  }
};
var SetAadOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_setaadoptions_free(ptr >>> 0, 1));
var SetAadOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    SetAadOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_setaadoptions_free(ptr, 0);
  }
  /**
   * @param {Function} value
   */
  set transform(value) {
    wasm2.setaadoptions_set_transform(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @returns {number}
   */
  get plaintextLength() {
    const ret = wasm2.agentconstructoroptions_keep_alive_msecs(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} value
   */
  set plaintext_length(value) {
    wasm2.agentconstructoroptions_set_keep_alive_msecs(this.__wbg_ptr, value);
  }
  /**
   * @param {Function} flush
   * @param {number} plaintext_length
   * @param {Function} transform
   */
  constructor(flush, plaintext_length, transform) {
    const ret = wasm2.setaadoptions_new(addHeapObject(flush), plaintext_length, addHeapObject(transform));
    this.__wbg_ptr = ret >>> 0;
    SetAadOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {Function}
   */
  get flush() {
    const ret = wasm2.setaadoptions_flush(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {Function} value
   */
  set flush(value) {
    wasm2.setaadoptions_set_flush(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @returns {Function}
   */
  get transform() {
    const ret = wasm2.setaadoptions_transform(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var SigHashTypeFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_sighashtype_free(ptr >>> 0, 1));
var SigHashType2 = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    SigHashTypeFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_sighashtype_free(ptr, 0);
  }
};
var StorageFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_storage_free(ptr >>> 0, 1));
var Storage = class {
  toJSON() {
    return {
      filename: this.filename
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    StorageFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_storage_free(ptr, 0);
  }
  /**
   * @returns {string}
   */
  get filename() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.storage_filename(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
};
var StreamTransformOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_streamtransformoptions_free(ptr >>> 0, 1));
var StreamTransformOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    StreamTransformOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_streamtransformoptions_free(ptr, 0);
  }
  /**
   * @param {Function} value
   */
  set transform(value) {
    wasm2.streamtransformoptions_set_transform(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {Function} flush
   * @param {Function} transform
   */
  constructor(flush, transform) {
    const ret = wasm2.streamtransformoptions_new(addHeapObject(flush), addHeapObject(transform));
    this.__wbg_ptr = ret >>> 0;
    StreamTransformOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {Function}
   */
  get flush() {
    const ret = wasm2.streamtransformoptions_flush(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {Function} value
   */
  set flush(value) {
    wasm2.streamtransformoptions_set_flush(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @returns {Function}
   */
  get transform() {
    const ret = wasm2.streamtransformoptions_transform(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var TransactionFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transaction_free(ptr >>> 0, 1));
var Transaction = class _Transaction {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_Transaction.prototype);
    obj.__wbg_ptr = ptr;
    TransactionFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      version: this.version,
      lockTime: this.lockTime,
      storageMass: this.storageMass,
      inputs: this.inputs,
      outputs: this.outputs,
      subnetworkId: this.subnetworkId,
      payload: this.payload,
      gas: this.gas,
      mass: this.mass,
      id: this.id
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transaction_free(ptr, 0);
  }
  /**
   * @param {ITransaction | Transaction} js_value
   */
  constructor(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_constructor(retptr, addBorrowedObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      TransactionFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {number}
   */
  get version() {
    const ret = wasm2.transaction_version(this.__wbg_ptr);
    return ret;
  }
  /**
   * Determines whether or not a transaction is a coinbase transaction. A coinbase
   * transaction is a special transaction created by miners that distributes fees and block subsidy
   * to the previous blocks' miners, and specifies the script_pub_key that will be used to pay the current
   * miner in future blocks.
   * @returns {boolean}
   */
  is_coinbase() {
    const ret = wasm2.transaction_is_coinbase(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @param {number} v
   */
  set version(v) {
    wasm2.transaction_set_version(this.__wbg_ptr, v);
  }
  /**
   * @returns {bigint}
   */
  get lockTime() {
    const ret = wasm2.transaction_lockTime(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} v
   */
  set lockTime(v) {
    wasm2.transaction_set_lockTime(this.__wbg_ptr, v);
  }
  /**
   * @returns {bigint}
   */
  get storageMass() {
    const ret = wasm2.transaction_get_mass(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} v
   */
  set storageMass(v) {
    wasm2.transaction_set_mass(this.__wbg_ptr, v);
  }
  /**
   * Serializes the transaction to a JSON string.
   * The schema of the JSON is defined by {@link ISerializableTransaction}.
   * @returns {string}
   */
  serializeToJSON() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_serializeToJSON(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * Serializes the transaction to a pure JavaScript Object.
   * The schema of the JavaScript object is defined by {@link ISerializableTransaction}.
   * @see {@link ISerializableTransaction}
   * @returns {ISerializableTransaction}
   */
  serializeToObject() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_serializeToObject(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Deserialize the {@link Transaction} Object from a JSON string.
   * @param {string} json
   * @returns {Transaction}
   */
  static deserializeFromJSON(json) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(json, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.transaction_deserializeFromJSON(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _Transaction.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {TransactionInput[]}
   */
  get inputs() {
    const ret = wasm2.transaction_get_inputs_as_js_array(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Serializes the transaction to a "Safe" JSON schema where it converts all `bigint` values to `string` to avoid potential client-side precision loss.
   * @returns {string}
   */
  serializeToSafeJSON() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_serializeToSafeJSON(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * Deserialize the {@link Transaction} Object from a pure JavaScript Object.
   * @param {any} js_value
   * @returns {Transaction}
   */
  static deserializeFromObject(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_deserializeFromObject(retptr, addBorrowedObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _Transaction.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {TransactionOutput[]}
   */
  get outputs() {
    const ret = wasm2.transaction_get_outputs_as_js_array(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {string}
   */
  get subnetworkId() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_get_subnetwork_id_as_hex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {(ITransactionInput | TransactionInput)[]} js_value
   */
  set inputs(js_value) {
    try {
      wasm2.transaction_set_inputs_from_js_array(this.__wbg_ptr, addBorrowedObject(js_value));
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {string}
   */
  get payload() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_get_payload_as_hex_string(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {(ITransactionOutput | TransactionOutput)[]} js_value
   */
  set outputs(js_value) {
    try {
      wasm2.transaction_set_outputs_from_js_array(this.__wbg_ptr, addBorrowedObject(js_value));
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {any} js_value
   */
  set payload(js_value) {
    wasm2.transaction_set_payload_from_js_value(this.__wbg_ptr, addHeapObject(js_value));
  }
  /**
   * Deserialize the {@link Transaction} Object from a "Safe" JSON schema where all `bigint` values are represented as `string`.
   * @param {string} json
   * @returns {Transaction}
   */
  static deserializeFromSafeJSON(json) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(json, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.transaction_deserializeFromSafeJSON(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _Transaction.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {(IGenesisCovenantGroup | GenesisCovenantGroup)[]} groups
   */
  populateGenesisCovenants(groups) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_populateGenesisCovenants(retptr, this.__wbg_ptr, addBorrowedObject(groups));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {any} js_value
   */
  set subnetworkId(js_value) {
    wasm2.transaction_set_subnetwork_id_from_js_value(this.__wbg_ptr, addHeapObject(js_value));
  }
  /**
   * @returns {bigint}
   */
  get gas() {
    const ret = wasm2.transaction_gas(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} v
   */
  set gas(v) {
    wasm2.transaction_set_gas(this.__wbg_ptr, v);
  }
  /**
   * Recompute and finalize the tx id based on updated tx fields
   * @returns {Hash}
   */
  finalize() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_finalize(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Hash2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @deprecated Use `storageMass` instead
   * @returns {bigint}
   */
  get mass() {
    const ret = wasm2.transaction_get_mass(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @deprecated Use `storageMass` instead
   * @param {bigint} v
   */
  set mass(v) {
    wasm2.transaction_set_mass(this.__wbg_ptr, v);
  }
  /**
   * Returns a list of unique addresses used by transaction inputs.
   * This method can be used to determine addresses used by transaction inputs
   * in order to select private keys needed for transaction signing.
   * @param {NetworkType | NetworkId | string} network_type
   * @returns {Address[]}
   */
  addresses(network_type) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_addresses(retptr, this.__wbg_ptr, addBorrowedObject(network_type));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Returns the transaction ID
   * @returns {string}
   */
  get id() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transaction_id(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
};
var TransactionInputFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transactioninput_free(ptr >>> 0, 1));
var TransactionInput = class _TransactionInput {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_TransactionInput.prototype);
    obj.__wbg_ptr = ptr;
    TransactionInputFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      sequence: this.sequence,
      sigOpCount: this.sigOpCount,
      computeBudget: this.computeBudget,
      previousOutpoint: this.previousOutpoint,
      signatureScript: this.signatureScript,
      utxo: this.utxo
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionInputFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transactioninput_free(ptr, 0);
  }
  /**
   * @param {ITransactionInput | TransactionInput} value
   */
  constructor(value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactioninput_constructor(retptr, addBorrowedObject(value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      TransactionInputFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {bigint}
   */
  get sequence() {
    const ret = wasm2.transactioninput_get_sequence(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} sequence
   */
  set sequence(sequence) {
    wasm2.transactioninput_set_sequence(this.__wbg_ptr, sequence);
  }
  /**
   * @returns {number}
   */
  get sigOpCount() {
    const ret = wasm2.transactioninput_get_sig_op_count(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} sig_op_count
   */
  set sigOpCount(sig_op_count) {
    wasm2.transactioninput_set_sig_op_count(this.__wbg_ptr, sig_op_count);
  }
  /**
   * @returns {number}
   */
  get computeBudget() {
    const ret = wasm2.transactioninput_get_compute_budget(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {number} compute_budget
   */
  set computeBudget(compute_budget) {
    wasm2.transactioninput_set_compute_budget(this.__wbg_ptr, compute_budget);
  }
  /**
   * @returns {TransactionOutpoint}
   */
  get previousOutpoint() {
    const ret = wasm2.transactioninput_get_previous_outpoint(this.__wbg_ptr);
    return TransactionOutpoint.__wrap(ret);
  }
  /**
   * @param {any} js_value
   */
  set previousOutpoint(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactioninput_set_previous_outpoint(retptr, this.__wbg_ptr, addBorrowedObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {string | undefined}
   */
  get signatureScript() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactioninput_get_signature_script_as_hex(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {any} js_value
   */
  set signatureScript(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactioninput_set_signature_script_from_js_value(retptr, this.__wbg_ptr, addHeapObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {UtxoEntryReference | undefined}
   */
  get utxo() {
    const ret = wasm2.transactioninput_get_utxo(this.__wbg_ptr);
    return ret === 0 ? void 0 : UtxoEntryReference.__wrap(ret);
  }
};
var TransactionOutpointFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transactionoutpoint_free(ptr >>> 0, 1));
var TransactionOutpoint = class _TransactionOutpoint {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_TransactionOutpoint.prototype);
    obj.__wbg_ptr = ptr;
    TransactionOutpointFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      transactionId: this.transactionId,
      index: this.index
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionOutpointFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transactionoutpoint_free(ptr, 0);
  }
  /**
   * @returns {string}
   */
  get transactionId() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactionoutpoint_transactionId(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {Hash} transaction_id
   * @param {number} index
   */
  constructor(transaction_id, index) {
    _assertClass2(transaction_id, Hash2);
    var ptr0 = transaction_id.__destroy_into_raw();
    const ret = wasm2.transactionoutpoint_ctor(ptr0, index);
    this.__wbg_ptr = ret >>> 0;
    TransactionOutpointFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {number}
   */
  get index() {
    const ret = wasm2.transactionoutpoint_index(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * @returns {string}
   */
  getId() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactionoutpoint_getId(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
};
var TransactionOutputFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transactionoutput_free(ptr >>> 0, 1));
var TransactionOutput = class _TransactionOutput {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_TransactionOutput.prototype);
    obj.__wbg_ptr = ptr;
    TransactionOutputFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      covenant: this.covenant,
      scriptPublicKey: this.scriptPublicKey,
      value: this.value
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionOutputFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transactionoutput_free(ptr, 0);
  }
  /**
   * @returns {CovenantBinding | undefined}
   */
  get covenant() {
    const ret = wasm2.transactionoutput_covenant(this.__wbg_ptr);
    return ret === 0 ? void 0 : CovenantBinding.__wrap(ret);
  }
  /**
   * @param {CovenantBinding} v
   */
  set covenant(v) {
    _assertClass2(v, CovenantBinding);
    var ptr0 = v.__destroy_into_raw();
    wasm2.transactionoutput_set_covenant(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {ScriptPublicKey}
   */
  get scriptPublicKey() {
    const ret = wasm2.transactionoutput_scriptPublicKey(this.__wbg_ptr);
    return ScriptPublicKey2.__wrap(ret);
  }
  /**
   * @param {ScriptPublicKey} v
   */
  set scriptPublicKey(v) {
    _assertClass2(v, ScriptPublicKey2);
    wasm2.transactionoutput_set_scriptPublicKey(this.__wbg_ptr, v.__wbg_ptr);
  }
  /**
   * TransactionOutput constructor
   * @param {bigint} value
   * @param {ScriptPublicKey} script_public_key
   * @param {CovenantBinding | null} [covenant]
   */
  constructor(value, script_public_key, covenant) {
    _assertClass2(script_public_key, ScriptPublicKey2);
    let ptr0 = 0;
    if (!isLikeNone2(covenant)) {
      _assertClass2(covenant, CovenantBinding);
      ptr0 = covenant.__destroy_into_raw();
    }
    const ret = wasm2.transactionoutput_ctor(value, script_public_key.__wbg_ptr, ptr0);
    this.__wbg_ptr = ret >>> 0;
    TransactionOutputFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {bigint}
   */
  get value() {
    const ret = wasm2.transactionoutput_value(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} v
   */
  set value(v) {
    wasm2.transactionoutput_set_value(this.__wbg_ptr, v);
  }
};
var TransactionRecordFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transactionrecord_free(ptr >>> 0, 1));
var TransactionRecord = class _TransactionRecord {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_TransactionRecord.prototype);
    obj.__wbg_ptr = ptr;
    TransactionRecordFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      data: this.data,
      value: this.value,
      binding: this.binding,
      blockDaaScore: this.blockDaaScore,
      type: this.type,
      id: this.id,
      unixtimeMsec: this.unixtimeMsec,
      network: this.network,
      note: this.note,
      metadata: this.metadata
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionRecordFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transactionrecord_free(ptr, 0);
  }
  /**
   * Check if the transaction record has the given address within the associated UTXO set.
   * @param {Address} address
   * @returns {boolean}
   */
  hasAddress(address) {
    _assertClass2(address, Address2);
    const ret = wasm2.transactionrecord_hasAddress(this.__wbg_ptr, address.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @returns {ITransactionData}
   */
  get data() {
    const ret = wasm2.transactionrecord_data(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {bigint}
   */
  get value() {
    const ret = wasm2.transactionrecord_value(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {IBinding}
   */
  get binding() {
    const ret = wasm2.transactionrecord_binding(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {bigint} currentDaaScore
   * @returns {string}
   */
  maturityProgress(currentDaaScore) {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactionrecord_maturityProgress(retptr, this.__wbg_ptr, addHeapObject(currentDaaScore));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {bigint}
   */
  get blockDaaScore() {
    const ret = wasm2.transactionrecord_blockDaaScore(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {string}
   */
  get type() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactionrecord_type(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Serialize the transaction record to a JavaScript object.
   * @returns {any}
   */
  serialize() {
    const ret = wasm2.transactionrecord_serialize(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {Hash}
   */
  get id() {
    const ret = wasm2.__wbg_get_transactionrecord_id(this.__wbg_ptr);
    return Hash2.__wrap(ret);
  }
  /**
   * @param {Hash} arg0
   */
  set id(arg0) {
    _assertClass2(arg0, Hash2);
    var ptr0 = arg0.__destroy_into_raw();
    wasm2.__wbg_set_transactionrecord_id(this.__wbg_ptr, ptr0);
  }
  /**
   * Unix time in milliseconds
   * @returns {bigint | undefined}
   */
  get unixtimeMsec() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.__wbg_get_transactionrecord_unixtimeMsec(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r2 = getDataViewMemory02().getBigInt64(retptr + 8 * 1, true);
      return r0 === 0 ? void 0 : BigInt.asUintN(64, r2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Unix time in milliseconds
   * @param {bigint | null} [arg0]
   */
  set unixtimeMsec(arg0) {
    wasm2.__wbg_set_transactionrecord_unixtimeMsec(this.__wbg_ptr, !isLikeNone2(arg0), isLikeNone2(arg0) ? BigInt(0) : arg0);
  }
  /**
   * @returns {NetworkId}
   */
  get network() {
    const ret = wasm2.__wbg_get_transactionrecord_network(this.__wbg_ptr);
    return NetworkId2.__wrap(ret);
  }
  /**
   * @param {NetworkId} arg0
   */
  set network(arg0) {
    _assertClass2(arg0, NetworkId2);
    var ptr0 = arg0.__destroy_into_raw();
    wasm2.__wbg_set_transactionrecord_network(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {string | undefined}
   */
  get note() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.__wbg_get_transactionrecord_note(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {string | null} [arg0]
   */
  set note(arg0) {
    var ptr0 = isLikeNone2(arg0) ? 0 : passStringToWasm02(arg0, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    var len0 = WASM_VECTOR_LEN2;
    wasm2.__wbg_set_transactionrecord_note(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @returns {string | undefined}
   */
  get metadata() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.__wbg_get_transactionrecord_metadata(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {string | null} [arg0]
   */
  set metadata(arg0) {
    var ptr0 = isLikeNone2(arg0) ? 0 : passStringToWasm02(arg0, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    var len0 = WASM_VECTOR_LEN2;
    wasm2.__wbg_set_transactionrecord_metadata(this.__wbg_ptr, ptr0, len0);
  }
};
var TransactionRecordNotificationFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transactionrecordnotification_free(ptr >>> 0, 1));
var TransactionRecordNotification = class _TransactionRecordNotification {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_TransactionRecordNotification.prototype);
    obj.__wbg_ptr = ptr;
    TransactionRecordNotificationFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      type: this.type,
      data: this.data
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionRecordNotificationFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transactionrecordnotification_free(ptr, 0);
  }
  /**
   * @returns {string}
   */
  get type() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.__wbg_get_transactionrecordnotification_type(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {string} arg0
   */
  set type(arg0) {
    const ptr0 = passStringToWasm02(arg0, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.__wbg_set_transactionrecordnotification_type(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @returns {TransactionRecord}
   */
  get data() {
    const ret = wasm2.__wbg_get_transactionrecordnotification_data(this.__wbg_ptr);
    return TransactionRecord.__wrap(ret);
  }
  /**
   * @param {TransactionRecord} arg0
   */
  set data(arg0) {
    _assertClass2(arg0, TransactionRecord);
    var ptr0 = arg0.__destroy_into_raw();
    wasm2.__wbg_set_transactionrecordnotification_data(this.__wbg_ptr, ptr0);
  }
};
var TransactionSigningHashFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transactionsigninghash_free(ptr >>> 0, 1));
var TransactionSigningHash = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionSigningHashFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transactionsigninghash_free(ptr, 0);
  }
  constructor() {
    const ret = wasm2.transactionsigninghash_new();
    this.__wbg_ptr = ret >>> 0;
    TransactionSigningHashFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @param {HexString | Uint8Array} data
   */
  update(data) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactionsigninghash_update(retptr, this.__wbg_ptr, addHeapObject(data));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  finalize() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactionsigninghash_finalize(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
};
var TransactionSigningHashECDSAFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transactionsigninghashecdsa_free(ptr >>> 0, 1));
var TransactionSigningHashECDSA = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionSigningHashECDSAFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transactionsigninghashecdsa_free(ptr, 0);
  }
  constructor() {
    const ret = wasm2.transactionsigninghashecdsa_new();
    this.__wbg_ptr = ret >>> 0;
    TransactionSigningHashECDSAFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @param {HexString | Uint8Array} data
   */
  update(data) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactionsigninghashecdsa_update(retptr, this.__wbg_ptr, addHeapObject(data));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  finalize() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.transactionsigninghashecdsa_finalize(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
};
var TransactionUtxoEntryFinalization2 = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_transactionutxoentry_free(ptr >>> 0, 1));
var TransactionUtxoEntry2 = class {
  toJSON() {
    return {
      amount: this.amount,
      scriptPublicKey: this.scriptPublicKey,
      blockDaaScore: this.blockDaaScore,
      isCoinbase: this.isCoinbase,
      covenantId: this.covenantId
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    TransactionUtxoEntryFinalization2.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_transactionutxoentry_free(ptr, 0);
  }
  /**
   * @returns {bigint}
   */
  get amount() {
    const ret = wasm2.__wbg_get_transactionutxoentry_amount(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} arg0
   */
  set amount(arg0) {
    wasm2.__wbg_set_transactionutxoentry_amount(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {ScriptPublicKey}
   */
  get scriptPublicKey() {
    const ret = wasm2.__wbg_get_transactionutxoentry_scriptPublicKey(this.__wbg_ptr);
    return ScriptPublicKey2.__wrap(ret);
  }
  /**
   * @param {ScriptPublicKey} arg0
   */
  set scriptPublicKey(arg0) {
    _assertClass2(arg0, ScriptPublicKey2);
    var ptr0 = arg0.__destroy_into_raw();
    wasm2.__wbg_set_transactionutxoentry_scriptPublicKey(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {bigint}
   */
  get blockDaaScore() {
    const ret = wasm2.__wbg_get_transactionutxoentry_blockDaaScore(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} arg0
   */
  set blockDaaScore(arg0) {
    wasm2.__wbg_set_transactionutxoentry_blockDaaScore(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {boolean}
   */
  get isCoinbase() {
    const ret = wasm2.__wbg_get_transactionutxoentry_isCoinbase(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @param {boolean} arg0
   */
  set isCoinbase(arg0) {
    wasm2.__wbg_set_transactionutxoentry_isCoinbase(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {Hash | undefined}
   */
  get covenantId() {
    const ret = wasm2.__wbg_get_transactionutxoentry_covenantId(this.__wbg_ptr);
    return ret === 0 ? void 0 : Hash2.__wrap(ret);
  }
  /**
   * @param {Hash | null} [arg0]
   */
  set covenantId(arg0) {
    let ptr0 = 0;
    if (!isLikeNone2(arg0)) {
      _assertClass2(arg0, Hash2);
      ptr0 = arg0.__destroy_into_raw();
    }
    wasm2.__wbg_set_transactionutxoentry_covenantId(this.__wbg_ptr, ptr0);
  }
};
var UserInfoOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_userinfooptions_free(ptr >>> 0, 1));
var UserInfoOptions = class _UserInfoOptions {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_UserInfoOptions.prototype);
    obj.__wbg_ptr = ptr;
    UserInfoOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    UserInfoOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_userinfooptions_free(ptr, 0);
  }
  /**
   * @param {string | null} [value]
   */
  set encoding(value) {
    wasm2.userinfooptions_set_encoding(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {string | null} [encoding]
   */
  constructor(encoding) {
    const ret = wasm2.userinfooptions_new_with_values(isLikeNone2(encoding) ? 0 : addHeapObject(encoding));
    this.__wbg_ptr = ret >>> 0;
    UserInfoOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {UserInfoOptions}
   */
  static new() {
    const ret = wasm2.userinfooptions_new();
    return _UserInfoOptions.__wrap(ret);
  }
  /**
   * @returns {string | undefined}
   */
  get encoding() {
    const ret = wasm2.userinfooptions_encoding(this.__wbg_ptr);
    return takeObject(ret);
  }
};
var UtxoContextFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_utxocontext_free(ptr >>> 0, 1));
var UtxoContext = class {
  toJSON() {
    return {
      matureLength: this.matureLength,
      balanceStrings: this.balanceStrings,
      isActive: this.isActive,
      balance: this.balance
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    UtxoContextFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_utxocontext_free(ptr, 0);
  }
  /**
   *
   * Returns a range of mature UTXO entries that are currently
   * managed by the UtxoContext and are available for spending.
   *
   * NOTE: This function is provided for informational purposes only.
   * **You should not manage UTXO entries manually if they are owned by UtxoContext.**
   *
   * The resulting range may be less than requested if UTXO entries
   * have been spent asynchronously by UtxoContext or by other means
   * (i.e. UtxoContext has received notification from the network that
   * UtxoEntries have been spent externally).
   *
   * UtxoEntries are kept in in the ascending sorted order by their amount.
   * @param {number} from
   * @param {number} to
   * @returns {UtxoEntryReference[]}
   */
  getMatureRange(from, to) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxocontext_getMatureRange(retptr, this.__wbg_ptr, from, to);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Obtain the length of the mature UTXO entries that are currently
   * managed by the UtxoContext.
   * @returns {number}
   */
  get matureLength() {
    const ret = wasm2.utxocontext_matureLength(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * Current {@link BalanceStrings} of the UtxoContext.
   * @returns {BalanceStrings | undefined}
   */
  get balanceStrings() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxocontext_balanceStrings(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return r0 === 0 ? void 0 : BalanceStrings.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Performs a scan of the given addresses and registers them in the context for event notifications.
   * @param {(Address | string)[]} addresses
   * @param {bigint | null} [optional_current_daa_score]
   * @returns {Promise<void>}
   */
  trackAddresses(addresses, optional_current_daa_score) {
    const ret = wasm2.utxocontext_trackAddresses(this.__wbg_ptr, addHeapObject(addresses), isLikeNone2(optional_current_daa_score) ? 0 : addHeapObject(optional_current_daa_score));
    return takeObject(ret);
  }
  /**
   * Unregister a list of addresses from the context. This will stop tracking of these addresses.
   * @param {(Address | string)[]} addresses
   * @returns {Promise<void>}
   */
  unregisterAddresses(addresses) {
    const ret = wasm2.utxocontext_unregisterAddresses(this.__wbg_ptr, addHeapObject(addresses));
    return takeObject(ret);
  }
  /**
   * @param {IUtxoContextArgs} js_value
   */
  constructor(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxocontext_ctor(retptr, addHeapObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      UtxoContextFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Clear the UtxoContext.  Unregister all addresses and clear all UTXO entries.
   * IMPORTANT: This function must be manually called when disconnecting or re-connecting to the node
   * (followed by address re-registration).
   * @returns {Promise<void>}
   */
  clear() {
    const ret = wasm2.utxocontext_clear(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {boolean}
   */
  get isActive() {
    const ret = wasm2.utxocontext_isActive(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * Current {@link Balance} of the UtxoContext.
   * @returns {Balance | undefined}
   */
  get balance() {
    const ret = wasm2.utxocontext_balance(this.__wbg_ptr);
    return ret === 0 ? void 0 : Balance.__wrap(ret);
  }
  /**
   * Returns pending UTXO entries that are currently managed by the UtxoContext.
   * @returns {UtxoEntryReference[]}
   */
  getPending() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxocontext_getPending(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var UtxoEntriesFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_utxoentries_free(ptr >>> 0, 1));
var UtxoEntries = class {
  toJSON() {
    return {
      items: this.items
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    UtxoEntriesFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_utxoentries_free(ptr, 0);
  }
  /**
   * @returns {any}
   */
  get items() {
    const ret = wasm2.utxoentries_get_items_as_js_array(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {any} js_value
   */
  set items(js_value) {
    try {
      wasm2.utxoentries_set_items_from_js_array(this.__wbg_ptr, addBorrowedObject(js_value));
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * Sort the contained entries by amount. Please note that
   * this function is not intended for use with large UTXO sets
   * as it duplicates the whole contained UTXO set while sorting.
   */
  sort() {
    wasm2.utxoentries_sort(this.__wbg_ptr);
  }
  /**
   * @returns {bigint}
   */
  amount() {
    const ret = wasm2.utxoentries_amount(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * Create a new `UtxoEntries` struct with a set of entries.
   * @param {any} js_value
   */
  constructor(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoentries_js_ctor(retptr, addHeapObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      UtxoEntriesFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var UtxoEntryFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_utxoentry_free(ptr >>> 0, 1));
var UtxoEntry = class _UtxoEntry {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_UtxoEntry.prototype);
    obj.__wbg_ptr = ptr;
    UtxoEntryFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      address: this.address,
      outpoint: this.outpoint,
      amount: this.amount,
      scriptPublicKey: this.scriptPublicKey,
      blockDaaScore: this.blockDaaScore,
      isCoinbase: this.isCoinbase,
      covenantId: this.covenantId
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    UtxoEntryFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_utxoentry_free(ptr, 0);
  }
  /**
   * @returns {Address | undefined}
   */
  get address() {
    const ret = wasm2.__wbg_get_utxoentry_address(this.__wbg_ptr);
    return ret === 0 ? void 0 : Address2.__wrap(ret);
  }
  /**
   * @param {Address | null} [arg0]
   */
  set address(arg0) {
    let ptr0 = 0;
    if (!isLikeNone2(arg0)) {
      _assertClass2(arg0, Address2);
      ptr0 = arg0.__destroy_into_raw();
    }
    wasm2.__wbg_set_utxoentry_address(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {TransactionOutpoint}
   */
  get outpoint() {
    const ret = wasm2.__wbg_get_utxoentry_outpoint(this.__wbg_ptr);
    return TransactionOutpoint.__wrap(ret);
  }
  /**
   * @param {TransactionOutpoint} arg0
   */
  set outpoint(arg0) {
    _assertClass2(arg0, TransactionOutpoint);
    var ptr0 = arg0.__destroy_into_raw();
    wasm2.__wbg_set_utxoentry_outpoint(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {bigint}
   */
  get amount() {
    const ret = wasm2.__wbg_get_utxoentry_amount(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} arg0
   */
  set amount(arg0) {
    wasm2.__wbg_set_utxoentry_amount(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {ScriptPublicKey}
   */
  get scriptPublicKey() {
    const ret = wasm2.__wbg_get_utxoentry_scriptPublicKey(this.__wbg_ptr);
    return ScriptPublicKey2.__wrap(ret);
  }
  /**
   * @param {ScriptPublicKey} arg0
   */
  set scriptPublicKey(arg0) {
    _assertClass2(arg0, ScriptPublicKey2);
    var ptr0 = arg0.__destroy_into_raw();
    wasm2.__wbg_set_utxoentry_scriptPublicKey(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {bigint}
   */
  get blockDaaScore() {
    const ret = wasm2.__wbg_get_utxoentry_blockDaaScore(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @param {bigint} arg0
   */
  set blockDaaScore(arg0) {
    wasm2.__wbg_set_utxoentry_blockDaaScore(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {boolean}
   */
  get isCoinbase() {
    const ret = wasm2.__wbg_get_utxoentry_isCoinbase(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @param {boolean} arg0
   */
  set isCoinbase(arg0) {
    wasm2.__wbg_set_utxoentry_isCoinbase(this.__wbg_ptr, arg0);
  }
  /**
   * @returns {Hash | undefined}
   */
  get covenantId() {
    const ret = wasm2.__wbg_get_utxoentry_covenantId(this.__wbg_ptr);
    return ret === 0 ? void 0 : Hash2.__wrap(ret);
  }
  /**
   * @param {Hash | null} [arg0]
   */
  set covenantId(arg0) {
    let ptr0 = 0;
    if (!isLikeNone2(arg0)) {
      _assertClass2(arg0, Hash2);
      ptr0 = arg0.__destroy_into_raw();
    }
    wasm2.__wbg_set_utxoentry_covenantId(this.__wbg_ptr, ptr0);
  }
  /**
   * @returns {string}
   */
  toString() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoentry_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var UtxoEntryReferenceFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_utxoentryreference_free(ptr >>> 0, 1));
var UtxoEntryReference = class _UtxoEntryReference {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_UtxoEntryReference.prototype);
    obj.__wbg_ptr = ptr;
    UtxoEntryReferenceFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      isCoinbase: this.isCoinbase,
      blockDaaScore: this.blockDaaScore,
      scriptPublicKey: this.scriptPublicKey,
      entry: this.entry,
      amount: this.amount,
      address: this.address,
      outpoint: this.outpoint
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    UtxoEntryReferenceFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_utxoentryreference_free(ptr, 0);
  }
  /**
   * @returns {boolean}
   */
  get isCoinbase() {
    const ret = wasm2.utxoentryreference_isCoinbase(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @returns {string}
   */
  toString() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoentryreference_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return takeObject(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {bigint}
   */
  get blockDaaScore() {
    const ret = wasm2.utxoentryreference_blockDaaScore(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @returns {ScriptPublicKey}
   */
  get scriptPublicKey() {
    const ret = wasm2.utxoentryreference_scriptPublicKey(this.__wbg_ptr);
    return ScriptPublicKey2.__wrap(ret);
  }
  /**
   * @returns {UtxoEntry}
   */
  get entry() {
    const ret = wasm2.utxoentryreference_entry(this.__wbg_ptr);
    return UtxoEntry.__wrap(ret);
  }
  /**
   * @returns {bigint}
   */
  get amount() {
    const ret = wasm2.utxoentryreference_amount(this.__wbg_ptr);
    return BigInt.asUintN(64, ret);
  }
  /**
   * @returns {Address | undefined}
   */
  get address() {
    const ret = wasm2.utxoentryreference_address(this.__wbg_ptr);
    return ret === 0 ? void 0 : Address2.__wrap(ret);
  }
  /**
   * @returns {TransactionOutpoint}
   */
  get outpoint() {
    const ret = wasm2.utxoentryreference_outpoint(this.__wbg_ptr);
    return TransactionOutpoint.__wrap(ret);
  }
};
var UtxoProcessorFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_utxoprocessor_free(ptr >>> 0, 1));
var UtxoProcessor = class {
  toJSON() {
    return {
      networkId: this.networkId,
      rpc: this.rpc,
      isActive: this.isActive
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    UtxoProcessorFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_utxoprocessor_free(ptr, 0);
  }
  /**
   * @returns {string | undefined}
   */
  get networkId() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoprocessor_networkId(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {NetworkId | string} network_id
   */
  setNetworkId(network_id) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoprocessor_setNetworkId(retptr, this.__wbg_ptr, addBorrowedObject(network_id));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {string | UtxoProcessorNotificationCallback} event
   * @param {UtxoProcessorNotificationCallback | null} [callback]
   */
  addEventListener(event, callback) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoprocessor_addEventListener(retptr, this.__wbg_ptr, addHeapObject(event), isLikeNone2(callback) ? 0 : addHeapObject(callback));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {UtxoProcessorEventType | UtxoProcessorEventType[] | string | string[]} event
   * @param {UtxoProcessorNotificationCallback | null} [callback]
   */
  removeEventListener(event, callback) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoprocessor_removeEventListener(retptr, this.__wbg_ptr, addHeapObject(event), isLikeNone2(callback) ? 0 : addHeapObject(callback));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {RpcClient}
   */
  get rpc() {
    const ret = wasm2.utxoprocessor_rpc(this.__wbg_ptr);
    return RpcClient.__wrap(ret);
  }
  /**
   *
   * Set the user transaction maturity period DAA score for a given network.
   * This controls the DAA period after which the user transactions are considered mature
   * and the wallet subsystem emits the transaction maturity event.
   *
   * @see {@link TransactionRecord}
   * @see {@link IUtxoProcessorEvent}
   *
   * @category Wallet SDK
   * @param {NetworkId | string} network_id
   * @param {bigint} value
   */
  static setUserTransactionMaturityDAA(network_id, value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoprocessor_setUserTransactionMaturityDAA(retptr, addBorrowedObject(network_id), value);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   *
   * Set the coinbase transaction maturity period DAA score for a given network.
   * This controls the DAA period after which the user transactions are considered mature
   * and the wallet subsystem emits the transaction maturity event.
   *
   * @see {@link TransactionRecord}
   * @see {@link IUtxoProcessorEvent}
   *
   * @category Wallet SDK
   * @param {NetworkId | string} network_id
   * @param {bigint} value
   */
  static setCoinbaseTransactionMaturityDAA(network_id, value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoprocessor_setCoinbaseTransactionMaturityDAA(retptr, addBorrowedObject(network_id), value);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * UtxoProcessor constructor.
   *
   *
   *
   * @see {@link IUtxoProcessorArgs}
   * @param {IUtxoProcessorArgs} js_value
   */
  constructor(js_value) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.utxoprocessor_ctor(retptr, addHeapObject(js_value));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      UtxoProcessorFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Stops the UtxoProcessor and ends processing UTXO and other notifications.
   * @returns {Promise<void>}
   */
  stop() {
    const ret = wasm2.utxoprocessor_stop(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Starts the UtxoProcessor and begins processing UTXO and other notifications.
   * @returns {Promise<void>}
   */
  start() {
    const ret = wasm2.utxoprocessor_start(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {boolean}
   */
  get isActive() {
    const ret = wasm2.utxoprocessor_isActive(this.__wbg_ptr);
    return ret !== 0;
  }
};
var WalletFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_wallet_free(ptr >>> 0, 1));
var Wallet = class {
  toJSON() {
    return {
      descriptor: this.descriptor,
      rpc: this.rpc,
      isOpen: this.isOpen,
      isSynced: this.isSynced
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    WalletFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_wallet_free(ptr, 0);
  }
  /**
   * @returns {WalletDescriptor | undefined}
   */
  get descriptor() {
    const ret = wasm2.wallet_descriptor(this.__wbg_ptr);
    return ret === 0 ? void 0 : WalletDescriptor.__wrap(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  disconnect() {
    const ret = wasm2.wallet_disconnect(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {IWalletConfig} config
   */
  constructor(config) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.wallet_constructor(retptr, addHeapObject(config));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      WalletFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {NetworkId | string} network_id
   */
  setNetworkId(network_id) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.wallet_setNetworkId(retptr, this.__wbg_ptr, addHeapObject(network_id));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {string | WalletNotificationCallback} event
   * @param {WalletNotificationCallback | null} [callback]
   */
  addEventListener(event, callback) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.wallet_addEventListener(retptr, this.__wbg_ptr, addHeapObject(event), isLikeNone2(callback) ? 0 : addHeapObject(callback));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {WalletEventType | WalletEventType[] | string | string[]} event
   * @param {WalletNotificationCallback | null} [callback]
   */
  removeEventListener(event, callback) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.wallet_removeEventListener(retptr, this.__wbg_ptr, addHeapObject(event), isLikeNone2(callback) ? 0 : addHeapObject(callback));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      if (r1) {
        throw takeObject(r0);
      }
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {RpcClient}
   */
  get rpc() {
    const ret = wasm2.wallet_rpc(this.__wbg_ptr);
    return RpcClient.__wrap(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  stop() {
    const ret = wasm2.wallet_stop(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {Promise<void>}
   */
  start() {
    const ret = wasm2.wallet_start(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * Check if a wallet with a given name exists.
   * @param {string | null} [name]
   * @returns {Promise<boolean>}
   */
  exists(name) {
    var ptr0 = isLikeNone2(name) ? 0 : passStringToWasm02(name, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    var len0 = WASM_VECTOR_LEN2;
    const ret = wasm2.wallet_exists(this.__wbg_ptr, ptr0, len0);
    return takeObject(ret);
  }
  /**
   * @param {IConnectOptions | undefined | null} [args]
   * @returns {Promise<void>}
   */
  connect(args) {
    const ret = wasm2.wallet_connect(this.__wbg_ptr, isLikeNone2(args) ? 0 : addHeapObject(args));
    return takeObject(ret);
  }
  /**
   * @remarks This is a local property indicating
   * if the wallet is currently open.
   * @returns {boolean}
   */
  get isOpen() {
    const ret = wasm2.wallet_isOpen(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @remarks This is a local property indicating
   * if the node is currently synced.
   * @returns {boolean}
   */
  get isSynced() {
    const ret = wasm2.wallet_isSynced(this.__wbg_ptr);
    return ret !== 0;
  }
  /**
   * @see {@link IGetStatusRequest} {@link IGetStatusResponse}
   * @throws `string` in case of an error.
   * @param {IGetStatusRequest} request
   * @returns {Promise<IGetStatusResponse>}
   */
  getStatus(request2) {
    const ret = wasm2.wallet_getStatus(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IWalletOpenRequest} {@link IWalletOpenResponse}
   * @throws `string` in case of an error.
   * @param {IWalletOpenRequest} request
   * @returns {Promise<IWalletOpenResponse>}
   */
  walletOpen(request2) {
    const ret = wasm2.wallet_walletOpen(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsGetRequest} {@link IAccountsGetResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsGetRequest} request
   * @returns {Promise<IAccountsGetResponse>}
   */
  accountsGet(request2) {
    const ret = wasm2.wallet_accountsGet(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IWalletCloseRequest} {@link IWalletCloseResponse}
   * @throws `string` in case of an error.
   * @param {IWalletCloseRequest} request
   * @returns {Promise<IWalletCloseResponse>}
   */
  walletClose(request2) {
    const ret = wasm2.wallet_walletClose(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsSendRequest} {@link IAccountsSendResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsSendRequest} request
   * @returns {Promise<IAccountsSendResponse>}
   */
  accountsSend(request2) {
    const ret = wasm2.wallet_accountsSend(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IWalletCreateRequest} {@link IWalletCreateResponse}
   * @throws `string` in case of an error.
   * @param {IWalletCreateRequest} request
   * @returns {Promise<IWalletCreateResponse>}
   */
  walletCreate(request2) {
    const ret = wasm2.wallet_walletCreate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IWalletExportRequest} {@link IWalletExportResponse}
   * @throws `string` in case of an error.
   * @param {IWalletExportRequest} request
   * @returns {Promise<IWalletExportResponse>}
   */
  walletExport(request2) {
    const ret = wasm2.wallet_walletExport(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IWalletImportRequest} {@link IWalletImportResponse}
   * @throws `string` in case of an error.
   * @param {IWalletImportRequest} request
   * @returns {Promise<IWalletImportResponse>}
   */
  walletImport(request2) {
    const ret = wasm2.wallet_walletImport(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IWalletReloadRequest} {@link IWalletReloadResponse}
   * @throws `string` in case of an error.
   * @param {IWalletReloadRequest} request
   * @returns {Promise<IWalletReloadResponse>}
   */
  walletReload(request2) {
    const ret = wasm2.wallet_walletReload(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IRetainContextRequest} {@link IRetainContextResponse}
   * @throws `string` in case of an error.
   * @param {IRetainContextRequest} request
   * @returns {Promise<IRetainContextResponse>}
   */
  retainContext(request2) {
    const ret = wasm2.wallet_retainContext(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsCreateRequest} {@link IAccountsCreateResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsCreateRequest} request
   * @returns {Promise<IAccountsCreateResponse>}
   */
  accountsCreate(request2) {
    const ret = wasm2.wallet_accountsCreate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsImportRequest} {@link IAccountsImportResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsImportRequest} request
   * @returns {Promise<IAccountsImportResponse>}
   */
  accountsImport(request2) {
    const ret = wasm2.wallet_accountsImport(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsRenameRequest} {@link IAccountsRenameResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsRenameRequest} request
   * @returns {Promise<IAccountsRenameResponse>}
   */
  accountsRename(request2) {
    const ret = wasm2.wallet_accountsRename(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IPrvKeyDataGetRequest} {@link IPrvKeyDataGetResponse}
   * @throws `string` in case of an error.
   * @param {IPrvKeyDataGetRequest} request
   * @returns {Promise<IPrvKeyDataGetResponse>}
   */
  prvKeyDataGet(request2) {
    const ret = wasm2.wallet_prvKeyDataGet(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IWalletEnumerateRequest} {@link IWalletEnumerateResponse}
   * @throws `string` in case of an error.
   * @param {IWalletEnumerateRequest} request
   * @returns {Promise<IWalletEnumerateResponse>}
   */
  walletEnumerate(request2) {
    const ret = wasm2.wallet_walletEnumerate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsActivateRequest} {@link IAccountsActivateResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsActivateRequest} request
   * @returns {Promise<IAccountsActivateResponse>}
   */
  accountsActivate(request2) {
    const ret = wasm2.wallet_accountsActivate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsEstimateRequest} {@link IAccountsEstimateResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsEstimateRequest} request
   * @returns {Promise<IAccountsEstimateResponse>}
   */
  accountsEstimate(request2) {
    const ret = wasm2.wallet_accountsEstimate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsTransferRequest} {@link IAccountsTransferResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsTransferRequest} request
   * @returns {Promise<IAccountsTransferResponse>}
   */
  accountsTransfer(request2) {
    const ret = wasm2.wallet_accountsTransfer(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IFeeRateEstimateRequest} {@link IFeeRateEstimateResponse}
   * @throws `string` in case of an error.
   * @param {IFeeRateEstimateRequest} request
   * @returns {Promise<IFeeRateEstimateResponse>}
   */
  feeRateEstimate(request2) {
    const ret = wasm2.wallet_feeRateEstimate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsDiscoveryRequest} {@link IAccountsDiscoveryResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsDiscoveryRequest} request
   * @returns {Promise<IAccountsDiscoveryResponse>}
   */
  accountsDiscovery(request2) {
    const ret = wasm2.wallet_accountsDiscovery(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsEnumerateRequest} {@link IAccountsEnumerateResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsEnumerateRequest} request
   * @returns {Promise<IAccountsEnumerateResponse>}
   */
  accountsEnumerate(request2) {
    const ret = wasm2.wallet_accountsEnumerate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsGetUtxosRequest} {@link IAccountsGetUtxosResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsGetUtxosRequest} request
   * @returns {Promise<IAccountsGetUtxosResponse>}
   */
  accountsGetUtxos(request2) {
    const ret = wasm2.wallet_accountsGetUtxos(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsPskbSendRequest} {@link IAccountsPskbSendResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsPskbSendRequest} request
   * @returns {Promise<IAccountsPskbSendResponse>}
   */
  accountsPskbSend(request2) {
    const ret = wasm2.wallet_accountsPskbSend(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsPskbSignRequest} {@link IAccountsPskbSignResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsPskbSignRequest} request
   * @returns {Promise<IAccountsPskbSignResponse>}
   */
  accountsPskbSign(request2) {
    const ret = wasm2.wallet_accountsPskbSign(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsDeactivateRequest} {@link IAccountsDeactivateResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsDeactivateRequest} request
   * @returns {Promise<IAccountsDeactivateResponse>}
   */
  accountsDeactivate(request2) {
    const ret = wasm2.wallet_accountsDeactivate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IPrvKeyDataCreateRequest} {@link IPrvKeyDataCreateResponse}
   * @throws `string` in case of an error.
   * @param {IPrvKeyDataCreateRequest} request
   * @returns {Promise<IPrvKeyDataCreateResponse>}
   */
  prvKeyDataCreate(request2) {
    const ret = wasm2.wallet_prvKeyDataCreate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IPrvKeyDataRemoveRequest} {@link IPrvKeyDataRemoveResponse}
   * @throws `string` in case of an error.
   * @param {IPrvKeyDataRemoveRequest} request
   * @returns {Promise<IPrvKeyDataRemoveResponse>}
   */
  prvKeyDataRemove(request2) {
    const ret = wasm2.wallet_prvKeyDataRemove(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IWalletChangeSecretRequest} {@link IWalletChangeSecretResponse}
   * @throws `string` in case of an error.
   * @param {IWalletChangeSecretRequest} request
   * @returns {Promise<IWalletChangeSecretResponse>}
   */
  walletChangeSecret(request2) {
    const ret = wasm2.wallet_walletChangeSecret(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link ITransactionsDataGetRequest} {@link ITransactionsDataGetResponse}
   * @throws `string` in case of an error.
   * @param {ITransactionsDataGetRequest} request
   * @returns {Promise<ITransactionsDataGetResponse>}
   */
  transactionsDataGet(request2) {
    const ret = wasm2.wallet_transactionsDataGet(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsCommitRevealRequest} {@link IAccountsCommitRevealResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsCommitRevealRequest} request
   * @returns {Promise<IAccountsCommitRevealResponse>}
   */
  accountsCommitReveal(request2) {
    const ret = wasm2.wallet_accountsCommitReveal(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAddressBookEnumerateRequest} {@link IAddressBookEnumerateResponse}
   * @throws `string` in case of an error.
   * @param {IAddressBookEnumerateRequest} request
   * @returns {Promise<IAddressBookEnumerateResponse>}
   */
  addressBookEnumerate(request2) {
    const ret = wasm2.wallet_addressBookEnumerate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IFeeRatePollerEnableRequest} {@link IFeeRatePollerEnableResponse}
   * @throws `string` in case of an error.
   * @param {IFeeRatePollerEnableRequest} request
   * @returns {Promise<IFeeRatePollerEnableResponse>}
   */
  feeRatePollerEnable(request2) {
    const ret = wasm2.wallet_feeRatePollerEnable(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IPrvKeyDataEnumerateRequest} {@link IPrvKeyDataEnumerateResponse}
   * @throws `string` in case of an error.
   * @param {IPrvKeyDataEnumerateRequest} request
   * @returns {Promise<IPrvKeyDataEnumerateResponse>}
   */
  prvKeyDataEnumerate(request2) {
    const ret = wasm2.wallet_prvKeyDataEnumerate(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsEnsureDefaultRequest} {@link IAccountsEnsureDefaultResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsEnsureDefaultRequest} request
   * @returns {Promise<IAccountsEnsureDefaultResponse>}
   */
  accountsEnsureDefault(request2) {
    const ret = wasm2.wallet_accountsEnsureDefault(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsPskbBroadcastRequest} {@link IAccountsPskbBroadcastResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsPskbBroadcastRequest} request
   * @returns {Promise<IAccountsPskbBroadcastResponse>}
   */
  accountsPskbBroadcast(request2) {
    const ret = wasm2.wallet_accountsPskbBroadcast(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IFeeRatePollerDisableRequest} {@link IFeeRatePollerDisableResponse}
   * @throws `string` in case of an error.
   * @param {IFeeRatePollerDisableRequest} request
   * @returns {Promise<IFeeRatePollerDisableResponse>}
   */
  feeRatePollerDisable(request2) {
    const ret = wasm2.wallet_feeRatePollerDisable(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link ITransactionsReplaceNoteRequest} {@link ITransactionsReplaceNoteResponse}
   * @throws `string` in case of an error.
   * @param {ITransactionsReplaceNoteRequest} request
   * @returns {Promise<ITransactionsReplaceNoteResponse>}
   */
  transactionsReplaceNote(request2) {
    const ret = wasm2.wallet_transactionsReplaceNote(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsCreateNewAddressRequest} {@link IAccountsCreateNewAddressResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsCreateNewAddressRequest} request
   * @returns {Promise<IAccountsCreateNewAddressResponse>}
   */
  accountsCreateNewAddress(request2) {
    const ret = wasm2.wallet_accountsCreateNewAddress(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IAccountsCommitRevealManualRequest} {@link IAccountsCommitRevealManualResponse}
   * @throws `string` in case of an error.
   * @param {IAccountsCommitRevealManualRequest} request
   * @returns {Promise<IAccountsCommitRevealManualResponse>}
   */
  accountsCommitRevealManual(request2) {
    const ret = wasm2.wallet_accountsCommitRevealManual(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link ITransactionsReplaceMetadataRequest} {@link ITransactionsReplaceMetadataResponse}
   * @throws `string` in case of an error.
   * @param {ITransactionsReplaceMetadataRequest} request
   * @returns {Promise<ITransactionsReplaceMetadataResponse>}
   */
  transactionsReplaceMetadata(request2) {
    const ret = wasm2.wallet_transactionsReplaceMetadata(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * Ping backend
   * @see {@link IBatchRequest} {@link IBatchResponse}
   * @throws `string` in case of an error.
   * @param {IBatchRequest} request
   * @returns {Promise<IBatchResponse>}
   */
  batch(request2) {
    const ret = wasm2.wallet_batch(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
  /**
   * @see {@link IFlushRequest} {@link IFlushResponse}
   * @throws `string` in case of an error.
   * @param {IFlushRequest} request
   * @returns {Promise<IFlushResponse>}
   */
  flush(request2) {
    const ret = wasm2.wallet_flush(this.__wbg_ptr, addHeapObject(request2));
    return takeObject(ret);
  }
};
var WalletDescriptorFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_walletdescriptor_free(ptr >>> 0, 1));
var WalletDescriptor = class _WalletDescriptor {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_WalletDescriptor.prototype);
    obj.__wbg_ptr = ptr;
    WalletDescriptorFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      title: this.title,
      filename: this.filename
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    WalletDescriptorFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_walletdescriptor_free(ptr, 0);
  }
  /**
   * @returns {string | undefined}
   */
  get title() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.__wbg_get_walletdescriptor_title(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getStringFromWasm02(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 1, 1);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {string | null} [arg0]
   */
  set title(arg0) {
    var ptr0 = isLikeNone2(arg0) ? 0 : passStringToWasm02(arg0, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    var len0 = WASM_VECTOR_LEN2;
    wasm2.__wbg_set_walletdescriptor_title(this.__wbg_ptr, ptr0, len0);
  }
  /**
   * @returns {string}
   */
  get filename() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.__wbg_get_walletdescriptor_filename(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @param {string} arg0
   */
  set filename(arg0) {
    const ptr0 = passStringToWasm02(arg0, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len0 = WASM_VECTOR_LEN2;
    wasm2.__wbg_set_walletdescriptor_filename(this.__wbg_ptr, ptr0, len0);
  }
};
var WasiOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_wasioptions_free(ptr >>> 0, 1));
var WasiOptions = class _WasiOptions {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_WasiOptions.prototype);
    obj.__wbg_ptr = ptr;
    WasiOptionsFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    WasiOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_wasioptions_free(ptr, 0);
  }
  /**
   * @param {object} value
   */
  set preopens(value) {
    wasm2.wasioptions_set_preopens(this.__wbg_ptr, addHeapObject(value));
  }
  /**
   * @param {any[] | null | undefined} args
   * @param {object | null | undefined} env
   * @param {object} preopens
   */
  constructor(args, env, preopens) {
    var ptr0 = isLikeNone2(args) ? 0 : passArrayJsValueToWasm0(args, wasm2.__wbindgen_export_1);
    var len0 = WASM_VECTOR_LEN2;
    const ret = wasm2.wasioptions_new_with_values(ptr0, len0, isLikeNone2(env) ? 0 : addHeapObject(env), addHeapObject(preopens));
    this.__wbg_ptr = ret >>> 0;
    WasiOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {object | undefined}
   */
  get env() {
    const ret = wasm2.wasioptions_env(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {object} preopens
   * @returns {WasiOptions}
   */
  static new(preopens) {
    const ret = wasm2.wasioptions_new(addHeapObject(preopens));
    return _WasiOptions.__wrap(ret);
  }
  /**
   * @returns {any[] | undefined}
   */
  get args() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.wasioptions_args(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      let v1;
      if (r0 !== 0) {
        v1 = getArrayJsValueFromWasm0(r0, r1).slice();
        wasm2.__wbindgen_export_3(r0, r1 * 4, 4);
      }
      return v1;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {object | null} [value]
   */
  set env(value) {
    wasm2.wasioptions_set_env(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @returns {object}
   */
  get preopens() {
    const ret = wasm2.wasioptions_preopens(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {any[] | null} [value]
   */
  set args(value) {
    var ptr0 = isLikeNone2(value) ? 0 : passArrayJsValueToWasm0(value, wasm2.__wbindgen_export_1);
    var len0 = WASM_VECTOR_LEN2;
    wasm2.wasioptions_set_args(this.__wbg_ptr, ptr0, len0);
  }
};
var WriteFileSyncOptionsFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_writefilesyncoptions_free(ptr >>> 0, 1));
var WriteFileSyncOptions = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    WriteFileSyncOptionsFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_writefilesyncoptions_free(ptr, 0);
  }
  /**
   * @param {string | null} [value]
   */
  set encoding(value) {
    wasm2.writefilesyncoptions_set_encoding(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {string | null} [encoding]
   * @param {string | null} [flag]
   * @param {number | null} [mode]
   */
  constructor(encoding, flag, mode) {
    const ret = wasm2.writefilesyncoptions_new(isLikeNone2(encoding) ? 0 : addHeapObject(encoding), isLikeNone2(flag) ? 0 : addHeapObject(flag), isLikeNone2(mode) ? 4294967297 : mode >>> 0);
    this.__wbg_ptr = ret >>> 0;
    WriteFileSyncOptionsFinalization.register(this, this.__wbg_ptr, this);
    return this;
  }
  /**
   * @returns {string | undefined}
   */
  get flag() {
    const ret = wasm2.writefilesyncoptions_flag(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @returns {number | undefined}
   */
  get mode() {
    const ret = wasm2.writefilesyncoptions_mode(this.__wbg_ptr);
    return ret === 4294967297 ? void 0 : ret;
  }
  /**
   * @returns {string | undefined}
   */
  get encoding() {
    const ret = wasm2.writefilesyncoptions_encoding(this.__wbg_ptr);
    return takeObject(ret);
  }
  /**
   * @param {string | null} [value]
   */
  set flag(value) {
    wasm2.writefilesyncoptions_set_flag(this.__wbg_ptr, isLikeNone2(value) ? 0 : addHeapObject(value));
  }
  /**
   * @param {number | null} [value]
   */
  set mode(value) {
    wasm2.writefilesyncoptions_set_mode(this.__wbg_ptr, isLikeNone2(value) ? 4294967297 : value >>> 0);
  }
};
var WriteStreamFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_writestream_free(ptr >>> 0, 1));
var WriteStream = class {
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    WriteStreamFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_writestream_free(ptr, 0);
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  on_with_open(listener) {
    try {
      const ret = wasm2.writestream_on_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  on_with_close(listener) {
    try {
      const ret = wasm2.writestream_on_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  once_with_open(listener) {
    try {
      const ret = wasm2.writestream_once_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  once_with_close(listener) {
    try {
      const ret = wasm2.writestream_once_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  add_listener_with_open(listener) {
    try {
      const ret = wasm2.writestream_add_listener_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  add_listener_with_close(listener) {
    try {
      const ret = wasm2.writestream_add_listener_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  prepend_listener_with_open(listener) {
    try {
      const ret = wasm2.writestream_prepend_listener_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  prepend_listener_with_close(listener) {
    try {
      const ret = wasm2.writestream_prepend_listener_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  prepend_once_listener_with_open(listener) {
    try {
      const ret = wasm2.writestream_prepend_once_listener_with_open(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Function} listener
   * @returns {any}
   */
  prepend_once_listener_with_close(listener) {
    try {
      const ret = wasm2.writestream_prepend_once_listener_with_close(this.__wbg_ptr, addBorrowedObject(listener));
      return takeObject(ret);
    } finally {
      heap[stack_pointer++] = void 0;
    }
  }
};
var XOnlyPublicKeyFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_xonlypublickey_free(ptr >>> 0, 1));
var XOnlyPublicKey = class _XOnlyPublicKey {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_XOnlyPublicKey.prototype);
    obj.__wbg_ptr = ptr;
    XOnlyPublicKeyFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    XOnlyPublicKeyFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_xonlypublickey_free(ptr, 0);
  }
  /**
   * Get the [`Address`] of this XOnlyPublicKey.
   * Receives a [`NetworkType`] to determine the prefix of the address.
   * JavaScript: `let address = xOnlyPublicKey.toAddress(NetworkType.MAINNET);`.
   * @param {NetworkType | NetworkId | string} network
   * @returns {Address}
   */
  toAddress(network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xonlypublickey_toAddress(retptr, this.__wbg_ptr, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {Address} address
   * @returns {XOnlyPublicKey}
   */
  static fromAddress(address) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      _assertClass2(address, Address2);
      wasm2.xonlypublickey_fromAddress(retptr, address.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _XOnlyPublicKey.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xonlypublickey_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * Get `ECDSA` [`Address`] of this XOnlyPublicKey.
   * Receives a [`NetworkType`] to determine the prefix of the address.
   * JavaScript: `let address = xOnlyPublicKey.toAddress(NetworkType.MAINNET);`.
   * @param {NetworkType | NetworkId | string} network
   * @returns {Address}
   */
  toAddressECDSA(network) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xonlypublickey_toAddressECDSA(retptr, this.__wbg_ptr, addBorrowedObject(network));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return Address2.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {string} key
   */
  constructor(key2) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(key2, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.xonlypublickey_try_new(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      XOnlyPublicKeyFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
var XPrvFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_xprv_free(ptr >>> 0, 1));
var XPrv = class _XPrv {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_XPrv.prototype);
    obj.__wbg_ptr = ptr;
    XPrvFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      childNumber: this.childNumber,
      chainCode: this.chainCode,
      privateKey: this.privateKey,
      parentFingerprint: this.parentFingerprint,
      xprv: this.xprv,
      depth: this.depth
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    XPrvFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_xprv_free(ptr, 0);
  }
  /**
   * @param {any} path
   * @returns {XPrv}
   */
  derivePath(path) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_derivePath(retptr, this.__wbg_ptr, addBorrowedObject(path));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _XPrv.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @param {string} prefix
   * @returns {string}
   */
  intoString(prefix) {
    let deferred3_0;
    let deferred3_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(prefix, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.xprv_intoString(retptr, this.__wbg_ptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr2 = r0;
      var len2 = r1;
      if (r3) {
        ptr2 = 0;
        len2 = 0;
        throw takeObject(r2);
      }
      deferred3_0 = ptr2;
      deferred3_1 = len2;
      return getStringFromWasm02(ptr2, len2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred3_0, deferred3_1, 1);
    }
  }
  /**
   * @returns {number}
   */
  get childNumber() {
    const ret = wasm2.xprv_childNumber(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * @param {number} child_number
   * @param {boolean | null} [hardened]
   * @returns {XPrv}
   */
  deriveChild(child_number, hardened) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_deriveChild(retptr, this.__wbg_ptr, child_number, isLikeNone2(hardened) ? 16777215 : hardened ? 1 : 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _XPrv.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * Create {@link XPrv} from `xprvxxxx..` string
   * @param {string} xprv
   * @returns {XPrv}
   */
  static fromXPrv(xprv) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(xprv, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.xprv_fromXPrv(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _XPrv.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {PrivateKey}
   */
  toPrivateKey() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_toPrivateKey(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return PrivateKey.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  get chainCode() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_chainCode(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get privateKey() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_privateKey(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get parentFingerprint() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_parentFingerprint(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get xprv() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * @returns {number}
   */
  get depth() {
    const ret = wasm2.xprv_depth(this.__wbg_ptr);
    return ret;
  }
  /**
   * @returns {XPub}
   */
  toXPub() {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_toXPub(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return XPub.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @param {HexString} seed
   */
  constructor(seed) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_try_new(retptr, addHeapObject(seed));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      XPrvFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  toString() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xprv_toString(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
};
var XPubFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((ptr) => wasm2.__wbg_xpub_free(ptr >>> 0, 1));
var XPub = class _XPub {
  static __wrap(ptr) {
    ptr = ptr >>> 0;
    const obj = Object.create(_XPub.prototype);
    obj.__wbg_ptr = ptr;
    XPubFinalization.register(obj, obj.__wbg_ptr, obj);
    return obj;
  }
  toJSON() {
    return {
      childNumber: this.childNumber,
      chainCode: this.chainCode,
      parentFingerprint: this.parentFingerprint,
      xpub: this.xpub,
      depth: this.depth
    };
  }
  toString() {
    return JSON.stringify(this);
  }
  __destroy_into_raw() {
    const ptr = this.__wbg_ptr;
    this.__wbg_ptr = 0;
    XPubFinalization.unregister(this);
    return ptr;
  }
  free() {
    const ptr = this.__destroy_into_raw();
    wasm2.__wbg_xpub_free(ptr, 0);
  }
  /**
   * @returns {PublicKey}
   */
  toPublicKey() {
    const ret = wasm2.xpub_toPublicKey(this.__wbg_ptr);
    return PublicKey.__wrap(ret);
  }
  /**
   * @param {any} path
   * @returns {XPub}
   */
  derivePath(path) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xpub_derivePath(retptr, this.__wbg_ptr, addBorrowedObject(path));
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _XPub.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      heap[stack_pointer++] = void 0;
    }
  }
  /**
   * @returns {number}
   */
  get childNumber() {
    const ret = wasm2.xpub_childNumber(this.__wbg_ptr);
    return ret >>> 0;
  }
  /**
   * @param {number} child_number
   * @param {boolean | null} [hardened]
   * @returns {XPub}
   */
  deriveChild(child_number, hardened) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xpub_deriveChild(retptr, this.__wbg_ptr, child_number, isLikeNone2(hardened) ? 16777215 : hardened ? 1 : 0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      return _XPub.__wrap(r0);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
  /**
   * @returns {string}
   */
  get chainCode() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xpub_chainCode(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get parentFingerprint() {
    let deferred1_0;
    let deferred1_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xpub_parentFingerprint(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      deferred1_0 = r0;
      deferred1_1 = r1;
      return getStringFromWasm02(r0, r1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred1_0, deferred1_1, 1);
    }
  }
  /**
   * @returns {string}
   */
  get xpub() {
    let deferred2_0;
    let deferred2_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      wasm2.xpub_xpub(retptr, this.__wbg_ptr);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr1 = r0;
      var len1 = r1;
      if (r3) {
        ptr1 = 0;
        len1 = 0;
        throw takeObject(r2);
      }
      deferred2_0 = ptr1;
      deferred2_1 = len1;
      return getStringFromWasm02(ptr1, len1);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred2_0, deferred2_1, 1);
    }
  }
  /**
   * @returns {number}
   */
  get depth() {
    const ret = wasm2.xpub_depth(this.__wbg_ptr);
    return ret;
  }
  /**
   * @param {string} prefix
   * @returns {string}
   */
  intoString(prefix) {
    let deferred3_0;
    let deferred3_1;
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(prefix, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.xpub_intoString(retptr, this.__wbg_ptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      var r3 = getDataViewMemory02().getInt32(retptr + 4 * 3, true);
      var ptr2 = r0;
      var len2 = r1;
      if (r3) {
        ptr2 = 0;
        len2 = 0;
        throw takeObject(r2);
      }
      deferred3_0 = ptr2;
      deferred3_1 = len2;
      return getStringFromWasm02(ptr2, len2);
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
      wasm2.__wbindgen_export_3(deferred3_0, deferred3_1, 1);
    }
  }
  /**
   * @param {string} xpub
   */
  constructor(xpub) {
    try {
      const retptr = wasm2.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = passStringToWasm02(xpub, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len0 = WASM_VECTOR_LEN2;
      wasm2.xpub_try_new(retptr, ptr0, len0);
      var r0 = getDataViewMemory02().getInt32(retptr + 4 * 0, true);
      var r1 = getDataViewMemory02().getInt32(retptr + 4 * 1, true);
      var r2 = getDataViewMemory02().getInt32(retptr + 4 * 2, true);
      if (r2) {
        throw takeObject(r1);
      }
      this.__wbg_ptr = r0 >>> 0;
      XPubFinalization.register(this, this.__wbg_ptr, this);
      return this;
    } finally {
      wasm2.__wbindgen_add_to_stack_pointer(16);
    }
  }
};
async function __wbg_load2(module2, imports) {
  if (typeof Response === "function" && module2 instanceof Response) {
    if (typeof WebAssembly.instantiateStreaming === "function") {
      try {
        return await WebAssembly.instantiateStreaming(module2, imports);
      } catch (e) {
        if (module2.headers.get("Content-Type") != "application/wasm") {
          console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
        } else {
          throw e;
        }
      }
    }
    const bytes2 = await module2.arrayBuffer();
    return await WebAssembly.instantiate(bytes2, imports);
  } else {
    const instance = await WebAssembly.instantiate(module2, imports);
    if (instance instanceof WebAssembly.Instance) {
      return { instance, module: module2 };
    } else {
      return instance;
    }
  }
}
function __wbg_get_imports2() {
  const imports = {};
  imports.wbg = {};
  imports.wbg.__wbg_BigInt_470dd987b8190f8e = function(arg0) {
    const ret = BigInt(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_BigInt_ddea6d2f55558acb = function() {
    return handleError2(function(arg0) {
      const ret = BigInt(getObject(arg0));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_String_8f0eb39a4a4c2f66 = function(arg0, arg1) {
    const ret = String(getObject(arg1));
    const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len1 = WASM_VECTOR_LEN2;
    getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbg_Window_b0044ac7db258535 = function(arg0) {
    const ret = getObject(arg0).Window;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_WorkerGlobalScope_b74cefefc62a37da = function(arg0) {
    const ret = getObject(arg0).WorkerGlobalScope;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_abort_775ef1d17fc65868 = function(arg0) {
    getObject(arg0).abort();
  };
  imports.wbg.__wbg_aborted_new = function(arg0) {
    const ret = Aborted2.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_accountkind_new = function(arg0) {
    const ret = AccountKind.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_addListener_d78339dd4535b756 = function(arg0, arg1, arg2, arg3) {
    const ret = getObject(arg0).addListener(getStringFromWasm02(arg1, arg2), getObject(arg3));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_address_new = function(arg0) {
    const ret = Address2.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_advance_b3ccc91b80962d79 = function() {
    return handleError2(function(arg0, arg1) {
      getObject(arg0).advance(arg1 >>> 0);
    }, arguments);
  };
  imports.wbg.__wbg_appendChild_8204974b7328bf98 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = getObject(arg0).appendChild(getObject(arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_append_8c7dd8d641a5f01b = function() {
    return handleError2(function(arg0, arg1, arg2, arg3, arg4) {
      getObject(arg0).append(getStringFromWasm02(arg1, arg2), getStringFromWasm02(arg3, arg4));
    }, arguments);
  };
  imports.wbg.__wbg_body_942ea927546a04ba = function(arg0) {
    const ret = getObject(arg0).body;
    return isLikeNone2(ret) ? 0 : addHeapObject(ret);
  };
  imports.wbg.__wbg_buffer_609cc3eee51ed158 = function(arg0) {
    const ret = getObject(arg0).buffer;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_call_672a4d21634d4a24 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = getObject(arg0).call(getObject(arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_call_7cccdd69e0791ae2 = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).call(getObject(arg1), getObject(arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_cancelAnimationFrame_032049cb190240a7 = function(arg0) {
    cancelAnimationFrame(takeObject(arg0));
  };
  imports.wbg.__wbg_clearInterval_d472232e2fb5e5e4 = function() {
    return handleError2(function(arg0) {
      clearInterval(getObject(arg0));
    }, arguments);
  };
  imports.wbg.__wbg_clearTimeout_c5ac0f4b6a07b59e = function() {
    return handleError2(function(arg0) {
      clearTimeout(getObject(arg0));
    }, arguments);
  };
  imports.wbg.__wbg_close_0880036443561527 = function() {
    return handleError2(function(arg0) {
      getObject(arg0).close();
    }, arguments);
  };
  imports.wbg.__wbg_continue_c46c11d3dbe1b030 = function() {
    return handleError2(function(arg0) {
      getObject(arg0).continue();
    }, arguments);
  };
  imports.wbg.__wbg_count_613cb921d67a4f26 = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).count();
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_createElement_8c9931a732ee2fea = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).createElement(getStringFromWasm02(arg1, arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_createIndex_873ac48adc772309 = function() {
    return handleError2(function(arg0, arg1, arg2, arg3, arg4) {
      const ret = getObject(arg0).createIndex(getStringFromWasm02(arg1, arg2), getObject(arg3), getObject(arg4));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_createObjectStore_e566459f7161f82f = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).createObjectStore(getStringFromWasm02(arg1, arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_createObjectURL_6e98d2f9c7bd9764 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = URL.createObjectURL(getObject(arg1));
      const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len1 = WASM_VECTOR_LEN2;
      getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
    }, arguments);
  };
  imports.wbg.__wbg_crypto_ed58b8e10a292839 = function(arg0) {
    const ret = getObject(arg0).crypto;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_data_432d9c3df2630942 = function(arg0) {
    const ret = getObject(arg0).data;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_delete_200677093b4cf756 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = getObject(arg0).delete(getObject(arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_delete_36c8630e530a2a1a = function(arg0, arg1) {
    const ret = getObject(arg0).delete(getObject(arg1));
    return ret;
  };
  imports.wbg.__wbg_document_d249400bd7bd996d = function(arg0) {
    const ret = getObject(arg0).document;
    return isLikeNone2(ret) ? 0 : addHeapObject(ret);
  };
  imports.wbg.__wbg_done_769e5ede4b31c67b = function(arg0) {
    const ret = getObject(arg0).done;
    return ret;
  };
  imports.wbg.__wbg_entries_3265d4158b33e5dc = function(arg0) {
    const ret = Object.entries(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_entries_c8a90a7ed73e84ce = function(arg0) {
    const ret = getObject(arg0).entries();
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_error_5edc95999c70d386 = function(arg0, arg1) {
    let deferred0_0;
    let deferred0_1;
    try {
      deferred0_0 = arg0;
      deferred0_1 = arg1;
      console.error(getStringFromWasm02(arg0, arg1));
    } finally {
      wasm2.__wbindgen_export_3(deferred0_0, deferred0_1, 1);
    }
  };
  imports.wbg.__wbg_error_b5d62a6100a65a3b = function(arg0, arg1) {
    console.error(getStringFromWasm02(arg0, arg1));
  };
  imports.wbg.__wbg_error_ff4ddaabdfc5dbb3 = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).error;
      return isLikeNone2(ret) ? 0 : addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_existsSync_6b2031627aea3e5a = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).existsSync(getStringFromWasm02(arg1, arg2));
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_fetch_509096533071c657 = function(arg0, arg1) {
    const ret = getObject(arg0).fetch(getObject(arg1));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_fetch_7bb58c5ed3c31810 = function(arg0) {
    const ret = fetch(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_fromCodePoint_f37c25c172f2e8b5 = function() {
    return handleError2(function(arg0) {
      const ret = String.fromCodePoint(arg0 >>> 0);
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_from_2a5d3e218e67aa85 = function(arg0) {
    const ret = Array.from(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_from_d608a04300bfd9ac = function(arg0) {
    const ret = Buffer.from(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_generatorsummary_new = function(arg0) {
    const ret = GeneratorSummary.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_getItem_17f98dee3b43fa7e = function() {
    return handleError2(function(arg0, arg1, arg2, arg3) {
      const ret = getObject(arg1).getItem(getStringFromWasm02(arg2, arg3));
      var ptr1 = isLikeNone2(ret) ? 0 : passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      var len1 = WASM_VECTOR_LEN2;
      getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
    }, arguments);
  };
  imports.wbg.__wbg_getRandomValues_bcb4912f16000dc4 = function() {
    return handleError2(function(arg0, arg1) {
      getObject(arg0).getRandomValues(getObject(arg1));
    }, arguments);
  };
  imports.wbg.__wbg_get_13495dac72693ecc = function(arg0, arg1) {
    const ret = getObject(arg0).get(getObject(arg1));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_get_67b2ba62fc30de12 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = Reflect.get(getObject(arg0), getObject(arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_get_8da03f81f6a1111e = function() {
    return handleError2(function(arg0, arg1) {
      const ret = getObject(arg0).get(getObject(arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_get_a8e28596722a45ff = function() {
    return handleError2(function(arg0, arg1) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        const ret = chrome.storage.local.get(getStringFromWasm02(arg0, arg1));
        return addHeapObject(ret);
      } finally {
        wasm2.__wbindgen_export_3(deferred0_0, deferred0_1, 1);
      }
    }, arguments);
  };
  imports.wbg.__wbg_get_b9b93047fe3cf45b = function(arg0, arg1) {
    const ret = getObject(arg0)[arg1 >>> 0];
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_get_f1f75752f252b231 = function() {
    return handleError2(function() {
      const ret = chrome.storage.local.get();
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_getwithrefkey_1dc361bd10053bfe = function(arg0, arg1) {
    const ret = getObject(arg0)[getObject(arg1)];
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_global_b6f5c73312f62313 = function(arg0) {
    const ret = getObject(arg0).global;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_has_a5ea9117f258a0ec = function() {
    return handleError2(function(arg0, arg1) {
      const ret = Reflect.has(getObject(arg0), getObject(arg1));
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_hash_new = function(arg0) {
    const ret = Hash2.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_headers_9cb51cfd2ac780a4 = function(arg0) {
    const ret = getObject(arg0).headers;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_index_e00ca5fff206ee3e = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).index(getStringFromWasm02(arg1, arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_indexedDB_601ec26c63e333de = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).indexedDB;
      return isLikeNone2(ret) ? 0 : addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_indexedDB_b1f49280282046f8 = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).indexedDB;
      return isLikeNone2(ret) ? 0 : addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_indexedDB_f6b47b0dc333fd2f = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).indexedDB;
      return isLikeNone2(ret) ? 0 : addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_innerHTML_e1553352fe93921a = function(arg0, arg1) {
    const ret = getObject(arg1).innerHTML;
    const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len1 = WASM_VECTOR_LEN2;
    getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbg_instanceof_ArrayBuffer_e14585432e3737fc = function(arg0) {
    let result;
    try {
      result = getObject(arg0) instanceof ArrayBuffer;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  };
  imports.wbg.__wbg_instanceof_Map_f3469ce2244d2430 = function(arg0) {
    let result;
    try {
      result = getObject(arg0) instanceof Map;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  };
  imports.wbg.__wbg_instanceof_Object_7f2dcef8f78644a4 = function(arg0) {
    let result;
    try {
      result = getObject(arg0) instanceof Object;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  };
  imports.wbg.__wbg_instanceof_Response_f2cc20d9f7dfd644 = function(arg0) {
    let result;
    try {
      result = getObject(arg0) instanceof Response;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  };
  imports.wbg.__wbg_instanceof_Uint8Array_17156bcf118086a9 = function(arg0) {
    let result;
    try {
      result = getObject(arg0) instanceof Uint8Array;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  };
  imports.wbg.__wbg_instanceof_Window_def73ea0955fc569 = function(arg0) {
    let result;
    try {
      result = getObject(arg0) instanceof Window;
    } catch (_) {
      result = false;
    }
    const ret = result;
    return ret;
  };
  imports.wbg.__wbg_isArray_a1eab7e0d067391b = function(arg0) {
    const ret = Array.isArray(getObject(arg0));
    return ret;
  };
  imports.wbg.__wbg_isSafeInteger_343e2beeeece1bb0 = function(arg0) {
    const ret = Number.isSafeInteger(getObject(arg0));
    return ret;
  };
  imports.wbg.__wbg_is_c7481c65e7e5df9e = function(arg0, arg1) {
    const ret = Object.is(getObject(arg0), getObject(arg1));
    return ret;
  };
  imports.wbg.__wbg_iterator_9a24c88df860dc65 = function() {
    const ret = Symbol.iterator;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_key_c5e0a01cf450dca2 = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg1).key(arg2 >>> 0);
      var ptr1 = isLikeNone2(ret) ? 0 : passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      var len1 = WASM_VECTOR_LEN2;
      getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
    }, arguments);
  };
  imports.wbg.__wbg_keys_5c77a08ddc2fb8a6 = function(arg0) {
    const ret = Object.keys(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_length_a446193dc22c12f8 = function(arg0) {
    const ret = getObject(arg0).length;
    return ret;
  };
  imports.wbg.__wbg_length_e2d2a49132c1b256 = function(arg0) {
    const ret = getObject(arg0).length;
    return ret;
  };
  imports.wbg.__wbg_length_ed4a84b02b798bda = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).length;
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_localStorage_1406c99c39728187 = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).localStorage;
      return isLikeNone2(ret) ? 0 : addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_location_350d99456c2f3693 = function(arg0) {
    const ret = getObject(arg0).location;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_log_6c164928aa7b57f4 = function(arg0, arg1) {
    console.log(getStringFromWasm02(arg0, arg1));
  };
  imports.wbg.__wbg_mkdirSync_29d1fd92bf140bd0 = function() {
    return handleError2(function(arg0, arg1, arg2, arg3) {
      getObject(arg0).mkdirSync(getStringFromWasm02(arg1, arg2), takeObject(arg3));
    }, arguments);
  };
  imports.wbg.__wbg_msCrypto_0a36e2ec3a343d26 = function(arg0) {
    const ret = getObject(arg0).msCrypto;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_navigator_1577371c070c8947 = function(arg0) {
    const ret = getObject(arg0).navigator;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_networkid_new = function(arg0) {
    const ret = NetworkId2.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_new0_f788a2397c7ca929 = function() {
    const ret = /* @__PURE__ */ new Date();
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_new_018dcc2d6c8c2f6a = function() {
    return handleError2(function() {
      const ret = new Headers();
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_new_0b790fd655ff1a97 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = new WebSocket(getStringFromWasm02(arg0, arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_new_23a2665fac83c611 = function(arg0, arg1) {
    try {
      var state0 = { a: arg0, b: arg1 };
      var cb0 = (arg02, arg12) => {
        const a = state0.a;
        state0.a = 0;
        try {
          return __wbg_adapter_161(a, state0.b, arg02, arg12);
        } finally {
          state0.a = a;
        }
      };
      const ret = new Promise(cb0);
      return addHeapObject(ret);
    } finally {
      state0.a = state0.b = 0;
    }
  };
  imports.wbg.__wbg_new_405e22f390576ce2 = function() {
    const ret = new Object();
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_new_5e0be73521bc8c17 = function() {
    const ret = /* @__PURE__ */ new Map();
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_new_757fd34d47ff40d2 = function(arg0) {
    const ret = new ArrayBuffer(arg0 >>> 0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_new_78feb108b6472713 = function() {
    const ret = new Array();
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_new_a12002a7f91c75be = function(arg0) {
    const ret = new Uint8Array(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_new_b1a33e5095abf678 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = new Worker(getStringFromWasm02(arg0, arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_new_e25e5aab09ff45db = function() {
    return handleError2(function() {
      const ret = new AbortController();
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_new_f5f8a7325e1cb479 = function() {
    const ret = new Error();
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_newnoargs_105ed471475aaf50 = function(arg0, arg1) {
    const ret = new Function(getStringFromWasm02(arg0, arg1));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_newwithbyteoffsetandlength_d97e637ebe145a9a = function(arg0, arg1, arg2) {
    const ret = new Uint8Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_newwithlength_a381634e90c276d4 = function(arg0) {
    const ret = new Uint8Array(arg0 >>> 0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_newwithnodejsconfigimpl_b0a2d4e5b0763676 = function() {
    return handleError2(function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
      const ret = new WebSocket(getStringFromWasm02(arg0, arg1), takeObject(arg2), takeObject(arg3), takeObject(arg4), takeObject(arg5), takeObject(arg6));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_newwithstrandinit_06c535e0a867c635 = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = new Request(getStringFromWasm02(arg0, arg1), getObject(arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_newwithstrsequenceandoptions_aaff55b467c81b63 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = new Blob(getObject(arg0), getObject(arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_next_25feadfc0913fea9 = function(arg0) {
    const ret = getObject(arg0).next;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_next_6574e1a8a62d1055 = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).next();
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_node_02999533c4ea02e3 = function(arg0) {
    const ret = getObject(arg0).node;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_nodedescriptor_new = function(arg0) {
    const ret = NodeDescriptor.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_now_807e54c39636c349 = function() {
    const ret = Date.now();
    return ret;
  };
  imports.wbg.__wbg_now_d18023d54d4e5500 = function(arg0) {
    const ret = getObject(arg0).now();
    return ret;
  };
  imports.wbg.__wbg_objectStore_21878d46d25b64b6 = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).objectStore(getStringFromWasm02(arg1, arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_oldVersion_e8337811e52861c6 = function(arg0) {
    const ret = getObject(arg0).oldVersion;
    return ret;
  };
  imports.wbg.__wbg_on_9ef8de87725b93b5 = function(arg0, arg1, arg2, arg3) {
    const ret = getObject(arg0).on(getStringFromWasm02(arg1, arg2), getObject(arg3));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_once_8901720a31f56808 = function(arg0, arg1, arg2, arg3) {
    const ret = getObject(arg0).once(getStringFromWasm02(arg1, arg2), getObject(arg3));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_openCursor_d8ea5d621ec422f8 = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).openCursor(getObject(arg1), __wbindgen_enum_IdbCursorDirection[arg2]);
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_open_e0c0b2993eb596e1 = function() {
    return handleError2(function(arg0, arg1, arg2, arg3) {
      const ret = getObject(arg0).open(getStringFromWasm02(arg1, arg2), arg3 >>> 0);
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_optionalheader_new = function(arg0) {
    const ret = OptionalHeader.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_pendingtransaction_new = function(arg0) {
    const ret = PendingTransaction.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_postMessage_6edafa8f7b9c2f52 = function() {
    return handleError2(function(arg0, arg1) {
      getObject(arg0).postMessage(getObject(arg1));
    }, arguments);
  };
  imports.wbg.__wbg_prependListener_dc1e8b094d0f731e = function(arg0, arg1, arg2, arg3) {
    const ret = getObject(arg0).prependListener(getStringFromWasm02(arg1, arg2), getObject(arg3));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_prependOnceListener_93873dc17dd2fcad = function(arg0, arg1, arg2, arg3) {
    const ret = getObject(arg0).prependOnceListener(getStringFromWasm02(arg1, arg2), getObject(arg3));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_process_5c1d670bc53614b8 = function(arg0) {
    const ret = getObject(arg0).process;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_protocol_faa0494a9b2554cb = function() {
    return handleError2(function(arg0, arg1) {
      const ret = getObject(arg1).protocol;
      const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len1 = WASM_VECTOR_LEN2;
      getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
    }, arguments);
  };
  imports.wbg.__wbg_publickey_new = function(arg0) {
    const ret = PublicKey.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_push_737cfc8c1432c2c6 = function(arg0, arg1) {
    const ret = getObject(arg0).push(getObject(arg1));
    return ret;
  };
  imports.wbg.__wbg_put_066faa31a6a88f5b = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).put(getObject(arg1), getObject(arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_queueMicrotask_97d92b4fcc8a61c5 = function(arg0) {
    queueMicrotask(getObject(arg0));
  };
  imports.wbg.__wbg_queueMicrotask_d3219def82552485 = function(arg0) {
    const ret = getObject(arg0).queueMicrotask;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_randomFillSync_ab2cfe79ebbf2740 = function() {
    return handleError2(function(arg0, arg1) {
      getObject(arg0).randomFillSync(takeObject(arg1));
    }, arguments);
  };
  imports.wbg.__wbg_readFileSync_42b340d959241f2b = function() {
    return handleError2(function(arg0, arg1, arg2, arg3) {
      const ret = getObject(arg0).readFileSync(getStringFromWasm02(arg1, arg2), takeObject(arg3));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_readdir_319d9b13a44c9af9 = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).readdir(getStringFromWasm02(arg1, arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_readyState_4013cfdf4f22afb0 = function(arg0) {
    const ret = getObject(arg0).readyState;
    return (__wbindgen_enum_IdbRequestReadyState.indexOf(ret) + 1 || 3) - 1;
  };
  imports.wbg.__wbg_readyState_6c28968f3e6c1e47 = function(arg0) {
    const ret = getObject(arg0).readyState;
    return ret;
  };
  imports.wbg.__wbg_removeAttribute_e419cd6726b4c62f = function() {
    return handleError2(function(arg0, arg1, arg2) {
      getObject(arg0).removeAttribute(getStringFromWasm02(arg1, arg2));
    }, arguments);
  };
  imports.wbg.__wbg_removeItem_9d2669ee3bba6f7d = function() {
    return handleError2(function(arg0, arg1, arg2) {
      getObject(arg0).removeItem(getStringFromWasm02(arg1, arg2));
    }, arguments);
  };
  imports.wbg.__wbg_remove_cb9af65ab98197c5 = function() {
    return handleError2(function(arg0, arg1) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        const ret = chrome.storage.local.remove(getStringFromWasm02(arg0, arg1));
        return addHeapObject(ret);
      } finally {
        wasm2.__wbindgen_export_3(deferred0_0, deferred0_1, 1);
      }
    }, arguments);
  };
  imports.wbg.__wbg_renameSync_86e78b84a05e4a0b = function() {
    return handleError2(function(arg0, arg1, arg2, arg3, arg4) {
      getObject(arg0).renameSync(getStringFromWasm02(arg1, arg2), getStringFromWasm02(arg3, arg4));
    }, arguments);
  };
  imports.wbg.__wbg_requestAnimationFrame_63a812187303a02c = function(arg0) {
    const ret = requestAnimationFrame(takeObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_require_05f2f70e92254dbb = function(arg0, arg1) {
    const ret = __require(getStringFromWasm02(arg0, arg1));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_require_11fc9008c54f5b90 = function(arg0, arg1) {
    const ret = __require(getStringFromWasm02(arg0, arg1));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_require_79b1e9274cde3c87 = function() {
    return handleError2(function() {
      const ret = module.require;
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_resolve_4851785c9c5f573d = function(arg0) {
    const ret = Promise.resolve(getObject(arg0));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_result_f29afabdf2c05826 = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).result;
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_rpcclient_new = function(arg0) {
    const ret = RpcClient.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_send_17f8c8c8e084cc5e = function() {
    return handleError2(function(arg0, arg1, arg2) {
      getObject(arg0).send(getArrayU8FromWasm0(arg1, arg2));
    }, arguments);
  };
  imports.wbg.__wbg_send_9a57107cc0d7eafa = function() {
    return handleError2(function(arg0, arg1, arg2) {
      getObject(arg0).send(getStringFromWasm02(arg1, arg2));
    }, arguments);
  };
  imports.wbg.__wbg_send_afb0c27f2d9698e3 = function() {
    return handleError2(function(arg0, arg1) {
      getObject(arg0).send(getObject(arg1));
    }, arguments);
  };
  imports.wbg.__wbg_setAttribute_2704501201f15687 = function() {
    return handleError2(function(arg0, arg1, arg2, arg3, arg4) {
      getObject(arg0).setAttribute(getStringFromWasm02(arg1, arg2), getStringFromWasm02(arg3, arg4));
    }, arguments);
  };
  imports.wbg.__wbg_setInterval_160c4baec24e25f6 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = setInterval(getObject(arg0), arg1 >>> 0);
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_setItem_212ecc915942ab0a = function() {
    return handleError2(function(arg0, arg1, arg2, arg3, arg4) {
      getObject(arg0).setItem(getStringFromWasm02(arg1, arg2), getStringFromWasm02(arg3, arg4));
    }, arguments);
  };
  imports.wbg.__wbg_setTime_8afa2faa26e7eb59 = function(arg0, arg1) {
    const ret = getObject(arg0).setTime(arg1);
    return ret;
  };
  imports.wbg.__wbg_setTimeout_430dd4984e76f6c3 = function() {
    return handleError2(function(arg0, arg1) {
      const ret = setTimeout(getObject(arg0), arg1 >>> 0);
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_set_005c36bbcfafb768 = function() {
    return handleError2(function(arg0) {
      const ret = chrome.storage.local.set(takeObject(arg0));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_set_37837023f3d740e8 = function(arg0, arg1, arg2) {
    getObject(arg0)[arg1 >>> 0] = takeObject(arg2);
  };
  imports.wbg.__wbg_set_3f1d0b984ed272ed = function(arg0, arg1, arg2) {
    getObject(arg0)[takeObject(arg1)] = takeObject(arg2);
  };
  imports.wbg.__wbg_set_65595bdd868b3009 = function(arg0, arg1, arg2) {
    getObject(arg0).set(getObject(arg1), arg2 >>> 0);
  };
  imports.wbg.__wbg_set_8fc6bf8a5b1071d1 = function(arg0, arg1, arg2) {
    const ret = getObject(arg0).set(getObject(arg1), getObject(arg2));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_set_bb8cecf6a62b9f46 = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = Reflect.set(getObject(arg0), getObject(arg1), getObject(arg2));
      return ret;
    }, arguments);
  };
  imports.wbg.__wbg_setbinaryType_9981a6ba2bd58b94 = function(arg0, arg1) {
    getObject(arg0).binaryType = __wbindgen_enum_BinaryType[arg1];
  };
  imports.wbg.__wbg_setbody_5923b78a95eedf29 = function(arg0, arg1) {
    getObject(arg0).body = getObject(arg1);
  };
  imports.wbg.__wbg_setcredentials_c3a22f1cd105a2c6 = function(arg0, arg1) {
    getObject(arg0).credentials = __wbindgen_enum_RequestCredentials[arg1];
  };
  imports.wbg.__wbg_setheaders_834c0bdb6a8949ad = function(arg0, arg1) {
    getObject(arg0).headers = getObject(arg1);
  };
  imports.wbg.__wbg_setinnerHTML_31bde41f835786f7 = function(arg0, arg1, arg2) {
    getObject(arg0).innerHTML = getStringFromWasm02(arg1, arg2);
  };
  imports.wbg.__wbg_setmethod_3c5280fe5d890842 = function(arg0, arg1, arg2) {
    getObject(arg0).method = getStringFromWasm02(arg1, arg2);
  };
  imports.wbg.__wbg_setmode_5dc300b865044b65 = function(arg0, arg1) {
    getObject(arg0).mode = __wbindgen_enum_RequestMode[arg1];
  };
  imports.wbg.__wbg_setonabort_3bf4db6614fa98e9 = function(arg0, arg1) {
    getObject(arg0).onabort = getObject(arg1);
  };
  imports.wbg.__wbg_setonblocked_aebf64bd39f1eca8 = function(arg0, arg1) {
    getObject(arg0).onblocked = getObject(arg1);
  };
  imports.wbg.__wbg_setonclose_b15bdabd419b6357 = function(arg0, arg1) {
    getObject(arg0).onclose = getObject(arg1);
  };
  imports.wbg.__wbg_setoncomplete_4d19df0dadb7c4d4 = function(arg0, arg1) {
    getObject(arg0).oncomplete = getObject(arg1);
  };
  imports.wbg.__wbg_setonerror_b0d9d723b8fddbbb = function(arg0, arg1) {
    getObject(arg0).onerror = getObject(arg1);
  };
  imports.wbg.__wbg_setonerror_d7e3056cc6e56085 = function(arg0, arg1) {
    getObject(arg0).onerror = getObject(arg1);
  };
  imports.wbg.__wbg_setonerror_e2c5c0fa6fbf6d99 = function(arg0, arg1) {
    getObject(arg0).onerror = getObject(arg1);
  };
  imports.wbg.__wbg_setonmessage_007594843a0b97e8 = function(arg0, arg1) {
    getObject(arg0).onmessage = getObject(arg1);
  };
  imports.wbg.__wbg_setonmessage_5a885b16bdc6dca6 = function(arg0, arg1) {
    getObject(arg0).onmessage = getObject(arg1);
  };
  imports.wbg.__wbg_setonopen_c42cfdbb28b087c4 = function(arg0, arg1) {
    getObject(arg0).onopen = getObject(arg1);
  };
  imports.wbg.__wbg_setonsuccess_afa464ee777a396d = function(arg0, arg1) {
    getObject(arg0).onsuccess = getObject(arg1);
  };
  imports.wbg.__wbg_setonupgradeneeded_fcf7ce4f2eb0cb5f = function(arg0, arg1) {
    getObject(arg0).onupgradeneeded = getObject(arg1);
  };
  imports.wbg.__wbg_setonversionchange_6ee07fa49ee1e3a5 = function(arg0, arg1) {
    getObject(arg0).onversionchange = getObject(arg1);
  };
  imports.wbg.__wbg_setsignal_75b21ef3a81de905 = function(arg0, arg1) {
    getObject(arg0).signal = getObject(arg1);
  };
  imports.wbg.__wbg_settype_39ed370d3edd403c = function(arg0, arg1, arg2) {
    getObject(arg0).type = getStringFromWasm02(arg1, arg2);
  };
  imports.wbg.__wbg_setunique_dd24c422aa05df89 = function(arg0, arg1) {
    getObject(arg0).unique = arg1 !== 0;
  };
  imports.wbg.__wbg_signal_aaf9ad74119f20a4 = function(arg0) {
    const ret = getObject(arg0).signal;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_stack_c99a96ed42647c4c = function(arg0, arg1) {
    const ret = getObject(arg1).stack;
    const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len1 = WASM_VECTOR_LEN2;
    getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbg_statSync_9a429acc496bafda = function() {
    return handleError2(function(arg0, arg1, arg2) {
      const ret = getObject(arg0).statSync(getStringFromWasm02(arg1, arg2));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_static_accessor_GLOBAL_88a902d13a557d07 = function() {
    const ret = typeof global === "undefined" ? null : global;
    return isLikeNone2(ret) ? 0 : addHeapObject(ret);
  };
  imports.wbg.__wbg_static_accessor_GLOBAL_THIS_56578be7e9f832b0 = function() {
    const ret = typeof globalThis === "undefined" ? null : globalThis;
    return isLikeNone2(ret) ? 0 : addHeapObject(ret);
  };
  imports.wbg.__wbg_static_accessor_SELF_37c5d418e4bf5819 = function() {
    const ret = typeof self === "undefined" ? null : self;
    return isLikeNone2(ret) ? 0 : addHeapObject(ret);
  };
  imports.wbg.__wbg_static_accessor_WINDOW_5de37043a91a9c40 = function() {
    const ret = typeof window === "undefined" ? null : window;
    return isLikeNone2(ret) ? 0 : addHeapObject(ret);
  };
  imports.wbg.__wbg_status_f6360336ca686bf0 = function(arg0) {
    const ret = getObject(arg0).status;
    return ret;
  };
  imports.wbg.__wbg_stringify_f7ed6987935b4a24 = function() {
    return handleError2(function(arg0) {
      const ret = JSON.stringify(getObject(arg0));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_subarray_aa9065fa9dc5df96 = function(arg0, arg1, arg2) {
    const ret = getObject(arg0).subarray(arg1 >>> 0, arg2 >>> 0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_target_0a62d9d79a2a1ede = function(arg0) {
    const ret = getObject(arg0).target;
    return isLikeNone2(ret) ? 0 : addHeapObject(ret);
  };
  imports.wbg.__wbg_text_7805bea50de2af49 = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).text();
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_then_44b73946d2fb3e7d = function(arg0, arg1) {
    const ret = getObject(arg0).then(getObject(arg1));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_then_48b406749878a531 = function(arg0, arg1, arg2) {
    const ret = getObject(arg0).then(getObject(arg1), getObject(arg2));
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_toString_2f76f493957b63da = function(arg0, arg1, arg2) {
    const ret = getObject(arg1).toString(arg2);
    const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len1 = WASM_VECTOR_LEN2;
    getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbg_toString_b5d4438bc26b267c = function() {
    return handleError2(function(arg0, arg1) {
      const ret = getObject(arg0).toString(arg1);
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_transaction_babc423936946a37 = function() {
    return handleError2(function(arg0, arg1, arg2, arg3) {
      const ret = getObject(arg0).transaction(getStringFromWasm02(arg1, arg2), __wbindgen_enum_IdbTransactionMode[arg3]);
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_transaction_new = function(arg0) {
    const ret = Transaction.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_transactioninput_new = function(arg0) {
    const ret = TransactionInput.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_transactionoutput_new = function(arg0) {
    const ret = TransactionOutput.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_transactionrecordnotification_new = function(arg0) {
    const ret = TransactionRecordNotification.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_unlinkSync_656392e8d747415f = function() {
    return handleError2(function(arg0, arg1, arg2) {
      getObject(arg0).unlinkSync(getStringFromWasm02(arg1, arg2));
    }, arguments);
  };
  imports.wbg.__wbg_update_acd72607f506872a = function() {
    return handleError2(function(arg0, arg1) {
      const ret = getObject(arg0).update(getObject(arg1));
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_url_ae10c34ca209681d = function(arg0, arg1) {
    const ret = getObject(arg1).url;
    const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len1 = WASM_VECTOR_LEN2;
    getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbg_userAgent_12e9d8e62297563f = function() {
    return handleError2(function(arg0, arg1) {
      const ret = getObject(arg1).userAgent;
      const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
      const len1 = WASM_VECTOR_LEN2;
      getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
    }, arguments);
  };
  imports.wbg.__wbg_utxoentryreference_new = function(arg0) {
    const ret = UtxoEntryReference.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_value_68c4e9a54bb7fd5e = function() {
    return handleError2(function(arg0) {
      const ret = getObject(arg0).value;
      return addHeapObject(ret);
    }, arguments);
  };
  imports.wbg.__wbg_value_cd1ffa7b1ab794f1 = function(arg0) {
    const ret = getObject(arg0).value;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_versions_c71aa1626a93e0a1 = function(arg0) {
    const ret = getObject(arg0).versions;
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_walletdescriptor_new = function(arg0) {
    const ret = WalletDescriptor.__wrap(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbg_warn_28319e260c89a4f8 = function(arg0, arg1) {
    console.warn(getStringFromWasm02(arg0, arg1));
  };
  imports.wbg.__wbg_writeFileSync_6325b339950ab342 = function() {
    return handleError2(function(arg0, arg1, arg2, arg3, arg4) {
      getObject(arg0).writeFileSync(getStringFromWasm02(arg1, arg2), takeObject(arg3), takeObject(arg4));
    }, arguments);
  };
  imports.wbg.__wbindgen_array_new = function() {
    const ret = [];
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_array_push = function(arg0, arg1) {
    getObject(arg0).push(takeObject(arg1));
  };
  imports.wbg.__wbindgen_as_number = function(arg0) {
    const ret = +getObject(arg0);
    return ret;
  };
  imports.wbg.__wbindgen_bigint_from_i64 = function(arg0) {
    const ret = arg0;
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_bigint_from_u64 = function(arg0) {
    const ret = BigInt.asUintN(64, arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_bigint_get_as_i64 = function(arg0, arg1) {
    const v = getObject(arg1);
    const ret = typeof v === "bigint" ? v : void 0;
    getDataViewMemory02().setBigInt64(arg0 + 8 * 1, isLikeNone2(ret) ? BigInt(0) : ret, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, !isLikeNone2(ret), true);
  };
  imports.wbg.__wbindgen_boolean_get = function(arg0) {
    const v = getObject(arg0);
    const ret = typeof v === "boolean" ? v ? 1 : 0 : 2;
    return ret;
  };
  imports.wbg.__wbindgen_cb_drop = function(arg0) {
    const obj = takeObject(arg0).original;
    if (obj.cnt-- == 1) {
      obj.a = 0;
      return true;
    }
    const ret = false;
    return ret;
  };
  imports.wbg.__wbindgen_closure_wrapper1063 = function(arg0, arg1, arg2) {
    const ret = makeClosure(arg0, arg1, 314, __wbg_adapter_69);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper1065 = function(arg0, arg1, arg2) {
    const ret = makeClosure(arg0, arg1, 314, __wbg_adapter_72);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper17871 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 6960, __wbg_adapter_78);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper18568 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 6973, __wbg_adapter_81);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper18570 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 6973, __wbg_adapter_84);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper18572 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 6973, __wbg_adapter_87);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper18995 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 7090, __wbg_adapter_90);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper18996 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 7090, __wbg_adapter_90);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper4766 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 989, __wbg_adapter_75);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_closure_wrapper924 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 254, __wbg_adapter_66);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_debug_string = function(arg0, arg1) {
    const ret = debugString2(getObject(arg1));
    const ptr1 = passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    const len1 = WASM_VECTOR_LEN2;
    getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbindgen_error_new = function(arg0, arg1) {
    const ret = new Error(getStringFromWasm02(arg0, arg1));
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_in = function(arg0, arg1) {
    const ret = getObject(arg0) in getObject(arg1);
    return ret;
  };
  imports.wbg.__wbindgen_is_array = function(arg0) {
    const ret = Array.isArray(getObject(arg0));
    return ret;
  };
  imports.wbg.__wbindgen_is_bigint = function(arg0) {
    const ret = typeof getObject(arg0) === "bigint";
    return ret;
  };
  imports.wbg.__wbindgen_is_falsy = function(arg0) {
    const ret = !getObject(arg0);
    return ret;
  };
  imports.wbg.__wbindgen_is_function = function(arg0) {
    const ret = typeof getObject(arg0) === "function";
    return ret;
  };
  imports.wbg.__wbindgen_is_null = function(arg0) {
    const ret = getObject(arg0) === null;
    return ret;
  };
  imports.wbg.__wbindgen_is_object = function(arg0) {
    const val = getObject(arg0);
    const ret = typeof val === "object" && val !== null;
    return ret;
  };
  imports.wbg.__wbindgen_is_string = function(arg0) {
    const ret = typeof getObject(arg0) === "string";
    return ret;
  };
  imports.wbg.__wbindgen_is_undefined = function(arg0) {
    const ret = getObject(arg0) === void 0;
    return ret;
  };
  imports.wbg.__wbindgen_jsval_eq = function(arg0, arg1) {
    const ret = getObject(arg0) === getObject(arg1);
    return ret;
  };
  imports.wbg.__wbindgen_jsval_loose_eq = function(arg0, arg1) {
    const ret = getObject(arg0) == getObject(arg1);
    return ret;
  };
  imports.wbg.__wbindgen_lt = function(arg0, arg1) {
    const ret = getObject(arg0) < getObject(arg1);
    return ret;
  };
  imports.wbg.__wbindgen_memory = function() {
    const ret = wasm2.memory;
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_neg = function(arg0) {
    const ret = -getObject(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_number_get = function(arg0, arg1) {
    const obj = getObject(arg1);
    const ret = typeof obj === "number" ? obj : void 0;
    getDataViewMemory02().setFloat64(arg0 + 8 * 1, isLikeNone2(ret) ? 0 : ret, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, !isLikeNone2(ret), true);
  };
  imports.wbg.__wbindgen_number_new = function(arg0) {
    const ret = arg0;
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_object_clone_ref = function(arg0) {
    const ret = getObject(arg0);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_object_drop_ref = function(arg0) {
    takeObject(arg0);
  };
  imports.wbg.__wbindgen_string_get = function(arg0, arg1) {
    const obj = getObject(arg1);
    const ret = typeof obj === "string" ? obj : void 0;
    var ptr1 = isLikeNone2(ret) ? 0 : passStringToWasm02(ret, wasm2.__wbindgen_export_1, wasm2.__wbindgen_export_2);
    var len1 = WASM_VECTOR_LEN2;
    getDataViewMemory02().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory02().setInt32(arg0 + 4 * 0, ptr1, true);
  };
  imports.wbg.__wbindgen_string_new = function(arg0, arg1) {
    const ret = getStringFromWasm02(arg0, arg1);
    return addHeapObject(ret);
  };
  imports.wbg.__wbindgen_throw = function(arg0, arg1) {
    throw new Error(getStringFromWasm02(arg0, arg1));
  };
  imports.wbg.__wbindgen_try_into_number = function(arg0) {
    let result;
    try {
      result = +getObject(arg0);
    } catch (e) {
      result = e;
    }
    const ret = result;
    return addHeapObject(ret);
  };
  return imports;
}
function __wbg_init_memory2(imports, memory) {
}
function __wbg_finalize_init2(instance, module2) {
  wasm2 = instance.exports;
  __wbg_init2.__wbindgen_wasm_module = module2;
  cachedDataViewMemory02 = null;
  cachedUint8ArrayMemory02 = null;
  return wasm2;
}
function initSync2(module2) {
  if (wasm2 !== void 0) return wasm2;
  if (typeof module2 !== "undefined") {
    if (Object.getPrototypeOf(module2) === Object.prototype) {
      ({ module: module2 } = module2);
    } else {
      console.warn("using deprecated parameters for `initSync()`; pass a single object instead");
    }
  }
  const imports = __wbg_get_imports2();
  __wbg_init_memory2(imports);
  if (!(module2 instanceof WebAssembly.Module)) {
    module2 = new WebAssembly.Module(module2);
  }
  const instance = new WebAssembly.Instance(module2, imports);
  return __wbg_finalize_init2(instance, module2);
}
async function __wbg_init2(module_or_path) {
  if (wasm2 !== void 0) return wasm2;
  if (typeof module_or_path !== "undefined") {
    if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
      ({ module_or_path } = module_or_path);
    } else {
      console.warn("using deprecated parameters for the initialization function; pass a single object instead");
    }
  }
  if (typeof module_or_path === "undefined") {
    module_or_path = new URL("kaspa_bg.wasm", import.meta.url);
  }
  const imports = __wbg_get_imports2();
  if (typeof module_or_path === "string" || typeof Request === "function" && module_or_path instanceof Request || typeof URL === "function" && module_or_path instanceof URL) {
    module_or_path = fetch(module_or_path);
  }
  __wbg_init_memory2(imports);
  const { instance, module: module2 } = await __wbg_load2(await module_or_path, imports);
  return __wbg_finalize_init2(instance, module2);
}
var kaspa_default = __wbg_init2;

// node_modules/@kronsdk/kron-sdk/dist/wasm/index.browser.js
var ready = null;
var WASM_LOAD_TIMEOUT_MS = 3e4;
function withTimeout(p, ms, what) {
  return Promise.race([
    p,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${what} timed out after ${ms / 1e3}s`)), ms))
  ]);
}
function loadKaspa(wasmUrl) {
  if (!ready) {
    ready = (async () => {
      try {
        const url = wasmUrl ?? new URL("../../vendor/kaspa/kaspa_bg.wasm", import.meta.url);
        await withTimeout(kaspa_default({ module_or_path: url }), WASM_LOAD_TIMEOUT_MS, "Kaspa WASM SDK load");
        return kaspa_exports;
      } catch (err) {
        ready = null;
        throw new Error(`Couldn't load the Kaspa WASM SDK (browser): ${err?.message ?? err}. Check your connection and retry.`);
      }
    })();
  }
  return ready;
}

// src/background/evm.ts
function evmConfig(network) {
  if (network === "kasplex") return { name: "Kasplex zkEVM", chainId: 202555, rpc: "https://evmrpc.kasplex.org", explorerApi: "https://api-explorer2.kasplex.org/api/v2", nativeSymbol: "KAS", wrapped: "0x2c2Ae87Ba178F48637acAe54B87c3924F544a83e" };
  if (network === "igra") return { name: "Igra Network", chainId: 38833, rpc: "https://rpc.igralabs.com:8545", explorerApi: "https://explorer.igralabs.com/api/v2", nativeSymbol: "iKAS", wrapped: "0x17Ec7E1768c813E2a3a9b0f94A35605CA520C242" };
  throw new Error("The selected network is not EVM compatible.");
}
var rpcId = 0;
async function evmRpc(network, method, params = []) {
  const config = evmConfig(network), controller = new AbortController(), timer = setTimeout(() => controller.abort(), 12e3);
  try {
    const response = await fetch(config.rpc, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: ++rpcId, method, params }), signal: controller.signal });
    if (!response.ok) throw new Error(`${config.name} RPC returned HTTP ${response.status}.`);
    const decoded = await response.json();
    if (decoded.error) throw new Error(String(decoded.error.message ?? "EVM RPC error"));
    return decoded.result;
  } finally {
    clearTimeout(timer);
  }
}
function hexBig(value) {
  const raw = String(value ?? "0x0").replace(/^0x/, "");
  return BigInt(`0x${raw || "0"}`);
}
function toHex2(value) {
  return `0x${value.toString(16)}`;
}
function formatUnits(value, decimals, visible = 8) {
  const raw = value.toString().padStart(decimals + 1, "0"), whole = raw.slice(0, -decimals) || "0", fraction = (decimals ? raw.slice(-decimals).slice(0, visible) : "").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole;
}
function parseUnits(value, decimals) {
  if (!/^\d+(\.\d+)?$/.test(value)) throw new Error("Enter a valid amount.");
  const [whole, fraction = ""] = value.split(".");
  if (fraction.length > decimals) throw new Error(`Use no more than ${decimals} decimal places.`);
  return BigInt(whole) * 10n ** BigInt(decimals) + BigInt(fraction.padEnd(decimals, "0") || "0");
}
async function trustedContracts(network) {
  const config = evmConfig(network), trusted = /* @__PURE__ */ new Set([config.wrapped.toLowerCase()]);
  try {
    const response = await fetch("https://api.katbridge.com/token-pair"), decoded = await response.json(), rows = Array.isArray(decoded) ? decoded : decoded.result ?? decoded.data ?? [];
    for (const row of rows) {
      const chain = Number(row.chainId ?? row.chain_id ?? row.l2_chain_id), address = String(row.l2Contract ?? row.l2_contract ?? row.contractAddress ?? row.l2_address ?? "");
      if (row.is_active !== false && chain === config.chainId && /^0x[0-9a-fA-F]{40}$/.test(address)) trusted.add(address.toLowerCase());
    }
  } catch {
  }
  return trusted;
}
async function evmSnapshot(network, address) {
  const config = evmConfig(network);
  const [balance, tokenResponse, trusted] = await Promise.all([evmRpc(network, "eth_getBalance", [address, "latest"]), fetch(`${config.explorerApi}/addresses/${address}/token-balances`), trustedContracts(network)]);
  if (!tokenResponse.ok) throw new Error(`L2 explorer returned HTTP ${tokenResponse.status}.`);
  const rows = await tokenResponse.json();
  const tokens = (Array.isArray(rows) ? rows : []).map((row) => {
    const token = row.token ?? {}, contract = String(token.address_hash ?? token.address ?? "");
    return { contract, symbol: String(token.symbol ?? "TOKEN").toUpperCase(), name: String(token.name ?? "Unknown token"), decimals: Number(token.decimals ?? 18), rawBalance: String(row.value ?? 0), balance: formatUnits(BigInt(row.value ?? 0), Number(token.decimals ?? 18)), trusted: trusted.has(contract.toLowerCase()), iconUrl: token.icon_url ?? null };
  }).filter((token) => BigInt(token.rawBalance) > 0n && token.contract);
  return { evm: true, address, balanceRaw: hexBig(balance).toString(), balance: formatUnits(hexBig(balance), 18), balanceKas: Number(formatUnits(hexBig(balance), 18, 12)), nativeSymbol: config.nativeSymbol, tokens };
}
async function evmHistory(network, address) {
  const config = evmConfig(network);
  const responses = await Promise.all([fetch(`${config.explorerApi}/addresses/${address}/transactions`), fetch(`${config.explorerApi}/addresses/${address}/token-transfers`)]);
  if (!responses[0].ok) throw new Error("L2 activity is unavailable.");
  const native = await responses[0].json(), items = [];
  for (const row of native.items ?? []) {
    const gas = BigInt(row.gas_used ?? 0) * BigInt(row.gas_price ?? 0);
    items.push({ transactionId: row.hash, from: row.from?.hash ?? row.from ?? "", to: row.to?.hash ?? row.to ?? "", amount: formatUnits(BigInt(row.value ?? 0), 18), symbol: config.nativeSymbol, fee: formatUnits(gas, 18, 18), blockTime: Date.parse(row.timestamp ?? "") || 0, status: String(row.result ?? row.status ?? "") });
  }
  if (responses[1].ok) {
    const tokens = await responses[1].json();
    for (const row of tokens.items ?? []) {
      const token = row.token ?? {}, total = row.total ?? {};
      items.push({ transactionId: row.transaction_hash ?? row.tx_hash, from: row.from?.hash ?? row.from ?? "", to: row.to?.hash ?? row.to ?? "", amount: formatUnits(BigInt(total.value ?? row.value ?? 0), Number(token.decimals ?? total.decimals ?? 18)), symbol: String(token.symbol ?? "TOKEN").toUpperCase(), fee: null, blockTime: Date.parse(row.timestamp ?? "") || 0, status: "success" });
    }
  }
  return items.sort((a, b) => b.blockTime - a.blockTime).slice(0, 50);
}
function erc20Data(recipient, amount) {
  return `0xa9059cbb${recipient.slice(2).padStart(64, "0")}${amount.toString(16).padStart(64, "0")}`;
}
async function evmTransactionFields(network, from, to, value, data) {
  const [nonce, gasPrice, gas] = await Promise.all([evmRpc(network, "eth_getTransactionCount", [from, "pending"]), evmRpc(network, "eth_gasPrice", []), evmRpc(network, "eth_estimateGas", [{ from, to, value: toHex2(value), ...data ? { data } : {} }])]);
  return { nonce: hexBig(nonce), gasPrice: hexBig(gasPrice), gas: hexBig(gas) };
}
async function waitReceipt(network, hash) {
  for (let i = 0; i < 30; i++) {
    const receipt = await evmRpc(network, "eth_getTransactionReceipt", [hash]);
    if (receipt) {
      if (hexBig(receipt.status) !== 1n) throw new Error("The transaction failed on-chain.");
      return receipt;
    }
    await new Promise((resolve) => setTimeout(resolve, 2e3));
  }
  throw new Error("Transaction broadcast, but confirmation is pending.");
}

// src/background/index.ts
var safe = /* @__PURE__ */ new Set([
  "getAccounts",
  "getNetwork",
  "disconnect"
]);
var extensionVersion = chrome.runtime.getManifest().version;
var sessionVault = null;
var sessionPassword = null;
var lastActivity = 0;
var preparedEvmTransfers = /* @__PURE__ */ new Map();
var approvals = /* @__PURE__ */ new Map();
chrome.runtime.onInstalled.addListener(
  () => chrome.alarms.create("auto-lock", { periodInMinutes: 1 })
);
chrome.alarms.onAlarm.addListener(async ({ name }) => {
  if (name !== "auto-lock") return;
  await hydrateSession();
  const state = await loadState();
  const autoLockMs = state.settings.autoLockMinutes * 6e4;
  if (state.settings.autoLockMinutes < 0) return;
  if (!sessionVault || autoLockMs > 0 && Date.now() - lastActivity < autoLockMs)
    return;
  sessionVault = null;
  sessionPassword = null;
  await chrome.storage.session.remove(["unlockedVault", "lastActivity"]);
  await saveState({ ...state, locked: true });
});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.kind === "approval") {
    const pending = approvals.get(String(message.id ?? ""));
    if (message.command === "get") {
      respond(
        pending ? { result: pending.view } : { error: { code: 4001, message: "Approval request expired." } }
      );
      return false;
    }
    if (message.command === "resolve" && pending) {
      clearTimeout(pending.timer);
      approvals.delete(pending.view.id);
      pending.resolve(message.approved === true);
      respond({ result: true });
      return false;
    }
  }
  if (message?.channel === "wallet") {
    void walletCommand(message).then((result) => respond({ result })).catch((error) => respond({ error: normalize(error) }));
    return true;
  }
  if (message?.kind !== "provider" || !isProviderRequest(message.request))
    return false;
  void handle(
    message.origin,
    message.request.method,
    message.request.params,
    sender
  ).then((result) => respond({ result })).catch((error) => respond({ error: normalize(error) }));
  return true;
});
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "wallet-operation") return;
  port.onMessage.addListener((message) => {
    if (message?.channel !== "wallet") return;
    const progress = (stage) => {
      try {
        port.postMessage({ progress: stage });
      } catch {
      }
    };
    void walletCommand(message, progress).then((result) => port.postMessage({ result })).catch((error) => port.postMessage({ error: normalize(error) }));
  });
});
async function walletCommand(message, progress = () => {
}) {
  await hydrateSession();
  const state = await loadState();
  if (sessionVault) await touchSession();
  if (message.command === "status") {
    const stored = await chrome.storage.local.get([
      "encryptedVault",
      "pendingInscription"
    ]);
    return {
      ...state,
      locked: sessionVault === null,
      hasVault: Boolean(stored.encryptedVault),
      pendingInscription: stored.pendingInscription ?? null
    };
  }
  if (message.command === "pendingApproval") {
    const pending = [...approvals.values()].find(
      (item) => item.view.origin === "Kaspire Wallet"
    );
    return pending?.view ?? null;
  }
  if (message.command === "resolveWalletApproval") {
    const id = String(message.id ?? "");
    const pending = approvals.get(id);
    if (!pending || pending.view.origin !== "Kaspire Wallet")
      throw new Error("Approval request expired.");
    clearTimeout(pending.timer);
    approvals.delete(id);
    pending.resolve(message.approved === true);
    return true;
  }
  if (message.command === "mnemonicWordStatus")
    return JSON.parse(
      (await core()).mnemonicWordStatus(String(message.phrase ?? ""))
    );
  if (message.command === "snapshot") {
    if (!state.selectedAddress) throw new Error("No wallet is selected.");
    if (state.network === "kasplex" || state.network === "igra") return evmWalletSnapshot(state);
    return walletSnapshot(state.selectedAddress, state.network);
  }
  if (message.command === "coreSnapshot") {
    if (!state.selectedAddress) throw new Error("No wallet is selected.");
    return walletCoreSnapshot(state.selectedAddress, state.network);
  }
  if (message.command === "balanceSnapshot") {
    if (!state.selectedAddress) throw new Error("No wallet is selected.");
    if (state.network === "kasplex" || state.network === "igra") return evmWalletSnapshot(state);
    return walletBalance(state.selectedAddress, state.network);
  }
  if (message.command === "assetsSnapshot") {
    if (!state.selectedAddress) throw new Error("No wallet is selected.");
    if (state.network === "kasplex" || state.network === "igra") return evmWalletSnapshot(state);
    const assets = await walletAssets(state.selectedAddress, state.network);
    await chrome.storage.session.set({
      assetReviewSnapshot: {
        address: state.selectedAddress,
        network: state.network,
        assets,
        loadedAt: Date.now()
      }
    });
    return assets;
  }
  if (message.command === "networkDiagnostics") {
    if (!state.selectedAddress) throw new Error("No wallet is selected.");
    if (state.network === "kasplex" || state.network === "igra") {
      const config = evmConfig(state.network), started = Date.now();
      try {
        await evmRpc(state.network, "eth_chainId");
        return [{ name: config.name, url: config.rpc, ok: true, detail: `Chain ${config.chainId}`, elapsedMs: Date.now() - started }];
      } catch (error) {
        return [{ name: config.name, url: config.rpc, ok: false, detail: error.message, elapsedMs: Date.now() - started }];
      }
    }
    return networkDiagnostics(state.selectedAddress, state.network);
  }
  if (message.command === "history") {
    if (!state.selectedAddress) throw new Error("No wallet is selected.");
    if (state.network === "kasplex" || state.network === "igra") {
      const { address } = await evmContext(state);
      return evmHistory(state.network, address);
    }
    return activityHistory(state.selectedAddress, state.network);
  }
  if (message.command === "market") {
    return state.network === "mainnet" ? marketPrice(state.settings.currency) : null;
  }
  if (message.command === "evmAddress") return (await evmContext(state)).address;
  if (message.command === "prepareEvmTransfer") {
    if (state.network !== "kasplex" && state.network !== "igra") throw new Error("Select Kasplex or Igra first.");
    const { address, secret } = await evmContext(state);
    const recipient = String(message.recipient ?? "").trim();
    if (!/^0x[0-9a-fA-F]{40}$/.test(recipient)) throw new Error("Enter a valid EVM address.");
    const token = message.token;
    const decimals = token ? Number(token.decimals ?? 18) : 18;
    const requestedAmountText = String(message.amount ?? "").trim();
    let amountText = requestedAmountText;
    let amount = parseUnits(amountText, decimals);
    if (amount <= 0n) throw new Error("Enter an amount greater than zero.");
    const config = evmConfig(state.network);
    const to = token ? String(token.contract) : recipient;
    if (token && !/^0x[0-9a-fA-F]{40}$/.test(to)) throw new Error("Invalid token contract.");
    let data = token ? erc20Data(recipient, amount) : "";
    let value = token ? 0n : amount;
    let fields = await evmTransactionFields(state.network, address, to, value, data);
    const balance = BigInt(String(await evmRpc(state.network, "eth_getBalance", [address, "latest"])).replace(/^0x/, "0x"));
    let fee = fields.gas * fields.gasPrice;
    if (!token && message.sendAll === true) {
      if (balance <= fee) throw new Error(`Insufficient ${config.nativeSymbol} for the network fee.`);
      amount = balance - fee;
      amountText = formatUnits(amount, 18, 18);
      value = amount;
      fields = await evmTransactionFields(state.network, address, to, value, data);
      fee = fields.gas * fields.gasPrice;
      if (balance <= fee) throw new Error(`Insufficient ${config.nativeSymbol} for the network fee.`);
      amount = balance - fee;
      amountText = formatUnits(amount, 18, 18);
      value = amount;
    }
    if (balance < value + fee) throw new Error(`Insufficient ${config.nativeSymbol} for amount and network fee.`);
    if (token) {
      const balanceCall = `0x70a08231${address.slice(2).padStart(64, "0")}`;
      const tokenBalance = BigInt(String(await evmRpc(state.network, "eth_call", [{ to, data: balanceCall }, "latest"])).replace(/^0x/, "0x"));
      if (tokenBalance < amount) throw new Error(`Insufficient ${String(token.symbol).toUpperCase()} balance.`);
    }
    const request2 = { walletAddress: state.selectedAddress, from: address, to, recipient, valueWei: value.toString(), nonce: Number(fields.nonce), gasLimit: Number(fields.gas), gasPriceWei: fields.gasPrice.toString(), chainId: config.chainId, data, tokenSymbol: token ? String(token.symbol).toUpperCase() : config.nativeSymbol, displayAmount: amountText };
    const wasm3 = await core();
    const review = JSON.parse(wasm3.prepareEvmTransaction(JSON.stringify(request2)));
    const id = crypto.randomUUID();
    preparedEvmTransfers.set(id, { request: request2, review, secret, createdAt: Date.now() });
    return { id, review, fee: formatUnits(fee, 18, 18), nativeSymbol: config.nativeSymbol, rawJson: request2 };
  }
  if (message.command === "submitEvmTransfer") {
    const id = String(message.id ?? ""), prepared = preparedEvmTransfers.get(id);
    if (!prepared || Date.now() - prepared.createdAt > 10 * 6e4) throw new Error("Secure EVM review expired. Review the transfer again.");
    preparedEvmTransfers.delete(id);
    const config = evmConfig(state.network);
    if (!await approve({ origin: "Kaspire Wallet", title: `Send ${prepared.review.tokenSymbol}`, description: "Review this L2 transaction before signing.", details: [`Network: ${prepared.review.network}`, `Recipient: ${prepared.review.recipient}`, `Amount: ${prepared.review.displayAmount} ${prepared.review.tokenSymbol}`, `Network fee: ${formatUnits(BigInt(prepared.request.gasPriceWei) * BigInt(prepared.request.gasLimit), 18, 18)} ${config.nativeSymbol}`], rawJson: prepared.request })) throw rpc(4001, "User rejected the transaction.");
    const signed = JSON.parse((await core()).signEvmTransaction(prepared.secret, JSON.stringify(prepared.request), prepared.review.reviewHash));
    const result = String(await evmRpc(state.network, "eth_sendRawTransaction", [signed.rawTransaction]));
    if (result.toLowerCase() !== String(signed.transactionHash).toLowerCase()) throw new Error("L2 broadcaster returned a mismatching transaction ID.");
    const receipt = await waitReceipt(state.network, result);
    return { transactionId: result, receipt, review: prepared.review, rawJson: prepared.request };
  }
  if (message.command === "tokenMarket")
    return tokenMarket(
      String(message.tokenId ?? ""),
      String(message.symbol ?? "")
    );
  if (message.command === "nftCollection") {
    if (!state.selectedAddress) throw new Error("No wallet is selected.");
    return nftCollection(
      state.selectedAddress,
      String(message.ticker ?? "").toUpperCase(),
      Number(message.offset ?? 0)
    );
  }
  if (message.command === "nftRarity")
    return nftRarity(
      String(message.ticker ?? "").toUpperCase(),
      String(message.tokenId ?? "")
    );
  if (message.command === "createPrivateKey") {
    const password = String(message.password ?? "");
    const wasm3 = await core();
    const material = JSON.parse(
      wasm3.importPrivateKey(String(message.privateKey ?? ""))
    );
    const id = crypto.randomUUID();
    const name = String(message.name ?? "Imported key").trim() || "Imported key";
    sessionVault = {
      version: 2,
      wallets: [
        { id, name, type: "private", secret: `private:${material.privateKey}` }
      ],
      createdAt: Date.now()
    };
    sessionPassword = password;
    await createVault(password, sessionVault);
    await rememberSession(sessionVault);
    state.selectedAddress = material.address;
    state.addresses = [
      {
        address: material.address,
        name,
        path: "private-key",
        watchOnly: false,
        walletId: id,
        coinType: 111111,
        account: 0,
        change: 0,
        index: 0
      }
    ];
    state.locked = false;
    state.recoveryVerified = true;
    await saveState(state);
    return { state: { ...state, locked: false } };
  }
  if (message.command === "createWatch") {
    const password = String(message.password ?? "");
    if (password.length < 12)
      throw new Error("Use at least 12 characters for the wallet password.");
    const address = await resolveWalletInput(
      String(message.address ?? ""),
      state.network
    );
    const name = String(message.name ?? "Watch wallet").trim() || "Watch wallet";
    sessionVault = { version: 2, wallets: [], createdAt: Date.now() };
    sessionPassword = password;
    await createVault(password, sessionVault);
    await rememberSession(sessionVault);
    const entry = {
      address,
      name,
      path: "watch-only",
      watchOnly: true,
      walletId: `watch:${address}`,
      coinType: 111111,
      account: 0,
      change: 0,
      index: 0
    };
    state.selectedAddress = address;
    state.addresses = [entry];
    state.locked = false;
    state.recoveryVerified = true;
    await saveState(state);
    return entry;
  }
  if (message.command === "pendingRecovery") {
    if (state.recoveryVerified || !sessionVault)
      throw new Error("No recovery verification is pending.");
    const entry = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!wallet || wallet.type !== "mnemonic")
      throw new Error("Recovery wallet is unavailable.");
    return wallet.secret.startsWith("mnemonic-passphrase:") ? wallet.secret.split(":").slice(2).join(":") : wallet.secret.slice("mnemonic:".length);
  }
  if (message.command === "verifyRecovery") {
    if (state.recoveryVerified || !sessionVault)
      throw new Error("No recovery verification is pending.");
    const entry = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!wallet || wallet.type !== "mnemonic")
      throw new Error("Recovery wallet is unavailable.");
    const phrase = wallet.secret.startsWith("mnemonic-passphrase:") ? wallet.secret.split(":").slice(2).join(":") : wallet.secret.slice("mnemonic:".length);
    const words = phrase.split(" ");
    const checks = Array.isArray(message.checks) ? message.checks : [];
    if (checks.length !== 3 || checks.some(
      (check) => !Number.isInteger(check?.index) || check.index < 0 || check.index >= words.length || String(check.word ?? "").trim().toLowerCase() !== words[check.index]
    ))
      throw new Error("One or more recovery words are incorrect.");
    state.recoveryVerified = true;
    await saveState(state);
    return true;
  }
  if (message.command === "cancelPendingRecovery") {
    if (state.recoveryVerified || !sessionVault)
      throw new Error("No wallet creation is pending.");
    const entry = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || !wallet || wallet.type !== "mnemonic")
      throw new Error("Pending recovery wallet is unavailable.");
    sessionVault.wallets = sessionVault.wallets.filter(
      (item) => item.id !== wallet.id
    );
    state.addresses = state.addresses.filter(
      (item) => item.walletId !== wallet.id
    );
    state.selectedAddress = state.addresses[0]?.address ?? null;
    state.recoveryVerified = true;
    if (state.addresses.length === 0) {
      sessionVault = null;
      sessionPassword = null;
      await chrome.storage.local.remove("encryptedVault");
      await chrome.storage.session.remove(["unlockedVault", "lastActivity"]);
    } else {
      await persistVault();
    }
    await saveState(state);
    return true;
  }
  if (message.command === "create" || message.command === "import") {
    const password = String(message.password ?? "");
    const passphrase = String(message.passphrase ?? "");
    const wasm3 = await core();
    const material = JSON.parse(
      message.command === "create" ? wasm3.generateWallet(passphrase) : wasm3.importWallet(String(message.words ?? ""), passphrase)
    );
    const id = crypto.randomUUID();
    const passphraseHex = [...new TextEncoder().encode(passphrase)].map((value) => value.toString(16).padStart(2, "0")).join("");
    const secret = passphrase ? `mnemonic-passphrase:${passphraseHex}:${material.mnemonic}` : `mnemonic:${material.mnemonic}`;
    sessionVault = {
      version: 2,
      wallets: [{ id, name: "Wallet 1", type: "mnemonic", secret }],
      createdAt: Date.now()
    };
    sessionPassword = password;
    await createVault(password, sessionVault);
    await rememberSession(sessionVault);
    state.selectedAddress = material.address;
    state.addresses = [
      {
        address: material.address,
        name: "Wallet 1",
        path: material.derivationPath,
        watchOnly: false,
        walletId: id,
        coinType: 111111,
        account: 0,
        change: 0,
        index: 0
      }
    ];
    state.locked = false;
    state.recoveryVerified = message.command !== "create";
    await saveState(state);
    return {
      state: { ...state, locked: false },
      recoveryPhrase: material.mnemonic
    };
  }
  if (message.command === "unlock") {
    const password = String(message.password ?? "");
    const payload = await unlockVault(password);
    if (payload.version !== 2 || !Array.isArray(payload.wallets))
      throw new Error("Unsupported vault format.");
    sessionVault = payload;
    sessionPassword = password;
    await rememberSession(payload);
    return { ...state, locked: false };
  }
  if (message.command === "addAccount" || message.command === "addSubwallet") {
    if (!sessionVault) throw new Error("Unlock Kaspire first.");
    const current = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    if (!current || current.watchOnly)
      throw new Error("Select a signing wallet.");
    const wallet = sessionVault.wallets.find(
      (item) => item.id === current.walletId
    );
    if (!wallet) throw new Error("Wallet key is unavailable.");
    const account = message.command === "addAccount" ? Math.max(
      -1,
      ...state.addresses.filter((item) => item.walletId === wallet.id).map((item) => item.account)
    ) + 1 : current.account;
    const index = message.command === "addSubwallet" ? Math.max(
      -1,
      ...state.addresses.filter(
        (item) => item.walletId === wallet.id && item.account === account
      ).map((item) => item.index)
    ) + 1 : 0;
    const wasm3 = await core();
    const derived = JSON.parse(
      wasm3.deriveAddressRange(
        wallet.secret,
        current.coinType,
        account,
        0,
        index,
        1
      )
    )[0];
    const address = wasm3.addressWithPrefix(
      derived.address,
      state.network === "testnet-10"
    );
    const entry = {
      address,
      name: message.command === "addAccount" ? `Account ${account}` : `Subwallet ${index}`,
      path: derived.derivationPath,
      watchOnly: false,
      walletId: wallet.id,
      coinType: current.coinType,
      account,
      change: 0,
      index
    };
    state.addresses.push(entry);
    state.selectedAddress = entry.address;
    await saveState(state);
    return entry;
  }
  if (message.command === "addWatch") {
    let address = await resolveWalletInput(
      String(message.address ?? ""),
      state.network
    );
    address = (await core()).addressWithPrefix(
      address,
      state.network === "testnet-10"
    );
    if (state.addresses.some((item) => item.address === address))
      throw new Error("This wallet is already in Kaspire.");
    const entry = {
      address,
      name: String(message.name ?? "Watch wallet").trim() || "Watch wallet",
      path: "watch-only",
      watchOnly: true,
      walletId: `watch:${address}`,
      coinType: 111111,
      account: 0,
      change: 0,
      index: 0
    };
    state.addresses.push(entry);
    state.selectedAddress = address;
    await saveState(state);
    return entry;
  }
  if (message.command === "addPrivateKey") {
    if (!sessionVault) throw new Error("Unlock Kaspire first.");
    const password = String(message.password ?? "");
    if (!sessionPassword) {
      await unlockVault(password);
      sessionPassword = password;
    }
    const material = JSON.parse(
      (await core()).importPrivateKey(String(message.privateKey ?? ""))
    );
    const id = crypto.randomUUID();
    const wallet = {
      id,
      name: String(message.name ?? "Imported key").trim() || "Imported key",
      type: "private",
      secret: `private:${material.privateKey}`
    };
    sessionVault.wallets.push(wallet);
    const address = state.network === "testnet-10" ? (await core()).addressWithPrefix(material.address, true) : material.address;
    const entry = {
      address,
      name: wallet.name,
      path: "private-key",
      watchOnly: false,
      walletId: id,
      coinType: 111111,
      account: 0,
      change: 0,
      index: 0
    };
    state.addresses.push(entry);
    state.selectedAddress = address;
    await persistVault();
    await saveState(state);
    return entry;
  }
  if (message.command === "addMnemonic") {
    if (!sessionVault) throw new Error("Unlock Kaspire first.");
    const password = String(message.password ?? "");
    if (!sessionPassword) {
      await unlockVault(password);
      sessionPassword = password;
    }
    const passphrase = String(message.passphrase ?? "");
    const wasm3 = await core();
    const material = JSON.parse(
      wasm3.importWallet(String(message.words ?? ""), passphrase)
    );
    const address = wasm3.addressWithPrefix(
      material.address,
      state.network === "testnet-10"
    );
    if (state.addresses.some((item) => item.address === address))
      throw new Error("This recovery wallet is already in Kaspire.");
    const id = crypto.randomUUID();
    const passphraseHex = [...new TextEncoder().encode(passphrase)].map((value) => value.toString(16).padStart(2, "0")).join("");
    const wallet = {
      id,
      name: String(message.name ?? "Imported wallet").trim() || "Imported wallet",
      type: "mnemonic",
      secret: passphrase ? `mnemonic-passphrase:${passphraseHex}:${material.mnemonic}` : `mnemonic:${material.mnemonic}`
    };
    sessionVault.wallets.push(wallet);
    const entry = {
      address,
      name: wallet.name,
      path: material.derivationPath,
      watchOnly: false,
      walletId: id,
      coinType: 111111,
      account: 0,
      change: 0,
      index: 0
    };
    state.addresses.push(entry);
    state.selectedAddress = address;
    await persistVault();
    await saveState(state);
    return entry;
  }
  if (message.command === "addGeneratedMnemonic") {
    if (!sessionVault) throw new Error("Unlock Kaspire first.");
    const password = String(message.password ?? "");
    if (!password) throw new Error("Enter the wallet password.");
    await unlockVault(password);
    sessionPassword = password;
    const wordCount = Number(message.wordCount ?? 24);
    if (wordCount !== 12 && wordCount !== 24)
      throw new Error("Choose either 12 or 24 recovery words.");
    const passphrase = String(message.passphrase ?? "");
    const wasm3 = await core();
    const material = JSON.parse(
      wasm3.generateWalletWithWordCount(passphrase, wordCount)
    );
    const address = wasm3.addressWithPrefix(
      material.address,
      state.network === "testnet-10"
    );
    if (state.addresses.some((item) => item.address === address))
      throw new Error("This recovery wallet is already in Kaspire.");
    const id = crypto.randomUUID();
    const passphraseHex = [...new TextEncoder().encode(passphrase)].map((value) => value.toString(16).padStart(2, "0")).join("");
    const name = String(message.name ?? "").trim() || `Wallet ${sessionVault.wallets.length + 1}`;
    sessionVault.wallets.push({
      id,
      name,
      type: "mnemonic",
      secret: passphrase ? `mnemonic-passphrase:${passphraseHex}:${material.mnemonic}` : `mnemonic:${material.mnemonic}`
    });
    state.addresses.push({
      address,
      name,
      path: material.derivationPath,
      watchOnly: false,
      walletId: id,
      coinType: 111111,
      account: 0,
      change: 0,
      index: 0
    });
    state.selectedAddress = address;
    state.recoveryVerified = false;
    await persistVault();
    await saveState(state);
    return { address, recoveryPhrase: material.mnemonic };
  }
  if (message.command === "select") {
    const address = String(message.address ?? "");
    if (!state.addresses.some((item) => item.address === address))
      throw new Error("Unknown wallet address.");
    state.selectedAddress = address;
    await saveState(state);
    return true;
  }
  if (message.command === "rename") {
    const entry = state.addresses.find(
      (item) => item.address === String(message.address ?? state.selectedAddress ?? "")
    );
    const name = String(message.name ?? "").trim();
    if (!entry || !name || name.length > 64)
      throw new Error("Invalid wallet name.");
    entry.name = name;
    await saveState(state);
    return true;
  }
  if (message.command === "removeAddress") {
    const address = String(message.address ?? state.selectedAddress ?? "");
    const entry = state.addresses.find((item) => item.address === address);
    if (!entry) throw new Error("Unknown wallet.");
    const removesSigningWallet = !entry.watchOnly && (entry.path === "private-key" || entry.account === 0 && entry.change === 0 && entry.index === 0);
    state.addresses = removesSigningWallet ? state.addresses.filter((item) => item.walletId !== entry.walletId) : state.addresses.filter((item) => item.address !== address);
    state.selectedAddress = state.addresses[0]?.address ?? null;
    if (removesSigningWallet && sessionVault) {
      sessionVault.wallets = sessionVault.wallets.filter(
        (item) => item.id !== entry.walletId
      );
    }
    if (state.addresses.length === 0) {
      sessionVault = null;
      sessionPassword = null;
      await chrome.storage.local.remove("encryptedVault");
      await chrome.storage.session.remove(["unlockedVault", "lastActivity"]);
    } else if (removesSigningWallet) {
      await persistVault();
    }
    state.recoveryVerified = true;
    await saveState(state);
    return true;
  }
  if (message.command === "setNetwork") {
    const network = String(message.network ?? "");
    if (!["mainnet", "testnet-10", "kasplex", "igra"].includes(network))
      throw new Error("Unsupported network.");
    return convertNetwork(state, network);
  }
  if (message.command === "setSettings") {
    const next = message.settings;
    if (next?.autoLockMinutes !== void 0) {
      const value = Number(next.autoLockMinutes);
      if (![-1, 0, 1, 5, 15, 30, 60].includes(value))
        throw new Error("Unsupported auto-lock duration.");
      state.settings.autoLockMinutes = value;
    }
    if (typeof next?.hideBalances === "boolean")
      state.settings.hideBalances = next.hideBalances;
    if (typeof next?.uppercase === "boolean")
      state.settings.uppercase = next.uppercase;
    if (typeof next?.showSubwallets === "boolean")
      state.settings.showSubwallets = next.showSubwallets;
    if (typeof next?.recipientAllowlist === "boolean")
      state.settings.recipientAllowlist = next.recipientAllowlist;
    if ([
      "USD",
      "EUR",
      "GBP",
      "AUD",
      "CAD",
      "JPY",
      "CNY",
      "CHF",
      "INR",
      "BRL",
      "KRW"
    ].includes(next?.currency))
      state.settings.currency = next.currency;
    if ([
      "midnight",
      "emerald",
      "amethyst",
      "sakura",
      "crimson",
      "phoenix",
      "cypherpunk"
    ].includes(next?.theme))
      state.settings.theme = next.theme;
    await saveState(state);
    return state.settings;
  }
  if (message.command === "addContact") {
    const name = String(message.name ?? "").trim();
    let address = await resolveWalletInput(
      String(message.address ?? ""),
      state.network
    );
    if (!name || name.length > 80) throw new Error("Invalid contact.");
    address = (await core()).addressWithPrefix(
      address,
      state.network === "testnet-10"
    );
    state.contacts.push({ id: crypto.randomUUID(), name, address });
    await saveState(state);
    return true;
  }
  if (message.command === "removeContact") {
    state.contacts = state.contacts.filter(
      (item) => item.id !== String(message.id ?? "")
    );
    await saveState(state);
    return true;
  }
  if (message.command === "editContact") {
    const contact = state.contacts.find(
      (item) => item.id === String(message.id ?? "")
    );
    const name = String(message.name ?? "").trim();
    let address = await resolveWalletInput(
      String(message.address ?? ""),
      state.network
    );
    if (!contact || !name || name.length > 80)
      throw new Error("Invalid contact.");
    address = (await core()).addressWithPrefix(
      address,
      state.network === "testnet-10"
    );
    contact.name = name;
    contact.address = address;
    await saveState(state);
    return true;
  }
  if (message.command === "disconnectOrigin") {
    delete state.permissions[String(message.origin ?? "")];
    await saveState(state);
    return true;
  }
  if (message.command === "exportSecret") {
    if (!sessionVault || !state.selectedAddress)
      throw new Error("Unlock Kaspire first.");
    const password = String(message.password ?? "");
    await unlockVault(password);
    const entry = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw new Error("Selected wallet has no exportable key.");
    if (!await approve({
      origin: "Kaspire Wallet",
      title: message.type === "recovery" ? "Reveal recovery phrase?" : "Reveal private key?",
      description: "Anyone who sees this secret can take every asset controlled by it.",
      details: [entry.name, entry.path]
    }))
      throw rpc(4001, "Secret export rejected.");
    if (message.type === "recovery") {
      if (wallet.type !== "mnemonic")
        throw new Error("This wallet was imported from a private key.");
      return wallet.secret.startsWith("mnemonic-passphrase:") ? wallet.secret.split(":").slice(2).join(":") : wallet.secret.slice("mnemonic:".length);
    }
    return (await core()).exportPrivateKey(signingSecret(wallet, entry));
  }
  if (message.command === "sendKas") {
    if (!sessionVault || !state.selectedAddress)
      throw new Error("Unlock a signing wallet first.");
    const recipient = await resolveWalletInput(
      String(message.recipient ?? ""),
      state.network
    );
    if (state.settings.recipientAllowlist && !state.contacts.some((item) => item.address === recipient) && !state.addresses.some((item) => item.address === recipient))
      throw new Error("Recipient is not in your address book.");
    const sendAll = message.sendAll === true;
    const amount = sendAll ? 0 : Number(message.amountSompi);
    if (!sendAll && (!Number.isSafeInteger(amount) || amount <= 0))
      throw new Error("Invalid recipient or amount.");
    const entry = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw new Error("Selected wallet cannot sign.");
    const spend = await spendingData(entry.address, state.network);
    const request2 = {
      sender: entry.address,
      recipient,
      amountSompi: amount,
      feeRate: spend.feeRate,
      utxosJson: spend.utxosJson,
      sendAll
    };
    const wasm3 = await core();
    const review = JSON.parse(wasm3.prepareTransaction(JSON.stringify(request2)));
    if (!await approve({
      origin: "Kaspire Wallet",
      title: "Approve KAS payment?",
      description: "Verify the payment reconstructed by the Rust security core.",
      details: [
        `Send: ${review.amountSompi / 1e8} KAS`,
        `To: ${review.recipient}`,
        `Fee: ${formatSompi(review.feeSompi)} KAS`,
        `Change: ${review.changeSompi / 1e8} KAS`
      ],
      rawJson: { request: request2, review }
    }))
      throw rpc(4001, "Payment rejected.");
    const signed = JSON.parse(
      wasm3.signTransaction(
        signingSecret(wallet, entry),
        JSON.stringify(request2),
        review.reviewHash
      )
    );
    const id = await broadcast(signed.submitJson, state.network);
    if (id && id !== signed.transactionId)
      throw new Error("Node returned a mismatching transaction ID.");
    return { transactionId: signed.transactionId, amountSompi: review.amountSompi, feeSompi: review.feeSompi };
  }
  if (message.command === "compound") {
    if (!sessionVault || !state.selectedAddress)
      throw new Error("Unlock a signing wallet first.");
    const entry = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw new Error("Selected wallet cannot sign.");
    const spend = await spendingData(entry.address, state.network);
    const count = JSON.parse(spend.utxosJson).length;
    if (count < 2) throw new Error("This wallet has fewer than two UTXOs.");
    const request2 = {
      sender: entry.address,
      recipient: entry.address,
      amountSompi: 0,
      feeRate: spend.feeRate,
      utxosJson: spend.utxosJson,
      sendAll: true
    };
    const wasm3 = await core();
    const review = JSON.parse(wasm3.prepareTransaction(JSON.stringify(request2)));
    if (!await approve({
      origin: "Kaspire Wallet",
      title: "Compound wallet UTXOs?",
      description: "All spendable KAS will return to the same wallet as one output minus the network fee.",
      details: [
        `${review.inputCount} inputs \u2192 ${review.outputCount} output`,
        `Returned: ${review.amountSompi / 1e8} KAS`,
        `Network fee: ${formatSompi(review.feeSompi)} KAS`
      ]
    }))
      throw rpc(4001, "UTXO compound rejected.");
    const signed = JSON.parse(
      wasm3.signTransaction(
        signingSecret(wallet, entry),
        JSON.stringify(request2),
        review.reviewHash
      )
    );
    const id = await broadcast(signed.submitJson, state.network);
    if (id && id !== signed.transactionId)
      throw new Error("Node returned a mismatching transaction ID.");
    return signed.transactionId;
  }
  if (message.command === "resumeInscription") {
    if (!sessionVault) throw new Error("Unlock Kaspire first.");
    const pending = (await chrome.storage.local.get("pendingInscription")).pendingInscription;
    if (!pending) throw new Error("No pending reveal exists.");
    return finishPendingInscription(
      "Kaspire Wallet",
      pending,
      state,
      sessionVault
    );
  }
  if (message.command === "prepareAsset") {
    if (!sessionVault) throw new Error("Unlock Kaspire first.");
    return prepareWalletAsset(message, state, progress);
  }
  if (message.command === "confirmPreparedAsset") {
    if (!sessionVault) throw new Error("Unlock Kaspire first.");
    return confirmPreparedAsset(
      String(message.preparedId ?? ""),
      state,
      sessionVault
    );
  }
  if (message.command === "sendAsset") {
    if (!sessionVault) throw new Error("Unlock Kaspire first.");
    const kind = String(message.kind ?? "");
    const method = kind === "krc20" ? "sendKRC20" : kind === "krc721" ? "transferKRC721" : kind === "kns" ? "transferKNS" : kind === "kcc20" ? "sendKCC20" : (() => {
      throw new Error("Unsupported asset kind.");
    })();
    const resolvedRecipient = await resolveWalletInput(
      String(message.to ?? ""),
      state.network
    );
    if (state.settings.recipientAllowlist && !state.contacts.some((item) => item.address === resolvedRecipient) && !state.addresses.some((item) => item.address === resolvedRecipient))
      throw new Error("Recipient is not in your address book.");
    const params = {
      to: resolvedRecipient,
      from: state.selectedAddress,
      ticker: message.ticker,
      amount: message.amount,
      tokenId: message.tokenId,
      assetId: message.assetId,
      covenantId: message.covenantId
    };
    return method === "sendKCC20" ? kcc20Transfer("Kaspire Wallet", params, state, sessionVault) : inscriptionTransfer(
      "Kaspire Wallet",
      method,
      params,
      state,
      sessionVault
    );
  }
  if (message.command === "exportBackup") {
    if (!sessionVault || !state.selectedAddress)
      throw new Error("Unlock a signing wallet first.");
    const password = String(message.password ?? "");
    const entry = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw new Error("Select a signing wallet to back up.");
    const wasm3 = await core(), primary = state.addresses.find(
      (item) => item.walletId === wallet.id && !item.watchOnly && item.account === 0 && item.change === 0 && item.index === 0
    ) ?? entry, mainAddress = wasm3.addressWithPrefix(primary.address, false);
    const addresses = state.addresses.filter((item) => item.walletId === wallet.id && !item.watchOnly).map((item) => ({
      address: wasm3.addressWithPrefix(item.address, false),
      derivationPath: item.path,
      coinType: item.coinType,
      account: item.account,
      change: item.change,
      index: item.index,
      used: true,
      explicit: true
    }));
    const backup = await createPortableBackup(password, {
      secret: wallet.secret,
      address: mainAddress,
      addresses,
      createdAt: Date.now()
    });
    return JSON.stringify(backup);
  }
  if (message.command === "importBackup") {
    const password = String(message.password ?? "");
    let backup;
    try {
      backup = JSON.parse(String(message.backup ?? ""));
    } catch {
      throw new Error("Backup is not valid JSON.");
    }
    if (backup?.format === "kaspire-extension-backup-v2") {
      if (backup?.vault?.version !== 2 || !Array.isArray(backup?.state?.addresses))
        throw new Error("Unsupported legacy Kaspire extension backup.");
      const payload = await decryptVault(
        backup.vault,
        password
      );
      if (payload.version !== 2 || !Array.isArray(payload.wallets))
        throw new Error("Damaged Kaspire vault payload.");
      const addresses2 = backup.state.addresses.filter(
        (item) => typeof item?.address === "string" && typeof item?.walletId === "string"
      );
      if (!addresses2.length) throw new Error("Backup contains no wallets.");
      sessionVault = payload;
      sessionPassword = password;
      await rememberSession(payload);
      await chrome.storage.local.set({ encryptedVault: backup.vault });
      state.addresses = addresses2;
      state.selectedAddress = addresses2.some(
        (item) => item.address === backup.state.selectedAddress
      ) ? backup.state.selectedAddress : addresses2[0].address;
      state.locked = false;
      await saveState(state);
      return true;
    }
    const decoded = await decryptPortableBackup(
      backup,
      password
    );
    const secret = String(decoded?.secret ?? ""), expected = String(decoded?.address ?? "").toLowerCase();
    if (!secret.startsWith("mnemonic:") && !secret.startsWith("mnemonic-passphrase:") && !secret.startsWith("private:"))
      throw new Error("Damaged Kaspire backup secret.");
    const wasm3 = await core();
    const material = secret.startsWith("private:") ? JSON.parse(wasm3.importPrivateKey(secret.slice(8))) : (() => {
      const raw = secret.startsWith("mnemonic:") ? { phrase: secret.slice(9), passphrase: "" } : (() => {
        const value = secret.slice("mnemonic-passphrase:".length), separator = value.indexOf(":");
        if (separator < 0 || value.slice(0, separator).length % 2)
          throw new Error("Damaged passphrase wallet backup.");
        const hex2 = value.slice(0, separator), bytes2 = new Uint8Array(hex2.length / 2);
        for (let i = 0; i < bytes2.length; i++)
          bytes2[i] = Number.parseInt(hex2.slice(i * 2, i * 2 + 2), 16);
        return {
          phrase: value.slice(separator + 1),
          passphrase: new TextDecoder().decode(bytes2)
        };
      })();
      return JSON.parse(wasm3.importWallet(raw.phrase, raw.passphrase));
    })();
    if (material.address.toLowerCase() !== expected)
      throw new Error("Backup address verification failed.");
    const id = crypto.randomUUID(), name = "Restored wallet", wallet = {
      id,
      name,
      type: secret.startsWith("private:") ? "private" : "mnemonic",
      secret
    };
    const source = Array.isArray(decoded?.addresses) ? decoded.addresses : [], addresses = [];
    if (wallet.type === "mnemonic")
      for (const item of source) {
        const path = String(item?.derivationPath ?? ""), coinType = Number(item?.coinType), account = Number(item?.account), change = Number(item?.change), index = Number(item?.index);
        if (!path.startsWith("m/") || ![coinType, account, change, index].every(Number.isInteger))
          throw new Error("Invalid HD address list in backup.");
        const derived = JSON.parse(
          wasm3.deriveAddressRange(secret, coinType, account, change, index, 1)
        )[0];
        if (!derived || String(derived.address).toLowerCase() !== String(item?.address ?? "").toLowerCase() || derived.derivationPath !== path)
          throw new Error("HD address verification failed.");
        addresses.push({
          address: wasm3.addressWithPrefix(
            derived.address,
            state.network === "testnet-10"
          ),
          name: index === 0 && account === 0 ? name : `${account === 0 ? "Subwallet" : "Account"} ${index}`,
          path,
          watchOnly: false,
          walletId: id,
          coinType,
          account,
          change,
          index
        });
      }
    if (!addresses.length)
      addresses.push({
        address: wasm3.addressWithPrefix(
          material.address,
          state.network === "testnet-10"
        ),
        name,
        path: material.derivationPath ?? "private-key",
        watchOnly: false,
        walletId: id,
        coinType: 111111,
        account: 0,
        change: 0,
        index: 0
      });
    sessionVault = { version: 2, wallets: [wallet], createdAt: Date.now() };
    sessionPassword = password;
    await createVault(password, sessionVault);
    await rememberSession(sessionVault);
    state.addresses = addresses;
    state.selectedAddress = addresses[0].address;
    state.locked = false;
    state.recoveryVerified = true;
    await saveState(state);
    return true;
  }
  if (message.command === "lock") {
    sessionVault = null;
    sessionPassword = null;
    await chrome.storage.session.remove(["unlockedVault", "lastActivity"]);
    await saveState({ ...state, locked: true });
    return true;
  }
  throw rpc(-32601, "Unknown wallet command.");
}
async function evmContext(state) {
  if (!sessionVault) throw new Error("Unlock Kaspire first.");
  const entry = state.addresses.find((item) => item.address === state.selectedAddress);
  if (!entry || entry.watchOnly) throw new Error("Select a signing wallet for Layer 2.");
  const wallet = sessionVault.wallets.find((item) => item.id === entry.walletId);
  if (!wallet) throw new Error("Wallet key is unavailable.");
  const secret = signingSecret(wallet, entry);
  return { address: (await core()).deriveEvmAddress(secret), secret };
}
async function evmWalletSnapshot(state) {
  if (state.network !== "kasplex" && state.network !== "igra") throw new Error("Select an L2 network.");
  const { address } = await evmContext(state);
  return evmSnapshot(state.network, address);
}
async function persistVault() {
  if (!sessionVault) throw new Error("Unlock Kaspire first.");
  if (!sessionPassword) {
    sessionVault = null;
    await hydrateSession();
    throw new Error(
      "Lock and unlock Kaspire again before changing encrypted wallet keys."
    );
  }
  await createVault(sessionPassword, sessionVault);
  await rememberSession(sessionVault);
}
async function hydrateSession() {
  if (sessionVault) return;
  const stored = await chrome.storage.session.get([
    "unlockedVault",
    "lastActivity"
  ]);
  const payload = stored.unlockedVault;
  if (payload?.version === 2 && Array.isArray(payload.wallets)) {
    sessionVault = payload;
    lastActivity = Number(stored.lastActivity) || Date.now();
  }
}
async function rememberSession(payload) {
  lastActivity = Date.now();
  await chrome.storage.session.set({ unlockedVault: payload, lastActivity });
}
async function touchSession() {
  lastActivity = Date.now();
  await chrome.storage.session.set({ lastActivity });
}
function signingSecret(wallet, entry) {
  return wallet.type === "mnemonic" ? `hd-path:${entry.path}:${wallet.secret}` : wallet.secret;
}
async function convertNetwork(state, network) {
  const wasm3 = await core();
  const selectedIndex = state.addresses.findIndex(
    (item) => item.address === state.selectedAddress
  );
  state.addresses = state.addresses.map((item) => ({
    ...item,
    address: wasm3.addressWithPrefix(item.address, network === "testnet-10")
  }));
  state.selectedAddress = (selectedIndex >= 0 ? state.addresses[selectedIndex]?.address : state.addresses[0]?.address) ?? null;
  state.network = network;
  state.permissions = {};
  await saveState(state);
  return { network, selectedAddress: state.selectedAddress };
}
async function activityHistory(address, network) {
  const [node, assets, kcc, stored] = await Promise.all([
    walletHistory(address, network),
    network === "mainnet" ? inscriptionAssets(address).catch(() => ({ transactions: [] })) : Promise.resolve({ transactions: [] }),
    network === "mainnet" ? kcc20History(address).catch(() => []) : Promise.resolve([]),
    chrome.storage.local.get("walletActivity")
  ]);
  const token = (assets.transactions ?? []).map((item) => {
    const from = String(item?.from_wallet ?? item?.from ?? ""), to = String(item?.to_wallet ?? item?.to ?? ""), id = String(item?.token_id ?? item?.asset_id ?? ""), protocol = String(
      item?.asset_kind ?? item?.protocol ?? item?.standard ?? ""
    ).toLowerCase(), assetKind = protocol.includes("721") || id.startsWith("krc721-") ? "KRC-721" : protocol === "kns" || id.endsWith(".kas") ? "KNS" : "KRC-20";
    return {
      transactionId: String(
        item?.transaction_id ?? item?.tx_id ?? item?.reveal_tx_id ?? item?.id ?? ""
      ),
      blockTime: Date.parse(String(item?.timestamp ?? item?.created_at ?? "")) || 0,
      isAccepted: true,
      incoming: to === address,
      assetKind,
      assetSymbol: String(
        item?.token_symbol ?? item?.ticker ?? item?.domain_name ?? "ASSET"
      ).toUpperCase(),
      displayAmount: String(
        item?.amount ?? (assetKind === "KRC-721" ? "1" : "")
      ),
      tokenId: String(
        item?.nft_token_id ?? item?.tokenId ?? item?.asset_id ?? ""
      ),
      counterparty: to === address ? from : to,
      from: from ? [{ address: from }] : [],
      to: to ? [{ address: to }] : [],
      feeSompi: null,
      totalInputSompi: null,
      totalOutputSompi: null,
      inputCount: null,
      outputCount: null,
      mass: null,
      payload: "",
      type: String(item?.type ?? "transfer")
    };
  });
  const local = (Array.isArray(stored.walletActivity) ? stored.walletActivity : []).filter((item) => item?.wallet === address).map((item) => item.transaction);
  const merged = /* @__PURE__ */ new Map();
  for (const item of [...local, ...node, ...token, ...kcc]) {
    const assetIdentity = item.assetKind === "KRC-20" ? item.assetSymbol : item.tokenId ?? item.assetSymbol ?? "";
    const key2 = `${item.transactionId}:${item.assetKind}:${assetIdentity}`;
    const previous = merged.get(key2);
    merged.set(
      key2,
      previous ? {
        ...item,
        ...previous,
        ...Object.fromEntries(
          Object.entries(item).filter(
            ([, value]) => value !== null && value !== "" && !(Array.isArray(value) && !value.length)
          )
        )
      } : item
    );
  }
  return [...merged.values()].sort((a, b) => b.blockTime - a.blockTime).slice(0, 150);
}
async function recordWalletActivity(wallet, transaction) {
  const stored = await chrome.storage.local.get("walletActivity"), rows = Array.isArray(stored.walletActivity) ? stored.walletActivity : [];
  rows.unshift({ wallet, transaction });
  await chrome.storage.local.set({ walletActivity: rows.slice(0, 500) });
}
async function handle(origin, method, params, sender) {
  await hydrateSession();
  const senderOrigin = sender.url ? new URL(sender.url).origin : "";
  if (!/^https?:\/\//.test(origin) || senderOrigin !== origin)
    throw rpc(4100, "Untrusted request origin.");
  const state = await loadState();
  const permitted = state.permissions[origin]?.accounts === true;
  if (method === "requestAccounts") {
    if (!state.selectedAddress)
      throw rpc(4100, "Create or import a wallet first.");
    if (!await approve({
      origin,
      title: "Connect dApp?",
      description: "Allow this site to view your selected wallet address.",
      details: [state.network === "kasplex" || state.network === "igra" ? sessionVault ? (await evmContext(state)).address : "Unlock to reveal the selected Layer 2 account" : state.selectedAddress]
    }))
      throw rpc(4001, "Connection rejected.");
    await hydrateSession();
    if (!sessionVault)
      throw rpc(4100, "Unlock Kaspire before connecting.");
    state.permissions[origin] = { accounts: true, connectedAt: Date.now() };
    await saveState(state);
    return [state.network === "kasplex" || state.network === "igra" ? (await evmContext(state)).address : state.selectedAddress];
  }
  if (!safe.has(method) && !permitted)
    throw rpc(4100, "Connect this site to Kaspire first.");
  if (method === "getAccounts")
    return permitted && state.selectedAddress ? [state.network === "kasplex" || state.network === "igra" ? (await evmContext(state)).address : state.selectedAddress] : [];
  if (method === "getNetwork") return state.network;
  if (method === "getBalance") {
    if (!state.selectedAddress) throw rpc(4100, "No wallet selected.");
    if (state.network === "kasplex" || state.network === "igra") return evmWalletSnapshot(state);
    return walletSnapshot(state.selectedAddress, state.network);
  }
  if (method === "getUtxoEntries") {
    if (!state.selectedAddress) throw rpc(4100, "No wallet selected.");
    if (state.network === "kasplex" || state.network === "igra") throw rpc(-32601, "UTXOs are not used on this Layer 2 network.");
    return (await walletSnapshot(state.selectedAddress, state.network)).utxos;
  }
  if (method === "disconnect") {
    delete state.permissions[origin];
    await saveState(state);
    return true;
  }
  if (method === "switchNetwork") {
    const network = params?.network;
    if (!["mainnet", "testnet-10", "kasplex", "igra"].includes(String(network)))
      throw rpc(-32602, "Unsupported Kaspa network.");
    if (network === state.network) return network;
    if (!await approve({
      origin,
      title: `Switch to ${network === "mainnet" ? "Mainnet" : network === "testnet-10" ? "TN10" : network === "kasplex" ? "Kasplex" : "Igra"}?`,
      description: "All Kaspire wallet addresses and subsequent requests will use this network.",
      details: ["Existing keys and derivation paths do not change."]
    }))
      throw rpc(4001, "Network switch rejected.");
    await convertNetwork(state, network);
    return network;
  }
  if (method === "pushTx") {
    const transaction = typeof params === "string" ? params : String(params?.txJsonString ?? "");
    if (!transaction || transaction.length > 1048576)
      throw rpc(-32602, "Invalid signed transaction.");
    try {
      JSON.parse(transaction);
    } catch {
      throw rpc(-32602, "Signed transaction is not valid JSON.");
    }
    return broadcast(transaction, state.network);
  }
  if (!sessionVault) throw rpc(4100, "Unlock Kaspire before signing.");
  if (method === "getPublicKey") {
    if (!state.selectedAddress) throw rpc(4100, "No wallet selected.");
    const entry = state.addresses.find(
      (item) => item.address === state.selectedAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw rpc(4100, "Selected wallet has no public key.");
    return (await core()).publicKey(signingSecret(wallet, entry));
  }
  if (method === "signMessage") {
    const message = String(params?.message ?? "");
    const address = String(
      params?.address ?? state.selectedAddress ?? ""
    );
    if (!message || message.length > 1e4 || address !== state.selectedAddress)
      throw rpc(-32602, "Invalid personal-message request.");
    const entry = state.addresses.find((item) => item.address === address);
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw rpc(4100, "Selected wallet cannot sign.");
    if (!await approve({
      origin,
      title: "Sign personal message?",
      description: "This does not send funds, but a signature can prove wallet ownership.",
      details: [`Address: ${address}`, `Message: ${message}`]
    }))
      throw rpc(4001, "Signature rejected.");
    lastActivity = Date.now();
    return {
      address,
      signature: (await core()).signPersonalMessage(
        signingSecret(wallet, entry),
        address,
        message
      )
    };
  }
  if (method === "sendKaspa") {
    const input = params;
    const allowed = /* @__PURE__ */ new Set(["to", "amountSompi", "from"]);
    if (!input || typeof input !== "object" || Object.keys(input).some((key2) => !allowed.has(key2)))
      throw rpc(-32602, "Invalid KAS payment request.");
    const recipient = String(input.to ?? "");
    const senderAddress = String(input.from ?? state.selectedAddress ?? "");
    const amount = typeof input.amountSompi === "number" ? input.amountSompi : Number(String(input.amountSompi ?? ""));
    if (senderAddress !== state.selectedAddress || !/^kaspa(test)?:[a-z0-9]{61,63}$/.test(recipient) || !Number.isSafeInteger(amount) || amount <= 0 || amount > 21e14)
      throw rpc(-32602, "Invalid KAS payment request.");
    const entry = state.addresses.find(
      (item) => item.address === senderAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw rpc(4100, "Selected wallet cannot sign.");
    const spend = await spendingData(senderAddress, state.network);
    const request2 = {
      sender: senderAddress,
      recipient,
      amountSompi: amount,
      feeRate: spend.feeRate,
      utxosJson: spend.utxosJson,
      sendAll: false
    };
    const wasm3 = await core();
    const review = JSON.parse(wasm3.prepareTransaction(JSON.stringify(request2)));
    if (!await approve({
      origin,
      title: "Approve KAS payment?",
      description: "Kaspire rebuilt and reviewed this transaction in its Rust security core.",
      details: [
        `Send: ${(review.amountSompi / 1e8).toLocaleString("en-US")} KAS`,
        `To: ${review.recipient}`,
        `Fee: ${(review.feeSompi / 1e8).toLocaleString("en-US")} KAS`,
        `Change: ${(review.changeSompi / 1e8).toLocaleString("en-US")} KAS`,
        `${review.inputCount.toLocaleString("en-US")} inputs \xB7 ${review.outputCount.toLocaleString("en-US")} outputs`
      ],
      rawJson: { request: request2, review }
    }))
      throw rpc(4001, "Payment rejected.");
    const signed = JSON.parse(
      wasm3.signTransaction(
        signingSecret(wallet, entry),
        JSON.stringify(request2),
        review.reviewHash
      )
    );
    const broadcastId = await broadcast(signed.submitJson, state.network);
    if (broadcastId && broadcastId !== signed.transactionId)
      throw rpc(-32e3, "Node returned a mismatching transaction ID.");
    lastActivity = Date.now();
    return signed.transactionId;
  }
  if (method === "signPskt") {
    const input = params;
    const senderAddress = String(input?.sender ?? state.selectedAddress ?? "");
    const signInputs = input?.options?.signInputs ?? input?.signInputs;
    if (!input || senderAddress !== state.selectedAddress || typeof input.txJsonString !== "string" || !Array.isArray(signInputs))
      throw rpc(-32602, "Invalid PSKT request.");
    const entry = state.addresses.find(
      (item) => item.address === senderAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw rpc(4100, "Selected wallet cannot sign.");
    const request2 = {
      sender: senderAddress,
      txJsonString: input.txJsonString,
      signInputs
    };
    const wasm3 = await core();
    const review = JSON.parse(wasm3.preparePskt(JSON.stringify(request2)));
    const warningDetails = review.warnings.map(
      (item) => `Warning: ${item}`
    );
    if (!await approve({
      origin,
      title: "Approve reviewed PSKT?",
      description: "Kaspire will sign only the selected inputs shown by the Rust security core.",
      details: [
        `Transaction: ${review.transactionId}`,
        `Fee: ${(review.feeSompi / 1e8).toLocaleString("en-US")} KAS`,
        `Wallet net: ${(review.walletNetSompi / 1e8).toLocaleString("en-US")} KAS`,
        `${review.selectedInputCount.toLocaleString("en-US")} of ${review.inputCount.toLocaleString("en-US")} inputs selected`,
        ...warningDetails
      ],
      rawJson: { request: request2, review }
    }))
      throw rpc(4001, "PSKT signature rejected.");
    lastActivity = Date.now();
    return JSON.parse(
      wasm3.signPskt(
        signingSecret(wallet, entry),
        JSON.stringify(request2),
        review.reviewHash
      )
    ).signedTxJson;
  }
  if (method === "signPolicyTransaction") {
    const input = params;
    const senderAddress = String(input?.sender ?? state.selectedAddress ?? "");
    if (!input || senderAddress !== state.selectedAddress || typeof input.txJsonString !== "string" || !Array.isArray(input.signInputIndexes) || typeof (input.redeemScript ?? "") !== "string")
      throw rpc(-32602, "Invalid policy transaction request.");
    const entry = state.addresses.find(
      (item) => item.address === senderAddress
    );
    const wallet = sessionVault.wallets.find(
      (item) => item.id === entry?.walletId
    );
    if (!entry || entry.watchOnly || !wallet)
      throw rpc(4100, "Selected wallet cannot sign.");
    const request2 = {
      sender: senderAddress,
      txJsonString: input.txJsonString,
      signInputIndexes: input.signInputIndexes,
      redeemScript: input.redeemScript ?? ""
    };
    const wasm3 = await core();
    const review = JSON.parse(
      wasm3.preparePolicyTransaction(JSON.stringify(request2))
    );
    if (!await approve({
      origin,
      title: "Approve vault transaction?",
      description: "Kaspire recognized and reconstructed a supported KasCoven vault policy.",
      details: [
        `Action: ${review.action}`,
        `Profile: ${review.profile}`,
        `Vault amount: ${review.vaultAmountSompi / 1e8} KAS`,
        `Fee: ${formatSompi(review.feeSompi)} KAS`,
        `${review.inputCount} inputs \xB7 ${review.outputCount} outputs`
      ]
    }))
      throw rpc(4001, "Policy transaction rejected.");
    lastActivity = Date.now();
    const signed = JSON.parse(
      wasm3.signPolicyTransaction(
        signingSecret(wallet, entry),
        JSON.stringify(request2),
        review.reviewHash
      )
    );
    return {
      signedTxJson: signed.signedTxJson,
      profile: review.profile,
      reviewHash: review.reviewHash
    };
  }
  if (method === "sendKCC20")
    return kcc20Transfer(origin, params, state, sessionVault);
  if (method === "sendKRC20" || method === "transferKRC721" || method === "transferKNS")
    return inscriptionTransfer(origin, method, params, state, sessionVault);
  throw rpc(4200, `${method} awaits the transaction approval window.`);
}
async function prepareWalletAsset(input, state, progress) {
  if (state.network !== "mainnet" || !state.selectedAddress)
    throw new Error("Kaspa assets are available on Mainnet only.");
  const sender = state.selectedAddress;
  progress("Resolving recipient\u2026");
  const recipient = await resolveWalletInput(
    String(input.to ?? ""),
    state.network
  );
  if (state.settings.recipientAllowlist && !state.contacts.some((item) => item.address === recipient) && !state.addresses.some((item) => item.address === recipient))
    throw new Error("Recipient is not in your address book.");
  const kind = String(input.kind ?? "");
  progress("Reading loaded wallet assets\u2026");
  const savedSnapshot = (await chrome.storage.session.get("assetReviewSnapshot")).assetReviewSnapshot;
  const assets = savedSnapshot?.address === sender && savedSnapshot?.network === state.network ? savedSnapshot.assets : await inscriptionAssets(sender);
  const ticker = String(input.ticker ?? "").trim().toUpperCase();
  const amount = String(input.amount ?? "");
  let prepared;
  if (kind === "kcc20") {
    const covenantId2 = String(input.covenantId ?? "").toLowerCase();
    const numericAmount = Number(amount);
    if (!/^[0-9a-f]{64}$/.test(covenantId2) || !Number.isSafeInteger(numericAmount) || numericAmount <= 0)
      throw new Error("Invalid KCC20 request.");
    const covenantAsset = (await walletAssets(sender, state.network)).kcc20.find(
      (item) => String(item.covenantId).toLowerCase() === covenantId2
    );
    if (covenantAsset?.standard === "kron-native") {
      prepared = await prepareKronTransfer(
        sender,
        recipient,
        covenantId2,
        numericAmount,
        String(input.displayAmount ?? ""),
        progress
      );
    } else {
      progress("Verifying KCC20 cells\u2026");
      const verified = await kcc20TransferData(
        sender,
        covenantId2,
        numericAmount
      );
      progress("Loading wallet UTXOs and fee\u2026");
      const funding = await spendingData(sender, state.network);
      const request2 = {
        sender,
        recipient,
        covenantId: covenantId2,
        ticker: verified.ticker,
        amount: numericAmount,
        decimals: verified.decimals,
        feeRate: funding.feeRate,
        templateHash: verified.templateHash,
        cells: verified.cells,
        fundingUtxosJson: funding.utxosJson
      };
      progress("Preparing native KCC20 review\u2026");
      const review = JSON.parse(
        (await core()).prepareKcc20Transfer(JSON.stringify(request2))
      );
      prepared = {
        type: "kcc20",
        sender,
        operation: {
          kind,
          sender,
          recipient,
          ticker: verified.ticker,
          amount,
          displayAmount: String(input.displayAmount ?? "")
        },
        request: request2,
        review,
        createdAt: Date.now()
      };
    }
  } else {
    let operation = {
      kind,
      sender,
      recipient,
      ticker: "",
      amount: "",
      tokenId: "",
      assetId: ""
    };
    if (kind === "krc20") {
      if (!/^[A-Z0-9_-]{1,32}$/.test(ticker) || !/^[0-9]+$/.test(amount) || BigInt(amount) <= 0n)
        throw new Error("Invalid KRC-20 amount or ticker.");
      const holding = assets.tokens.find(
        (item) => String(item.symbol).toUpperCase() === ticker
      );
      if (!holding || BigInt(amount) > BigInt(String(holding.raw_balance ?? "0")))
        throw new Error(
          "Invalid amount, too many decimals, or insufficient token balance."
        );
      operation = {
        ...operation,
        ticker,
        amount,
        displayAmount: String(input.displayAmount ?? "")
      };
    } else if (kind === "kns") {
      const assetId = String(input.assetId ?? "").toLowerCase();
      const domain = assets.domains.find(
        (item) => String(item.asset_id).toLowerCase() === assetId
      );
      if (!/^[0-9a-f]{64}i0$/.test(assetId) || !domain)
        throw new Error(
          "The KNS indexer did not provide this domain asset ID. Refresh and try again."
        );
      operation = {
        ...operation,
        assetId,
        domainName: String(domain.name ?? "")
      };
    } else if (kind === "krc721") {
      const tokenId = String(input.tokenId ?? "").trim();
      if (!/^[A-Z0-9_-]{1,32}$/.test(ticker) || !tokenId || tokenId.length > 128 || !assets.krc721.some(
        (item) => String(item.symbol).toUpperCase() === ticker
      ))
        throw new Error("Select a held KRC-721 NFT.");
      operation = { ...operation, ticker, tokenId };
    } else throw new Error("Unsupported asset kind.");
    progress("Preparing native inscription plan\u2026");
    const wasm3 = await core();
    const plan = JSON.parse(wasm3.prepareInscription(JSON.stringify(operation)));
    progress("Loading wallet UTXOs and fee\u2026");
    const spend = await spendingData(sender, state.network);
    const request2 = {
      sender,
      walletAddress: sender,
      recipient: plan.commitAddress,
      amountSompi: plan.commitAmountSompi,
      feeRate: spend.feeRate,
      utxosJson: spend.utxosJson,
      sendAll: false
    };
    progress("Preparing native commit review\u2026");
    const review = JSON.parse(wasm3.prepareTransaction(JSON.stringify(request2)));
    prepared = {
      type: "inscription",
      sender,
      operation,
      plan,
      request: request2,
      review,
      createdAt: Date.now()
    };
  }
  const preparedId = crypto.randomUUID();
  progress("Opening secure review\u2026");
  await chrome.storage.session.set({
    preparedAsset: { id: preparedId, ...prepared }
  });
  return {
    preparedId,
    type: prepared.type,
    operation: prepared.operation,
    review: prepared.review,
    plan: prepared.plan
  };
}
function hexBytes(value) {
  if (!/^[0-9a-f]+$/i.test(value) || value.length % 2)
    throw new Error("Invalid hexadecimal covenant data.");
  return Uint8Array.from(
    value.match(/../g).map((byte) => Number.parseInt(byte, 16))
  );
}
function kronSafeScript(value) {
  const json = typeof value?.toJSON === "function" ? value.toJSON() : value ?? {}, version2 = Number(json.version ?? 0), script = String(json.script ?? json.scriptPublicKey ?? value ?? "");
  if (!Number.isInteger(version2) || version2 < 0 || version2 > 65535 || !/^[0-9a-f]+$/i.test(script))
    throw new Error("Invalid KRON script public key.");
  const versionHex = version2.toString(16).padStart(4, "0").match(/../g).reverse().join("");
  return `${versionHex}${script.toLowerCase()}`;
}
function assembleKronSafeTransaction(kaspa, covenantSpend, fundingEntries, changeAddress, networkFee) {
  const covenantInputs = covenantSpend.inputs.map((input) => ({
    transactionId: input.transactionId,
    index: input.index,
    sequence: "0",
    sigOpCount: 0,
    computeBudget: input.computeBudget ?? spend_exports.TOKEN_COMPUTE,
    signatureScript: input.signatureScript,
    utxo: {
      address: null,
      amount: String(input.value),
      scriptPublicKey: kronSafeScript(input.scriptPublicKey),
      blockDaaScore: "0",
      isCoinbase: false,
      covenantId: null
    }
  }));
  const fundingInputs = fundingEntries.map((entry) => ({
    transactionId: entry.outpoint.transactionId,
    index: entry.outpoint.index,
    sequence: "0",
    sigOpCount: 0,
    computeBudget: spend_exports.FUNDING_COMPUTE,
    signatureScript: "",
    utxo: {
      address: null,
      amount: String(entry.amount),
      scriptPublicKey: kronSafeScript(entry.scriptPublicKey),
      blockDaaScore: String(entry.blockDaaScore ?? 0),
      isCoinbase: entry.isCoinbase === true,
      covenantId: null
    }
  }));
  const covenantInputValue = Array.from(
    covenantSpend.inputs
  ).reduce((sum, input) => sum + BigInt(input.value), 0n), fundingTotal = fundingEntries.reduce(
    (sum, entry) => sum + BigInt(entry.amount),
    0n
  ), covenantOutputValue = Array.from(covenantSpend.outputs).reduce(
    (sum, output) => sum + BigInt(output.value),
    0n
  ), change = covenantInputValue + fundingTotal - covenantOutputValue - networkFee;
  if (change < 0n)
    throw new Error("Insufficient KAS funding for KRON transaction.");
  const outputs = covenantSpend.outputs.map((output) => ({
    value: String(output.value),
    scriptPublicKey: kronSafeScript(output.scriptPublicKey),
    covenant: {
      authorizingInput: Number(output.binding.authorizingInput),
      covenantId: String(output.binding.covid)
    }
  }));
  outputs.push({
    value: String(change),
    scriptPublicKey: kronSafeScript(kaspa.payToAddressScript(changeAddress))
  });
  const transaction = kaspa.Transaction.deserializeFromSafeJSON(
    JSON.stringify({
      id: "00".repeat(32),
      version: spend_exports.TX_VERSION,
      inputs: [...covenantInputs, ...fundingInputs],
      outputs,
      subnetworkId: "00".repeat(20),
      lockTime: "0",
      gas: "0",
      storageMass: "0",
      payload: ""
    })
  );
  transaction.finalize();
  return {
    transaction,
    fundingInputIndexes: fundingInputs.map(
      (_, index) => index + covenantInputs.length
    ),
    totalIn: covenantInputValue + fundingTotal,
    covenantOut: covenantOutputValue,
    change
  };
}
function estimateKronFeeWithoutMutation(assembled, feeRateSompiPerGram) {
  const transaction = assembled.transaction, placeholderBytes = 66n * BigInt(assembled.fundingInputIndexes.length), serializedBytes = BigInt(spend_exports.estimatedSerializedSize(transaction)) + placeholderBytes, normalizedTransient = (serializedBytes * 4n * 500000n + 1000000n - 1n) / 1000000n, computeGrams = Array.from(transaction.inputs ?? []).reduce(
    (sum, input) => sum + BigInt(input.computeBudget ?? 0) * 100n,
    0n
  ), computeMass = 2000n + computeGrams, billableMass = computeMass > normalizedTransient ? computeMass : normalizedTransient, rate = BigInt(
    Math.max(Math.ceil(feeRateSompiPerGram), spend_exports.MIN_RELAY_FEERATE)
  ), fee = billableMass * rate * 6n / 5n;
  return fee > 10000n ? fee : 10000n;
}
async function prepareKronTransfer(sender, recipient, covenantId2, amount, displayAmount, progress) {
  let stage = "cell discovery";
  try {
    progress("Verifying KRON token cells\u2026");
    const verified = await kronTransferData(sender, covenantId2, amount);
    stage = "WASM loading";
    progress("Loading KRON covenant engine\u2026");
    const kaspa = await loadKaspa(
      chrome.runtime.getURL("wasm/kron_kaspa_bg.wasm")
    );
    stage = "cell decoding";
    const decoded = verified.cells.map((cell) => ({
      cell,
      decoded: kcc20Tx_exports.decodeKcc20Redeem(hexBytes(cell.redeemScript), {
        maxIns: 4,
        maxOuts: 4
      })
    }));
    const first = decoded[0];
    if (!first) throw new Error("No spendable KRON token cells were found.");
    const template = first.decoded.template;
    for (const item of decoded) {
      if (item.decoded.state.identifierType !== kcc20Tx_exports.IDENTIFIER.ADDRESS || item.decoded.state.amount !== BigInt(item.cell.tokenAmount))
        throw new Error(
          "KRON cell ownership or amount did not match its verified state."
        );
    }
    stage = "recipient script";
    const recipientScript = String(
      kaspa.payToAddressScript(recipient).script ?? ""
    ), recipientMatch = /^20([0-9a-f]{64})ac$/i.exec(recipientScript);
    if (!recipientMatch?.[1])
      throw new Error("KRON transfers require a standard P2PK recipient.");
    stage = "covenant transition";
    const senderTokens = decoded.map((item) => ({
      transactionId: item.cell.transactionId,
      index: item.cell.index,
      value: BigInt(item.cell.value),
      state: item.decoded.state
    }));
    const covenantSpend = kcc20Tx_exports.buildKcc20Send(
      kaspa,
      template,
      senderTokens,
      hexBytes(recipientMatch[1]),
      BigInt(amount),
      senderTokens.length,
      covenantId2
    );
    for (const output of covenantSpend.outputs) {
      if (output.binding?.covid !== covenantId2 || !/^[0-9a-f]{64}$/.test(output.binding.covid))
        throw new Error("Generated output has an invalid covenant binding.");
    }
    stage = "KAS funding";
    progress("Loading KAS funding and fee estimate\u2026");
    const funding = await spendingData(sender, "mainnet"), rows = JSON.parse(funding.utxosJson).map((row) => {
      const entry = row.utxoEntry ?? {}, nested = entry.scriptPublicKey ?? {}, script = String(
        typeof nested === "string" ? nested : nested.script ?? nested.scriptPublicKey ?? ""
      );
      if (!/^[0-9a-f]+$/i.test(script))
        throw new Error("Kaspa node returned an invalid funding script.");
      return {
        outpoint: row.outpoint,
        amount: BigInt(entry.amount),
        scriptPublicKey: { version: Number(nested.version ?? 0), script },
        blockDaaScore: BigInt(entry.blockDaaScore ?? 0),
        isCoinbase: entry.isCoinbase === true
      };
    }).sort(
      (a, b) => a.amount > b.amount ? -1 : a.amount < b.amount ? 1 : 0
    );
    const selected = [];
    let total = 0n;
    for (const row of rows) {
      selected.push(row);
      total += row.amount;
      if (total >= 100000000n) break;
    }
    if (total < 50100000n)
      throw new Error(
        "At least about 0.51 KAS is required for the KRON token carrier and network fee."
      );
    stage = "initial transaction assembly";
    let assembled = assembleKronSafeTransaction(
      kaspa,
      covenantSpend,
      selected,
      sender,
      10000n
    );
    stage = "fee calculation";
    const fee = estimateKronFeeWithoutMutation(assembled, funding.feeRate);
    stage = "final transaction assembly";
    assembled = assembleKronSafeTransaction(
      kaspa,
      covenantSpend,
      selected,
      sender,
      fee
    );
    stage = "SafeJSON serialization";
    const pskt = spend_exports.toPsktJson(assembled), request2 = {
      sender,
      txJsonString: pskt.txJsonString,
      signInputs: pskt.signInputs
    };
    stage = "Rust security review";
    progress("Preparing secure KRON review\u2026");
    const review = JSON.parse(
      (await core()).preparePskt(JSON.stringify(request2))
    ), rawTransaction = JSON.parse(pskt.txJsonString), inputTotalSompi = rawTransaction.inputs.reduce(
      (sum, input) => sum + BigInt(input.utxo?.amount ?? 0),
      0n
    ), outputTotalSompi = rawTransaction.outputs.reduce(
      (sum, output) => sum + BigInt(output.value ?? 0),
      0n
    ), lockedKasSompi = senderTokens.reduce(
      (sum, input) => sum + BigInt(input.value),
      0n
    ), lockedKasOutputSompi = covenantSpend.outputs.reduce(
      (sum, output) => sum + BigInt(output.value),
      0n
    ), lockedKasTopUpSompi = lockedKasOutputSompi > lockedKasSompi ? lockedKasOutputSompi - lockedKasSompi : 0n, lockedKasReleasedSompi = lockedKasSompi > lockedKasOutputSompi ? lockedKasSompi - lockedKasOutputSompi : 0n, computeBudget = rawTransaction.inputs.reduce(
      (sum, input) => sum + Number(input.computeBudget ?? 0),
      0
    ), computeMass = 2e3 + computeBudget * 100, transientMass = Number(
      (BigInt(spend_exports.estimatedSerializedSize(assembled)) * 4n * 500000n + 999999n) / 1000000n
    ), feeMass = Math.max(computeMass, transientMass);
    return {
      type: "kron",
      sender,
      operation: {
        kind: "kcc20",
        sender,
        recipient,
        ticker: verified.ticker,
        amount: String(amount),
        displayAmount: displayAmount || String(amount),
        covenantId: covenantId2
      },
      request: request2,
      review: {
        ...review,
        rawJson: rawTransaction,
        templateHash: /^[0-9a-f]{64}$/.test(verified.templateHash) ? verified.templateHash : "",
        networkFeeSompi: Number(inputTotalSompi - outputTotalSompi),
        feeSompi: Number(inputTotalSompi - outputTotalSompi),
        inputTotalSompi: Number(inputTotalSompi),
        outputTotalSompi: Number(outputTotalSompi),
        covenantInputCount: senderTokens.length,
        covenantOutputCount: covenantSpend.outputs.length,
        lockedKasSompi: Number(lockedKasSompi),
        lockedKasTopUpSompi: Number(lockedKasTopUpSompi),
        lockedKasReleasedSompi: Number(lockedKasReleasedSompi),
        lockedKasOutputSompi: Number(lockedKasOutputSompi),
        computeBudget,
        computeMass,
        transientMass,
        feeMass,
        mass: feeMass
      },
      createdAt: Date.now()
    };
  } catch (error) {
    throw new Error(
      `[Kaspire Extension ${extensionVersion} \xB7 KRON ${stage}] ${error?.message ?? error}`
    );
  }
}
async function broadcastKron(signedTxJson, expectedTransactionId) {
  const kaspa = await loadKaspa(
    chrome.runtime.getURL("wasm/kron_kaspa_bg.wasm")
  );
  let transaction;
  try {
    transaction = kaspa.Transaction.deserializeFromSafeJSON(signedTxJson);
  } catch (error) {
    throw new Error(
      `[Kaspire Extension ${extensionVersion} \xB7 KRON signed SafeJSON] ${error?.message ?? error}`
    );
  }
  const localId = String(
    transaction.id ?? transaction.getId?.() ?? ""
  ).toLowerCase();
  if (localId && localId !== expectedTransactionId.toLowerCase())
    throw new Error("KRON signed transaction ID changed after approval.");
  const safe2 = JSON.parse(signedTxJson), rpcTransaction = {
    id: String(safe2.id),
    version: Number(safe2.version),
    inputs: (safe2.inputs ?? []).map((input) => ({
      previousOutpoint: {
        transactionId: String(input.transactionId),
        index: Number(input.index)
      },
      signatureScript: String(input.signatureScript ?? ""),
      sequence: BigInt(input.sequence),
      sigOpCount: Number(input.sigOpCount),
      computeBudget: Number(input.computeBudget ?? 0)
    })),
    outputs: (safe2.outputs ?? []).map((output) => {
      const covenant = output.covenant == null ? void 0 : {
        authorizingInput: Number(output.covenant.authorizingInput),
        covenantId: String(output.covenant.covenantId).toLowerCase()
      };
      if (covenant && !/^[0-9a-f]{64}$/.test(covenant.covenantId))
        throw new Error("Signed KRON output has an invalid covenant ID.");
      return {
        value: BigInt(output.value),
        scriptPublicKey: String(output.scriptPublicKey),
        ...covenant ? { covenant } : {}
      };
    }),
    subnetworkId: String(safe2.subnetworkId),
    lockTime: BigInt(safe2.lockTime),
    gas: BigInt(safe2.gas),
    storageMass: BigInt(safe2.storageMass ?? 0),
    payload: String(safe2.payload ?? "")
  };
  let rpc2;
  try {
    const resolver = new kaspa.Resolver(), url = await resolver.getUrl("borsh", "mainnet");
    rpc2 = new kaspa.RpcClient({ url, encoding: "borsh" });
    await rpc2.connect();
    const result = await rpc2.submitTransaction({
      transaction: rpcTransaction,
      allowOrphan: false
    });
    const transactionId = String(
      result?.transactionId ?? result ?? ""
    ).toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(transactionId))
      throw new Error("Kaspa node returned no valid KRON transaction ID.");
    if (transactionId !== expectedTransactionId.toLowerCase())
      throw new Error("Kaspa node returned a mismatching KRON transaction ID.");
    return transactionId;
  } catch (error) {
    throw new Error(
      `[Kaspire Extension ${extensionVersion} \xB7 KRON wRPC broadcast] ${error?.message ?? error}`
    );
  } finally {
    try {
      await rpc2?.disconnect();
    } catch {
    }
  }
}
async function confirmPreparedAsset(preparedId, state, vault) {
  const stored = (await chrome.storage.session.get("preparedAsset")).preparedAsset;
  if (!stored || stored.id !== preparedId || Date.now() - stored.createdAt > 15 * 6e4)
    throw new Error("Prepared asset review expired. Prepare it again.");
  if (stored.sender !== state.selectedAddress)
    throw new Error("The selected wallet changed after review.");
  const entry = state.addresses.find((item) => item.address === stored.sender);
  const wallet = vault.wallets.find((item) => item.id === entry?.walletId);
  if (!entry || entry.watchOnly || !wallet)
    throw new Error("Selected wallet cannot sign.");
  const wasm3 = await core();
  if (stored.type === "kcc20") {
    if (!await approve({
      origin: "Kaspire Wallet",
      title: "Authorize KCC20 covenant transfer?",
      description: "Verify the native Rust review before signing.",
      details: kcc20ReviewDetails(stored.operation, stored.review),
      rawJson: stored.review.rawJson ?? stored.request
    }))
      throw rpc(4001, "KCC20 transfer rejected.");
    const signed = JSON.parse(
      wasm3.signKcc20Transfer(
        signingSecret(wallet, entry),
        JSON.stringify(stored.request),
        stored.review.reviewHash
      )
    );
    await broadcastKcc20(signed.wrpcJson, signed.transactionId);
    await recordWalletActivity(stored.sender, {
      transactionId: signed.transactionId,
      blockTime: Date.now(),
      isAccepted: true,
      incoming: false,
      assetKind: "KCC20",
      assetSymbol: stored.operation.ticker,
      displayAmount: stored.operation.displayAmount || stored.operation.amount,
      tokenId: stored.request.covenantId,
      covenantId: stored.review.covenantId,
      templateHash: stored.review.templateHash,
      counterparty: stored.operation.recipient,
      from: [{ address: stored.sender, ownerId: "" }],
      to: [{ address: stored.operation.recipient, ownerId: "" }],
      feeSompi: stored.review.feeSompi,
      inputCount: stored.review.covenantInputCount,
      outputCount: stored.review.covenantOutputCount,
      mass: stored.review.mass,
      computeMass: stored.review.computeMass,
      storageMass: stored.review.storageMass,
      storageMassTarget: stored.review.storageMassTarget,
      transientMass: stored.review.transientMass,
      feeMass: stored.review.feeMass,
      computeBudget: stored.review.computeBudget,
      lockedKasSompi: stored.review.lockedKasSompi,
      lockedKasTopUpSompi: stored.review.lockedKasTopUpSompi,
      lockedKasReleasedSompi: stored.review.lockedKasReleasedSompi,
      lockedKasOutputSompi: stored.review.lockedKasOutputSompi,
      type: "transfer"
    });
    await chrome.storage.session.remove("preparedAsset");
    return {
      kind: "kcc20",
      transactionId: signed.transactionId,
      revealTransactionId: signed.transactionId,
      revealFeeSompi: stored.review.feeSompi
    };
  }
  if (stored.type === "kron") {
    const warnings = (stored.review.warnings ?? []).map(
      (item) => `Warning: ${item}`
    );
    if (!await approve({
      origin: "Kaspire Wallet",
      title: `Authorize ${stored.operation.ticker} transfer?`,
      description: "Kaspire independently reviewed the KRON covenant PSKT and will sign only the selected P2PK funding inputs.",
      details: [
        `Send: ${stored.operation.displayAmount} ${stored.operation.ticker}`,
        `To: ${stored.operation.recipient}`,
        `Covenant ID: ${stored.operation.covenantId}`,
        `Network fee: ${formatSompi(stored.review.networkFeeSompi)} KAS`,
        `${stored.review.covenantInputCount} covenant input(s) \xB7 ${stored.review.covenantOutputCount} covenant output(s)`,
        `${stored.review.selectedInputCount} of ${stored.review.inputCount} inputs selected for signing`,
        ...warnings
      ],
      rawJson: stored.review.rawJson ?? {
        request: stored.request,
        review: stored.review
      }
    }))
      throw rpc(4001, "KRON transfer rejected.");
    const signed = JSON.parse(
      wasm3.signPskt(
        signingSecret(wallet, entry),
        JSON.stringify(stored.request),
        stored.review.reviewHash
      )
    ).signedTxJson;
    await broadcastKron(signed, stored.review.transactionId);
    await recordWalletActivity(stored.sender, {
      transactionId: stored.review.transactionId,
      blockTime: Date.now(),
      isAccepted: true,
      incoming: false,
      assetKind: "KCC20",
      assetSymbol: stored.operation.ticker,
      displayAmount: stored.operation.displayAmount,
      tokenId: stored.operation.covenantId,
      covenantId: stored.operation.covenantId,
      templateHash: stored.review.templateHash,
      counterparty: stored.operation.recipient,
      from: [{ address: stored.sender }],
      to: [{ address: stored.operation.recipient }],
      feeSompi: stored.review.feeSompi,
      totalInputSompi: stored.review.inputTotalSompi,
      totalOutputSompi: stored.review.outputTotalSompi,
      inputCount: stored.review.covenantInputCount,
      outputCount: stored.review.covenantOutputCount,
      mass: stored.review.mass,
      computeMass: stored.review.computeMass,
      transientMass: stored.review.transientMass,
      feeMass: stored.review.feeMass,
      computeBudget: stored.review.computeBudget,
      lockedKasSompi: stored.review.lockedKasSompi,
      lockedKasTopUpSompi: stored.review.lockedKasTopUpSompi,
      lockedKasReleasedSompi: stored.review.lockedKasReleasedSompi,
      lockedKasOutputSompi: stored.review.lockedKasOutputSompi,
      rawJson: JSON.parse(signed),
      type: "kron-transfer",
      standard: "kron-native"
    });
    await chrome.storage.session.remove("preparedAsset");
    return {
      kind: "kcc20",
      transactionId: stored.review.transactionId,
      revealTransactionId: stored.review.transactionId,
      revealFeeSompi: stored.review.feeSompi
    };
  }
  if (!await approve({
    origin: "Kaspire Wallet",
    title: "Authorize asset commit?",
    description: "This signs the commit transaction shown in the preceding review.",
    details: [
      `To: ${stored.operation.recipient}`,
      `Temporary commit: ${formatSompi(stored.review.amountSompi)} KAS`,
      `Fee: ${formatSompi(stored.review.feeSompi)} KAS`
    ]
  }))
    throw rpc(4001, "Asset transfer rejected.");
  const signedCommit = JSON.parse(
    wasm3.signTransaction(
      signingSecret(wallet, entry),
      JSON.stringify(stored.request),
      stored.review.reviewHash
    )
  );
  const id = await broadcast(signedCommit.submitJson, state.network);
  if (id && id !== signedCommit.transactionId)
    throw new Error("Node returned a mismatching commit ID.");
  const pending = {
    operation: stored.operation,
    plan: stored.plan,
    commitTransactionId: signedCommit.transactionId,
    commitFeeSompi: stored.review.feeSompi,
    createdAt: Date.now(),
    state: "commit-accepted"
  };
  await chrome.storage.local.set({ pendingInscription: pending });
  await chrome.storage.session.remove("preparedAsset");
  return finishPendingInscription("Kaspire Wallet", pending, state, vault);
}
async function inscriptionTransfer(origin, method, params, state, vault) {
  if (state.network !== "mainnet")
    throw rpc(4200, "Kaspa inscription assets are available on Mainnet only.");
  const input = params;
  const sender = String(input?.from ?? state.selectedAddress ?? "");
  const recipient = String(input?.to ?? "");
  if (!input || sender !== state.selectedAddress || !/^kaspa:[a-z0-9]{61,63}$/.test(recipient))
    throw rpc(-32602, "Invalid asset transfer request.");
  const entry = state.addresses.find((item) => item.address === sender);
  const wallet = vault.wallets.find((item) => item.id === entry?.walletId);
  if (!entry || entry.watchOnly || !wallet)
    throw rpc(4100, "Selected wallet cannot sign.");
  const assets = await inscriptionAssets(sender);
  let operation;
  if (method === "sendKRC20") {
    const ticker = String(input.ticker ?? "").trim().toUpperCase();
    const amount = String(input.amount ?? "");
    if (!/^[A-Z0-9_-]{1,32}$/.test(ticker) || !/^\d+$/.test(amount) || amount === "0")
      throw rpc(-32602, "Invalid KRC-20 amount or ticker.");
    const holding = assets.tokens.find(
      (item) => item.symbol.toUpperCase() === ticker
    );
    if (!holding || BigInt(amount) > BigInt(holding.raw_balance))
      throw rpc(-32602, "Insufficient verified KRC-20 balance.");
    const displayAmount = formatRawTokenAmount(
      amount,
      Number(holding.decimals ?? 8)
    );
    operation = {
      kind: "krc20",
      sender,
      recipient,
      ticker,
      amount,
      displayAmount,
      tokenId: `krc20-${ticker.toLowerCase()}`,
      assetId: ""
    };
  } else if (method === "transferKNS") {
    const assetId = String(input.assetId ?? "").toLowerCase();
    if (!/^[0-9a-f]{64}i0$/.test(assetId) || !assets.domains.some((item) => item.asset_id === assetId))
      throw rpc(
        -32602,
        "The selected wallet does not own this verified KNS asset."
      );
    operation = {
      kind: "kns",
      sender,
      recipient,
      ticker: "",
      amount: "",
      tokenId: "",
      assetId
    };
  } else {
    const ticker = String(input.ticker ?? "").trim().toUpperCase();
    const tokenId = String(input.tokenId ?? "").trim();
    if (!/^[A-Z0-9_-]{1,32}$/.test(ticker) || !tokenId || tokenId.length > 128 || !assets.krc721.some(
      (item) => item.symbol.toUpperCase() === ticker
    ) || !await verifyKrc721Ownership(sender, ticker, tokenId))
      throw rpc(
        -32602,
        "The selected wallet does not own this verified KRC-721 token."
      );
    operation = {
      kind: "krc721",
      sender,
      recipient,
      ticker,
      amount: "",
      tokenId,
      assetId: ""
    };
  }
  const wasm3 = await core();
  const plan = JSON.parse(wasm3.prepareInscription(JSON.stringify(operation)));
  const spend = await spendingData(sender, state.network);
  const commitRequest = {
    sender,
    recipient: plan.commitAddress,
    amountSompi: plan.commitAmountSompi,
    feeRate: spend.feeRate,
    utxosJson: spend.utxosJson,
    sendAll: false
  };
  const commit = JSON.parse(
    wasm3.prepareTransaction(JSON.stringify(commitRequest))
  );
  const label = method === "sendKRC20" ? `${operation.amount} raw units ${operation.ticker}` : method === "transferKNS" ? `KNS ${operation.assetId}` : `${operation.ticker} #${operation.tokenId}`;
  if (!await approve({
    origin,
    title: "Approve asset commit?",
    description: "This is step 1 of the Kaspa commit/reveal transfer.",
    details: [
      label,
      `To: ${recipient}`,
      `Commit: ${plan.commitAmountSompi / 1e8} KAS`,
      `Fee: ${formatSompi(commit.feeSompi)} KAS`
    ]
  }))
    throw rpc(4001, "Asset transfer rejected.");
  const signedCommit = JSON.parse(
    wasm3.signTransaction(
      signingSecret(wallet, entry),
      JSON.stringify(commitRequest),
      commit.reviewHash
    )
  );
  const id = await broadcast(signedCommit.submitJson, state.network);
  if (id && id !== signedCommit.transactionId)
    throw rpc(-32e3, "Node returned a mismatching commit ID.");
  await chrome.storage.local.set({
    pendingInscription: {
      operation,
      plan,
      commitTransactionId: signedCommit.transactionId,
      createdAt: Date.now()
    }
  });
  const commitUtxosJson = await waitForUtxo(
    plan.commitAddress,
    signedCommit.transactionId,
    state.network
  );
  const revealRequest = {
    operation,
    commitTransactionId: signedCommit.transactionId,
    commitUtxosJson,
    feeRate: (await spendingData(plan.commitAddress, state.network)).feeRate
  };
  const reveal = JSON.parse(wasm3.prepareReveal(JSON.stringify(revealRequest)));
  if (!await approve({
    origin,
    title: "Approve asset reveal?",
    description: "This final transaction publishes the reviewed asset transfer.",
    details: [
      label,
      `To: ${recipient}`,
      `Reveal fee: ${formatSompi(reveal.feeSompi)} KAS`,
      `Commit transaction: ${signedCommit.transactionId}`
    ]
  }))
    throw rpc(
      4001,
      "Reveal rejected; the commit remains recoverable in Kaspire."
    );
  const signedReveal = JSON.parse(
    wasm3.signReveal(
      signingSecret(wallet, entry),
      JSON.stringify(revealRequest),
      reveal.reviewHash
    )
  );
  const revealId = await broadcast(signedReveal.submitJson, state.network);
  if (revealId && revealId !== signedReveal.transactionId)
    throw rpc(-32e3, "Node returned a mismatching reveal ID.");
  await recordWalletActivity(sender, {
    transactionId: signedReveal.transactionId,
    commitTransactionId: signedCommit.transactionId,
    blockTime: Date.now(),
    isAccepted: true,
    incoming: false,
    assetKind: operation.kind === "krc721" ? "KRC-721" : operation.kind === "kns" ? "KNS" : "KRC-20",
    assetSymbol: operation.ticker || operation.assetId || "KNS",
    displayAmount: operation.displayAmount || (operation.kind === "krc721" ? "1" : ""),
    tokenId: operation.tokenId || operation.assetId || "",
    counterparty: recipient,
    from: [{ address: sender }],
    to: [{ address: recipient }],
    feeSompi: reveal.feeSompi,
    type: "transfer"
  });
  await chrome.storage.local.remove("pendingInscription");
  lastActivity = Date.now();
  return {
    kind: operation.kind,
    commitTransactionId: signedCommit.transactionId,
    revealTransactionId: signedReveal.transactionId,
    commitFeeSompi: commit.feeSompi,
    revealFeeSompi: reveal.feeSompi
  };
}
async function kcc20Transfer(origin, params, state, vault) {
  if (state.network !== "mainnet")
    throw rpc(4200, "KCC20 is available on Mainnet only.");
  const input = params;
  const sender = String(input?.from ?? state.selectedAddress ?? "");
  const recipient = String(input?.to ?? "");
  const covenantId2 = String(input?.covenantId ?? "").toLowerCase();
  const amount = Number(String(input?.amount ?? ""));
  if (sender !== state.selectedAddress || !/^kaspa:[a-z0-9]{61,63}$/.test(recipient) || !/^[0-9a-f]{64}$/.test(covenantId2) || !Number.isSafeInteger(amount) || amount <= 0)
    throw rpc(-32602, "Invalid KCC20 request.");
  const entry = state.addresses.find((item) => item.address === sender);
  const wallet = vault.wallets.find((item) => item.id === entry?.walletId);
  if (!entry || entry.watchOnly || !wallet)
    throw rpc(4100, "Selected wallet cannot sign.");
  const verified = await kcc20TransferData(sender, covenantId2, amount);
  const funding = await spendingData(sender, state.network);
  const request2 = {
    sender,
    recipient,
    covenantId: covenantId2,
    ticker: verified.ticker,
    amount,
    decimals: verified.decimals,
    feeRate: funding.feeRate,
    templateHash: verified.templateHash,
    cells: verified.cells,
    fundingUtxosJson: funding.utxosJson
  };
  const wasm3 = await core();
  const review = JSON.parse(wasm3.prepareKcc20Transfer(JSON.stringify(request2)));
  const display = (amount / 10 ** verified.decimals).toLocaleString("en-US", {
    maximumFractionDigits: verified.decimals
  });
  if (!await approve({
    origin,
    title: "Approve verified KCC20 transfer?",
    description: "Kaspire checked indexer cells against the local node and executes the covenant locally.",
    details: kcc20ReviewDetails(
      { ticker: verified.ticker, displayAmount: display, recipient },
      review
    ),
    rawJson: { request: request2, review }
  }))
    throw rpc(4001, "KCC20 transfer rejected.");
  const signed = JSON.parse(
    wasm3.signKcc20Transfer(
      signingSecret(wallet, entry),
      JSON.stringify(request2),
      review.reviewHash
    )
  );
  await broadcastKcc20(signed.wrpcJson, signed.transactionId);
  await recordWalletActivity(sender, {
    transactionId: signed.transactionId,
    blockTime: Date.now(),
    isAccepted: true,
    incoming: false,
    assetKind: "KCC20",
    assetSymbol: verified.ticker,
    displayAmount: display,
    tokenId: covenantId2,
    covenantId: review.covenantId,
    templateHash: review.templateHash,
    counterparty: recipient,
    from: [{ address: sender }],
    to: [{ address: recipient }],
    feeSompi: review.feeSompi,
    inputCount: review.covenantInputCount,
    outputCount: review.covenantOutputCount,
    mass: review.mass,
    computeMass: review.computeMass,
    storageMass: review.storageMass,
    storageMassTarget: review.storageMassTarget,
    transientMass: review.transientMass,
    feeMass: review.feeMass,
    computeBudget: review.computeBudget,
    lockedKasSompi: review.lockedKasSompi,
    lockedKasTopUpSompi: review.lockedKasTopUpSompi,
    lockedKasReleasedSompi: review.lockedKasReleasedSompi,
    lockedKasOutputSompi: review.lockedKasOutputSompi,
    type: "transfer"
  });
  lastActivity = Date.now();
  return signed.transactionId;
}
async function finishPendingInscription(origin, pending, state, vault) {
  if (state.network !== "mainnet")
    throw new Error("Switch back to Mainnet to resume the reveal.");
  const operation = pending?.operation;
  const plan = pending?.plan;
  const commitTransactionId = String(pending?.commitTransactionId ?? "");
  if (!operation || !plan || !/^[0-9a-f]{64}$/.test(commitTransactionId))
    throw new Error("Pending reveal data is damaged.");
  const entry = state.addresses.find(
    (item) => item.address === operation.sender
  );
  const wallet = vault.wallets.find((item) => item.id === entry?.walletId);
  if (!entry || entry.watchOnly || !wallet)
    throw new Error("The wallet controlling this reveal is unavailable.");
  const commitUtxosJson = await waitForUtxo(
    plan.commitAddress,
    commitTransactionId,
    state.network
  );
  const revealRequest = {
    operation,
    commitTransactionId,
    commitUtxosJson,
    feeRate: (await spendingData(plan.commitAddress, state.network)).feeRate
  };
  const wasm3 = await core();
  const review = JSON.parse(wasm3.prepareReveal(JSON.stringify(revealRequest)));
  if (!await approve({
    origin,
    title: "Resume pending asset reveal?",
    description: "The commit is already on-chain. Verify and publish the final asset transfer.",
    details: [
      `Kind: ${operation.kind}`,
      `To: ${operation.recipient}`,
      `Reveal fee: ${formatSompi(review.feeSompi)} KAS`,
      `Commit: ${commitTransactionId}`
    ]
  }))
    throw rpc(4001, "Reveal rejected.");
  const signed = JSON.parse(
    wasm3.signReveal(
      signingSecret(wallet, entry),
      JSON.stringify(revealRequest),
      review.reviewHash
    )
  );
  const id = await broadcast(signed.submitJson, state.network);
  if (id && id !== signed.transactionId)
    throw new Error("Node returned a mismatching reveal ID.");
  await recordWalletActivity(operation.sender, {
    transactionId: signed.transactionId,
    commitTransactionId,
    blockTime: Date.now(),
    isAccepted: true,
    incoming: false,
    assetKind: operation.kind === "krc721" ? "KRC-721" : operation.kind === "kns" ? "KNS" : "KRC-20",
    assetSymbol: operation.ticker || operation.domainName || "KNS",
    displayAmount: operation.displayAmount || operation.amount || (operation.kind === "krc721" ? "1" : ""),
    tokenId: operation.tokenId || operation.assetId || "",
    counterparty: operation.recipient,
    from: [{ address: operation.sender }],
    to: [{ address: operation.recipient }],
    feeSompi: review.feeSompi,
    type: "transfer"
  });
  await chrome.storage.local.remove("pendingInscription");
  return {
    commitTransactionId,
    revealTransactionId: signed.transactionId,
    revealFeeSompi: review.feeSompi
  };
}
async function approve(input) {
  const id = crypto.randomUUID();
  const view = { id, ...input };
  return new Promise(async (resolve) => {
    const timer = setTimeout(() => {
      approvals.delete(id);
      resolve(false);
    }, 6e5);
    approvals.set(id, { view, resolve, timer });
    if (input.origin === "Kaspire Wallet") return;
    try {
      await chrome.windows.create({
        url: chrome.runtime.getURL(
          `approval.html?id=${encodeURIComponent(id)}`
        ),
        type: "popup",
        width: 430,
        height: 650,
        focused: true
      });
    } catch {
      clearTimeout(timer);
      approvals.delete(id);
      resolve(false);
    }
  });
}
function rpc(code, message) {
  return Object.assign(new Error(message), { code });
}
function formatSompi(value) {
  const sompi = BigInt(String(value));
  const digits = sompi.toString().padStart(9, "0");
  const whole = digits.slice(0, -8);
  const fraction = digits.slice(-8).replace(/0+$/g, "");
  return fraction ? `${whole}.${fraction}` : whole;
}
function kcc20ReviewDetails(operation, review) {
  return [
    `${operation.displayAmount || operation.amount} ${operation.ticker}`,
    `To: ${operation.recipient}`,
    `Covenant ID: ${review.covenantId}`,
    `Template hash: ${review.templateHash}`,
    `Covenant inputs: ${review.covenantInputCount} \xB7 outputs: ${review.covenantOutputCount}`,
    `KAS in token inputs: ${formatSompi(review.lockedKasSompi)} KAS`,
    ...Number(review.lockedKasTopUpSompi) ? [`KAS reserve top-up: ${formatSompi(review.lockedKasTopUpSompi)} KAS`] : [],
    ...Number(review.lockedKasReleasedSompi) ? [`KAS returned: ${formatSompi(review.lockedKasReleasedSompi)} KAS`] : [],
    `KAS in new token cells: ${formatSompi(review.lockedKasOutputSompi)} KAS`,
    `Network fee: ${formatSompi(review.feeSompi)} KAS`,
    `Effective mass: ${Number(review.mass).toLocaleString("en-US")}`,
    `Compute mass: ${Number(review.computeMass).toLocaleString("en-US")}`,
    `Storage mass: ${Number(review.storageMass).toLocaleString("en-US")}`,
    `Transient mass: ${Number(review.transientMass).toLocaleString("en-US")}`,
    `Fee mass: ${Number(review.feeMass).toLocaleString("en-US")}`
  ];
}
function normalize(error) {
  const item = error;
  const message = typeof item?.message === "string" ? item.message : typeof error === "string" ? error : typeof error === "object" && error ? String(error) : "Kaspire request failed.";
  return {
    code: typeof item?.code === "number" ? item.code : -32603,
    message: message && message !== "[object Object]" ? message : "Kaspire request failed. Check Network diagnostics and try again."
  };
}
//# sourceMappingURL=background.js.map
