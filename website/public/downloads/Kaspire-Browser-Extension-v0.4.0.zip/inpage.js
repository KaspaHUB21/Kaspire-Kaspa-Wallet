// src/shared/protocol.ts
var PROVIDER_CHANNEL = "kaspire:provider:v1";

// src/inpage/provider.ts
var KaspireProvider = class {
  isKaspire = true;
  version = "1.0.0";
  listeners = /* @__PURE__ */ new Map();
  constructor() {
    addEventListener("message", (event) => {
      const message = event.data;
      if (event.source !== window || message?.channel !== PROVIDER_CHANNEL || message.direction !== "event") return;
      this.emit(message.event, message.data);
    });
  }
  emit(event, data) {
    for (const listener of this.listeners.get(event) ?? []) try {
      listener(data);
    } catch {
    }
  }
  request({ method, params }) {
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        removeEventListener("message", receive);
        reject(new Error("Kaspire request timed out."));
      }, 36e4);
      const receive = (event) => {
        const r = event.data;
        if (event.source !== window || r?.channel !== PROVIDER_CHANNEL || r.direction !== "response" || r.id !== id) return;
        clearTimeout(timeout);
        removeEventListener("message", receive);
        r.error ? reject(Object.assign(new Error(r.error.message), r.error)) : resolve(r.result);
      };
      addEventListener("message", receive);
      postMessage({ channel: PROVIDER_CHANNEL, direction: "request", id, method, params }, location.origin);
    });
  }
  on(event, listener) {
    const set = this.listeners.get(event) ?? /* @__PURE__ */ new Set();
    set.add(listener);
    this.listeners.set(event, set);
    return this;
  }
  removeListener(event, listener) {
    this.listeners.get(event)?.delete(listener);
    return this;
  }
  async requestAccounts() {
    const accounts = await this.request({ method: "requestAccounts" });
    this.emit("accountsChanged", accounts);
    return accounts;
  }
  getAccounts() {
    return this.request({ method: "getAccounts" });
  }
  getNetwork() {
    return this.request({ method: "getNetwork" });
  }
  async switchNetwork(network) {
    const selected = await this.request({ method: "switchNetwork", params: { network } });
    this.emit("networkChanged", selected);
    return selected;
  }
  getPublicKey() {
    return this.request({ method: "getPublicKey" });
  }
  getBalance() {
    return this.request({ method: "getBalance" });
  }
  getUtxoEntries() {
    return this.request({ method: "getUtxoEntries" });
  }
  async disconnect() {
    const result = await this.request({ method: "disconnect" });
    this.emit("accountsChanged", []);
    this.emit("disconnect", { code: 4900, message: "Kaspire disconnected this site." });
    return result;
  }
  signMessage(message, address) {
    return this.request({ method: "signMessage", params: { message, address } });
  }
  sendKaspa(params) {
    return this.request({ method: "sendKaspa", params });
  }
  sendKRC20(params) {
    return this.request({ method: "sendKRC20", params });
  }
  sendKCC20(params) {
    return this.request({ method: "sendKCC20", params });
  }
  signPskt(params) {
    return this.request({ method: "signPskt", params });
  }
  transferKRC721(params) {
    return this.request({ method: "transferKRC721", params });
  }
  transferKNS(params) {
    return this.request({ method: "transferKNS", params });
  }
};
KaspireProvider.prototype.connect = function() {
  return this.requestAccounts();
};
KaspireProvider.prototype.pushTx = function(transaction) {
  return this.request({ method: "pushTx", params: transaction });
};
KaspireProvider.prototype.signPskt = function(first, options) {
  return this.request({ method: "signPskt", params: typeof first === "string" ? { txJsonString: first, options } : first });
};
KaspireProvider.prototype.signPolicyTransaction = function(params) {
  return this.request({ method: "signPolicyTransaction", params });
};
var provider = new KaspireProvider();
Object.defineProperty(window, "kaspire", { value: provider, configurable: false, writable: false });
dispatchEvent(new CustomEvent("kaspire#initialized"));
//# sourceMappingURL=inpage.js.map
