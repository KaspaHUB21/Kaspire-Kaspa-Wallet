var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/qrcode/lib/can-promise.js
var require_can_promise = __commonJS({
  "node_modules/qrcode/lib/can-promise.js"(exports, module) {
    module.exports = function() {
      return typeof Promise === "function" && Promise.prototype && Promise.prototype.then;
    };
  }
});

// node_modules/qrcode/lib/core/utils.js
var require_utils = __commonJS({
  "node_modules/qrcode/lib/core/utils.js"(exports) {
    var toSJISFunction;
    var CODEWORDS_COUNT = [
      0,
      // Not used
      26,
      44,
      70,
      100,
      134,
      172,
      196,
      242,
      292,
      346,
      404,
      466,
      532,
      581,
      655,
      733,
      815,
      901,
      991,
      1085,
      1156,
      1258,
      1364,
      1474,
      1588,
      1706,
      1828,
      1921,
      2051,
      2185,
      2323,
      2465,
      2611,
      2761,
      2876,
      3034,
      3196,
      3362,
      3532,
      3706
    ];
    exports.getSymbolSize = function getSymbolSize(version) {
      if (!version) throw new Error('"version" cannot be null or undefined');
      if (version < 1 || version > 40) throw new Error('"version" should be in range from 1 to 40');
      return version * 4 + 17;
    };
    exports.getSymbolTotalCodewords = function getSymbolTotalCodewords(version) {
      return CODEWORDS_COUNT[version];
    };
    exports.getBCHDigit = function(data) {
      let digit = 0;
      while (data !== 0) {
        digit++;
        data >>>= 1;
      }
      return digit;
    };
    exports.setToSJISFunction = function setToSJISFunction(f) {
      if (typeof f !== "function") {
        throw new Error('"toSJISFunc" is not a valid function.');
      }
      toSJISFunction = f;
    };
    exports.isKanjiModeEnabled = function() {
      return typeof toSJISFunction !== "undefined";
    };
    exports.toSJIS = function toSJIS(kanji) {
      return toSJISFunction(kanji);
    };
  }
});

// node_modules/qrcode/lib/core/error-correction-level.js
var require_error_correction_level = __commonJS({
  "node_modules/qrcode/lib/core/error-correction-level.js"(exports) {
    exports.L = { bit: 1 };
    exports.M = { bit: 0 };
    exports.Q = { bit: 3 };
    exports.H = { bit: 2 };
    function fromString(string) {
      if (typeof string !== "string") {
        throw new Error("Param is not a string");
      }
      const lcStr = string.toLowerCase();
      switch (lcStr) {
        case "l":
        case "low":
          return exports.L;
        case "m":
        case "medium":
          return exports.M;
        case "q":
        case "quartile":
          return exports.Q;
        case "h":
        case "high":
          return exports.H;
        default:
          throw new Error("Unknown EC Level: " + string);
      }
    }
    exports.isValid = function isValid(level) {
      return level && typeof level.bit !== "undefined" && level.bit >= 0 && level.bit < 4;
    };
    exports.from = function from(value2, defaultValue) {
      if (exports.isValid(value2)) {
        return value2;
      }
      try {
        return fromString(value2);
      } catch (e) {
        return defaultValue;
      }
    };
  }
});

// node_modules/qrcode/lib/core/bit-buffer.js
var require_bit_buffer = __commonJS({
  "node_modules/qrcode/lib/core/bit-buffer.js"(exports, module) {
    function BitBuffer() {
      this.buffer = [];
      this.length = 0;
    }
    BitBuffer.prototype = {
      get: function(index) {
        const bufIndex = Math.floor(index / 8);
        return (this.buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
      },
      put: function(num, length) {
        for (let i = 0; i < length; i++) {
          this.putBit((num >>> length - i - 1 & 1) === 1);
        }
      },
      getLengthInBits: function() {
        return this.length;
      },
      putBit: function(bit) {
        const bufIndex = Math.floor(this.length / 8);
        if (this.buffer.length <= bufIndex) {
          this.buffer.push(0);
        }
        if (bit) {
          this.buffer[bufIndex] |= 128 >>> this.length % 8;
        }
        this.length++;
      }
    };
    module.exports = BitBuffer;
  }
});

// node_modules/qrcode/lib/core/bit-matrix.js
var require_bit_matrix = __commonJS({
  "node_modules/qrcode/lib/core/bit-matrix.js"(exports, module) {
    function BitMatrix(size) {
      if (!size || size < 1) {
        throw new Error("BitMatrix size must be defined and greater than 0");
      }
      this.size = size;
      this.data = new Uint8Array(size * size);
      this.reservedBit = new Uint8Array(size * size);
    }
    BitMatrix.prototype.set = function(row, col, value2, reserved) {
      const index = row * this.size + col;
      this.data[index] = value2;
      if (reserved) this.reservedBit[index] = true;
    };
    BitMatrix.prototype.get = function(row, col) {
      return this.data[row * this.size + col];
    };
    BitMatrix.prototype.xor = function(row, col, value2) {
      this.data[row * this.size + col] ^= value2;
    };
    BitMatrix.prototype.isReserved = function(row, col) {
      return this.reservedBit[row * this.size + col];
    };
    module.exports = BitMatrix;
  }
});

// node_modules/qrcode/lib/core/alignment-pattern.js
var require_alignment_pattern = __commonJS({
  "node_modules/qrcode/lib/core/alignment-pattern.js"(exports) {
    var getSymbolSize = require_utils().getSymbolSize;
    exports.getRowColCoords = function getRowColCoords(version) {
      if (version === 1) return [];
      const posCount = Math.floor(version / 7) + 2;
      const size = getSymbolSize(version);
      const intervals = size === 145 ? 26 : Math.ceil((size - 13) / (2 * posCount - 2)) * 2;
      const positions = [size - 7];
      for (let i = 1; i < posCount - 1; i++) {
        positions[i] = positions[i - 1] - intervals;
      }
      positions.push(6);
      return positions.reverse();
    };
    exports.getPositions = function getPositions(version) {
      const coords = [];
      const pos = exports.getRowColCoords(version);
      const posLength = pos.length;
      for (let i = 0; i < posLength; i++) {
        for (let j = 0; j < posLength; j++) {
          if (i === 0 && j === 0 || // top-left
          i === 0 && j === posLength - 1 || // bottom-left
          i === posLength - 1 && j === 0) {
            continue;
          }
          coords.push([pos[i], pos[j]]);
        }
      }
      return coords;
    };
  }
});

// node_modules/qrcode/lib/core/finder-pattern.js
var require_finder_pattern = __commonJS({
  "node_modules/qrcode/lib/core/finder-pattern.js"(exports) {
    var getSymbolSize = require_utils().getSymbolSize;
    var FINDER_PATTERN_SIZE = 7;
    exports.getPositions = function getPositions(version) {
      const size = getSymbolSize(version);
      return [
        // top-left
        [0, 0],
        // top-right
        [size - FINDER_PATTERN_SIZE, 0],
        // bottom-left
        [0, size - FINDER_PATTERN_SIZE]
      ];
    };
  }
});

// node_modules/qrcode/lib/core/mask-pattern.js
var require_mask_pattern = __commonJS({
  "node_modules/qrcode/lib/core/mask-pattern.js"(exports) {
    exports.Patterns = {
      PATTERN000: 0,
      PATTERN001: 1,
      PATTERN010: 2,
      PATTERN011: 3,
      PATTERN100: 4,
      PATTERN101: 5,
      PATTERN110: 6,
      PATTERN111: 7
    };
    var PenaltyScores = {
      N1: 3,
      N2: 3,
      N3: 40,
      N4: 10
    };
    exports.isValid = function isValid(mask) {
      return mask != null && mask !== "" && !isNaN(mask) && mask >= 0 && mask <= 7;
    };
    exports.from = function from(value2) {
      return exports.isValid(value2) ? parseInt(value2, 10) : void 0;
    };
    exports.getPenaltyN1 = function getPenaltyN1(data) {
      const size = data.size;
      let points = 0;
      let sameCountCol = 0;
      let sameCountRow = 0;
      let lastCol = null;
      let lastRow = null;
      for (let row = 0; row < size; row++) {
        sameCountCol = sameCountRow = 0;
        lastCol = lastRow = null;
        for (let col = 0; col < size; col++) {
          let module2 = data.get(row, col);
          if (module2 === lastCol) {
            sameCountCol++;
          } else {
            if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
            lastCol = module2;
            sameCountCol = 1;
          }
          module2 = data.get(col, row);
          if (module2 === lastRow) {
            sameCountRow++;
          } else {
            if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
            lastRow = module2;
            sameCountRow = 1;
          }
        }
        if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
        if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
      }
      return points;
    };
    exports.getPenaltyN2 = function getPenaltyN2(data) {
      const size = data.size;
      let points = 0;
      for (let row = 0; row < size - 1; row++) {
        for (let col = 0; col < size - 1; col++) {
          const last = data.get(row, col) + data.get(row, col + 1) + data.get(row + 1, col) + data.get(row + 1, col + 1);
          if (last === 4 || last === 0) points++;
        }
      }
      return points * PenaltyScores.N2;
    };
    exports.getPenaltyN3 = function getPenaltyN3(data) {
      const size = data.size;
      let points = 0;
      let bitsCol = 0;
      let bitsRow = 0;
      for (let row = 0; row < size; row++) {
        bitsCol = bitsRow = 0;
        for (let col = 0; col < size; col++) {
          bitsCol = bitsCol << 1 & 2047 | data.get(row, col);
          if (col >= 10 && (bitsCol === 1488 || bitsCol === 93)) points++;
          bitsRow = bitsRow << 1 & 2047 | data.get(col, row);
          if (col >= 10 && (bitsRow === 1488 || bitsRow === 93)) points++;
        }
      }
      return points * PenaltyScores.N3;
    };
    exports.getPenaltyN4 = function getPenaltyN4(data) {
      let darkCount = 0;
      const modulesCount = data.data.length;
      for (let i = 0; i < modulesCount; i++) darkCount += data.data[i];
      const k = Math.abs(Math.ceil(darkCount * 100 / modulesCount / 5) - 10);
      return k * PenaltyScores.N4;
    };
    function getMaskAt(maskPattern, i, j) {
      switch (maskPattern) {
        case exports.Patterns.PATTERN000:
          return (i + j) % 2 === 0;
        case exports.Patterns.PATTERN001:
          return i % 2 === 0;
        case exports.Patterns.PATTERN010:
          return j % 3 === 0;
        case exports.Patterns.PATTERN011:
          return (i + j) % 3 === 0;
        case exports.Patterns.PATTERN100:
          return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
        case exports.Patterns.PATTERN101:
          return i * j % 2 + i * j % 3 === 0;
        case exports.Patterns.PATTERN110:
          return (i * j % 2 + i * j % 3) % 2 === 0;
        case exports.Patterns.PATTERN111:
          return (i * j % 3 + (i + j) % 2) % 2 === 0;
        default:
          throw new Error("bad maskPattern:" + maskPattern);
      }
    }
    exports.applyMask = function applyMask(pattern, data) {
      const size = data.size;
      for (let col = 0; col < size; col++) {
        for (let row = 0; row < size; row++) {
          if (data.isReserved(row, col)) continue;
          data.xor(row, col, getMaskAt(pattern, row, col));
        }
      }
    };
    exports.getBestMask = function getBestMask(data, setupFormatFunc) {
      const numPatterns = Object.keys(exports.Patterns).length;
      let bestPattern = 0;
      let lowerPenalty = Infinity;
      for (let p = 0; p < numPatterns; p++) {
        setupFormatFunc(p);
        exports.applyMask(p, data);
        const penalty = exports.getPenaltyN1(data) + exports.getPenaltyN2(data) + exports.getPenaltyN3(data) + exports.getPenaltyN4(data);
        exports.applyMask(p, data);
        if (penalty < lowerPenalty) {
          lowerPenalty = penalty;
          bestPattern = p;
        }
      }
      return bestPattern;
    };
  }
});

// node_modules/qrcode/lib/core/error-correction-code.js
var require_error_correction_code = __commonJS({
  "node_modules/qrcode/lib/core/error-correction-code.js"(exports) {
    var ECLevel = require_error_correction_level();
    var EC_BLOCKS_TABLE = [
      // L  M  Q  H
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      2,
      2,
      1,
      2,
      2,
      4,
      1,
      2,
      4,
      4,
      2,
      4,
      4,
      4,
      2,
      4,
      6,
      5,
      2,
      4,
      6,
      6,
      2,
      5,
      8,
      8,
      4,
      5,
      8,
      8,
      4,
      5,
      8,
      11,
      4,
      8,
      10,
      11,
      4,
      9,
      12,
      16,
      4,
      9,
      16,
      16,
      6,
      10,
      12,
      18,
      6,
      10,
      17,
      16,
      6,
      11,
      16,
      19,
      6,
      13,
      18,
      21,
      7,
      14,
      21,
      25,
      8,
      16,
      20,
      25,
      8,
      17,
      23,
      25,
      9,
      17,
      23,
      34,
      9,
      18,
      25,
      30,
      10,
      20,
      27,
      32,
      12,
      21,
      29,
      35,
      12,
      23,
      34,
      37,
      12,
      25,
      34,
      40,
      13,
      26,
      35,
      42,
      14,
      28,
      38,
      45,
      15,
      29,
      40,
      48,
      16,
      31,
      43,
      51,
      17,
      33,
      45,
      54,
      18,
      35,
      48,
      57,
      19,
      37,
      51,
      60,
      19,
      38,
      53,
      63,
      20,
      40,
      56,
      66,
      21,
      43,
      59,
      70,
      22,
      45,
      62,
      74,
      24,
      47,
      65,
      77,
      25,
      49,
      68,
      81
    ];
    var EC_CODEWORDS_TABLE = [
      // L  M  Q  H
      7,
      10,
      13,
      17,
      10,
      16,
      22,
      28,
      15,
      26,
      36,
      44,
      20,
      36,
      52,
      64,
      26,
      48,
      72,
      88,
      36,
      64,
      96,
      112,
      40,
      72,
      108,
      130,
      48,
      88,
      132,
      156,
      60,
      110,
      160,
      192,
      72,
      130,
      192,
      224,
      80,
      150,
      224,
      264,
      96,
      176,
      260,
      308,
      104,
      198,
      288,
      352,
      120,
      216,
      320,
      384,
      132,
      240,
      360,
      432,
      144,
      280,
      408,
      480,
      168,
      308,
      448,
      532,
      180,
      338,
      504,
      588,
      196,
      364,
      546,
      650,
      224,
      416,
      600,
      700,
      224,
      442,
      644,
      750,
      252,
      476,
      690,
      816,
      270,
      504,
      750,
      900,
      300,
      560,
      810,
      960,
      312,
      588,
      870,
      1050,
      336,
      644,
      952,
      1110,
      360,
      700,
      1020,
      1200,
      390,
      728,
      1050,
      1260,
      420,
      784,
      1140,
      1350,
      450,
      812,
      1200,
      1440,
      480,
      868,
      1290,
      1530,
      510,
      924,
      1350,
      1620,
      540,
      980,
      1440,
      1710,
      570,
      1036,
      1530,
      1800,
      570,
      1064,
      1590,
      1890,
      600,
      1120,
      1680,
      1980,
      630,
      1204,
      1770,
      2100,
      660,
      1260,
      1860,
      2220,
      720,
      1316,
      1950,
      2310,
      750,
      1372,
      2040,
      2430
    ];
    exports.getBlocksCount = function getBlocksCount(version, errorCorrectionLevel) {
      switch (errorCorrectionLevel) {
        case ECLevel.L:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 0];
        case ECLevel.M:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 1];
        case ECLevel.Q:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 2];
        case ECLevel.H:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 3];
        default:
          return void 0;
      }
    };
    exports.getTotalCodewordsCount = function getTotalCodewordsCount(version, errorCorrectionLevel) {
      switch (errorCorrectionLevel) {
        case ECLevel.L:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 0];
        case ECLevel.M:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 1];
        case ECLevel.Q:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 2];
        case ECLevel.H:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 3];
        default:
          return void 0;
      }
    };
  }
});

// node_modules/qrcode/lib/core/galois-field.js
var require_galois_field = __commonJS({
  "node_modules/qrcode/lib/core/galois-field.js"(exports) {
    var EXP_TABLE = new Uint8Array(512);
    var LOG_TABLE = new Uint8Array(256);
    (function initTables() {
      let x = 1;
      for (let i = 0; i < 255; i++) {
        EXP_TABLE[i] = x;
        LOG_TABLE[x] = i;
        x <<= 1;
        if (x & 256) {
          x ^= 285;
        }
      }
      for (let i = 255; i < 512; i++) {
        EXP_TABLE[i] = EXP_TABLE[i - 255];
      }
    })();
    exports.log = function log(n) {
      if (n < 1) throw new Error("log(" + n + ")");
      return LOG_TABLE[n];
    };
    exports.exp = function exp(n) {
      return EXP_TABLE[n];
    };
    exports.mul = function mul(x, y) {
      if (x === 0 || y === 0) return 0;
      return EXP_TABLE[LOG_TABLE[x] + LOG_TABLE[y]];
    };
  }
});

// node_modules/qrcode/lib/core/polynomial.js
var require_polynomial = __commonJS({
  "node_modules/qrcode/lib/core/polynomial.js"(exports) {
    var GF = require_galois_field();
    exports.mul = function mul(p1, p2) {
      const coeff = new Uint8Array(p1.length + p2.length - 1);
      for (let i = 0; i < p1.length; i++) {
        for (let j = 0; j < p2.length; j++) {
          coeff[i + j] ^= GF.mul(p1[i], p2[j]);
        }
      }
      return coeff;
    };
    exports.mod = function mod(divident, divisor) {
      let result = new Uint8Array(divident);
      while (result.length - divisor.length >= 0) {
        const coeff = result[0];
        for (let i = 0; i < divisor.length; i++) {
          result[i] ^= GF.mul(divisor[i], coeff);
        }
        let offset = 0;
        while (offset < result.length && result[offset] === 0) offset++;
        result = result.slice(offset);
      }
      return result;
    };
    exports.generateECPolynomial = function generateECPolynomial(degree) {
      let poly = new Uint8Array([1]);
      for (let i = 0; i < degree; i++) {
        poly = exports.mul(poly, new Uint8Array([1, GF.exp(i)]));
      }
      return poly;
    };
  }
});

// node_modules/qrcode/lib/core/reed-solomon-encoder.js
var require_reed_solomon_encoder = __commonJS({
  "node_modules/qrcode/lib/core/reed-solomon-encoder.js"(exports, module) {
    var Polynomial = require_polynomial();
    function ReedSolomonEncoder(degree) {
      this.genPoly = void 0;
      this.degree = degree;
      if (this.degree) this.initialize(this.degree);
    }
    ReedSolomonEncoder.prototype.initialize = function initialize(degree) {
      this.degree = degree;
      this.genPoly = Polynomial.generateECPolynomial(this.degree);
    };
    ReedSolomonEncoder.prototype.encode = function encode(data) {
      if (!this.genPoly) {
        throw new Error("Encoder not initialized");
      }
      const paddedData = new Uint8Array(data.length + this.degree);
      paddedData.set(data);
      const remainder = Polynomial.mod(paddedData, this.genPoly);
      const start = this.degree - remainder.length;
      if (start > 0) {
        const buff = new Uint8Array(this.degree);
        buff.set(remainder, start);
        return buff;
      }
      return remainder;
    };
    module.exports = ReedSolomonEncoder;
  }
});

// node_modules/qrcode/lib/core/version-check.js
var require_version_check = __commonJS({
  "node_modules/qrcode/lib/core/version-check.js"(exports) {
    exports.isValid = function isValid(version) {
      return !isNaN(version) && version >= 1 && version <= 40;
    };
  }
});

// node_modules/qrcode/lib/core/regex.js
var require_regex = __commonJS({
  "node_modules/qrcode/lib/core/regex.js"(exports) {
    var numeric = "[0-9]+";
    var alphanumeric = "[A-Z $%*+\\-./:]+";
    var kanji = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
    kanji = kanji.replace(/u/g, "\\u");
    var byte = "(?:(?![A-Z0-9 $%*+\\-./:]|" + kanji + ")(?:.|[\r\n]))+";
    exports.KANJI = new RegExp(kanji, "g");
    exports.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g");
    exports.BYTE = new RegExp(byte, "g");
    exports.NUMERIC = new RegExp(numeric, "g");
    exports.ALPHANUMERIC = new RegExp(alphanumeric, "g");
    var TEST_KANJI = new RegExp("^" + kanji + "$");
    var TEST_NUMERIC = new RegExp("^" + numeric + "$");
    var TEST_ALPHANUMERIC = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
    exports.testKanji = function testKanji(str) {
      return TEST_KANJI.test(str);
    };
    exports.testNumeric = function testNumeric(str) {
      return TEST_NUMERIC.test(str);
    };
    exports.testAlphanumeric = function testAlphanumeric(str) {
      return TEST_ALPHANUMERIC.test(str);
    };
  }
});

// node_modules/qrcode/lib/core/mode.js
var require_mode = __commonJS({
  "node_modules/qrcode/lib/core/mode.js"(exports) {
    var VersionCheck = require_version_check();
    var Regex = require_regex();
    exports.NUMERIC = {
      id: "Numeric",
      bit: 1 << 0,
      ccBits: [10, 12, 14]
    };
    exports.ALPHANUMERIC = {
      id: "Alphanumeric",
      bit: 1 << 1,
      ccBits: [9, 11, 13]
    };
    exports.BYTE = {
      id: "Byte",
      bit: 1 << 2,
      ccBits: [8, 16, 16]
    };
    exports.KANJI = {
      id: "Kanji",
      bit: 1 << 3,
      ccBits: [8, 10, 12]
    };
    exports.MIXED = {
      bit: -1
    };
    exports.getCharCountIndicator = function getCharCountIndicator(mode, version) {
      if (!mode.ccBits) throw new Error("Invalid mode: " + mode);
      if (!VersionCheck.isValid(version)) {
        throw new Error("Invalid version: " + version);
      }
      if (version >= 1 && version < 10) return mode.ccBits[0];
      else if (version < 27) return mode.ccBits[1];
      return mode.ccBits[2];
    };
    exports.getBestModeForData = function getBestModeForData(dataStr) {
      if (Regex.testNumeric(dataStr)) return exports.NUMERIC;
      else if (Regex.testAlphanumeric(dataStr)) return exports.ALPHANUMERIC;
      else if (Regex.testKanji(dataStr)) return exports.KANJI;
      else return exports.BYTE;
    };
    exports.toString = function toString(mode) {
      if (mode && mode.id) return mode.id;
      throw new Error("Invalid mode");
    };
    exports.isValid = function isValid(mode) {
      return mode && mode.bit && mode.ccBits;
    };
    function fromString(string) {
      if (typeof string !== "string") {
        throw new Error("Param is not a string");
      }
      const lcStr = string.toLowerCase();
      switch (lcStr) {
        case "numeric":
          return exports.NUMERIC;
        case "alphanumeric":
          return exports.ALPHANUMERIC;
        case "kanji":
          return exports.KANJI;
        case "byte":
          return exports.BYTE;
        default:
          throw new Error("Unknown mode: " + string);
      }
    }
    exports.from = function from(value2, defaultValue) {
      if (exports.isValid(value2)) {
        return value2;
      }
      try {
        return fromString(value2);
      } catch (e) {
        return defaultValue;
      }
    };
  }
});

// node_modules/qrcode/lib/core/version.js
var require_version = __commonJS({
  "node_modules/qrcode/lib/core/version.js"(exports) {
    var Utils = require_utils();
    var ECCode = require_error_correction_code();
    var ECLevel = require_error_correction_level();
    var Mode = require_mode();
    var VersionCheck = require_version_check();
    var G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
    var G18_BCH = Utils.getBCHDigit(G18);
    function getBestVersionForDataLength(mode, length, errorCorrectionLevel) {
      for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
        if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel, mode)) {
          return currentVersion;
        }
      }
      return void 0;
    }
    function getReservedBitsCount(mode, version) {
      return Mode.getCharCountIndicator(mode, version) + 4;
    }
    function getTotalBitsFromDataArray(segments, version) {
      let totalBits = 0;
      segments.forEach(function(data) {
        const reservedBits = getReservedBitsCount(data.mode, version);
        totalBits += reservedBits + data.getBitsLength();
      });
      return totalBits;
    }
    function getBestVersionForMixedData(segments, errorCorrectionLevel) {
      for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
        const length = getTotalBitsFromDataArray(segments, currentVersion);
        if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel, Mode.MIXED)) {
          return currentVersion;
        }
      }
      return void 0;
    }
    exports.from = function from(value2, defaultValue) {
      if (VersionCheck.isValid(value2)) {
        return parseInt(value2, 10);
      }
      return defaultValue;
    };
    exports.getCapacity = function getCapacity(version, errorCorrectionLevel, mode) {
      if (!VersionCheck.isValid(version)) {
        throw new Error("Invalid QR Code version");
      }
      if (typeof mode === "undefined") mode = Mode.BYTE;
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
      if (mode === Mode.MIXED) return dataTotalCodewordsBits;
      const usableBits = dataTotalCodewordsBits - getReservedBitsCount(mode, version);
      switch (mode) {
        case Mode.NUMERIC:
          return Math.floor(usableBits / 10 * 3);
        case Mode.ALPHANUMERIC:
          return Math.floor(usableBits / 11 * 2);
        case Mode.KANJI:
          return Math.floor(usableBits / 13);
        case Mode.BYTE:
        default:
          return Math.floor(usableBits / 8);
      }
    };
    exports.getBestVersionForData = function getBestVersionForData(data, errorCorrectionLevel) {
      let seg;
      const ecl = ECLevel.from(errorCorrectionLevel, ECLevel.M);
      if (Array.isArray(data)) {
        if (data.length > 1) {
          return getBestVersionForMixedData(data, ecl);
        }
        if (data.length === 0) {
          return 1;
        }
        seg = data[0];
      } else {
        seg = data;
      }
      return getBestVersionForDataLength(seg.mode, seg.getLength(), ecl);
    };
    exports.getEncodedBits = function getEncodedBits(version) {
      if (!VersionCheck.isValid(version) || version < 7) {
        throw new Error("Invalid QR Code version");
      }
      let d = version << 12;
      while (Utils.getBCHDigit(d) - G18_BCH >= 0) {
        d ^= G18 << Utils.getBCHDigit(d) - G18_BCH;
      }
      return version << 12 | d;
    };
  }
});

// node_modules/qrcode/lib/core/format-info.js
var require_format_info = __commonJS({
  "node_modules/qrcode/lib/core/format-info.js"(exports) {
    var Utils = require_utils();
    var G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
    var G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
    var G15_BCH = Utils.getBCHDigit(G15);
    exports.getEncodedBits = function getEncodedBits(errorCorrectionLevel, mask) {
      const data = errorCorrectionLevel.bit << 3 | mask;
      let d = data << 10;
      while (Utils.getBCHDigit(d) - G15_BCH >= 0) {
        d ^= G15 << Utils.getBCHDigit(d) - G15_BCH;
      }
      return (data << 10 | d) ^ G15_MASK;
    };
  }
});

// node_modules/qrcode/lib/core/numeric-data.js
var require_numeric_data = __commonJS({
  "node_modules/qrcode/lib/core/numeric-data.js"(exports, module) {
    var Mode = require_mode();
    function NumericData(data) {
      this.mode = Mode.NUMERIC;
      this.data = data.toString();
    }
    NumericData.getBitsLength = function getBitsLength(length) {
      return 10 * Math.floor(length / 3) + (length % 3 ? length % 3 * 3 + 1 : 0);
    };
    NumericData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    NumericData.prototype.getBitsLength = function getBitsLength() {
      return NumericData.getBitsLength(this.data.length);
    };
    NumericData.prototype.write = function write(bitBuffer) {
      let i, group, value2;
      for (i = 0; i + 3 <= this.data.length; i += 3) {
        group = this.data.substr(i, 3);
        value2 = parseInt(group, 10);
        bitBuffer.put(value2, 10);
      }
      const remainingNum = this.data.length - i;
      if (remainingNum > 0) {
        group = this.data.substr(i);
        value2 = parseInt(group, 10);
        bitBuffer.put(value2, remainingNum * 3 + 1);
      }
    };
    module.exports = NumericData;
  }
});

// node_modules/qrcode/lib/core/alphanumeric-data.js
var require_alphanumeric_data = __commonJS({
  "node_modules/qrcode/lib/core/alphanumeric-data.js"(exports, module) {
    var Mode = require_mode();
    var ALPHA_NUM_CHARS = [
      "0",
      "1",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z",
      " ",
      "$",
      "%",
      "*",
      "+",
      "-",
      ".",
      "/",
      ":"
    ];
    function AlphanumericData(data) {
      this.mode = Mode.ALPHANUMERIC;
      this.data = data;
    }
    AlphanumericData.getBitsLength = function getBitsLength(length) {
      return 11 * Math.floor(length / 2) + 6 * (length % 2);
    };
    AlphanumericData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    AlphanumericData.prototype.getBitsLength = function getBitsLength() {
      return AlphanumericData.getBitsLength(this.data.length);
    };
    AlphanumericData.prototype.write = function write(bitBuffer) {
      let i;
      for (i = 0; i + 2 <= this.data.length; i += 2) {
        let value2 = ALPHA_NUM_CHARS.indexOf(this.data[i]) * 45;
        value2 += ALPHA_NUM_CHARS.indexOf(this.data[i + 1]);
        bitBuffer.put(value2, 11);
      }
      if (this.data.length % 2) {
        bitBuffer.put(ALPHA_NUM_CHARS.indexOf(this.data[i]), 6);
      }
    };
    module.exports = AlphanumericData;
  }
});

// node_modules/qrcode/lib/core/byte-data.js
var require_byte_data = __commonJS({
  "node_modules/qrcode/lib/core/byte-data.js"(exports, module) {
    var Mode = require_mode();
    function ByteData(data) {
      this.mode = Mode.BYTE;
      if (typeof data === "string") {
        this.data = new TextEncoder().encode(data);
      } else {
        this.data = new Uint8Array(data);
      }
    }
    ByteData.getBitsLength = function getBitsLength(length) {
      return length * 8;
    };
    ByteData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    ByteData.prototype.getBitsLength = function getBitsLength() {
      return ByteData.getBitsLength(this.data.length);
    };
    ByteData.prototype.write = function(bitBuffer) {
      for (let i = 0, l = this.data.length; i < l; i++) {
        bitBuffer.put(this.data[i], 8);
      }
    };
    module.exports = ByteData;
  }
});

// node_modules/qrcode/lib/core/kanji-data.js
var require_kanji_data = __commonJS({
  "node_modules/qrcode/lib/core/kanji-data.js"(exports, module) {
    var Mode = require_mode();
    var Utils = require_utils();
    function KanjiData(data) {
      this.mode = Mode.KANJI;
      this.data = data;
    }
    KanjiData.getBitsLength = function getBitsLength(length) {
      return length * 13;
    };
    KanjiData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    KanjiData.prototype.getBitsLength = function getBitsLength() {
      return KanjiData.getBitsLength(this.data.length);
    };
    KanjiData.prototype.write = function(bitBuffer) {
      let i;
      for (i = 0; i < this.data.length; i++) {
        let value2 = Utils.toSJIS(this.data[i]);
        if (value2 >= 33088 && value2 <= 40956) {
          value2 -= 33088;
        } else if (value2 >= 57408 && value2 <= 60351) {
          value2 -= 49472;
        } else {
          throw new Error(
            "Invalid SJIS character: " + this.data[i] + "\nMake sure your charset is UTF-8"
          );
        }
        value2 = (value2 >>> 8 & 255) * 192 + (value2 & 255);
        bitBuffer.put(value2, 13);
      }
    };
    module.exports = KanjiData;
  }
});

// node_modules/dijkstrajs/dijkstra.js
var require_dijkstra = __commonJS({
  "node_modules/dijkstrajs/dijkstra.js"(exports, module) {
    "use strict";
    var dijkstra = {
      single_source_shortest_paths: function(graph, s, d) {
        var predecessors = {};
        var costs = {};
        costs[s] = 0;
        var open = dijkstra.PriorityQueue.make();
        open.push(s, 0);
        var closest, u, v, cost_of_s_to_u, adjacent_nodes, cost_of_e, cost_of_s_to_u_plus_cost_of_e, cost_of_s_to_v, first_visit;
        while (!open.empty()) {
          closest = open.pop();
          u = closest.value;
          cost_of_s_to_u = closest.cost;
          adjacent_nodes = graph[u] || {};
          for (v in adjacent_nodes) {
            if (adjacent_nodes.hasOwnProperty(v)) {
              cost_of_e = adjacent_nodes[v];
              cost_of_s_to_u_plus_cost_of_e = cost_of_s_to_u + cost_of_e;
              cost_of_s_to_v = costs[v];
              first_visit = typeof costs[v] === "undefined";
              if (first_visit || cost_of_s_to_v > cost_of_s_to_u_plus_cost_of_e) {
                costs[v] = cost_of_s_to_u_plus_cost_of_e;
                open.push(v, cost_of_s_to_u_plus_cost_of_e);
                predecessors[v] = u;
              }
            }
          }
        }
        if (typeof d !== "undefined" && typeof costs[d] === "undefined") {
          var msg = ["Could not find a path from ", s, " to ", d, "."].join("");
          throw new Error(msg);
        }
        return predecessors;
      },
      extract_shortest_path_from_predecessor_list: function(predecessors, d) {
        var nodes = [];
        var u = d;
        var predecessor;
        while (u) {
          nodes.push(u);
          predecessor = predecessors[u];
          u = predecessors[u];
        }
        nodes.reverse();
        return nodes;
      },
      find_path: function(graph, s, d) {
        var predecessors = dijkstra.single_source_shortest_paths(graph, s, d);
        return dijkstra.extract_shortest_path_from_predecessor_list(
          predecessors,
          d
        );
      },
      /**
       * A very naive priority queue implementation.
       */
      PriorityQueue: {
        make: function(opts) {
          var T = dijkstra.PriorityQueue, t = {}, key;
          opts = opts || {};
          for (key in T) {
            if (T.hasOwnProperty(key)) {
              t[key] = T[key];
            }
          }
          t.queue = [];
          t.sorter = opts.sorter || T.default_sorter;
          return t;
        },
        default_sorter: function(a, b) {
          return a.cost - b.cost;
        },
        /**
         * Add a new item to the queue and ensure the highest priority element
         * is at the front of the queue.
         */
        push: function(value2, cost) {
          var item = { value: value2, cost };
          this.queue.push(item);
          this.queue.sort(this.sorter);
        },
        /**
         * Return the highest priority element in the queue.
         */
        pop: function() {
          return this.queue.shift();
        },
        empty: function() {
          return this.queue.length === 0;
        }
      }
    };
    if (typeof module !== "undefined") {
      module.exports = dijkstra;
    }
  }
});

// node_modules/qrcode/lib/core/segments.js
var require_segments = __commonJS({
  "node_modules/qrcode/lib/core/segments.js"(exports) {
    var Mode = require_mode();
    var NumericData = require_numeric_data();
    var AlphanumericData = require_alphanumeric_data();
    var ByteData = require_byte_data();
    var KanjiData = require_kanji_data();
    var Regex = require_regex();
    var Utils = require_utils();
    var dijkstra = require_dijkstra();
    function getStringByteLength(str) {
      return unescape(encodeURIComponent(str)).length;
    }
    function getSegments(regex, mode, str) {
      const segments = [];
      let result;
      while ((result = regex.exec(str)) !== null) {
        segments.push({
          data: result[0],
          index: result.index,
          mode,
          length: result[0].length
        });
      }
      return segments;
    }
    function getSegmentsFromString(dataStr) {
      const numSegs = getSegments(Regex.NUMERIC, Mode.NUMERIC, dataStr);
      const alphaNumSegs = getSegments(Regex.ALPHANUMERIC, Mode.ALPHANUMERIC, dataStr);
      let byteSegs;
      let kanjiSegs;
      if (Utils.isKanjiModeEnabled()) {
        byteSegs = getSegments(Regex.BYTE, Mode.BYTE, dataStr);
        kanjiSegs = getSegments(Regex.KANJI, Mode.KANJI, dataStr);
      } else {
        byteSegs = getSegments(Regex.BYTE_KANJI, Mode.BYTE, dataStr);
        kanjiSegs = [];
      }
      const segs = numSegs.concat(alphaNumSegs, byteSegs, kanjiSegs);
      return segs.sort(function(s1, s2) {
        return s1.index - s2.index;
      }).map(function(obj) {
        return {
          data: obj.data,
          mode: obj.mode,
          length: obj.length
        };
      });
    }
    function getSegmentBitsLength(length, mode) {
      switch (mode) {
        case Mode.NUMERIC:
          return NumericData.getBitsLength(length);
        case Mode.ALPHANUMERIC:
          return AlphanumericData.getBitsLength(length);
        case Mode.KANJI:
          return KanjiData.getBitsLength(length);
        case Mode.BYTE:
          return ByteData.getBitsLength(length);
      }
    }
    function mergeSegments(segs) {
      return segs.reduce(function(acc, curr) {
        const prevSeg = acc.length - 1 >= 0 ? acc[acc.length - 1] : null;
        if (prevSeg && prevSeg.mode === curr.mode) {
          acc[acc.length - 1].data += curr.data;
          return acc;
        }
        acc.push(curr);
        return acc;
      }, []);
    }
    function buildNodes(segs) {
      const nodes = [];
      for (let i = 0; i < segs.length; i++) {
        const seg = segs[i];
        switch (seg.mode) {
          case Mode.NUMERIC:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.ALPHANUMERIC, length: seg.length },
              { data: seg.data, mode: Mode.BYTE, length: seg.length }
            ]);
            break;
          case Mode.ALPHANUMERIC:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.BYTE, length: seg.length }
            ]);
            break;
          case Mode.KANJI:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.BYTE, length: getStringByteLength(seg.data) }
            ]);
            break;
          case Mode.BYTE:
            nodes.push([
              { data: seg.data, mode: Mode.BYTE, length: getStringByteLength(seg.data) }
            ]);
        }
      }
      return nodes;
    }
    function buildGraph(nodes, version) {
      const table = {};
      const graph = { start: {} };
      let prevNodeIds = ["start"];
      for (let i = 0; i < nodes.length; i++) {
        const nodeGroup = nodes[i];
        const currentNodeIds = [];
        for (let j = 0; j < nodeGroup.length; j++) {
          const node = nodeGroup[j];
          const key = "" + i + j;
          currentNodeIds.push(key);
          table[key] = { node, lastCount: 0 };
          graph[key] = {};
          for (let n = 0; n < prevNodeIds.length; n++) {
            const prevNodeId = prevNodeIds[n];
            if (table[prevNodeId] && table[prevNodeId].node.mode === node.mode) {
              graph[prevNodeId][key] = getSegmentBitsLength(table[prevNodeId].lastCount + node.length, node.mode) - getSegmentBitsLength(table[prevNodeId].lastCount, node.mode);
              table[prevNodeId].lastCount += node.length;
            } else {
              if (table[prevNodeId]) table[prevNodeId].lastCount = node.length;
              graph[prevNodeId][key] = getSegmentBitsLength(node.length, node.mode) + 4 + Mode.getCharCountIndicator(node.mode, version);
            }
          }
        }
        prevNodeIds = currentNodeIds;
      }
      for (let n = 0; n < prevNodeIds.length; n++) {
        graph[prevNodeIds[n]].end = 0;
      }
      return { map: graph, table };
    }
    function buildSingleSegment(data, modesHint) {
      let mode;
      const bestMode = Mode.getBestModeForData(data);
      mode = Mode.from(modesHint, bestMode);
      if (mode !== Mode.BYTE && mode.bit < bestMode.bit) {
        throw new Error('"' + data + '" cannot be encoded with mode ' + Mode.toString(mode) + ".\n Suggested mode is: " + Mode.toString(bestMode));
      }
      if (mode === Mode.KANJI && !Utils.isKanjiModeEnabled()) {
        mode = Mode.BYTE;
      }
      switch (mode) {
        case Mode.NUMERIC:
          return new NumericData(data);
        case Mode.ALPHANUMERIC:
          return new AlphanumericData(data);
        case Mode.KANJI:
          return new KanjiData(data);
        case Mode.BYTE:
          return new ByteData(data);
      }
    }
    exports.fromArray = function fromArray(array) {
      return array.reduce(function(acc, seg) {
        if (typeof seg === "string") {
          acc.push(buildSingleSegment(seg, null));
        } else if (seg.data) {
          acc.push(buildSingleSegment(seg.data, seg.mode));
        }
        return acc;
      }, []);
    };
    exports.fromString = function fromString(data, version) {
      const segs = getSegmentsFromString(data, Utils.isKanjiModeEnabled());
      const nodes = buildNodes(segs);
      const graph = buildGraph(nodes, version);
      const path = dijkstra.find_path(graph.map, "start", "end");
      const optimizedSegs = [];
      for (let i = 1; i < path.length - 1; i++) {
        optimizedSegs.push(graph.table[path[i]].node);
      }
      return exports.fromArray(mergeSegments(optimizedSegs));
    };
    exports.rawSplit = function rawSplit(data) {
      return exports.fromArray(
        getSegmentsFromString(data, Utils.isKanjiModeEnabled())
      );
    };
  }
});

// node_modules/qrcode/lib/core/qrcode.js
var require_qrcode = __commonJS({
  "node_modules/qrcode/lib/core/qrcode.js"(exports) {
    var Utils = require_utils();
    var ECLevel = require_error_correction_level();
    var BitBuffer = require_bit_buffer();
    var BitMatrix = require_bit_matrix();
    var AlignmentPattern = require_alignment_pattern();
    var FinderPattern = require_finder_pattern();
    var MaskPattern = require_mask_pattern();
    var ECCode = require_error_correction_code();
    var ReedSolomonEncoder = require_reed_solomon_encoder();
    var Version = require_version();
    var FormatInfo = require_format_info();
    var Mode = require_mode();
    var Segments = require_segments();
    function setupFinderPattern(matrix, version) {
      const size = matrix.size;
      const pos = FinderPattern.getPositions(version);
      for (let i = 0; i < pos.length; i++) {
        const row = pos[i][0];
        const col = pos[i][1];
        for (let r = -1; r <= 7; r++) {
          if (row + r <= -1 || size <= row + r) continue;
          for (let c = -1; c <= 7; c++) {
            if (col + c <= -1 || size <= col + c) continue;
            if (r >= 0 && r <= 6 && (c === 0 || c === 6) || c >= 0 && c <= 6 && (r === 0 || r === 6) || r >= 2 && r <= 4 && c >= 2 && c <= 4) {
              matrix.set(row + r, col + c, true, true);
            } else {
              matrix.set(row + r, col + c, false, true);
            }
          }
        }
      }
    }
    function setupTimingPattern(matrix) {
      const size = matrix.size;
      for (let r = 8; r < size - 8; r++) {
        const value2 = r % 2 === 0;
        matrix.set(r, 6, value2, true);
        matrix.set(6, r, value2, true);
      }
    }
    function setupAlignmentPattern(matrix, version) {
      const pos = AlignmentPattern.getPositions(version);
      for (let i = 0; i < pos.length; i++) {
        const row = pos[i][0];
        const col = pos[i][1];
        for (let r = -2; r <= 2; r++) {
          for (let c = -2; c <= 2; c++) {
            if (r === -2 || r === 2 || c === -2 || c === 2 || r === 0 && c === 0) {
              matrix.set(row + r, col + c, true, true);
            } else {
              matrix.set(row + r, col + c, false, true);
            }
          }
        }
      }
    }
    function setupVersionInfo(matrix, version) {
      const size = matrix.size;
      const bits = Version.getEncodedBits(version);
      let row, col, mod;
      for (let i = 0; i < 18; i++) {
        row = Math.floor(i / 3);
        col = i % 3 + size - 8 - 3;
        mod = (bits >> i & 1) === 1;
        matrix.set(row, col, mod, true);
        matrix.set(col, row, mod, true);
      }
    }
    function setupFormatInfo(matrix, errorCorrectionLevel, maskPattern) {
      const size = matrix.size;
      const bits = FormatInfo.getEncodedBits(errorCorrectionLevel, maskPattern);
      let i, mod;
      for (i = 0; i < 15; i++) {
        mod = (bits >> i & 1) === 1;
        if (i < 6) {
          matrix.set(i, 8, mod, true);
        } else if (i < 8) {
          matrix.set(i + 1, 8, mod, true);
        } else {
          matrix.set(size - 15 + i, 8, mod, true);
        }
        if (i < 8) {
          matrix.set(8, size - i - 1, mod, true);
        } else if (i < 9) {
          matrix.set(8, 15 - i - 1 + 1, mod, true);
        } else {
          matrix.set(8, 15 - i - 1, mod, true);
        }
      }
      matrix.set(size - 8, 8, 1, true);
    }
    function setupData(matrix, data) {
      const size = matrix.size;
      let inc = -1;
      let row = size - 1;
      let bitIndex = 7;
      let byteIndex = 0;
      for (let col = size - 1; col > 0; col -= 2) {
        if (col === 6) col--;
        while (true) {
          for (let c = 0; c < 2; c++) {
            if (!matrix.isReserved(row, col - c)) {
              let dark = false;
              if (byteIndex < data.length) {
                dark = (data[byteIndex] >>> bitIndex & 1) === 1;
              }
              matrix.set(row, col - c, dark);
              bitIndex--;
              if (bitIndex === -1) {
                byteIndex++;
                bitIndex = 7;
              }
            }
          }
          row += inc;
          if (row < 0 || size <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    }
    function createData(version, errorCorrectionLevel, segments) {
      const buffer = new BitBuffer();
      segments.forEach(function(data) {
        buffer.put(data.mode.bit, 4);
        buffer.put(data.getLength(), Mode.getCharCountIndicator(data.mode, version));
        data.write(buffer);
      });
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
      if (buffer.getLengthInBits() + 4 <= dataTotalCodewordsBits) {
        buffer.put(0, 4);
      }
      while (buffer.getLengthInBits() % 8 !== 0) {
        buffer.putBit(0);
      }
      const remainingByte = (dataTotalCodewordsBits - buffer.getLengthInBits()) / 8;
      for (let i = 0; i < remainingByte; i++) {
        buffer.put(i % 2 ? 17 : 236, 8);
      }
      return createCodewords(buffer, version, errorCorrectionLevel);
    }
    function createCodewords(bitBuffer, version, errorCorrectionLevel) {
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewords = totalCodewords - ecTotalCodewords;
      const ecTotalBlocks = ECCode.getBlocksCount(version, errorCorrectionLevel);
      const blocksInGroup2 = totalCodewords % ecTotalBlocks;
      const blocksInGroup1 = ecTotalBlocks - blocksInGroup2;
      const totalCodewordsInGroup1 = Math.floor(totalCodewords / ecTotalBlocks);
      const dataCodewordsInGroup1 = Math.floor(dataTotalCodewords / ecTotalBlocks);
      const dataCodewordsInGroup2 = dataCodewordsInGroup1 + 1;
      const ecCount = totalCodewordsInGroup1 - dataCodewordsInGroup1;
      const rs = new ReedSolomonEncoder(ecCount);
      let offset = 0;
      const dcData = new Array(ecTotalBlocks);
      const ecData = new Array(ecTotalBlocks);
      let maxDataSize = 0;
      const buffer = new Uint8Array(bitBuffer.buffer);
      for (let b = 0; b < ecTotalBlocks; b++) {
        const dataSize = b < blocksInGroup1 ? dataCodewordsInGroup1 : dataCodewordsInGroup2;
        dcData[b] = buffer.slice(offset, offset + dataSize);
        ecData[b] = rs.encode(dcData[b]);
        offset += dataSize;
        maxDataSize = Math.max(maxDataSize, dataSize);
      }
      const data = new Uint8Array(totalCodewords);
      let index = 0;
      let i, r;
      for (i = 0; i < maxDataSize; i++) {
        for (r = 0; r < ecTotalBlocks; r++) {
          if (i < dcData[r].length) {
            data[index++] = dcData[r][i];
          }
        }
      }
      for (i = 0; i < ecCount; i++) {
        for (r = 0; r < ecTotalBlocks; r++) {
          data[index++] = ecData[r][i];
        }
      }
      return data;
    }
    function createSymbol(data, version, errorCorrectionLevel, maskPattern) {
      let segments;
      if (Array.isArray(data)) {
        segments = Segments.fromArray(data);
      } else if (typeof data === "string") {
        let estimatedVersion = version;
        if (!estimatedVersion) {
          const rawSegments = Segments.rawSplit(data);
          estimatedVersion = Version.getBestVersionForData(rawSegments, errorCorrectionLevel);
        }
        segments = Segments.fromString(data, estimatedVersion || 40);
      } else {
        throw new Error("Invalid data");
      }
      const bestVersion = Version.getBestVersionForData(segments, errorCorrectionLevel);
      if (!bestVersion) {
        throw new Error("The amount of data is too big to be stored in a QR Code");
      }
      if (!version) {
        version = bestVersion;
      } else if (version < bestVersion) {
        throw new Error(
          "\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + bestVersion + ".\n"
        );
      }
      const dataBits = createData(version, errorCorrectionLevel, segments);
      const moduleCount = Utils.getSymbolSize(version);
      const modules = new BitMatrix(moduleCount);
      setupFinderPattern(modules, version);
      setupTimingPattern(modules);
      setupAlignmentPattern(modules, version);
      setupFormatInfo(modules, errorCorrectionLevel, 0);
      if (version >= 7) {
        setupVersionInfo(modules, version);
      }
      setupData(modules, dataBits);
      if (isNaN(maskPattern)) {
        maskPattern = MaskPattern.getBestMask(
          modules,
          setupFormatInfo.bind(null, modules, errorCorrectionLevel)
        );
      }
      MaskPattern.applyMask(maskPattern, modules);
      setupFormatInfo(modules, errorCorrectionLevel, maskPattern);
      return {
        modules,
        version,
        errorCorrectionLevel,
        maskPattern,
        segments
      };
    }
    exports.create = function create(data, options) {
      if (typeof data === "undefined" || data === "") {
        throw new Error("No input text");
      }
      let errorCorrectionLevel = ECLevel.M;
      let version;
      let mask;
      if (typeof options !== "undefined") {
        errorCorrectionLevel = ECLevel.from(options.errorCorrectionLevel, ECLevel.M);
        version = Version.from(options.version);
        mask = MaskPattern.from(options.maskPattern);
        if (options.toSJISFunc) {
          Utils.setToSJISFunction(options.toSJISFunc);
        }
      }
      return createSymbol(data, version, errorCorrectionLevel, mask);
    };
  }
});

// node_modules/qrcode/lib/renderer/utils.js
var require_utils2 = __commonJS({
  "node_modules/qrcode/lib/renderer/utils.js"(exports) {
    function hex2rgba(hex) {
      if (typeof hex === "number") {
        hex = hex.toString();
      }
      if (typeof hex !== "string") {
        throw new Error("Color should be defined as hex string");
      }
      let hexCode = hex.slice().replace("#", "").split("");
      if (hexCode.length < 3 || hexCode.length === 5 || hexCode.length > 8) {
        throw new Error("Invalid hex color: " + hex);
      }
      if (hexCode.length === 3 || hexCode.length === 4) {
        hexCode = Array.prototype.concat.apply([], hexCode.map(function(c) {
          return [c, c];
        }));
      }
      if (hexCode.length === 6) hexCode.push("F", "F");
      const hexValue = parseInt(hexCode.join(""), 16);
      return {
        r: hexValue >> 24 & 255,
        g: hexValue >> 16 & 255,
        b: hexValue >> 8 & 255,
        a: hexValue & 255,
        hex: "#" + hexCode.slice(0, 6).join("")
      };
    }
    exports.getOptions = function getOptions(options) {
      if (!options) options = {};
      if (!options.color) options.color = {};
      const margin = typeof options.margin === "undefined" || options.margin === null || options.margin < 0 ? 4 : options.margin;
      const width = options.width && options.width >= 21 ? options.width : void 0;
      const scale = options.scale || 4;
      return {
        width,
        scale: width ? 4 : scale,
        margin,
        color: {
          dark: hex2rgba(options.color.dark || "#000000ff"),
          light: hex2rgba(options.color.light || "#ffffffff")
        },
        type: options.type,
        rendererOpts: options.rendererOpts || {}
      };
    };
    exports.getScale = function getScale(qrSize, opts) {
      return opts.width && opts.width >= qrSize + opts.margin * 2 ? opts.width / (qrSize + opts.margin * 2) : opts.scale;
    };
    exports.getImageWidth = function getImageWidth(qrSize, opts) {
      const scale = exports.getScale(qrSize, opts);
      return Math.floor((qrSize + opts.margin * 2) * scale);
    };
    exports.qrToImageData = function qrToImageData(imgData, qr, opts) {
      const size = qr.modules.size;
      const data = qr.modules.data;
      const scale = exports.getScale(size, opts);
      const symbolSize = Math.floor((size + opts.margin * 2) * scale);
      const scaledMargin = opts.margin * scale;
      const palette = [opts.color.light, opts.color.dark];
      for (let i = 0; i < symbolSize; i++) {
        for (let j = 0; j < symbolSize; j++) {
          let posDst = (i * symbolSize + j) * 4;
          let pxColor = opts.color.light;
          if (i >= scaledMargin && j >= scaledMargin && i < symbolSize - scaledMargin && j < symbolSize - scaledMargin) {
            const iSrc = Math.floor((i - scaledMargin) / scale);
            const jSrc = Math.floor((j - scaledMargin) / scale);
            pxColor = palette[data[iSrc * size + jSrc] ? 1 : 0];
          }
          imgData[posDst++] = pxColor.r;
          imgData[posDst++] = pxColor.g;
          imgData[posDst++] = pxColor.b;
          imgData[posDst] = pxColor.a;
        }
      }
    };
  }
});

// node_modules/qrcode/lib/renderer/canvas.js
var require_canvas = __commonJS({
  "node_modules/qrcode/lib/renderer/canvas.js"(exports) {
    var Utils = require_utils2();
    function clearCanvas(ctx, canvas, size) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (!canvas.style) canvas.style = {};
      canvas.height = size;
      canvas.width = size;
      canvas.style.height = size + "px";
      canvas.style.width = size + "px";
    }
    function getCanvasElement() {
      try {
        return document.createElement("canvas");
      } catch (e) {
        throw new Error("You need to specify a canvas element");
      }
    }
    exports.render = function render2(qrData, canvas, options) {
      let opts = options;
      let canvasEl = canvas;
      if (typeof opts === "undefined" && (!canvas || !canvas.getContext)) {
        opts = canvas;
        canvas = void 0;
      }
      if (!canvas) {
        canvasEl = getCanvasElement();
      }
      opts = Utils.getOptions(opts);
      const size = Utils.getImageWidth(qrData.modules.size, opts);
      const ctx = canvasEl.getContext("2d");
      const image = ctx.createImageData(size, size);
      Utils.qrToImageData(image.data, qrData, opts);
      clearCanvas(ctx, canvasEl, size);
      ctx.putImageData(image, 0, 0);
      return canvasEl;
    };
    exports.renderToDataURL = function renderToDataURL(qrData, canvas, options) {
      let opts = options;
      if (typeof opts === "undefined" && (!canvas || !canvas.getContext)) {
        opts = canvas;
        canvas = void 0;
      }
      if (!opts) opts = {};
      const canvasEl = exports.render(qrData, canvas, opts);
      const type = opts.type || "image/png";
      const rendererOpts = opts.rendererOpts || {};
      return canvasEl.toDataURL(type, rendererOpts.quality);
    };
  }
});

// node_modules/qrcode/lib/renderer/svg-tag.js
var require_svg_tag = __commonJS({
  "node_modules/qrcode/lib/renderer/svg-tag.js"(exports) {
    var Utils = require_utils2();
    function getColorAttrib(color, attrib) {
      const alpha = color.a / 255;
      const str = attrib + '="' + color.hex + '"';
      return alpha < 1 ? str + " " + attrib + '-opacity="' + alpha.toFixed(2).slice(1) + '"' : str;
    }
    function svgCmd(cmd, x, y) {
      let str = cmd + x;
      if (typeof y !== "undefined") str += " " + y;
      return str;
    }
    function qrToPath(data, size, margin) {
      let path = "";
      let moveBy = 0;
      let newRow = false;
      let lineLength = 0;
      for (let i = 0; i < data.length; i++) {
        const col = Math.floor(i % size);
        const row = Math.floor(i / size);
        if (!col && !newRow) newRow = true;
        if (data[i]) {
          lineLength++;
          if (!(i > 0 && col > 0 && data[i - 1])) {
            path += newRow ? svgCmd("M", col + margin, 0.5 + row + margin) : svgCmd("m", moveBy, 0);
            moveBy = 0;
            newRow = false;
          }
          if (!(col + 1 < size && data[i + 1])) {
            path += svgCmd("h", lineLength);
            lineLength = 0;
          }
        } else {
          moveBy++;
        }
      }
      return path;
    }
    exports.render = function render2(qrData, options, cb) {
      const opts = Utils.getOptions(options);
      const size = qrData.modules.size;
      const data = qrData.modules.data;
      const qrcodesize = size + opts.margin * 2;
      const bg = !opts.color.light.a ? "" : "<path " + getColorAttrib(opts.color.light, "fill") + ' d="M0 0h' + qrcodesize + "v" + qrcodesize + 'H0z"/>';
      const path = "<path " + getColorAttrib(opts.color.dark, "stroke") + ' d="' + qrToPath(data, size, opts.margin) + '"/>';
      const viewBox = 'viewBox="0 0 ' + qrcodesize + " " + qrcodesize + '"';
      const width = !opts.width ? "" : 'width="' + opts.width + '" height="' + opts.width + '" ';
      const svgTag = '<svg xmlns="http://www.w3.org/2000/svg" ' + width + viewBox + ' shape-rendering="crispEdges">' + bg + path + "</svg>\n";
      if (typeof cb === "function") {
        cb(null, svgTag);
      }
      return svgTag;
    };
  }
});

// node_modules/qrcode/lib/browser.js
var require_browser = __commonJS({
  "node_modules/qrcode/lib/browser.js"(exports) {
    var canPromise = require_can_promise();
    var QRCode2 = require_qrcode();
    var CanvasRenderer = require_canvas();
    var SvgRenderer = require_svg_tag();
    function renderCanvas(renderFunc, canvas, text, opts, cb) {
      const args = [].slice.call(arguments, 1);
      const argsNum = args.length;
      const isLastArgCb = typeof args[argsNum - 1] === "function";
      if (!isLastArgCb && !canPromise()) {
        throw new Error("Callback required as last argument");
      }
      if (isLastArgCb) {
        if (argsNum < 2) {
          throw new Error("Too few arguments provided");
        }
        if (argsNum === 2) {
          cb = text;
          text = canvas;
          canvas = opts = void 0;
        } else if (argsNum === 3) {
          if (canvas.getContext && typeof cb === "undefined") {
            cb = opts;
            opts = void 0;
          } else {
            cb = opts;
            opts = text;
            text = canvas;
            canvas = void 0;
          }
        }
      } else {
        if (argsNum < 1) {
          throw new Error("Too few arguments provided");
        }
        if (argsNum === 1) {
          text = canvas;
          canvas = opts = void 0;
        } else if (argsNum === 2 && !canvas.getContext) {
          opts = text;
          text = canvas;
          canvas = void 0;
        }
        return new Promise(function(resolve, reject) {
          try {
            const data = QRCode2.create(text, opts);
            resolve(renderFunc(data, canvas, opts));
          } catch (e) {
            reject(e);
          }
        });
      }
      try {
        const data = QRCode2.create(text, opts);
        cb(null, renderFunc(data, canvas, opts));
      } catch (e) {
        cb(e);
      }
    }
    exports.create = QRCode2.create;
    exports.toCanvas = renderCanvas.bind(null, CanvasRenderer.render);
    exports.toDataURL = renderCanvas.bind(null, CanvasRenderer.renderToDataURL);
    exports.toString = renderCanvas.bind(null, function(data, _, opts) {
      return SvgRenderer.render(data, opts);
    });
  }
});

// src/ui/wallet.ts
var import_qrcode = __toESM(require_browser(), 1);
var root = document.querySelector("#app");
var view = "home";
var status;
var snapshot;
var context = {};
async function rawCommand(name, values = {}) {
  let timer;
  try {
    const response = await Promise.race([
      chrome.runtime.sendMessage({
        channel: "wallet",
        command: name,
        ...values
      }),
      new Promise((_, reject) => {
        timer = setTimeout(
          () => reject(
            new Error(
              "The secure review did not respond within 30 seconds. Try again."
            )
          ),
          3e4
        );
      })
    ]);
    if (!response)
      throw new Error("Kaspire background service did not return a response.");
    if (response.error)
      throw Object.assign(new Error(response.error.message), response.error);
    return response.result;
  } finally {
    if (timer !== void 0) clearTimeout(timer);
  }
}
function persistentCommand(name, values = {}) {
  return new Promise((resolve, reject) => {
    const port = chrome.runtime.connect({ name: "wallet-operation" });
    let finished = false;
    const timer = setTimeout(() => {
      if (!finished) {
        finished = true;
        port.disconnect();
        reject(
          new Error(
            "The secure operation did not respond within 45 seconds. Try again."
          )
        );
      }
    }, 45e3);
    const close = () => {
      if (!finished) {
        finished = true;
        clearTimeout(timer);
        port.disconnect();
      }
    };
    port.onMessage.addListener((response) => {
      if (response?.progress) {
        const button = document.querySelector("#review");
        if (button) button.textContent = response.progress;
        return;
      }
      close();
      response?.error ? reject(
        Object.assign(new Error(response.error.message), response.error)
      ) : resolve(response?.result);
    });
    port.onDisconnect.addListener(() => {
      if (!finished) {
        finished = true;
        clearTimeout(timer);
        reject(
          new Error(
            chrome.runtime.lastError?.message ?? "Kaspire background operation was interrupted."
          )
        );
      }
    });
    port.postMessage({ channel: "wallet", command: name, ...values });
  });
}
function esc(input) {
  const node = document.createElement("span");
  node.textContent = String(input ?? "");
  return node.innerHTML;
}
function value(id) {
  return (document.querySelector(`#${id}`)?.value ?? "").trim();
}
function short(input) {
  return input ? `${input.slice(0, 11)}\u2026${input.slice(-6)}` : "No wallet";
}
function fmt(input, digits = 8) {
  return Number(input || 0).toLocaleString("en-US", {
    maximumFractionDigits: digits
  });
}
function tokenAmount(raw, decimals) {
  const input = String(raw ?? "0").padStart(decimals + 1, "0");
  const whole = (decimals ? input.slice(0, -decimals) : input).replace(
    /\B(?=(\d{3})+(?!\d))/g,
    ","
  );
  const fraction = decimals ? input.slice(-decimals).replace(/0+$/g, "") : "";
  return fraction ? `${whole}.${fraction}` : whole;
}
function rawAmount(input, decimals) {
  const [whole, fraction = ""] = input.split(".");
  if (fraction.length > decimals)
    throw new Error(`This asset supports at most ${decimals} decimals.`);
  return `${whole}${fraction.padEnd(decimals, "0")}`.replace(/^0+(?=\d)/, "");
}
async function copy(text, message = "Copied") {
  await navigator.clipboard.writeText(text);
  toast(message);
}
function toast(message, error = false) {
  const item = document.createElement("div");
  item.className = `toast ${error ? "toast-error" : ""}`;
  item.textContent = message;
  document.body.append(item);
  setTimeout(() => item.remove(), 2200);
}
function download(content, name) {
  const url = URL.createObjectURL(
    new Blob([content], { type: "application/json" })
  );
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}
var caseWords = {
  KAS: "KAS",
  KASPA: "Kaspa",
  KRC20: "KRC20",
  "KRC-20": "KRC-20",
  KRC721: "KRC721",
  "KRC-721": "KRC-721",
  KCC20: "KCC20",
  KNS: "KNS",
  NFT: "NFT",
  NFTS: "NFTs",
  UTXO: "UTXO",
  UTXOS: "UTXOs",
  HUB21: "HUB21",
  BIP39: "BIP39",
  "BIP-39": "BIP-39",
  TN10: "TN10",
  TX: "TX",
  ID: "ID",
  DAPPS: "dApps",
  DAPP: "dApp",
  USD: "USD"
};
function classicCase(container) {
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
  let node;
  while (node = walker.nextNode()) {
    if (node.parentElement?.closest(
      "[data-preserve-case], .wallet-select b, .wallet-card-main b, .my-wallet b, .receive h1"
    )) continue;
    const text = node.textContent ?? "";
    if (!/[A-Z]/.test(text) || text !== text.toUpperCase()) continue;
    node.textContent = text.toLowerCase().replace(
      /[a-z0-9]+(?:-[a-z0-9]+)*/g,
      (word, index) => caseWords[word.toUpperCase()] ?? word[0].toUpperCase() + word.slice(1)
    );
  }
}
function ticker(input) {
  return String(input ?? "").trim().toUpperCase();
}
function eyeIcon(hidden = false) {
  return `<svg class="ui-symbol" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.7"/>${hidden ? '<path d="m4 4 16 16"/>' : ""}</svg>`;
}
function lockIcon() {
  return '<svg class="ui-symbol" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15" r="1"/></svg>';
}
function shell(content, title = "KASPIRE", back = false) {
  root.innerHTML = `<main class="app natural-case"><header class="top">${back ? '<button id="back" class="icon" aria-label="Back">\u2039</button>' : '<img src="kaspire-icon.png" alt="Kaspire">'}<b>${esc(title)}</b>${status && !status.locked ? `<button id="top-lock" class="icon top-lock" aria-label="Lock Kaspire" title="Lock Kaspire">${lockIcon()}</button>` : "<span></span>"}</header>${content}</main>`;
  classicCase(root);
  enhanceForms(root);
  document.querySelector("#top-lock")?.addEventListener("click", async () => {
    await command("lock");
    view = "home";
    await render();
  });
  document.querySelector("#back")?.addEventListener("click", () => {
    view = view === "wallets" || view === "settings" || view === "home" ? "home" : context.returnView ?? (view === "contact" || view === "my-wallets" ? "address-book" : "settings");
    context = {};
    void render();
  });
}
function enhanceForms(container) {
  const textWalker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
  let textNode;
  while (textNode = textWalker.nextNode()) {
    if (textNode.textContent?.toLowerCase().includes("vault password")) {
      textNode.textContent = textNode.textContent.replace(
        /vault password/gi,
        (match) => match[0] === "V" ? "Wallet password" : "wallet password"
      );
    }
  }
  container.querySelectorAll('input[type="password"]').forEach((input) => {
    if (input.parentElement?.classList.contains("password-field")) return;
    const wrapper = document.createElement("span");
    wrapper.className = "password-field";
    input.parentNode.insertBefore(wrapper, input);
    wrapper.append(input);
    const reveal = document.createElement("button");
    reveal.type = "button";
    reveal.className = "password-eye";
    reveal.setAttribute("aria-label", "Show password");
    reveal.innerHTML = eyeIcon(true);
    reveal.onclick = () => {
      const showing = input.type === "text";
      input.type = showing ? "password" : "text";
      reveal.innerHTML = eyeIcon(showing);
      reveal.setAttribute("aria-label", showing ? "Show password" : "Hide password");
      input.focus();
    };
    wrapper.append(reveal);
  });
  container.querySelectorAll("input").forEach((input) => {
    input.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" || event.isComposing) return;
      const scope = input.closest(".form, .verify-grid, section") ?? container;
      const submit = scope.querySelector(
        '#submit, #save, #continue, #review, button[type="submit"]'
      );
      if (!submit || submit.disabled) return;
      event.preventDefault();
      submit.click();
    });
  });
}
async function render() {
  status = await command("status");
  document.documentElement.dataset.theme = status.settings?.theme ?? "midnight";
  if (!status.hasVault) return onboarding();
  if (status.locked) return unlock();
  if (status.recoveryVerified === false)
    return recovery(await command("pendingRecovery"));
  if (view === "home") return home();
  if (view === "wallets") return wallets();
  if (view === "watch" || view === "create-wallet" || view === "import-seed" || view === "import-key" || view === "rename")
    return walletForm();
  if (view === "remove") return removeWallet();
  if (view === "settings") return settings();
  if (view === "display" || view === "security" || view === "backups")
    return settingsDetail();
  if (view === "network") return network();
  if (view === "address-book") return addressBook();
  if (view === "contact") return contactForm();
  if (view === "my-wallets") return myWallets();
  if (view === "receive") return receive();
  if (view === "activity") return activity();
}
function legacyOnboarding(initialMode = "create") {
  let mode = initialMode, count = 24;
  const paint = () => {
    shell(
      `<section class="onboard"><p class="eyebrow">KASPIRE BROWSER WALLET</p><h1>${mode === "create" ? "Create a secure wallet" : mode === "seed" ? "Import recovery words" : "Import private key"}</h1><div class="segmented"><button data-mode="create" class="${mode === "create" ? "active" : ""}">Create</button><button data-mode="seed" class="${mode === "seed" ? "active" : ""}">Seed</button><button data-mode="key" class="${mode === "key" ? "active" : ""}">Private key</button></div><div class="form">${mode === "seed" ? `<div class="word-count"><button data-count="12" class="${count === 12 ? "active" : ""}">12 words</button><button data-count="24" class="${count === 24 ? "active" : ""}">24 words</button></div><div class="seed-grid">${seedFields(count)}</div><label>BIP-39 passphrase <small>optional</small><input id="passphrase" type="password"></label>` : ""}${mode === "key" ? '<label>Wallet name<input id="wallet-name" value="Imported key"></label><label>Private key<input id="private-key" type="password" maxlength="64"></label>' : mode === "create" ? '<label>BIP-39 passphrase <small>optional</small><input id="passphrase" type="password"></label>' : ""}<label>Vault password<input id="password" type="password" minlength="12"></label><label>Confirm password<input id="password-confirm" type="password" minlength="12"></label><button id="submit">${mode === "create" ? "CREATE WALLET" : mode === "seed" ? "IMPORT WALLET" : "IMPORT PRIVATE KEY"}</button><p id="error" class="error"></p></div></section>`
    );
    document.querySelectorAll("[data-mode]").forEach(
      (button) => button.onclick = () => {
        mode = button.dataset.mode;
        paint();
      }
    );
    document.querySelectorAll("[data-count]").forEach(
      (button) => button.onclick = () => {
        count = Number(button.dataset.count);
        paint();
      }
    );
    if (mode === "seed") wireSeed();
    document.querySelector("#submit").onclick = async () => {
      try {
        const password = value("password");
        if (password !== value("password-confirm"))
          throw new Error("Passwords do not match.");
        if (password.length < 12)
          throw new Error("Use at least 12 characters.");
        if (mode === "key")
          await command("createPrivateKey", {
            password,
            privateKey: value("private-key"),
            name: value("wallet-name")
          });
        else {
          const result = await command(
            mode === "create" ? "create" : "import",
            {
              password,
              passphrase: value("passphrase"),
              words: mode === "seed" ? readSeed(count) : ""
            }
          );
          if (result.recoveryPhrase) return recovery(result.recoveryPhrase);
        }
        view = "home";
        await render();
      } catch (error) {
        document.querySelector("#error").textContent = error.message;
      }
    };
  };
  paint();
}
function seedFields(count, words = []) {
  return Array.from(
    { length: count },
    (_, index) => `<label class="seed-word"><span>${index + 1}</span><input data-word="${index}" value="${esc(words[index] ?? "")}" spellcheck="false"><div class="suggestions"></div></label>`
  ).join("");
}
function wireSeed() {
  document.querySelectorAll("[data-word]").forEach(
    (input) => input.oninput = async () => {
      input.value = input.value.toLowerCase().replace(/[^a-z]/g, "");
      const typed = input.value;
      const result = await command("mnemonicWordStatus", {
        phrase: typed
      });
      if (input.value !== typed) return;
      input.classList.toggle(
        "invalid",
        Boolean(typed && result.invalidWords.length)
      );
      const box = input.parentElement.querySelector(".suggestions");
      box.innerHTML = typed.length >= 3 ? result.suggestions.slice(0, 5).map((word) => `<button type="button">${word}</button>`).join("") : "";
      box.querySelectorAll("button").forEach(
        (button) => button.onclick = () => {
          input.value = button.textContent ?? "";
          input.classList.remove("invalid");
          box.innerHTML = "";
          document.querySelector(
            `[data-word="${Number(input.dataset.word) + 1}"]`
          )?.focus();
        }
      );
    }
  );
}
function readSeed(count) {
  const words = Array.from(
    { length: count },
    (_, index) => document.querySelector(`[data-word="${index}"]`).value.trim()
  );
  if (words.some((word) => !word))
    throw new Error(`Enter all ${count} recovery words.`);
  return words.join(" ");
}
function recovery(phrase) {
  const words = phrase.split(" ");
  shell(
    `<section class="onboard recovery"><p class="eyebrow">RECOVERY PHRASE</p><h1>Write these words down.</h1><p class="warning-box">Never photograph, copy or share these words.</p><div class="seed-grid read-only">${seedFields(words.length, words)}</div><button id="verify">I SAVED IT OFFLINE</button><button id="cancel-recovery" class="outline">CANCEL</button><p id="recovery-error" class="error"></p></section>`
  );
  document.querySelectorAll("[data-word]").forEach((input) => input.readOnly = true);
  document.querySelector("#verify").onclick = () => challenge(words);
  document.querySelector("#cancel-recovery").onclick = async () => {
    try {
      await command("cancelPendingRecovery");
      context = {};
      view = "home";
      await render();
    } catch (error) {
      document.querySelector("#recovery-error").textContent = error.message;
    }
  };
}
function challenge(words) {
  const indexes = /* @__PURE__ */ new Set();
  while (indexes.size < 3)
    indexes.add(
      (crypto.getRandomValues(new Uint32Array(1))[0] ?? 0) % words.length
    );
  const chosen = [...indexes].sort((a, b) => a - b);
  shell(
    `<section class="onboard"><p class="eyebrow">VERIFY BACKUP</p><h1>Confirm three words.</h1><div class="verify-grid">${chosen.map((index) => `<label>Word ${index + 1}<input data-check="${index}"></label>`).join("")}</div><button id="finish">VERIFY & CONTINUE</button><p id="error" class="error"></p></section>`,
    "VERIFY SEED",
    true
  );
  document.querySelector("#finish").onclick = async () => {
    try {
      await command("verifyRecovery", {
        checks: chosen.map((index) => ({
          index,
          word: document.querySelector(
            `[data-check="${index}"]`
          ).value
        }))
      });
      view = "home";
      await render();
    } catch (error) {
      document.querySelector("#error").textContent = error.message;
    }
  };
}
function unlock() {
  shell(
    `<section class="unlock"><img class="hero-logo" src="kaspire-icon.png" alt=""><p class="eyebrow">WELCOME BACK</p><h1>Unlock Kaspire</h1><div class="form"><label>Vault password<input id="password" type="password"></label><button id="submit">UNLOCK WALLET</button><p id="error" class="error"></p></div></section>`
  );
  document.querySelector("#submit").onclick = async () => {
    try {
      await command("unlock", { password: value("password") });
      view = "home";
      await render();
    } catch (error) {
      document.querySelector("#error").textContent = error.message;
    }
  };
}
function home() {
  const selected = status.addresses.find(
    (item) => item.address === status.selectedAddress
  );
  shell(
    `<section class="dashboard"><div class="wallet-head"><div class="wallet-brand"><button id="wallets" class="wallet-select"><img src="kaspire-icon.png" alt=""><span><b>${esc(selected?.name ?? "Wallet")}</b><small id="active-address">${short(status.selectedAddress)}</small></span></button><button id="copy-main-address" class="copy-main" title="Copy wallet address" aria-label="Copy wallet address">\u29C9</button></div><div class="head-buttons"><button id="network" class="pill">\u25CF ${networkLabel()}</button><button id="settings" class="icon">\u2699</button></div></div><section class="balance-card"><p>TOTAL BALANCE</p><strong id="balance">\u2014 ${status.network === "igra" ? "iKAS" : "KAS"}</strong><small id="fiat"></small><button id="privacy" class="eye" aria-label="${status.settings.hideBalances ? "Show balances" : "Hide balances"}">${eyeIcon(status.settings.hideBalances)}</button></section><div class="quick-actions"><button id="send"><b>\u2191</b><span>SEND</span></button><button id="receive"><b>\u2193</b><span>RECEIVE</span></button><button id="activity"><b>\u2261</b><span>ACTIVITY</span></button></div><section class="assets"><div class="section-title"><h2>ASSETS & NAMES</h2><span id="asset-count"></span></div><div id="asset-list"><div class="loading">Loading assets\u2026</div></div></section><button id="app-promo" class="app-promo">Kaspire is even better in the app!<span>\u203A</span></button></section>`
  );
  document.querySelector("#wallets").onclick = () => go("wallets");
  document.querySelector("#copy-main-address").onclick = async () => copy(isL2() ? await command("evmAddress") : status.selectedAddress, "Wallet address copied");
  document.querySelector("#network").onclick = chooseNetwork;
  document.querySelector("#settings").onclick = () => go("settings");
  document.querySelector("#privacy").onclick = async () => {
    await command("setSettings", {
      settings: { hideBalances: !status.settings.hideBalances }
    });
    await render();
  };
  document.querySelector("#send").onclick = () => isL2() ? sendEvm() : send({ kind: "kas" });
  document.querySelector("#receive").onclick = () => go("receive");
  document.querySelector("#activity").onclick = () => go("activity");
  document.querySelector("#app-promo").onclick = () => chrome.tabs.create({ url: "https://kaspire.kaslab.space/" });
  void loadHome();
}
function isL2() {
  return status.network === "kasplex" || status.network === "igra";
}
function networkLabel() {
  return status.network === "mainnet" ? "MAINNET" : status.network === "testnet-10" ? "TN10" : status.network === "kasplex" ? "KASPLEX" : "IGRA";
}
function chooseNetwork() {
  const overlay = document.createElement("div");
  overlay.className = "kaspire-modal";
  overlay.innerHTML = `<section class="recipient-sheet"><div class="sheet-title"><h2>Select network</h2><button id="close-network" class="icon">\xD7</button></div>${[["mainnet", "Kaspa Mainnet"], ["testnet-10", "Kaspa TN10"], ["kasplex", "Kasplex L2"], ["igra", "Igra L2"]].map(([id, name]) => `<button class="recipient-row" data-network="${id}"><span>\u25CF</span><span><b>${name}</b><small>${id === status.network ? "Selected" : "Switch network"}</small></span></button>`).join("")}</section>`;
  document.body.append(overlay);
  overlay.querySelector("#close-network").onclick = () => overlay.remove();
  overlay.querySelectorAll("[data-network]").forEach((button) => button.onclick = async () => {
    await command("setNetwork", { network: button.dataset.network });
    overlay.remove();
    await render();
  });
}
function walletCard(item) {
  return `<article class="wallet-card ${item.watchOnly ? "watch-card" : ""}" data-select="${esc(item.address)}"><div class="wallet-type">${item.watchOnly ? "\u25C9 WATCH WALLET" : "\u25C6 SIGNING WALLET"}</div><div class="wallet-card-main"><span class="wallet-symbol">${item.watchOnly ? "\u25CE" : "\u25A3"}</span><span><b>${esc(item.name)}</b><small>${esc(item.path)}</small><button class="copy-wallet" data-copy="${esc(item.address)}">${short(item.address)} \u29C9</button></span></div><div class="wallet-card-actions"><button class="mini rename-wallet" data-address="${esc(item.address)}">RENAME</button><button class="mini danger-outline remove-wallet" data-address="${esc(item.address)}">REMOVE</button></div></article>`;
}
function wallets() {
  const signing = status.addresses.filter(
    (item) => !item.watchOnly && (status.settings.showSubwallets || item.index === 0)
  );
  const watches = status.addresses.filter((item) => item.watchOnly);
  shell(
    `<section class="wallets-screen"><p class="eyebrow">KASPIRE WALLETS</p><h1>Wallets</h1><h2>SIGNING WALLETS</h2><div class="wallet-list">${signing.map(walletCard).join("") || '<div class="empty">No signing wallets.</div>'}</div><h2>WATCH WALLETS</h2><div class="wallet-list">${watches.map(walletCard).join("") || '<div class="empty">No watch wallets stored.</div>'}</div><div class="wallet-actions"><button id="subwallet">\uFF0B SUBWALLET</button><button id="account">\uFF0B ACCOUNT</button><button id="create-wallet" class="outline">\uFF0B CREATE WALLET</button><button id="seed" class="outline">IMPORT 12 / 24 WORDS</button><button id="key" class="outline">IMPORT PRIVATE KEY</button><button id="watch" class="outline">ADD WATCH WALLET</button></div></section>`,
    "WALLETS",
    true
  );
  document.querySelectorAll("[data-select]").forEach(
    (card) => card.onclick = async (event) => {
      if (event.target.closest("button")) return;
      await command("select", { address: card.dataset.select });
      view = "home";
      await render();
    }
  );
  document.querySelectorAll("[data-copy]").forEach(
    (button) => button.onclick = () => copy(button.dataset.copy ?? "", "Address copied")
  );
  document.querySelectorAll(".rename-wallet").forEach(
    (button) => button.onclick = () => {
      context = { address: button.dataset.address, returnView: "wallets" };
      go("rename");
    }
  );
  document.querySelectorAll(".remove-wallet").forEach(
    (button) => button.onclick = () => {
      context = { address: button.dataset.address, returnView: "wallets" };
      go("remove");
    }
  );
  document.querySelector("#watch").onclick = () => go("watch");
  document.querySelector("#create-wallet").onclick = () => go("create-wallet");
  document.querySelector("#seed").onclick = () => go("import-seed");
  document.querySelector("#key").onclick = () => go("import-key");
  document.querySelector("#subwallet").onclick = async () => {
    try {
      await command("addSubwallet");
      await render();
    } catch (error) {
      toast(error.message, true);
    }
  };
  document.querySelector("#account").onclick = async () => {
    try {
      await command("addAccount");
      await render();
    } catch (error) {
      toast(error.message, true);
    }
  };
}
function walletForm() {
  const mode = view, current = status.addresses.find(
    (item) => item.address === context.address
  ), countState = { count: 12 };
  const title = mode === "watch" ? "Add watch wallet" : mode === "create-wallet" ? "Create a secure wallet" : mode === "import-seed" ? "Import recovery words" : mode === "import-key" ? "Import private key" : "Rename wallet";
  shell(
    `<section class="form-page"><p class="eyebrow">${mode === "watch" ? "WATCH ONLY" : "KASPIRE WALLET"}</p><h1>${title}</h1>${mode === "watch" ? '<p class="info-box">Watch wallets display public balances and assets, but cannot sign or spend.</p>' : mode === "create-wallet" ? '<p class="info-box">Choose 12 or 24 recovery words. An optional BIP-39 passphrase creates a separate wallet and cannot be recovered from the words alone.</p>' : ""}<div class="form"><label>Wallet name<input id="wallet-name" value="${esc(current?.name ?? (mode === "watch" ? "Watch wallet" : mode === "create-wallet" ? `Wallet ${status.addresses.filter((item) => !item.watchOnly && item.account === 0 && item.index === 0).length + 1}` : mode === "import-key" ? "Imported key" : "Imported wallet"))}"></label>${mode === "watch" ? '<label>Kaspa address or name.kas<input id="wallet-address" placeholder="kaspa:\u2026 or name.kas"></label>' : mode === "import-key" ? '<label>Private key<input id="private-key" type="password" maxlength="64"></label><label>Vault password<input id="vault-password" type="password"></label>' : mode === "import-seed" ? `<div class="word-count"><button data-count="12" class="active">12 words</button><button data-count="24">24 words</button></div><div id="seed-grid" class="seed-grid">${seedFields(12)}</div><label>BIP-39 passphrase <small>optional</small><input id="passphrase" type="password"></label><label>Vault password<input id="vault-password" type="password"></label>` : mode === "create-wallet" ? '<div class="word-count"><button data-count="12" class="active">12 words</button><button data-count="24">24 words</button></div><label>Vault password<input id="vault-password" type="password" autocomplete="current-password"></label><label class="toggle-row"><span>Use BIP39 passphrase</span><input id="use-passphrase" type="checkbox"></label><label id="passphrase-field" style="display:none">BIP39 passphrase<input id="passphrase" type="password" autocomplete="off"><small>This cannot be recovered from the seed words.</small></label>' : ""}<button id="save">${mode === "rename" ? "SAVE NAME" : mode === "watch" ? "ADD WATCH WALLET" : mode === "create-wallet" ? "CREATE WALLET" : "IMPORT WALLET"}</button><p id="error" class="error"></p></div></section>`,
    title.toUpperCase(),
    true
  );
  if (mode === "import-seed" || mode === "create-wallet") {
    if (mode === "import-seed") wireSeed();
    document.querySelectorAll("[data-count]").forEach(
      (button) => button.onclick = () => {
        countState.count = Number(button.dataset.count);
        if (mode === "import-seed")
          document.querySelector("#seed-grid").innerHTML = seedFields(
            countState.count
          );
        document.querySelectorAll("[data-count]").forEach(
          (item) => item.classList.toggle(
            "active",
            item.dataset.count === String(countState.count)
          )
        );
        if (mode === "import-seed") wireSeed();
      }
    );
    if (mode === "create-wallet") {
      const passphraseToggle = document.querySelector("#use-passphrase");
      const passphraseField = document.querySelector("#passphrase-field");
      passphraseToggle.onchange = () => {
        passphraseField.style.display = passphraseToggle.checked ? "block" : "none";
        if (!passphraseToggle.checked)
          document.querySelector("#passphrase").value = "";
      };
    }
  }
  document.querySelector("#save").onclick = async () => {
    try {
      if (mode === "watch")
        await command("addWatch", {
          name: value("wallet-name"),
          address: value("wallet-address")
        });
      else if (mode === "import-key")
        await command("addPrivateKey", {
          name: value("wallet-name"),
          privateKey: value("private-key"),
          password: value("vault-password")
        });
      else if (mode === "import-seed")
        await command("addMnemonic", {
          name: value("wallet-name"),
          words: readSeed(countState.count),
          passphrase: value("passphrase"),
          password: value("vault-password")
        });
      else if (mode === "create-wallet") {
        const result = await command("addGeneratedMnemonic", {
          name: value("wallet-name"),
          wordCount: countState.count,
          passphrase: document.querySelector(
            "#use-passphrase"
          )?.checked ? value("passphrase") : "",
          password: value("vault-password")
        });
        context = {};
        return recovery(result.recoveryPhrase);
      } else
        await command("rename", {
          address: context.address,
          name: value("wallet-name")
        });
      context = {};
      view = "wallets";
      await render();
    } catch (error) {
      document.querySelector("#error").textContent = error.message;
    }
  };
}
function removeWallet() {
  const item = status.addresses.find(
    (entry) => entry.address === context.address
  );
  const removesEntireWallet = item && !item.watchOnly && (item.path === "private-key" || item.account === 0 && item.change === 0 && item.index === 0);
  shell(
    `<section class="confirm-page"><div class="confirm-icon">!</div><h1>Remove ${esc(item?.name ?? "wallet")}?</h1><p>${item?.watchOnly ? "This removes only the watch-wallet entry." : removesEntireWallet ? "This removes the signing wallet and every account or subwallet derived from it. Verify your offline recovery backup first." : "This removes only this derived address. Verify your offline backup first."}</p><button id="remove" class="danger">REMOVE WALLET</button><button id="cancel" class="outline">CANCEL</button><p id="error" class="error"></p></section>`,
    "CONFIRM",
    true
  );
  document.querySelector("#cancel").onclick = () => go("wallets");
  document.querySelector("#remove").onclick = async () => {
    try {
      await command("removeAddress", { address: context.address });
      context = {};
      view = "wallets";
      await render();
    } catch (error) {
      document.querySelector("#error").textContent = error.message;
    }
  };
}
function settingsLink(icon, title, subtitle, target) {
  return `<button class="settings-link" data-view="${target}"><span class="setting-icon">${icon}</span><span><b>${title}</b><small>${subtitle}</small></span><i>\u203A</i></button>`;
}
function settings() {
  shell(
    `<section class="settings"><div class="settings-title"><span><p class="eyebrow">KASPIRE</p><h1>Settings</h1></span><button id="hub21"><img src="hub21-wordmark.png" alt="HUB21"></button></div>${settingsLink("\u233E", "Security", "Automatic lock \xB7 encrypted vault", "security")}${settingsLink("\u25A3", "Wallets", "Signing \xB7 watch \xB7 accounts \xB7 subwallets", "wallets")}${settingsLink("\u25C9", "Wallet display", `${status.settings.currency} \xB7 ${status.settings.theme} \xB7 privacy`, "display")}${settingsLink("\u25CE", "Network", "Endpoint \xB7 dApp sessions \xB7 diagnostics", "network")}${settingsLink("\u2659", "Address book", "Contacts \xB7 recipient allowlist", "address-book")}${settingsLink("\u21E9", "Backups", "Encrypted backup \xB7 recovery \xB7 private key", "backups")}<details class="settings-group"><summary><span class="setting-icon">\u2197</span><b>HUB21 Toolbox</b><i>\u203A</i></summary><div class="settings-content">${toolbox()}</div></details><button id="lock" class="outline settings-lock">LOCK KASPIRE</button><footer class="settings-about"><span>Kaspire Extension</span><b>Version ${esc(chrome.runtime.getManifest().version)}</b><button id="report-bug" class="report-bug"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21.7 3.2 18.5 20c-.2 1.2-.9 1.5-1.9.9l-4.9-3.6-2.4 2.3c-.3.3-.5.5-1 .5l.4-5 9.1-8.2c.4-.4-.1-.6-.6-.2L6 13.7l-4.8-1.5c-1.1-.3-1.1-1 .2-1.5L20.2 3c.9-.3 1.7.2 1.5.2Z"/></svg><span>Report a bug</span></button></footer></section>`,
    "SETTINGS",
    true
  );
  document.querySelector("#hub21").onclick = () => chrome.tabs.create({ url: "https://kaslab.space" });
  document.querySelector("#report-bug").onclick = () => chrome.tabs.create({ url: "https://t.me/kaspirewallet" });
  document.querySelectorAll("[data-view]").forEach(
    (button) => button.onclick = () => go(button.dataset.view)
  );
  document.querySelector("#lock").onclick = async () => {
    await command("lock");
    await render();
  };
  wireLinks();
}
function settingsDetail() {
  if (view === "security")
    shell(
      `<section class="form-page"><h1>Security</h1><div class="form"><label>Automatic wallet lock<select id="autolock">${[[0, "Immediately"], [1, "1 minute"], [5, "5 minutes"], [15, "15 minutes"], [30, "30 minutes"], [60, "60 minutes"], [-1, "Never"]].map(([minutes, label]) => `<option value="${minutes}" ${status.settings.autoLockMinutes === minutes ? "selected" : ""}>${label}</option>`).join("")}</select></label><div class="endpoint-card"><b>Hardware-backed browser wallet</b><span>Argon2id + AES-256-GCM</span><small>Secrets remain encrypted at rest.</small></div></div></section>`,
      "SECURITY",
      true
    );
  else if (view === "display")
    shell(
      `<section class="form-page"><h1>Wallet display</h1><div class="form"><label>Currency<select id="currency">${["USD", "EUR", "GBP", "AUD", "CAD", "JPY", "CNY", "CHF", "INR", "BRL", "KRW"].map((code) => `<option ${status.settings.currency === code ? "selected" : ""}>${code}</option>`).join("")}</select></label><label>Kaspire design<select id="theme">${["midnight", "emerald", "amethyst", "sakura", "crimson", "phoenix", "cypherpunk"].map((theme) => `<option ${status.settings.theme === theme ? "selected" : ""}>${theme}</option>`).join("")}</select></label>${toggle("show-subwallets", "Show subwallets", status.settings.showSubwallets)}${toggle("hide", "Privacy: hide wallet amounts", status.settings.hideBalances)}</div></section>`,
      "WALLET DISPLAY",
      true
    );
  else
    shell(
      `<section class="form-page"><h1>Backups</h1><p class="info-box">All sensitive actions stay inside Kaspire.</p><button id="backup">EXPORT ENCRYPTED BACKUP</button><button id="restore" class="outline">RESTORE ENCRYPTED BACKUP</button><button id="recovery" class="danger-outline">EXPORT RECOVERY PHRASE</button><button id="private" class="danger-outline">EXPORT PRIVATE KEY</button></section>`,
      "BACKUPS",
      true
    );
  if (view === "security")
    document.querySelector("#autolock").onchange = (event) => void command("setSettings", {
      settings: {
        autoLockMinutes: Number(event.target.value)
      }
    });
  if (view === "display") {
    const keys = {
      "show-subwallets": "showSubwallets",
      hide: "hideBalances"
    };
    Object.entries(keys).forEach(
      ([id, key]) => document.querySelector(`#${id}`).onchange = (event) => void command("setSettings", {
        settings: {
          [String(key)]: event.target.checked
        }
      })
    );
    document.querySelector("#currency").onchange = (event) => void command("setSettings", {
      settings: { currency: event.target.value }
    });
    document.querySelector("#theme").onchange = async (event) => {
      await command("setSettings", {
        settings: { theme: event.target.value }
      });
      await render();
    };
  }
  if (view === "backups") wireBackup();
}
function toggle(id, label, checked) {
  return `<label class="toggle-row"><span>${label}</span><input id="${id}" type="checkbox" ${checked ? "checked" : ""}></label>`;
}
function toolbox() {
  return [
    ["Token Explorer", "https://kaspatoken.kaslab.space"],
    ["KasCoven Vaults", "https://vaults.kaslab.space"],
    ["Kaspa Dev Tools", "https://devtools.kaslab.space"],
    ["KCC20 Indexer", "https://kcc20.info"],
    ["Discover more", "https://kaslab.space"]
  ].map(
    ([name, url]) => `<button class="tool-link outline" data-url="${url}">${name}<span>\u2197</span></button>`
  ).join("");
}
function wireLinks() {
  document.querySelectorAll(".tool-link").forEach(
    (button) => button.onclick = () => chrome.tabs.create({ url: button.dataset.url ?? "" })
  );
}
function wireBackup() {
  for (const action of ["backup", "restore", "recovery", "private"])
    document.querySelector(`#${action}`).onclick = () => secretAction(action);
}
function secretAction(action) {
  const backup = action === "backup", restore = action === "restore";
  shell(
    `<section class="form-page"><p class="eyebrow">SECURE ACTION</p><h1>${backup ? "Encrypted portable backup" : restore ? "Restore encrypted backup" : "Confirm vault password"}</h1>${backup ? '<p class="info-box">Choose a unique password. Kaspire cannot recover this password or a lost BIP-39 passphrase.</p>' : restore ? '<p class="info-box">Paste the complete kaspire-backup-v1 or v2 JSON. It is decrypted only inside Kaspire.</p>' : ""}<div class="form">${restore ? '<label>Encrypted Kaspire backup<textarea id="backup-code" rows="7" placeholder="Paste the complete backup text"></textarea></label>' : ""}<label>${backup ? "Backup password (12+ characters)" : "Vault password"}<input id="secret-password" type="password"></label>${backup ? '<label>Confirm backup password<input id="confirm-password" type="password"></label>' : ""}<button id="continue">${backup ? "ENCRYPT BACKUP" : restore ? "RESTORE" : "CONTINUE"}</button><p id="error" class="error"></p><pre id="secret" hidden></pre><div id="backup-actions" hidden><button id="copy-backup" class="outline">COPY BACKUP TEXT</button><button id="save-backup" class="outline">SAVE JSON FILE</button></div></div></section>`,
    "AUTHORIZE",
    true
  );
  document.querySelector("#continue").onclick = async () => {
    try {
      const password = value("secret-password");
      if (backup) {
        if (password.length < 12)
          throw new Error("Use at least 12 characters.");
        if (password !== value("confirm-password"))
          throw new Error("Backup passwords do not match.");
        const secret = await command("exportBackup", { password });
        const output = document.querySelector("#secret");
        output.hidden = false;
        output.textContent = secret;
        const actions = document.querySelector("#backup-actions");
        actions.hidden = false;
        document.querySelector("#copy-backup").onclick = () => copy(secret, "Encrypted backup copied");
        document.querySelector("#save-backup").onclick = () => download(secret, "kaspire-backup-v2.json");
        document.querySelector("#secret-password").value = "";
        document.querySelector("#confirm-password").value = "";
      } else if (restore) {
        await command("importBackup", {
          password,
          backup: value("backup-code")
        });
        toast("Backup restored");
        view = "home";
        await render();
      } else {
        const secret = await command("exportSecret", {
          password,
          type: action
        });
        const output = document.querySelector("#secret");
        output.hidden = false;
        output.textContent = secret;
      }
    } catch (error) {
      document.querySelector("#error").textContent = error.message;
    }
  };
}
function network() {
  const l2 = isL2();
  shell(
    `<section class="network-screen"><p class="eyebrow">NETWORK</p><h1>${l2 ? `${networkLabel()} Layer 2` : status.network === "testnet-10" ? "Kaspa TN10" : "Kaspa Mainnet"}</h1><div class="endpoint-card"><b>${l2 ? "EVM RPC endpoint" : "Kaspa endpoint"}</b><code>${status.network === "kasplex" ? "https://evmrpc.kasplex.org" : status.network === "igra" ? "https://rpc.igralabs.com:8545" : status.network === "testnet-10" ? "https://api-tn10.kaspa.org" : "https://kaspire.kaslab.space/api"}</code><small>${l2 ? "Live Layer 2 RPC" : "Kaspire node gateway"}</small></div><div class="network-list">${l2 ? `<div><span>Assets & activity</span><b>Verified L2 explorer API</b></div><div><span>Transaction signer</span><b>Native Rust EVM core</b></div>` : `<div><span>KRC-20 / KNS / KRC-721</span><b>KaspaToken + fallbacks</b></div><div><span>KCC20</span><b>kcc20.info + KasCOV</b></div>`}<div><span>Connection</span><b>Encrypted browser provider</b></div><div><span>Connected dApps</span><b>${Object.keys(status.permissions).length}</b></div></div><button id="diagnostics">RUN NETWORK DIAGNOSTICS</button><div id="results"></div></section>`,
    "NETWORK",
    true
  );
  document.querySelector("#diagnostics").onclick = async () => {
    const output = document.querySelector("#results");
    output.innerHTML = '<div class="loading">Running checks\u2026</div>';
    const checks = await command("networkDiagnostics");
    output.innerHTML = checks.map(
      (check) => `<article class="diagnostic ${check.ok ? "ok" : "fail"}"><b>${check.ok ? "\u25CF" : "!"} ${esc(check.name)}</b><code>${esc(check.url)}</code><span>${esc(check.detail)} \xB7 ${check.elapsedMs} ms</span></article>`
    ).join("");
  };
}
function addressBook() {
  shell(
    `<section class="address-book"><p class="eyebrow">RECIPIENTS</p><h1>Address book</h1><label class="allowlist"><span><b>Only allow saved recipients</b><small>Blocks transfers to addresses outside this address book.</small></span><input id="allowlist" type="checkbox" ${status.settings.recipientAllowlist ? "checked" : ""}></label><div class="contact-list">${status.contacts.map((item) => `<article><span class="contact-avatar">\u2659</span><span><b>${esc(item.name)}</b><small>${short(item.address)}</small></span><button class="mini edit" data-id="${item.id}">EDIT</button><button class="mini danger-outline delete" data-id="${item.id}">\xD7</button></article>`).join("") || '<div class="empty">No saved contacts.</div>'}</div><div class="bottom-actions"><button id="mine" class="outline">MY WALLETS</button><button id="add">ADD CONTACT</button></div></section>`,
    "ADDRESS BOOK",
    true
  );
  document.querySelector("#allowlist").onchange = (event) => void command("setSettings", {
    settings: {
      recipientAllowlist: event.target.checked
    }
  });
  document.querySelector("#mine").onclick = () => go("my-wallets");
  document.querySelector("#add").onclick = () => {
    context = { returnView: "address-book" };
    go("contact");
  };
  document.querySelectorAll(".edit").forEach(
    (button) => button.onclick = () => {
      context = { contactId: button.dataset.id, returnView: "address-book" };
      go("contact");
    }
  );
  document.querySelectorAll(".delete").forEach(
    (button) => button.onclick = async () => {
      await command("removeContact", { id: button.dataset.id });
      await render();
    }
  );
}
function contactForm() {
  const contact = status.contacts.find(
    (item) => item.id === context.contactId
  );
  shell(
    `<section class="form-page"><p class="eyebrow">ADDRESS BOOK</p><h1>${contact ? "Edit contact" : "Add contact"}</h1><div class="form"><label>Name<input id="name" value="${esc(contact?.name ?? "")}"></label><label>Kaspa address or name.kas<input id="address" value="${esc(contact?.address ?? "")}"></label><button id="save">SAVE CONTACT</button><p id="error" class="error"></p></div></section>`,
    "CONTACT",
    true
  );
  document.querySelector("#save").onclick = async () => {
    try {
      await command(contact ? "editContact" : "addContact", {
        id: contact?.id,
        name: value("name"),
        address: value("address")
      });
      context = {};
      view = "address-book";
      await render();
    } catch (error) {
      document.querySelector("#error").textContent = error.message;
    }
  };
}
function myWallets() {
  shell(
    `<section class="wallets-screen"><p class="eyebrow">ADDRESS BOOK</p><h1>My wallets</h1><div class="wallet-list">${status.addresses.map((item) => `<article class="my-wallet"><span class="wallet-symbol">${item.watchOnly ? "\u25CE" : "\u25A3"}</span><span><b>${esc(item.name)}</b><small>${esc(item.watchOnly ? "Watch wallet" : item.path)}</small><code>${esc(item.address)}</code></span><button class="mini own-copy" data-address="${esc(item.address)}">COPY</button></article>`).join("")}</div></section>`,
    "MY WALLETS",
    true
  );
  document.querySelectorAll(".own-copy").forEach(
    (button) => button.onclick = () => copy(button.dataset.address ?? "", "Wallet address copied")
  );
}
async function receive() {
  const current = status.addresses.find(
    (item) => item.address === status.selectedAddress
  );
  const address = isL2() ? await command("evmAddress") : status.selectedAddress;
  shell(
    `<section class="receive"><div class="receive-icon">\u2193</div><p class="eyebrow">RECEIVE ${networkLabel()}</p><h1>${esc(current?.name ?? "Wallet")}</h1><div class="receive-qr"><img id="receive-qr" alt="QR code for the receive address"></div><div class="address-full">${esc(address)}</div><button id="copy">COPY ADDRESS</button><p>${isL2() ? "Share this address only for L2 payments and assets." : "Only send assets for the selected Kaspa network."}</p></section>`,
    "RECEIVE",
    true
  );
  document.querySelector("#copy").onclick = () => copy(address, "Address copied");
  document.querySelector("#receive-qr").src = await import_qrcode.default.toDataURL(address, {
    width: 260,
    margin: 2,
    errorCorrectionLevel: "M",
    color: { dark: "#061012", light: "#ffffff" }
  });
}
async function loadHome() {
  try {
    if (isL2()) return await loadEvmHome();
    const balance = await command("balanceSnapshot");
    snapshot = {
      ...balance,
      utxoCount: 0,
      utxos: [],
      assets: { tokens: [], domains: [], krc721: [], kcc20: [] }
    };
    if (!document.querySelector("#balance")) return;
    document.querySelector("#balance").textContent = status.settings.hideBalances ? "\u2022\u2022\u2022\u2022 KAS" : `${fmt(balance.balanceKas)} KAS`;
    document.querySelector("#fiat").textContent = "Loading market value\u2026";
    void command("market").then((market) => {
      if (!document.querySelector("#fiat")) return;
      document.querySelector("#fiat").textContent = market && !status.settings.hideBalances ? `\u2248 ${(balance.balanceKas * market.kasUsd * market.rate).toLocaleString("en-US", { style: "currency", currency: market.currency })}` : "Live balance";
    }).catch(() => {
      if (document.querySelector("#fiat"))
        document.querySelector("#fiat").textContent = "Live balance";
    });
    void command("coreSnapshot").then((core) => {
      snapshot = { ...snapshot, ...core };
      if (document.querySelector("#fiat"))
        document.querySelector("#fiat").textContent += " \xB7 " + fmt(core.utxoCount, 0) + " UTXOs";
      addCompound(core);
    });
    const assets = await command("assetsSnapshot");
    if (!document.querySelector("#asset-list")) return;
    snapshot = { ...snapshot, assets };
    renderAssetGroups(assets);
  } catch (error) {
    if (document.querySelector("#asset-list"))
      document.querySelector("#asset-list").innerHTML = `<p class="error">${esc(error.message)}</p>`;
  }
}
async function loadEvmHome() {
  const data = await command("balanceSnapshot");
  snapshot = data;
  if (!document.querySelector("#balance")) return;
  document.querySelector("#active-address").textContent = short(data.address);
  document.querySelector("#balance").textContent = status.settings.hideBalances ? `\u2022\u2022\u2022\u2022 ${data.nativeSymbol}` : `${fmt(data.balanceKas)} ${data.nativeSymbol}`;
  document.querySelector("#fiat").textContent = `${networkLabel()} \xB7 Layer 2`;
  document.querySelector("#asset-count").textContent = String(data.tokens.length);
  document.querySelector("#asset-list").innerHTML = data.tokens.length ? `<details class="asset-group"><summary><span class="group-icon">\u25B1</span><span><b>L2 TOKENS</b><small>${data.tokens.length} assets</small></span><i>\u2304</i></summary><div>${data.tokens.map((token, index) => `<button class="asset-row" data-evm-token="${index}"><span class="asset-icon">${token.iconUrl ? `<img src="${esc(token.iconUrl)}" alt="">` : esc(token.symbol.slice(0, 1))}</span><span><b data-preserve-case>${esc(token.symbol)}</b><small>${status.settings.hideBalances ? "\u2022\u2022\u2022\u2022\u2022\u2022" : esc(token.balance)}</small></span><i>\u203A</i></button>`).join("")}</div></details>` : '<div class="empty">No Layer 2 tokens found.</div>';
  document.querySelectorAll("[data-evm-token]").forEach((button) => button.onclick = () => evmTokenDetail(data.tokens[Number(button.dataset.evmToken)]));
}
function evmTokenDetail(token) {
  shell(`<section class="token-detail"><div class="token-logo">${token.iconUrl ? `<img src="${esc(token.iconUrl)}" alt="">` : esc(token.symbol.slice(0, 2))}</div><h1 data-preserve-case>${esc(token.symbol)}</h1><p>${status.settings.hideBalances ? "\u2022\u2022\u2022\u2022\u2022\u2022" : esc(token.balance)} ${esc(token.symbol)}</p><div class="review-card"><div><span>Network</span><b>${networkLabel()}</b></div><div><span>Contract</span><b class="wrap-id">${esc(token.contract)}</b></div><div><span>Verification</span><b>${token.trusted ? "Known bridge asset" : "On-chain token"}</b></div></div><button id="send-evm-token">Send asset</button></section>`, "TOKEN DETAILS", true);
  document.querySelector("#send-evm-token").onclick = () => sendEvm(token);
}
function renderAssetGroups(assets) {
  const groups = [
    {
      key: "krc20",
      title: "KRC-20 TOKENS",
      items: (assets.tokens ?? []).map((raw) => ({
        kind: "krc20",
        symbol: ticker(raw.symbol),
        balance: tokenAmount(raw.raw_balance, raw.decimals),
        raw: { ...raw, symbol: ticker(raw.symbol) }
      }))
    },
    {
      key: "kcc20",
      title: "KCC20 COVENANT TOKENS",
      items: (assets.kcc20 ?? []).map((raw) => ({
        kind: "kcc20",
        symbol: ticker(raw.symbol),
        balance: tokenAmount(raw.rawBalance, raw.decimals),
        raw: { ...raw, symbol: ticker(raw.symbol) }
      }))
    },
    {
      key: "krc721",
      title: "KRC-721 COLLECTIONS",
      items: (assets.krc721 ?? []).map((raw) => ({
        kind: "krc721",
        symbol: ticker(raw.symbol),
        balance: String(raw.balance ?? 1),
        raw: { ...raw, symbol: ticker(raw.symbol) }
      }))
    },
    {
      key: "kns",
      title: "KNS DOMAINS",
      items: (assets.domains ?? []).map((raw) => ({
        kind: "kns",
        symbol: raw.name,
        balance: "",
        raw
      }))
    }
  ].filter((group) => group.items.length);
  document.querySelector("#asset-count").textContent = String(
    groups.reduce((sum, group) => sum + group.items.length, 0)
  );
  document.querySelector("#asset-list").innerHTML = groups.length ? groups.map(
    (group) => `<details class="asset-group"><summary><span class="group-icon">\u25B1</span><span><b>${group.title}</b><small>${group.items.length} asset${group.items.length === 1 ? "" : "s"}</small></span><i>\u2304</i></summary><div>${group.key === "kns" ? `<div class="kns-chips">${group.items.map((item, index) => `<button data-group="${group.key}" data-index="${index}">\u25CE ${esc(item.symbol)}</button>`).join("")}</div>` : group.items.map((item, index) => `<button class="asset-row" data-group="${group.key}" data-index="${index}"><span class="asset-icon" id="icon-${group.key}-${index}">${item.raw.image_url ? `<img src="${esc(item.raw.image_url)}" alt="">` : esc(item.symbol.slice(0, 1))}</span><span><b data-preserve-case>${esc(item.symbol)}</b><small>${status.settings.hideBalances ? "\u2022\u2022\u2022\u2022\u2022\u2022" : esc(item.balance)}</small></span><i>\u203A</i></button>`).join("")}</div></details>`
  ).join("") : '<div class="empty">No assets or names found.</div>';
  for (const group of groups)
    document.querySelectorAll(`[data-group="${group.key}"]`).forEach(
      (button) => button.onclick = () => assetDetail(group.items[Number(button.dataset.index)])
    );
  const tokens = groups.find((group) => group.key === "krc20")?.items ?? [];
  tokens.forEach(
    (item, index) => void command("tokenMarket", {
      tokenId: item.raw.token_id ?? `krc20-${item.symbol.toLowerCase()}`,
      symbol: item.symbol
    }).then((market) => {
      item.market = market;
      const icon = document.querySelector(
        `#icon-krc20-${index}`
      );
      if (icon && market.imageUrl)
        icon.innerHTML = `<img src="${esc(market.imageUrl)}" alt="">`;
    }).catch(() => void 0)
  );
}
function assetDetail(asset) {
  if (asset.kind === "krc721") return nftGallery(asset);
  if (asset.kind === "kcc20" && asset.raw?.standard === "kron-native")
    return kronDetail(asset);
  if (asset.kind !== "krc20") return send(asset);
  shell(
    `<section class="token-detail"><div id="token-image" class="token-logo">${esc(asset.symbol.slice(0, 2))}</div><h1>${esc(asset.symbol)}</h1><p>${esc(asset.balance)} ${esc(asset.symbol)}</p><div class="price-grid"><div><small>Floor price</small><b id="floor-kas">Loading\u2026</b><span id="floor-usd"></span></div><div><small>Balance value</small><b id="value-kas">Loading\u2026</b><span id="value-usd"></span></div></div><button id="send-token">SEND ASSET</button><button id="explorer" class="outline">CHECK ON EXPLORER</button><p id="market-error" class="error"></p></section>`,
    "TOKEN DETAILS",
    true
  );
  document.querySelector("#send-token").onclick = () => send(asset);
  const apply = (market) => {
    const balance = Number(asset.balance.replaceAll(",", ""));
    document.querySelector("#floor-kas").textContent = market.priceKas == null ? "\u2014" : `${fmt(market.priceKas)} KAS`;
    document.querySelector("#floor-usd").textContent = market.priceUsd == null ? "\u2014" : `$${fmt(market.priceUsd)}`;
    document.querySelector("#value-kas").textContent = market.priceKas == null ? "\u2014" : `${fmt(market.priceKas * balance)} KAS`;
    document.querySelector("#value-usd").textContent = market.priceUsd == null ? "\u2014" : `$${fmt(market.priceUsd * balance)}`;
    if (market.imageUrl)
      document.querySelector("#token-image").innerHTML = `<img src="${esc(market.imageUrl)}" alt="">`;
    document.querySelector("#explorer").onclick = () => chrome.tabs.create({ url: market.explorerUrl });
  };
  if (asset.market) apply(asset.market);
  else
    void command("tokenMarket", {
      tokenId: asset.raw.token_id ?? `krc20-${asset.symbol.toLowerCase()}`,
      symbol: asset.symbol
    }).then(apply).catch((error) => {
      document.querySelector("#floor-kas").textContent = "\u2014";
      document.querySelector("#value-kas").textContent = "\u2014";
      document.querySelector("#market-error").textContent = error.message;
    });
}
function kronDetail(asset) {
  const image = asset.raw?.image_url ? `<img src="${esc(asset.raw.image_url)}" alt="">` : esc(asset.symbol.slice(0, 2));
  shell(
    `<section class="token-detail"><div class="token-logo">${image}</div><h1>${esc(asset.symbol)}</h1><p>${esc(asset.raw?.name ?? "KRON Native token")}</p><strong>${esc(asset.balance)} ${esc(asset.symbol)}</strong><div class="review-card"><div><span>Standard</span><b>KRON Native KCC20</b></div><div><span>Verification</span><b>Template verified</b></div><div><span>Covenant ID</span><b class="wrap-id">${esc(asset.raw.covenantId)}</b></div></div><button id="send-kron">Send asset</button><button id="kcc-explorer" class="outline">Check on KCC20 Explorer</button><p class="hint">The KRON covenant transaction is built locally, reviewed by Kaspire and signed only after your approval.</p></section>`,
    "TOKEN DETAILS",
    true
  );
  document.querySelector("#send-kron").onclick = () => send(asset);
  document.querySelector("#kcc-explorer").onclick = () => chrome.tabs.create({ url: asset.raw.explorerUrl });
}
async function nftGallery(asset) {
  shell(
    `<section class="nft-screen"><p class="eyebrow">KRC-721 COLLECTION</p><h1>${esc(asset.symbol)} NFTs</h1><p id="nft-count" class="muted">Loading held token IDs\u2026</p><div id="nft-grid" class="nft-grid"><div class="loading">Loading gallery\u2026</div></div><button id="load-more" hidden>LOAD MORE</button></section>`,
    `${asset.symbol} NFTs`,
    true
  );
  let offset = 0;
  const load = async (more = false) => {
    try {
      const page = await command("nftCollection", {
        ticker: asset.symbol,
        offset
      });
      if (!document.querySelector("#nft-grid")) return;
      document.querySelector("#nft-count").textContent = `${page.total} NFTs held`;
      const html = page.nfts.map(
        (nft, index) => `<button class="nft-card" data-nft='${esc(JSON.stringify(nft))}'><span>${nft.imageUrl ? `<img src="${esc(nft.imageUrl)}" alt="${esc(nft.ticker)} #${esc(nft.tokenId)}">` : "<b>NO IMAGE</b>"}</span><b>#${esc(nft.tokenId)}</b><small>${nft.rarityRank == null ? "RANK \u2014" : `RANK #${nft.rarityRank}`}</small></button>`
      ).join("");
      if (more)
        document.querySelector("#nft-grid").insertAdjacentHTML("beforeend", html);
      else
        document.querySelector("#nft-grid").innerHTML = html || '<div class="empty">No NFTs returned.</div>';
      document.querySelectorAll(".nft-card").forEach(
        (button) => button.onclick = () => nftPreview(JSON.parse(button.dataset.nft ?? "{}"), asset)
      );
      const loadMore = document.querySelector("#load-more");
      loadMore.hidden = page.nextOffset == null;
      if (page.nextOffset != null) {
        offset = page.nextOffset;
        loadMore.onclick = () => void load(true);
      }
    } catch (error) {
      document.querySelector("#nft-grid").innerHTML = `<p class="error">${esc(error.message)}</p>`;
    }
  };
  await load();
}
function send(asset) {
  let sendAllNative = false;
  const owned = asset.kind === "krc20" ? snapshot?.assets?.tokens ?? [] : asset.kind === "krc721" ? [asset.raw] : asset.kind === "kns" ? snapshot?.assets?.domains ?? [] : asset.kind === "kcc20" ? snapshot?.assets?.kcc20 ?? [] : [];
  shell(
    `<section class="send-screen"><p class="eyebrow">SEND</p><h1>${asset.kind === "kas" ? "Send KAS" : `Send <span data-preserve-case>${esc(ticker(asset.symbol ?? asset.kind))}</span>`}</h1><div class="form">${asset.kind !== "kas" ? `<label>Asset<select id="asset-select" data-preserve-case>${owned.map((item, index) => `<option value="${index}" ${item === asset.raw || item.symbol === asset.raw?.symbol ? "selected" : ""}>${esc(asset.kind === "kns" ? item.name : ticker(item.symbol))}${asset.tokenId ? ` #${esc(asset.tokenId)}` : ""}</option>`).join("")}</select></label>` : ""}<label>Address / KNS name<div class="recipient-input"><input id="recipient" autocomplete="off"><button id="choose-recipient" type="button" title="Address book">\u2659</button></div></label>${asset.kind === "krc721" ? `<label>Token ID<input id="token-id" value="${esc(asset.tokenId ?? asset.raw?.tokenId ?? "")}" readonly></label>` : ""}${["kas", "krc20", "kcc20"].includes(asset.kind) ? `<label>Amount<div class="amount"><input id="amount" inputmode="decimal" placeholder="0.00"><button id="max" type="button">MAX</button></div></label><small class="available">Available: ${esc(asset.balance ?? (snapshot ? `${fmt(snapshot.balanceKas)} KAS` : "\u2014"))}</small>` : ""}<section class="tx-meta"><span>Network</span><b>${status.network === "mainnet" ? "Kaspa Mainnet" : "Kaspa TN10"}</b><span>Fee</span><b>Live node estimate</b><span>Signer</span><b>Rusty Kaspa v2.0.1</b></section><button id="review">REVIEW TRANSFER</button><p id="error" class="error"></p></div></section>`,
    "Send",
    true
  );
  const amount = document.querySelector("#amount");
  if (amount)
    amount.oninput = () => {
      sendAllNative = false;
      amount.value = amount.value.replace(",", ".").replace(/[^\d.]/g, "").match(/^\d*(?:\.\d{0,8})?/)?.[0] ?? "";
    };
  document.querySelector("#max")?.addEventListener("click", () => {
    if (amount)
      amount.value = (asset.kind === "kas" ? String(snapshot?.balanceKas ?? 0) : String(asset.balance ?? 0)).replaceAll(",", "");
    if (asset.kind === "kas") sendAllNative = true;
  });
  document.querySelector("#choose-recipient").onclick = () => recipientPicker();
  document.querySelector("#review").onclick = async () => {
    const reviewButton = document.querySelector("#review");
    reviewButton.disabled = true;
    reviewButton.textContent = "Preparing secure review\u2026";
    try {
      const recipient = value("recipient");
      if (asset.kind === "kas") {
        const input = value("amount");
        if (!/^\d+(\.\d{1,8})?$/.test(input))
          throw new Error("Enter a valid amount.");
        const [whole, fraction = ""] = input.split(".");
        const result = await command("sendKas", {
          recipient,
          amountSompi: Number(`${whole}${fraction.padEnd(8, "0")}`),
          sendAll: sendAllNative
        });
        kaspaTransactionReceipt(result, {
          kind: "kas",
          recipient,
          amount: sendAllNative && result?.amountSompi != null ? String(Number(result.amountSompi) / 1e8) : input,
          symbol: "KAS"
        });
        return;
      }
      const selected = owned[Number(value("asset-select"))] ?? asset.raw;
      const displayAmount = value("amount");
      let amountValue = displayAmount;
      if (["krc20", "kcc20"].includes(asset.kind))
        amountValue = rawAmount(displayAmount, Number(selected.decimals ?? 8));
      const prepared = await persistentCommand("prepareAsset", {
        kind: asset.kind,
        to: recipient,
        ticker: selected.symbol ?? asset.symbol,
        amount: amountValue,
        displayAmount,
        tokenId: value("token-id"),
        assetId: selected.asset_id,
        covenantId: selected.covenantId
      });
      assetTransferReview(prepared);
    } catch (error) {
      const label = document.querySelector("#error");
      if (label) label.textContent = error.message;
      reviewButton.disabled = false;
      reviewButton.textContent = "Review transfer";
    }
  };
}
function assetTransferReview(prepared) {
  const operation = prepared.operation, review = prepared.review;
  const row = (label, value2) => `<div class="detail-row"><span>${esc(label)}</span><b ${label === "Ticker" ? "data-preserve-case" : ""}>${esc(value2)}</b></div>`;
  if (prepared.type === "kron") review.feeSompi = review.networkFeeSompi;
  const kcc = prepared.type === "kcc20" || prepared.type === "kron" ? `${row("Validation", prepared.type === "kron" ? "KRON template verified" : "Indexer verified")}${row("Covenant ID", review.covenantId ?? operation.covenantId)}${review.templateHash ? row("Template hash", review.templateHash) : ""}${row("Covenant inputs", fmt(review.covenantInputCount, 0))}${row("Covenant outputs", fmt(review.covenantOutputCount, 0))}${row("KAS in token inputs", sompiLabel(review.lockedKasSompi))}${Number(review.lockedKasTopUpSompi) ? row("KAS reserve top-up", sompiLabel(review.lockedKasTopUpSompi)) : ""}${Number(review.lockedKasReleasedSompi) ? row("KAS returned to wallet", sompiLabel(review.lockedKasReleasedSompi)) : ""}${row("KAS in new token cells", sompiLabel(review.lockedKasOutputSompi))}${row("Effective mass", fmt(review.mass, 0))}${row("Compute mass", fmt(review.computeMass, 0))}${review.storageMass != null ? row("Storage mass (normalized)", fmt(review.storageMass, 0)) : ""}${review.storageMassTarget != null ? row("Safe storage target", fmt(review.storageMassTarget, 0)) : ""}${row("Transient mass (normalized)", fmt(review.transientMass, 0))}${row("Fee mass", fmt(review.feeMass, 0))}${row("Compute budget", fmt(review.computeBudget, 0))}` : "";
  const raw = review.rawJson ?? prepared.request ?? {};
  shell(
    `<section class="transaction-detail"><p class="eyebrow">Review asset transfer</p><h1>Verify every detail</h1><section class="detail-section">${row("Protocol", String(operation.kind).toUpperCase())}${row("Recipient", operation.recipient)}${operation.ticker ? row("Ticker", ticker(operation.ticker)) : ""}${operation.amount ? row("Raw amount", operation.amount) : ""}${operation.displayAmount ? row("Amount", `${operation.displayAmount} ${ticker(operation.ticker)}`) : ""}${operation.tokenId ? row("Token ID", operation.tokenId) : ""}${kcc}${prepared.type === "inscription" ? row("Temporary commit", `${sompiLabel(review.amountSompi)}`) : ""}${row("Network fee", sompiLabel(review.feeSompi))}</section>${prepared.type === "inscription" ? '<p class="muted">The 0.3 KAS commit returns to this wallet through the reveal transaction, minus network fees. A committed transfer can be resumed.</p>' : Number(review.lockedKasTopUpSompi) ? '<p class="reserve-note">The reserve top-up adds only the KAS needed to keep the new token cells spendable. It is not a network fee.</p>' : ""}${Number(review.lockedKasReleasedSompi) ? '<p class="return-note">Excess KAS from consumed token cells returns as normal wallet change.</p>' : ""}<details class="raw-json"><summary>Raw JSON output</summary><pre>${esc(JSON.stringify(raw, null, 2))}</pre></details><button id="confirm-asset">Authorize ${prepared.type === "inscription" ? "commit + reveal" : "on-chain transfer"}</button><button id="cancel-asset" class="outline">Cancel</button><p id="review-error" class="error"></p></section>`,
    "Review asset transfer",
    true
  );
  document.querySelector("#cancel-asset").onclick = () => {
    view = "home";
    void render();
  };
  document.querySelector("#confirm-asset").onclick = async () => {
    const button = document.querySelector("#confirm-asset");
    button.disabled = true;
    button.textContent = "Authorizing\u2026";
    try {
      const result = await command("confirmPreparedAsset", {
        preparedId: prepared.preparedId
      });
      kaspaTransactionReceipt(result, {
        kind: operation.kind,
        recipient: operation.recipient,
        amount: operation.displayAmount,
        symbol: ticker(operation.ticker) || String(operation.kind).toUpperCase()
      });
    } catch (error) {
      document.querySelector("#review-error").textContent = error.message;
      button.disabled = false;
      button.textContent = "Authorize commit + reveal";
    }
  };
}
function recipientPicker() {
  const overlay = document.createElement("div");
  overlay.className = "kaspire-modal";
  const own = status.addresses.map((item) => ({
    ...item,
    detail: item.watchOnly ? "Watch wallet" : item.path
  }));
  overlay.innerHTML = `<section class="recipient-sheet"><div class="sheet-title"><h2>Address book</h2><button id="close-picker" class="icon">\xD7</button></div><label class="allowlist"><span><b>Only allow saved recipients</b><small>${status.settings.recipientAllowlist ? "Enabled" : "Disabled"}</small></span></label><h3>CONTACTS</h3>${status.contacts.map((item) => `<button class="recipient-row" data-address="${esc(item.address)}"><span>\u2659</span><span><b>${esc(item.name)}</b><small>${short(item.address)}</small></span></button>`).join("") || '<p class="muted">No saved contacts.</p>'}<h3>MY WALLETS</h3>${own.map((item) => `<button class="recipient-row" data-address="${esc(item.address)}"><span>\u25A3</span><span><b>${esc(item.name)}</b><small>${esc(item.detail)} \xB7 ${short(item.address)}</small></span></button>`).join("")}</section>`;
  document.body.append(overlay);
  overlay.querySelector("#close-picker").onclick = () => overlay.remove();
  overlay.querySelectorAll("[data-address]").forEach(
    (button) => button.onclick = () => {
      document.querySelector("#recipient").value = button.dataset.address ?? "";
      overlay.remove();
    }
  );
}
function sompiLabel(value2) {
  if (value2 == null) return "\u2014";
  const digits = BigInt(String(value2)).toString().padStart(9, "0");
  const fraction = digits.slice(-8).replace(/0+$/g, "");
  return `${digits.slice(0, -8)}${fraction ? `.${fraction}` : ""} KAS`;
}
function prettyJson(value2) {
  return JSON.stringify(
    value2,
    (_key, nested) => typeof nested === "bigint" ? nested.toString() : nested,
    2
  );
}
async function activity() {
  shell(
    '<section class="activity"><p class="eyebrow">Activity</p><h1>Transactions</h1><div id="history"><div class="loading">Loading activity\u2026</div></div></section>',
    "Activity",
    true
  );
  try {
    const rows = await command("history");
    if (!document.querySelector("#history")) return;
    document.querySelector("#history").innerHTML = rows.length ? rows.map((item, index) => {
      if (isL2()) {
        const own = String(snapshot?.address ?? "").toLowerCase();
        item.incoming = String(item.to ?? "").toLowerCase() === own;
        item.isAccepted = item.status !== "error";
        item.assetKind = item.symbol;
        item.assetSymbol = item.symbol;
        item.displayAmount = item.amount;
        item.counterparty = item.incoming ? item.from : item.to;
        item.from = [{ address: item.from }];
        item.to = [{ address: item.to }];
      }
      const direction = item.incoming ? "Received" : "Sent";
      const amount = !isL2() && item.assetKind === "KAS" ? sompiLabel(item.amountSompi) : `${item.displayAmount ? `${esc(item.displayAmount)} ` : ""}${esc(item.assetSymbol ?? item.assetKind)}${item.tokenId ? ` #${esc(item.tokenId)}` : ""}`;
      return `<button class="activity-row" data-tx="${index}"><span class="activity-direction ${item.incoming ? "incoming" : "outgoing"}">${item.incoming ? "\u2199" : "\u2197"}</span><span><b>${direction}</b><small>${esc(item.assetKind)}${item.assetSymbol && item.assetSymbol !== item.assetKind ? ` \xB7 ${esc(item.assetSymbol)}` : ""}</small><em>${item.blockTime ? new Date(item.blockTime).toLocaleString() : "Pending"} \xB7 ${short(item.transactionId)}</em>${item.counterparty ? `<em>${item.incoming ? "From" : "To"} ${short(item.counterparty)}</em>` : ""}</span><strong>${status.settings.hideBalances ? "\u2022\u2022\u2022\u2022\u2022\u2022" : `${item.incoming ? "+" : "-"}${amount}`}</strong><i>\u203A</i></button>`;
    }).join("") : '<div class="empty">No transactions yet.</div>';
    document.querySelectorAll("[data-tx]").forEach(
      (button) => button.onclick = () => transactionDetail(rows[Number(button.dataset.tx)])
    );
  } catch (error) {
    document.querySelector("#history").innerHTML = `<p class="error">${esc(error.message)}</p>`;
  }
}
function sendEvm(token) {
  let sendAllNative = false;
  const symbol = token?.symbol ?? (status.network === "igra" ? "iKAS" : "KAS");
  shell(`<section class="send-screen"><p class="eyebrow">SEND</p><h1>Send <span data-preserve-case>${esc(symbol)}</span></h1><div class="form"><label>Address<div class="recipient-input"><input id="recipient" autocomplete="off"><button id="choose-recipient" type="button" title="Address book">\u2659</button></div></label><label>Amount<div class="amount"><input id="amount" inputmode="decimal" placeholder="0.00"><button id="max" type="button">MAX</button></div></label><small class="available">Available: ${esc(token?.balance ?? snapshot?.balance ?? "\u2014")} ${esc(symbol)}</small><section class="tx-meta"><span>Network</span><b>${networkLabel()}</b><span>Fee</span><b>Live RPC estimate</b><span>Signer</span><b>Native Rust security core</b></section><button id="review">REVIEW TRANSFER</button><p id="error" class="error"></p></div></section>`, "Send", true);
  const amount = document.querySelector("#amount");
  amount.oninput = () => {
    sendAllNative = false;
    const decimals = Number(token?.decimals ?? 18);
    amount.value = amount.value.replace(",", ".").replace(/[^\d.]/g, "").match(new RegExp(`^\\d*(?:\\.\\d{0,${decimals}})?`))?.[0] ?? "";
  };
  document.querySelector("#max").onclick = () => {
    amount.value = String(token?.balance ?? snapshot?.balance ?? "0").replaceAll(",", "");
    sendAllNative = !token;
  };
  document.querySelector("#choose-recipient").onclick = () => recipientPicker();
  document.querySelector("#review").onclick = async () => {
    const error = document.querySelector("#error"), button = document.querySelector("#review");
    try {
      button.disabled = true;
      button.textContent = "Preparing secure review\u2026";
      const prepared = await command("prepareEvmTransfer", { recipient: value("recipient"), amount: value("amount"), token, sendAll: sendAllNative });
      const approved = await evmReview(prepared);
      if (!approved) return;
      button.textContent = "Signing and broadcasting\u2026";
      const result = await command("submitEvmTransfer", { id: prepared.id });
      transactionReceipt(result, symbol, prepared.review.displayAmount);
    } catch (reason) {
      error.textContent = reason.message;
    } finally {
      button.disabled = false;
      button.textContent = "Review transfer";
    }
  };
}
function evmReview(prepared) {
  return new Promise((resolve) => {
    const overlay = document.createElement("div");
    overlay.className = "kaspire-modal approval-modal";
    overlay.innerHTML = `<section class="approval-sheet"><p class="eyebrow">SECURE REVIEW</p><h1>Review Layer 2 transfer</h1><div class="approval-details"><p>Network: ${esc(prepared.review.network)}</p><p>Recipient: ${esc(prepared.review.recipient)}</p><p>Amount: ${esc(prepared.review.displayAmount)} ${esc(prepared.review.tokenSymbol)}</p><p>Network fee: ${esc(prepared.fee)} ${esc(prepared.nativeSymbol)}</p></div><details class="raw-json"><summary>Raw JSON output</summary><pre>${esc(prettyJson(prepared.rawJson))}</pre></details><div class="approval-actions"><button id="cancel-evm" class="outline">Cancel</button><button id="approve-evm">Approve</button></div></section>`;
    document.body.append(overlay);
    overlay.querySelector("#cancel-evm").onclick = () => {
      overlay.remove();
      resolve(false);
    };
    overlay.querySelector("#approve-evm").onclick = () => {
      overlay.remove();
      resolve(true);
    };
  });
}
function transactionReceipt(result, symbol, amount) {
  shell(`<section class="transaction-detail"><header class="tx-detail-head"><span class="activity-direction outgoing">\u2713</span><span><h1>Transaction sent</h1><b>${esc(amount)} ${esc(symbol)}</b></span></header><section class="detail-section"><h3>Network</h3>${detailRow("Network", networkLabel())}${detailRow("Status", "Confirmed")}</section><section class="copy-detail"><label>Transaction ID</label><code>${esc(result.transactionId)}</code><button id="copy-detail">Copy transaction ID</button></section><details class="raw-json"><summary>Raw JSON output</summary><pre>${esc(prettyJson(result))}</pre></details><button id="done">Done</button></section>`, "Transaction details", true);
  document.querySelector("#copy-detail").onclick = () => copy(result.transactionId, "Transaction ID copied");
  document.querySelector("#done").onclick = () => {
    view = "home";
    void render();
  };
}
function transactionDetail(item) {
  context.returnView = "activity";
  const direction = item.incoming ? "Received" : "Sent", amount = item.assetKind === "KAS" ? sompiLabel(item.amountSompi) : `${item.displayAmount ?? ""} ${item.assetSymbol ?? item.assetKind}${item.tokenId && item.assetKind !== "KCC20" ? ` #${item.tokenId}` : ""}`;
  const parties = (title, rows) => `<section class="detail-section"><h3>${title}</h3>${rows?.length ? rows.map((row) => `<div class="party"><code>${esc(row.address)}</code>${row.amountSompi != null ? `<b>${sompiLabel(row.amountSompi)}</b>` : ""}${row.ownerId ? `<small>Owner / Covenant: <span>${esc(row.ownerId)}</span></small>` : ""}</div>`).join("") : "<p>Not available</p>"}</section>`;
  const kcc = item.assetKind === "KCC20" && item.covenantId ? `<section class="detail-section"><h3>KCC20 covenant</h3>${detailRow("Covenant ID", item.covenantId)}${item.templateHash ? detailRow("Template hash", item.templateHash) : ""}${item.inputCount != null ? detailRow("Covenant inputs", fmt(item.inputCount, 0)) : ""}${item.outputCount != null ? detailRow("Covenant outputs", fmt(item.outputCount, 0)) : ""}${item.lockedKasSompi != null ? detailRow("KAS in token inputs", sompiLabel(item.lockedKasSompi)) : ""}${Number(item.lockedKasTopUpSompi) ? detailRow("KAS reserve top-up", sompiLabel(item.lockedKasTopUpSompi)) : ""}${Number(item.lockedKasReleasedSompi) ? detailRow("KAS returned to wallet", sompiLabel(item.lockedKasReleasedSompi)) : ""}${item.lockedKasOutputSompi != null ? detailRow("KAS in new token cells", sompiLabel(item.lockedKasOutputSompi)) : ""}${item.computeMass != null ? detailRow("Compute mass", fmt(item.computeMass, 0)) : ""}${item.storageMass != null ? detailRow("Storage mass", fmt(item.storageMass, 0)) : ""}${item.transientMass != null ? detailRow("Transient mass", fmt(item.transientMass, 0)) : ""}${item.feeMass != null ? detailRow("Fee mass", fmt(item.feeMass, 0)) : ""}</section>${Number(item.lockedKasTopUpSompi) ? '<p class="reserve-note">The reserve top-up adds only the KAS needed to keep the new token cells spendable. It is not a network fee.</p>' : ""}` : "";
  const rawJson = item.rawJson ?? {
    transactionId: item.transactionId,
    assetKind: item.assetKind,
    inputs: item.inputs ?? item.from ?? [],
    outputs: item.outputs ?? item.to ?? [],
    payload: item.payload ?? "",
    feeSompi: item.feeSompi,
    mass: item.mass
  };
  const rawOutput = `<details class="raw-json"><summary>Raw JSON output</summary><pre>${esc(prettyJson(rawJson))}</pre></details>`;
  shell(
    `<section class="transaction-detail"><header class="tx-detail-head"><span class="activity-direction ${item.incoming ? "incoming" : "outgoing"}">${item.incoming ? "\u2199" : "\u2197"}</span><span><h1>${direction}</h1><b>${status.settings.hideBalances ? "\u2022\u2022\u2022\u2022\u2022\u2022" : `${item.incoming ? "+" : "-"}${esc(amount)}`}</b></span></header><section class="detail-section"><h3>Transfer</h3>${detailRow("Direction", direction)}${detailRow("Asset", `${item.assetKind}${item.assetSymbol && item.assetSymbol !== item.assetKind ? ` \xB7 ${item.assetSymbol}` : ""}`)}${detailRow("Amount", amount)}${detailRow("Status", item.isAccepted ? "Confirmed" : "Pending")}${detailRow("Date", item.blockTime ? new Date(item.blockTime).toLocaleString() : "Pending")}</section>${parties("From", item.from)}${parties("To", item.to)}${kcc}<section class="detail-section"><h3>Network</h3>${item.feeSompi != null ? detailRow("Fee", sompiLabel(item.feeSompi)) : ""}${item.totalInputSompi != null ? detailRow("Total inputs", sompiLabel(item.totalInputSompi)) : ""}${item.totalOutputSompi != null ? detailRow("Total outputs", sompiLabel(item.totalOutputSompi)) : ""}${item.inputCount != null ? detailRow("Inputs", item.inputCount) : ""}${item.outputCount != null ? detailRow("Outputs", item.outputCount) : ""}${item.mass != null ? detailRow("Effective mass", fmt(item.mass, 0)) : ""}${item.blockDaaScore ? detailRow("Block DAA score", item.blockDaaScore) : ""}${detailRow("Coinbase", item.isCoinbase ? "Yes" : "No")}</section><section class="copy-detail"><label>Transaction ID</label><code>${esc(item.transactionId)}</code><button id="copy-detail">Copy transaction ID</button></section>${item.tokenId ? `<section class="copy-detail"><label>Token / Asset ID</label><code>${esc(item.tokenId)}</code></section>` : ""}</section>`,
    "Transaction details",
    true
  );
  document.querySelector(".transaction-detail").insertAdjacentHTML("beforeend", rawOutput);
  document.querySelector("#copy-detail").onclick = () => copy(item.transactionId, "Transaction ID copied");
}
function detailRow(label, value2) {
  return `<div class="detail-row"><span>${esc(label)}</span><b>${esc(value2)}</b></div>`;
}
async function command(name, values = {}) {
  const guarded = [
    "sendKas",
    "sendAsset",
    "confirmPreparedAsset",
    "compound",
    "resumeInscription",
    "exportSecret",
    "submitEvmTransfer"
  ].includes(name);
  return guarded ? withInAppApprovals(persistentCommand(name, values)) : rawCommand(name, values);
}
async function withInAppApprovals(task) {
  let settled = false, result, failure;
  void task.then((value2) => {
    result = value2;
    settled = true;
  }).catch((error) => {
    failure = error;
    settled = true;
  });
  while (!settled) {
    const pending = await rawCommand("pendingApproval");
    if (pending) {
      const approved = await approvalModal(pending);
      await rawCommand("resolveWalletApproval", { id: pending.id, approved });
    } else await new Promise((resolve) => setTimeout(resolve, 80));
  }
  if (failure) throw failure;
  return result;
}
function approvalModal(item) {
  return new Promise((resolve) => {
    const overlay = document.createElement("div");
    overlay.className = "kaspire-modal approval-modal";
    overlay.innerHTML = `<section class="approval-sheet"><p class="eyebrow">SECURE APPROVAL</p><h1>${esc(item.title)}</h1><h2>${esc(item.origin)}</h2><p>${esc(item.description)}</p><div class="approval-details">${item.details.map((detail) => `<p>${esc(detail)}</p>`).join("")}</div>${item.rawJson != null ? `<details class="raw-json"><summary>Raw JSON output</summary><pre>${esc(prettyJson(item.rawJson))}</pre></details>` : ""}<div class="approval-actions"><button id="reject-approval" class="outline">REJECT</button><button id="accept-approval">APPROVE</button></div><small>Verify every detail. Kaspire never signs silently.</small></section>`;
    document.body.append(overlay);
    const finish = (approved) => {
      overlay.remove();
      resolve(approved);
    };
    overlay.querySelector("#reject-approval").onclick = () => finish(false);
    overlay.querySelector("#accept-approval").onclick = () => finish(true);
  });
}
function kaspaTransactionReceipt(result, details) {
  const ids = typeof result === "string" ? [result] : [
    result?.commitTransactionId,
    result?.revealTransactionId,
    result?.transactionId
  ].filter(Boolean);
  shell(
    `<section class="receipt-screen"><div class="receipt-check">\u2713</div><p class="eyebrow">TRANSACTION CONFIRMED</p><h1>Transaction sent</h1><div class="receipt-details"><span>Asset</span><b>${esc(details.symbol ?? details.kind?.toUpperCase())}</b>${details.amount ? `<span>Amount</span><b>${esc(details.amount)}</b>` : ""}<span>Recipient</span><code>${esc(details.recipient ?? status.selectedAddress)}</code>${ids.map((id, index) => `<span>${ids.length > 1 ? index === 0 ? "Commit transaction" : "Reveal transaction" : "Transaction ID"}</span><code>${esc(id)}</code><button class="mini receipt-copy" data-id="${esc(id)}">COPY TX ID</button>`).join("")}</div><button id="close-receipt">CLOSE</button></section>`,
    "RECEIPT"
  );
  document.querySelectorAll(".receipt-copy").forEach(
    (button) => button.onclick = () => copy(button.dataset.id ?? "", "Transaction ID copied")
  );
  document.querySelector("#close-receipt").onclick = () => {
    view = "home";
    void render();
  };
}
function addCompound(core) {
  if (core.utxoCount < 2 || !document.querySelector(".balance-card") || document.querySelector("#compound"))
    return;
  const button = document.createElement("button");
  button.id = "compound";
  button.className = "compound outline";
  button.textContent = `COMPOUND ${core.utxoCount} UTXOS`;
  button.onclick = async () => {
    try {
      const result = await command("compound");
      kaspaTransactionReceipt(result, {
        kind: "compound",
        symbol: "KAS UTXO COMPOUND",
        recipient: status.selectedAddress
      });
    } catch (error) {
      toast(error.message, true);
    }
  };
  document.querySelector(".balance-card").append(button);
}
function nftPreview(nft, asset) {
  const overlay = document.createElement("div");
  overlay.className = "kaspire-modal";
  overlay.innerHTML = `<section class="nft-preview">${nft.imageUrl ? `<img src="${esc(nft.imageUrl)}" alt="">` : ""}<h2>${esc(nft.ticker)} #${esc(nft.tokenId)}</h2><p id="nft-rarity">Loading rarity rank\u2026</p><div><button id="close-nft" class="outline">CLOSE</button><button id="send-nft">SEND NFT</button></div></section>`;
  document.body.append(overlay);
  overlay.querySelector("#close-nft").onclick = () => overlay.remove();
  overlay.querySelector("#send-nft").onclick = () => {
    overlay.remove();
    send({
      ...asset,
      raw: { ...asset.raw, tokenId: nft.tokenId },
      tokenId: nft.tokenId
    });
  };
  void command("nftRarity", { ticker: nft.ticker, tokenId: nft.tokenId }).then((value2) => {
    const label = overlay.querySelector("#nft-rarity");
    if (label)
      label.textContent = value2.rarityRank == null ? "Rarity rank unavailable" : `Rarity rank #${value2.rarityRank}`;
  }).catch(() => {
    const label = overlay.querySelector("#nft-rarity");
    if (label) label.textContent = "Rarity rank unavailable";
  });
}
function onboarding() {
  shell(
    `<section class="first-run"><div class="first-brand"><img src="kaspire-icon.png" alt=""><b>KASPIRE</b></div><h1>YOUR KASPA.<br>YOUR CONTROL.</h1><p>The Kaspa wallet that makes no compromises. Fully open source and secure.</p><div class="first-actions"><button id="first-create">\uFF0B CREATE 24-WORD WALLET</button><button id="first-seed" class="outline">\u25C6 IMPORT 12 / 24 WORDS</button><button id="first-key" class="outline">\u25A3 IMPORT PRIVATE KEY</button></div><div class="watch-divider"><span></span><b>OR WATCH ONLY</b><span></span></div><div class="form"><label>Watch a Kaspa address or KNS domain<input id="first-watch-address" placeholder="kaspa:q\u2026 or name.kas"></label><label>Wallet name<input id="first-watch-name" value="Watch wallet"></label><label>Vault password<input id="first-watch-password" type="password" minlength="12"></label><label>Confirm password<input id="first-watch-confirm" type="password" minlength="12"></label><button id="first-watch">WATCH WALLET</button><p id="first-error" class="error"></p></div></section>`
  );
  document.querySelector("#first-create").onclick = () => legacyOnboarding("create");
  document.querySelector("#first-seed").onclick = () => legacyOnboarding("seed");
  document.querySelector("#first-key").onclick = () => legacyOnboarding("key");
  document.querySelector("#first-watch").onclick = async () => {
    try {
      const password = value("first-watch-password");
      if (password !== value("first-watch-confirm"))
        throw new Error("Passwords do not match.");
      await command("createWatch", {
        address: value("first-watch-address"),
        name: value("first-watch-name"),
        password
      });
      view = "home";
      await render();
    } catch (error) {
      document.querySelector("#first-error").textContent = error.message;
    }
  };
}
function go(next) {
  if (!context.returnView) context.returnView = view;
  view = next;
  void render();
}
var casingObserver = new MutationObserver((records) => {
  for (const record of records)
    for (const added of Array.from(record.addedNodes)) {
      if (added instanceof HTMLElement) classicCase(added);
      else if (added.parentElement) classicCase(added.parentElement);
    }
});
casingObserver.observe(document.body, { childList: true, subtree: true });
window.addEventListener("pagehide", () => {
  if (status?.settings?.autoLockMinutes === 0 && !status?.locked) {
    void chrome.runtime.sendMessage({ channel: "wallet", command: "lock" });
  }
});
void render();
//# sourceMappingURL=wallet.js.map
